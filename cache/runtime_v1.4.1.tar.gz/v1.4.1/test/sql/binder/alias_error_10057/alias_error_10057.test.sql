-- bwc_tag:nb_steps=2
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

with test_data as (
  select 'foo' as a
)
select test_data.foobar as new_column from test_data where new_column is not null;
-- bwc_tag:end_query

