-- bwc_tag:nb_steps=12
SET catalog_error_max_schemas = 0;
-- bwc_tag:end_query

ATTACH 'output/did_you_mean_db_0.db';
-- bwc_tag:end_query

ATTACH 'output/did_you_mean_db_1.db';
-- bwc_tag:end_query

ATTACH 'output/did_you_mean_db_2.db';
-- bwc_tag:end_query

ATTACH 'output/did_you_mean_db_3.db';
-- bwc_tag:end_query

ATTACH 'output/did_you_mean_db_4.db';
-- bwc_tag:end_query

ATTACH 'output/did_you_mean_db_5.db';
-- bwc_tag:end_query

ATTACH 'output/did_you_mean_db_6.db';
-- bwc_tag:end_query

ATTACH 'output/did_you_mean_db_7.db';
-- bwc_tag:end_query

ATTACH 'output/did_you_mean_db_8.db';
-- bwc_tag:end_query

ATTACH 'output/did_you_mean_db_9.db';
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

FROM tbl;
-- bwc_tag:end_query

