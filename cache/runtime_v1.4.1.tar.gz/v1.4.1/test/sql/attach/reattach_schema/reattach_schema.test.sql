-- bwc_tag:nb_steps=23
ATTACH 'output/reattach_schema.db' AS new_db;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA new_db.my_schema;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE new_db.my_schema.my_table(col INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO new_db.my_schema.my_table VALUES (42);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW new_db.my_schema.my_view AS SELECT 84
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE new_db.my_schema.my_sequence;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO new_db.my_schema.one() AS (SELECT 1);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO new_db.my_schema.range(a) as TABLE SELECT * FROM range(a)
-- bwc_tag:end_query

SELECT new_db.my_schema.one()
-- bwc_tag:end_query

SELECT * FROM new_db.my_schema.range(3)
-- bwc_tag:end_query

DETACH new_db
-- bwc_tag:end_query

ATTACH 'output/reattach_schema.db' AS new_name;
-- bwc_tag:end_query

SELECT * FROM new_name.my_schema.my_table
-- bwc_tag:end_query

SELECT * FROM new_name.my_schema.my_view
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('new_name.my_schema.my_sequence')
-- bwc_tag:end_query

SELECT new_name.my_schema.one()
-- bwc_tag:end_query

SELECT * FROM new_name.my_schema.range(3)
-- bwc_tag:end_query

USE new_name.my_schema
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

USE new_name.my_schema.my_table
-- bwc_tag:end_query

SELECT * FROM my_table
-- bwc_tag:end_query

SELECT * FROM my_view
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('my_sequence')
-- bwc_tag:end_query

SELECT one()
-- bwc_tag:end_query

