-- bwc_tag:nb_steps=20
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

ATTACH DATABASE ':memory:' AS db1;
-- bwc_tag:end_query

ATTACH DATABASE ':memory:' AS db2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE db1.table_in_db1(i int);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE db2.table_in_db2(i int);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA db2.test_schema;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE db2.test_schema.table_in_db2_test_schema(i int);
-- bwc_tag:end_query

SHOW TABLES
-- bwc_tag:end_query

USE DB1
-- bwc_tag:end_query

SHOW TABLES
-- bwc_tag:end_query

USE db1
-- bwc_tag:end_query

SHOW TABLES
-- bwc_tag:end_query

USE db2
-- bwc_tag:end_query

SHOW TABLES
-- bwc_tag:end_query

USE db2.test_schema;
-- bwc_tag:end_query

SHOW TABLES
-- bwc_tag:end_query

USE DB2.TEST_sChEmA;
-- bwc_tag:end_query

SHOW TABLES
-- bwc_tag:end_query

FROM table_in_db2
-- bwc_tag:end_query

FROM table_in_db2_test_schema
-- bwc_tag:end_query

