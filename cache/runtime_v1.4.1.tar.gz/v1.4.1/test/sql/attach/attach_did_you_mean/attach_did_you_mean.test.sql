-- bwc_tag:nb_steps=21
ATTACH DATABASE ':memory:' AS db1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE hello(i INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE db1.test(a INTEGER);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA db1.myschema
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE db1.myschema.blablabla(i INTEGER)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM blablabla;
-- bwc_tag:end_query

SET catalog_error_max_schemas=0
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM blablabla;
-- bwc_tag:end_query

RESET catalog_error_max_schemas
-- bwc_tag:end_query

USE db1
-- bwc_tag:end_query

SELECT * FROM test
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM blablabla
-- bwc_tag:end_query

SELECT * FROM myschema.blablabla
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM hello;
-- bwc_tag:end_query

SELECT * FROM memory.hello
-- bwc_tag:end_query

USE db1.myschema
-- bwc_tag:end_query

SELECT * FROM blablabla
-- bwc_tag:end_query

SELECT * FROM test;
-- bwc_tag:end_query

SELECT * FROM db1.main.test
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM hello;
-- bwc_tag:end_query

