-- bwc_tag:nb_steps=20
set storage_compatibility_version='latest';
-- bwc_tag:end_query

attach 'output/db1.db';
-- bwc_tag:end_query

use db1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE A (A1 INTEGER PRIMARY KEY,A2 VARCHAR, A3 INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE INDEX A_index ON A (A2);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE B(B1 INTEGER REFERENCES A(A1));
-- bwc_tag:end_query

attach 'output/db1_other.db';
-- bwc_tag:end_query

USE db1_other;
-- bwc_tag:end_query

detach db1;
-- bwc_tag:end_query

attach 'output/db1.db' as other_db;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA disable_checkpoint_on_shutdown
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA wal_autocheckpoint='1TB';
-- bwc_tag:end_query

attach 'output/db2.db';
-- bwc_tag:end_query

use db2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE A (A1 INTEGER PRIMARY KEY,A2 VARCHAR, A3 INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE INDEX A_index ON A (A2);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE B(B1 INTEGER REFERENCES A(A1));
-- bwc_tag:end_query

USE db1_other;
-- bwc_tag:end_query

detach db2;
-- bwc_tag:end_query

attach 'output/db2.db' as other_db2;
-- bwc_tag:end_query

