-- bwc_tag:nb_steps=7
attach ':memory:' as test;
-- bwc_tag:end_query

use test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create schema schema1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table schema1.table1 as select 1 as a;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

set schema='schema2';
-- bwc_tag:end_query

set schema='schema1';
-- bwc_tag:end_query

select * from table1;
-- bwc_tag:end_query

