-- bwc_tag:nb_steps=4
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

ATTACH 'output/constraint_test.db' as test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test.tbl(i INTEGER PRIMARY KEY);
-- bwc_tag:end_query

select constraint_catalog, table_catalog, table_name from information_schema.table_constraints limit 1
-- bwc_tag:end_query

