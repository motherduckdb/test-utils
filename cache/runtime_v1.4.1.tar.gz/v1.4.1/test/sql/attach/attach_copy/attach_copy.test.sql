-- bwc_tag:nb_steps=7
ATTACH DATABASE ':memory:' AS db1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE db1.test(a INTEGER, b INTEGER, c VARCHAR(10));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY db1.test FROM 'data/csv/test/test.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY db1.main.test FROM 'data/csv/test/test.csv';
-- bwc_tag:end_query

COPY db1.main.test TO 'output/test.csv';
-- bwc_tag:end_query

USE db1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY test FROM 'data/csv/test/test.csv';
-- bwc_tag:end_query

