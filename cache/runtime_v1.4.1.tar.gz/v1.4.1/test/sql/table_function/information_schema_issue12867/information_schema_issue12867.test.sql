-- bwc_tag:nb_steps=3
-- bwc_tag:execute_from_sql
CREATE TABLE a (a1 int, a2 int, PRIMARY KEY (a1, a2));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE b (a1 int, a2 int, FOREIGN KEY (a1, a2) REFERENCES a);
-- bwc_tag:end_query

SELECT table_name, column_name, ordinal_position FROM information_schema.key_column_usage ORDER BY table_name, ordinal_position;
-- bwc_tag:end_query

