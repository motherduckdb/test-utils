-- bwc_tag:nb_steps=9
SELECT * FROM repeat(0, 3)
-- bwc_tag:end_query

SELECT * FROM repeat(NULL, 2)
-- bwc_tag:end_query

SELECT * FROM repeat('hello', 2)
-- bwc_tag:end_query

SELECT * FROM repeat('thisisalongstring', 2)
-- bwc_tag:end_query

SELECT * FROM repeat(blob '\x00\x00hello', 2)
-- bwc_tag:end_query

SELECT * FROM repeat(1, 10000)
-- bwc_tag:end_query

SELECT * FROM repeat(DATE '1992-01-01', 2)
-- bwc_tag:end_query

SELECT * FROM repeat(INTERVAL '30 days', 2)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM repeat(INTERVAL '30 days', NULL)
-- bwc_tag:end_query

