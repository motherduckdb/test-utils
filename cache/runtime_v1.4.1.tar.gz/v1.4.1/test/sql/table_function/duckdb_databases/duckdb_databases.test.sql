-- bwc_tag:nb_steps=12
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

SELECT * FROM duckdb_databases();
-- bwc_tag:end_query

SELECT database_name, internal, readonly, path, type FROM duckdb_databases() ORDER BY database_name;
-- bwc_tag:end_query

ATTACH 'output/duckdb_databases.db' AS new_duckdb_database
-- bwc_tag:end_query

SELECT database_name, internal, split(replace(path, '\', '/'), '/')[-1], type FROM duckdb_databases() WHERE path IS NOT NULL;
-- bwc_tag:end_query

SELECT readonly FROM duckdb_databases WHERE database_name='new_duckdb_database';
-- bwc_tag:end_query

SELECT database_name FROM duckdb_databases ORDER BY database_name
-- bwc_tag:end_query

SHOW databases
-- bwc_tag:end_query

SELECT datname FROM pg_catalog.pg_database ORDER BY 1
-- bwc_tag:end_query

DETACH new_duckdb_database;
-- bwc_tag:end_query

ATTACH 'output/duckdb_databases.db' AS readonly_duckdb_database (READONLY 1);
-- bwc_tag:end_query

SELECT readonly FROM duckdb_databases WHERE database_name='readonly_duckdb_database';
-- bwc_tag:end_query

