-- bwc_tag:nb_steps=3
-- bwc_tag:load_db=convert_to_persistent

ATTACH 'output/convert_to_persistent.duckdb' AS convert_to_persistent;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table test as select range i from range(1_000_000);
-- bwc_tag:end_query

select memory_usage_bytes from duckdb_memory() where tag = 'IN_MEMORY_TABLE'
-- bwc_tag:end_query

