-- bwc_tag:nb_steps=22
SELECT d::DATE FROM range(DATE '1992-01-01', DATE '1992-10-01', INTERVAL (1) MONTH) tbl(d)
-- bwc_tag:end_query

SELECT * FROM range(date '1992-01-01', date '1992-01-01', interval '1' month);
-- bwc_tag:end_query

SELECT d::DATE FROM generate_series(DATE '1992-01-01', DATE '1992-10-01', INTERVAL (1) MONTH) tbl(d)
-- bwc_tag:end_query

SELECT d FROM range(TIMESTAMP '1992-01-01 00:00:00', TIMESTAMP '1992-01-01 12:00:00', INTERVAL (1) HOUR) tbl(d)
-- bwc_tag:end_query

SELECT * FROM range(timestamp '1992-01-01 00:00:00', timestamp '1992-01-01 00:00:00', interval '1' month);
-- bwc_tag:end_query

SELECT * FROM range(timestamp '1992-01-01 00:00:00', timestamp '1992-01-01 00:00:01', interval '1' month);
-- bwc_tag:end_query

SELECT d FROM range(TIMESTAMP '1992-01-01 00:00:00', TIMESTAMP '1991-06-01 00:00:00', INTERVAL '1 MONTH ago') tbl(d)
-- bwc_tag:end_query

SELECT d FROM generate_series(TIMESTAMP '1992-01-01 00:00:00', TIMESTAMP '1991-06-01 00:00:00', -INTERVAL '1 MONTH') tbl(d)
-- bwc_tag:end_query

SELECT d FROM range(TIMESTAMP '1992-01-01 00:00:00', TIMESTAMP '1992-12-31 12:00:00', INTERVAL '1 MONTH 1 DAY 1 HOUR') tbl(d)
-- bwc_tag:end_query

SELECT COUNT(*) FROM range(TIMESTAMP '1992-01-01 00:00:00', TIMESTAMP '2020-01-01 00:00:00', INTERVAL '1 DAY') tbl(d)
-- bwc_tag:end_query

SELECT COUNT(*) FROM generate_series(TIMESTAMP '1992-01-01 00:00:00', TIMESTAMP '2020-01-01 00:00:00', INTERVAL '1 DAY') tbl(d)
-- bwc_tag:end_query

SELECT COUNT(*) FROM range(NULL, TIMESTAMP '1992-12-31 12:00:00', INTERVAL '1 MONTH') tbl(d)
-- bwc_tag:end_query

SELECT COUNT(*) FROM generate_series(NULL, TIMESTAMP '1992-12-31 12:00:00', INTERVAL '1 MONTH') tbl(d)
-- bwc_tag:end_query

explain
from range('290309-12-22 (BC) 00:00:00'::TIMESTAMP, '294247-01-10 04:00:54.775806'::TIMESTAMP, interval '1 hour');
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT d FROM range(TIMESTAMP '1992-01-01 00:00:00', TIMESTAMP '1992-12-31 12:00:00', INTERVAL '0 MONTH') tbl(d)
-- bwc_tag:end_query

SELECT d FROM range(TIMESTAMP '1992-01-01 00:00:00', TIMESTAMP '1992-12-31 12:00:00', INTERVAL '1 MONTH ago') tbl(d)
-- bwc_tag:end_query

SELECT d FROM range(TIMESTAMP '1993-01-01 00:00:00', TIMESTAMP '1992-01-01 00:00:00', INTERVAL '1 MONTH') tbl(d)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT d FROM range(TIMESTAMP '1992-01-01 00:00:00', TIMESTAMP '1992-12-31 12:00:00', INTERVAL '1 MONTH' - INTERVAL '1 HOUR') tbl(d)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT COUNT(*) FROM generate_series('294247-01-10'::TIMESTAMP, 'infinity'::TIMESTAMP, INTERVAL '1 DAY');
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT COUNT(*) FROM range('294247-01-10'::TIMESTAMP, 'infinity'::TIMESTAMP, INTERVAL '1 DAY');
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT COUNT(*) FROM generate_series('-infinity'::TIMESTAMP, '290309-12-22 (BC) 00:00:00'::TIMESTAMP, INTERVAL '1 DAY');
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT COUNT(*) FROM range('-infinity'::TIMESTAMP, '290309-12-22 (BC) 00:00:00'::TIMESTAMP, INTERVAL '1 DAY');
-- bwc_tag:end_query

