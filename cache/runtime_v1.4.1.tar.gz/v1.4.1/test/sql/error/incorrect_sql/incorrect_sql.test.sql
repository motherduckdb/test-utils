-- bwc_tag:nb_steps=34
-- bwc_tag:expected_result=error

SELEC 42;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELEC 42, 'thisisareallylongstringloremipsumblablathisisareallylongstringloremipsumblablalthisisareallylongstringloremipsumblablalthisisareallylongstringloremipsumblablal';
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELEC 42, '🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆';
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT '🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆', x, '🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆';
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT FUNFUNFUN();
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE VIEW v1
AS SELECT FUNFUNFUN();
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT SUM(42, 84, 11, 'hello')
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT cos(0, 1, 2, 3);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM RANG();
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM RANGE(1, hello=3);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT * FROM READ_CSV('x', hello=3);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT 42 WHERE 1=1 WHERE 1=0;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT 42
SELECT 42;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT 42; SELEC 42;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM integers2;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM bla.integers2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE VIEW v1 AS SELECT * FROM integers2;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

with cte1 as (select 42 as j), cte2 as (select ref.j as k from cte1 as ref), cte3 as (select ref2.j+1 as i from cte1 as ref2) SELECT * FROM integers9;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

with cte1 as (select 42 as j), cte2 as (select ref.j as k from cte1 as ref), cte3 as (select ref2.j+1 as i from cte1 as ref2) SELECT * FROM integers9 where x=3 order by x+1+1+1+1+1+1+1+1+1+1+1;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT
    l_returnflag,
    l_linestatus,
    sum(l_quantity) AS sum_qty,
    sum(l_extendedprice) AS sum_base_price,
    sum(l_extendedprice * (1 - l_discount)) AS sum_disc_price,
    sum(l_extendedprice * (1 - l_discount) * (1 + l_tax)) AS sum_charge,
    avg(l_quantity) AS avg_qty,
    avg(l_extendedprice) AS avg_price,
    avg(l_discount) AS avg_disc,
    count(*) AS count_order
FROM
    lineitem
WHERE
    l_shipdate <= CAST('1998-09-02' AS date)
GROUP BY
    l_returnflag,
    l_linestatus
ORDER BY
    l_returnflag,
    l_linestatus;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select 🦆🍞 from 🦆🍞;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

with 🍞🍞 as (select 'bread' as 🍞), 🦆🦆 as (select ref.🍞 as "🍞" from 🍞🍞 as ref) SELECT * FROM integers9 where x LIKE '🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆🦆' order by x+1+1+1+1+1+1+1+1+1+1+1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(integ INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE strings(str VARCHAR);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE chickens(feather INTEGER, beak INTEGER);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM integres;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT feathe FROM chickens;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT feathe FROM chickens, integers, strings;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT st FROM chickens, integers, strings;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT chicken.feather FROM chickens
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT chicken.st FROM chickens, integers, strings;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE 🦆🍞(🦆🦆🦆 INTEGER, 🍞🍞🍞 INTEGER);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT 🦆.🦆🦆🦆 FROM 🦆🍞
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT 🦆🦆 FROM 🦆🍞, chickens
-- bwc_tag:end_query

