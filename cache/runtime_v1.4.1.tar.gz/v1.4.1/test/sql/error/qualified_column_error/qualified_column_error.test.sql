-- bwc_tag:nb_steps=11
-- bwc_tag:execute_from_sql
create schema "dbt_temp"
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create or replace table "dbt_temp"."foo_2" as (select 42 as num_2);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select "dbt_temp"."foo_2".num_3 FROM  "dbt_temp"."foo_2"
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select "dbt_temp"."foo_1".num_2 FROM  "dbt_temp"."foo_2"
-- bwc_tag:end_query

attach ':memory:' as cat
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create schema cat.schema
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table cat.schema.tbl(col struct(v1 int));
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select cat.schema.tbl.col.v2 from cat.schema.tbl
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select cat.schema.tbl.cxl.v1 from cat.schema.tbl
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select cat.schema.txl.col.v1 from cat.schema.tbl
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select cat.schxma.tbl.col.v1 from cat.schema.tbl
-- bwc_tag:end_query

