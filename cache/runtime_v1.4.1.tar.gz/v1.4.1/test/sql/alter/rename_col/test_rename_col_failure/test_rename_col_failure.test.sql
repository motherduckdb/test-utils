-- bwc_tag:nb_steps=4
-- bwc_tag:execute_from_sql
CREATE TABLE test(i INTEGER, j INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE test RENAME COLUMN blablabla TO k
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE test RENAME COLUMN i TO j
-- bwc_tag:end_query

SELECT i, j FROM test
-- bwc_tag:end_query

