-- bwc_tag:nb_steps=52
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers (a INT)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (1)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO cte_sq(a,b) AS (WITH cte AS (SELECT a * 2 AS c) SELECT cte.c + sq.d FROM cte, (SELECT b * 3 AS d) AS sq)
-- bwc_tag:end_query

SELECT cte_sq(3,4)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO nested_cte(needle, haystack) AS needle IN (
    SELECT i FROM (
        WITH ints AS (
            SELECT CAST(UNNEST(string_split(haystack,',')) AS INT) AS i
        )
        SELECT i FROM ints
    ) AS sq
)
-- bwc_tag:end_query

SELECT nested_cte(2, '2,2,2,2')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO IFELSE(a,b,c) AS CASE WHEN a THEN b ELSE c END
-- bwc_tag:end_query

SELECT IFELSE(1, IFELSE(1,'a','b'), 'c')
-- bwc_tag:end_query

SELECT IFELSE(1, IFELSE(0,'a','b'), 'c')
-- bwc_tag:end_query

SELECT IFELSE(0, IFELSE(1,'a','b'), 'c')
-- bwc_tag:end_query

SELECT IFELSE(1, IFELSE(1,a,'b'), 'c') FROM integers
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT IFELSE(1,IFELSE(1,b,1),a) FROM integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO f1(x) AS (SELECT MIN(a) + x FROM integers)
-- bwc_tag:end_query

select f1(42) from integers;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO mod_two(k) AS k%2
-- bwc_tag:end_query

SELECT mod_two(a), SUM(a) FROM integers GROUP BY mod_two(a)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO add_mac(a, b) AS a + b
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO double_add(a, b, c) AS add_mac(add_mac(a, b), c)
-- bwc_tag:end_query

SELECT double_add(1, 2, 3)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO triple_add1(a, b, c, d) AS add_mac(add_mac(a, b), add_mac(c, d))
-- bwc_tag:end_query

SELECT triple_add1(1, 2, 3, 4)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO triple_add2(a, b, c, d) as add_mac(add_mac(add_mac(a, b), c), d)
-- bwc_tag:end_query

SELECT triple_add2(1, 2, 3, 4)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (41)
-- bwc_tag:end_query

SELECT add((SELECT MIN(a) FROM integers), (SELECT MAX(a) FROM integers))
-- bwc_tag:end_query

SELECT (SELECT MAX(add(i1.a, a)) FROM integers) FROM integers i1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE MACRO prep(x) AS ?+1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO add_one(a) AS a + 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PREPARE v1 AS SELECT add_one(?::INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
EXECUTE v1(1)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO my_square(a) AS a * a
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PREPARE v2 AS SELECT my_square(?::INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
EXECUTE v2(3)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE documents(id VARCHAR, body VARCHAR)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO documents VALUES ('doc1', ' QUÁCK+QUÁCK+QUÁCK'), ('doc2', ' BÁRK+BÁRK+BÁRK+BÁRK'), ('doc3', ' MÉOW+MÉOW+MÉOW+MÉOW+MÉOW')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA fts_main_documents
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE fts_main_documents.docs AS (
    SELECT
        row_number() OVER () AS docid,
        id AS name
    FROM
        main.documents
)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE fts_main_documents.terms AS (
    SELECT
        term,
        docid,
        row_number() OVER (PARTITION BY docid) AS pos
    FROM (
        SELECT
            unnest(string_split_regex(regexp_replace(lower(strip_accents(body)), '[^a-z]', ' ', 'g'), '\s+')) AS term,
            row_number() OVER () AS docid
        FROM main.documents
    ) AS sq
    WHERE
        term != ''
)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE fts_main_documents.docs ADD len INT
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
UPDATE fts_main_documents.docs d
SET len = (
    SELECT count(term)
    FROM fts_main_documents.terms t
    WHERE t.docid = d.docid
)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE fts_main_documents.dict AS
WITH distinct_terms AS (
    SELECT DISTINCT term, docid
    FROM fts_main_documents.terms
    ORDER BY docid
)
SELECT
    row_number() OVER () AS termid,
    term
FROM
    distinct_terms
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE fts_main_documents.terms ADD termid INT
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
UPDATE fts_main_documents.terms t
SET termid = (
    SELECT termid
    FROM fts_main_documents.dict d
    WHERE t.term = d.term
)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE fts_main_documents.terms DROP term
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE fts_main_documents.dict ADD df INT
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
UPDATE fts_main_documents.dict d
SET df = (
    SELECT count(distinct docid)
    FROM fts_main_documents.terms t
    WHERE d.termid = t.termid
    GROUP BY termid
)
-- bwc_tag:end_query

WITH ppterms AS (
    SELECT unnest(string_split_regex(regexp_replace(lower(strip_accents('QUÁCK BÁRK')), '[^a-z]', ' ', 'g'), '\s+')) AS term
), qtermids AS (
    SELECT termid
    FROM fts_main_documents.dict AS dict
    JOIN ppterms
    USING (term)
), qterms AS (
    SELECT termid,
           docid
    FROM fts_main_documents.terms AS terms
    WHERE termid IN (
        SELECT qtermids.termid FROM qtermids
    )
), subscores AS (
    SELECT docs.docid,
           len,
           term_tf.termid,
           tf,
           df,
           (log((3 - df + 0.5) / (df + 0.5))* ((tf * (1.2 + 1)/(tf + 1.2 * (1 - 0.75 + 0.75 * (len / 4)))))) AS subscore
    FROM (
        SELECT termid,
               docid,
               COUNT(*) AS tf
        FROM qterms
        GROUP BY docid,
                 termid
    ) AS term_tf
    JOIN (
        SELECT DISTINCT docid
        FROM qterms
    ) AS cdocs
    ON term_tf.docid = cdocs.docid
    JOIN fts_main_documents.docs AS docs
    ON term_tf.docid = docs.docid
    JOIN fts_main_documents.dict AS dict
    ON term_tf.termid = dict.termid
)
SELECT name,
       score
FROM (
    SELECT docid,
           sum(subscore) AS score
    FROM subscores
    GROUP BY docid
) AS scores
JOIN fts_main_documents.docs AS docs
ON scores.docid = docs.docid
ORDER BY score DESC
LIMIT 1000
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO fts_match(docname, query_string) AS docname IN (
WITH ppterms AS (SELECT unnest(string_split_regex(regexp_replace(lower(strip_accents(query_string)), '[^a-z]', ' ', 'g'), '\s+')) AS term),
qtermids AS (SELECT termid FROM fts_main_documents.dict AS dict, ppterms WHERE dict.term = ppterms.term),
qterms AS (SELECT termid, docid FROM fts_main_documents.terms AS terms WHERE termid IN (SELECT qtermids.termid FROM qtermids)),
subscores AS (
SELECT docs.docid, len, term_tf.termid,
        tf, df, (log((3 - df + 0.5) / (df + 0.5))* ((tf * (1.2 + 1)/(tf + 1.2 * (1 - 0.75 + 0.75 * (len / 4)))))) AS subscore
FROM (SELECT termid, docid, COUNT(*) AS tf FROM qterms
    GROUP BY docid, termid) AS term_tf
    JOIN (SELECT docid FROM qterms
        GROUP BY docid) -- HAVING COUNT(DISTINCT termid) = 3)
        AS cdocs ON term_tf.docid = cdocs.docid
    JOIN fts_main_documents.docs AS docs ON term_tf.docid = docs.docid
    JOIN fts_main_documents.dict AS dict ON term_tf.termid = dict.termid)
SELECT name FROM (SELECT docid, sum(subscore) AS score
    FROM subscores GROUP BY docid) AS scores JOIN fts_main_documents.docs AS docs ON
    scores.docid = docs.docid ORDER BY score DESC LIMIT 1000)
-- bwc_tag:end_query

SELECT * FROM documents WHERE fts_match(id, 'QUÁCK BÁRK')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO mywindow(k,v) AS SUM(v) OVER (PARTITION BY k)
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
WITH grouped AS (SELECT mod(range, 3) AS grp, range AS val FROM RANGE(500))
SELECT DISTINCT grp, mywindow(grp, val) FROM grouped ORDER BY grp
-- bwc_tag:end_query

