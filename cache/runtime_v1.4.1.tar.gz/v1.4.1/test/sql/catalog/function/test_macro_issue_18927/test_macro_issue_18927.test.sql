-- bwc_tag:nb_steps=2
-- bwc_tag:execute_from_sql
CREATE OR REPLACE MACRO my(s) AS s.lower().split('').aggregate('count');
-- bwc_tag:end_query

SELECT my('AA');
-- bwc_tag:end_query

