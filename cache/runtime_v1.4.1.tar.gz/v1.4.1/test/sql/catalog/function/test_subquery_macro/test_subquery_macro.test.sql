-- bwc_tag:nb_steps=15
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers (a INT)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (1)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO subquery(a) AS (SELECT a)
-- bwc_tag:end_query

SELECT subquery(1)
-- bwc_tag:end_query

SELECT subquery(NULL)
-- bwc_tag:end_query

SELECT subquery(3) + a FROM integers
-- bwc_tag:end_query

SELECT subquery(a) FROM integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE MACRO a1(a) AS (SELECT a + a FROM integers)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO a1(b) AS (SELECT a + a FROM integers)
-- bwc_tag:end_query

SELECT a1(3)
-- bwc_tag:end_query

SELECT a1(3) + a FROM integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE MACRO a2(a) AS (SELECT i.a + a FROM integers i)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO a2(b) AS (SELECT i.a + b FROM integers i)
-- bwc_tag:end_query

SELECT a2(3)
-- bwc_tag:end_query

