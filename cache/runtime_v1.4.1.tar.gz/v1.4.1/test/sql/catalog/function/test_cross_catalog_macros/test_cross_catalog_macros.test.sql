-- bwc_tag:nb_steps=3
-- bwc_tag:execute_from_sql
CREATE MACRO my_first_macro() AS (84)
-- bwc_tag:end_query

CREATE TEMPORARY MACRO my_second_macro() AS my_first_macro() + 42;
-- bwc_tag:end_query

SELECT my_second_macro()
-- bwc_tag:end_query

