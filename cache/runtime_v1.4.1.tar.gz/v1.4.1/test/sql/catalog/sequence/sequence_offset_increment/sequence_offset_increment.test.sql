-- bwc_tag:nb_steps=3
-- bwc_tag:execute_from_sql
create sequence xx start 100 increment by 2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('xx')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('xx')
-- bwc_tag:end_query

