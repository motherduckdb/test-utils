-- bwc_tag:nb_steps=3
-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE IF NOT EXISTS integers AS SELECT i1.i FROM range(10000000000000000) i1(i);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE TABLE integers AS SELECT i1.i FROM range(10000000000000000) i1(i);
-- bwc_tag:end_query

