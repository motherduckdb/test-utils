-- bwc_tag:nb_steps=12
-- bwc_tag:execute_from_sql
CREATE TABLE "MyTable"(i integer, "BigColumn" integer);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE MyTable ALTER BIGCOLUMN SET DATA TYPE VARCHAR
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE MyTable DROP COLUMN BIGCOLUMN;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT BIGCOLUMN FROM MyTable
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE MyTable ADD COLUMN "BIGCOLUMN" VARCHAR;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE MyTable ALTER COLUMN BIGCOLUMN SET DEFAULT 3
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO MyTable(BIGCOLUMN) VALUES (DEFAULT)
-- bwc_tag:end_query

SELECT BIGCOLUMN FROM MyTable
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE MyTable ALTER COLUMN BIGCOLUMN DROP DEFAULT
-- bwc_tag:end_query

SELECT BIGCOLUMN FROM MyTable
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE MyTable RENAME BIGCOLUMN TO "SmallColumn"
-- bwc_tag:end_query

SELECT SmallColumn FROM MyTable
-- bwc_tag:end_query

