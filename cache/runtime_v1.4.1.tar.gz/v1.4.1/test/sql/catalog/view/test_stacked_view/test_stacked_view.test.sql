-- bwc_tag:nb_steps=6
-- bwc_tag:execute_from_sql
CREATE TABLE t1(i INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES (41), (42), (43), (44)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW v1 (v1c1, v1c2) AS SELECT i,i+1 FROM t1 WHERE i > 41
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW v2 (v2c1, v2c2, v2c3) AS SELECT v1c1, v1c2, v1c1+v1c2 FROM v1 WHERE v1c2 > 42
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW v3 (v3c1, v3c2) AS SELECT v2c1, v2c3 FROM v2 WHERE v2c1 > 43
-- bwc_tag:end_query

SELECT v3c2+1 FROM v3 WHERE v3c1 > 42
-- bwc_tag:end_query

