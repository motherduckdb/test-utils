-- bwc_tag:nb_steps=10
-- bwc_tag:skip_query
PRAGMA enable_verification;
-- bwc_tag:end_query

ATTACH ':memory:' AS db1;
-- bwc_tag:end_query

USE db1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE data AS
SELECT i, hash(i)::VARCHAR AS value FROM generate_series(1, 10000) s(i);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE data ALTER COLUMN value SET NOT NULL;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE INDEX data_value ON data(value);
-- bwc_tag:end_query

ATTACH ':memory:' AS db2;
-- bwc_tag:end_query

COPY FROM DATABASE db1 TO db2;
-- bwc_tag:end_query

SELECT database_name, table_name, index_name FROM duckdb_indexes ORDER BY ALL;
-- bwc_tag:end_query

SELECT database_name, table_name, index_count FROM duckdb_tables ORDER BY ALL;
-- bwc_tag:end_query

