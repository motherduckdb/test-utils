-- bwc_tag:nb_steps=60
SET default_null_order='nulls_first';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(a INTEGER, b INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (1, 10), (2, 12), (3, 14), (4, 16), (5, NULL), (NULL, NULL)
-- bwc_tag:end_query

SELECT * FROM integers WHERE TRUE ORDER BY 1
-- bwc_tag:end_query

SELECT * FROM integers WHERE FALSE ORDER BY 1
-- bwc_tag:end_query

SELECT * FROM integers WHERE NULL ORDER BY 1
-- bwc_tag:end_query

SELECT * FROM integers WHERE a=2 AND a=2
-- bwc_tag:end_query

SELECT * FROM integers WHERE a=2 AND a>0
-- bwc_tag:end_query

SELECT * FROM integers WHERE a>0 AND a=2
-- bwc_tag:end_query

SELECT * FROM integers WHERE a=2 AND a<4
-- bwc_tag:end_query

SELECT * FROM integers WHERE a<4 AND a=2
-- bwc_tag:end_query

SELECT * FROM integers WHERE a=2 AND a<=2
-- bwc_tag:end_query

SELECT * FROM integers WHERE a=2 AND a>=2
-- bwc_tag:end_query

SELECT * FROM integers WHERE a>2 AND a>4
-- bwc_tag:end_query

SELECT * FROM integers WHERE a>4 AND a>2
-- bwc_tag:end_query

SELECT * FROM integers WHERE a>4 AND a>=4
-- bwc_tag:end_query

SELECT * FROM integers WHERE a>=4 AND a>4
-- bwc_tag:end_query

SELECT * FROM integers WHERE a<2 AND a<4
-- bwc_tag:end_query

SELECT * FROM integers WHERE a<4 AND a<2
-- bwc_tag:end_query

SELECT * FROM integers WHERE a<2 AND a<=2
-- bwc_tag:end_query

SELECT * FROM integers WHERE a<=2 AND a<2
-- bwc_tag:end_query

SELECT * FROM integers WHERE a<2 AND a<>3
-- bwc_tag:end_query

SELECT * FROM integers WHERE a<=1 AND a<>3
-- bwc_tag:end_query

SELECT * FROM integers WHERE a>4 AND a<>2
-- bwc_tag:end_query

SELECT * FROM integers WHERE a>=5 AND a<>2
-- bwc_tag:end_query

SELECT * FROM integers WHERE a>=4 AND a<>4 AND a<>4
-- bwc_tag:end_query

SELECT * FROM integers WHERE a<3 AND a<4 AND a<5 AND a<10 AND a<2 AND a<20
-- bwc_tag:end_query

SELECT * FROM integers WHERE a=2 AND a=4
-- bwc_tag:end_query

SELECT * FROM integers WHERE a=2 AND a>4
-- bwc_tag:end_query

SELECT * FROM integers WHERE a>4 AND a=2
-- bwc_tag:end_query

SELECT * FROM integers WHERE a=2 AND a>2
-- bwc_tag:end_query

SELECT * FROM integers WHERE a>=4 AND a=2
-- bwc_tag:end_query

SELECT * FROM integers WHERE a=4 AND a<2
-- bwc_tag:end_query

SELECT * FROM integers WHERE a<2 AND a=4
-- bwc_tag:end_query

SELECT * FROM integers WHERE a=2 AND a<2
-- bwc_tag:end_query

SELECT * FROM integers WHERE a<=2 AND a=4
-- bwc_tag:end_query

SELECT * FROM integers WHERE a<2 AND a>4
-- bwc_tag:end_query

SELECT * FROM integers WHERE a=2 AND a<>2
-- bwc_tag:end_query

SELECT * FROM integers WHERE a<>2 AND a=2
-- bwc_tag:end_query

SELECT * FROM integers WHERE 0
-- bwc_tag:end_query

SELECT * FROM integers WHERE a<2 AND 0
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE strings(s VARCHAR)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO strings VALUES ('hello'), ('world'), (NULL)
-- bwc_tag:end_query

SELECT * FROM strings WHERE s='hello' AND s='hello'
-- bwc_tag:end_query

SELECT * FROM strings WHERE s='hello' AND s='world'
-- bwc_tag:end_query

SELECT * FROM strings WHERE s='hello' AND s<>'hello'
-- bwc_tag:end_query

SELECT * FROM strings WHERE s='hello' AND s<>'world'
-- bwc_tag:end_query

SELECT * FROM strings WHERE s='hello' AND s>'a'
-- bwc_tag:end_query

SELECT * FROM strings WHERE s='hello' AND s>='hello'
-- bwc_tag:end_query

SELECT * FROM strings WHERE s='hello' AND s<='hello'
-- bwc_tag:end_query

SELECT * FROM strings WHERE s='hello' AND s<'z'
-- bwc_tag:end_query

SELECT * FROM strings WHERE s='hello' AND s<='a'
-- bwc_tag:end_query

SELECT * FROM strings WHERE s='hello' AND s<'hello'
-- bwc_tag:end_query

SELECT * FROM strings WHERE s='hello' AND s>'hello'
-- bwc_tag:end_query

SELECT * FROM strings WHERE s='hello' AND s>='z'
-- bwc_tag:end_query

SELECT * FROM strings WHERE s<>'hello' AND s<='a'
-- bwc_tag:end_query

SELECT * FROM strings WHERE s<>'hello' AND s<'hello'
-- bwc_tag:end_query

SELECT * FROM strings WHERE s<>'hello' AND s>'hello'
-- bwc_tag:end_query

SELECT * FROM strings WHERE s<>'world' AND s>='hello'
-- bwc_tag:end_query

