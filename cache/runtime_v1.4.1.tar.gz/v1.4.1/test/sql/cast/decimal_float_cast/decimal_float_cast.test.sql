-- bwc_tag:nb_steps=4
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

select cast(100000000000000000000 as double) < cast(99999999999999999999.99999 as double);
-- bwc_tag:end_query

select 100000000000000000000 > 99999999999999999999.99999;
-- bwc_tag:end_query

select cast(999999999999999.9999 as double) <= cast(999999999999999.99999999 as double);
-- bwc_tag:end_query

