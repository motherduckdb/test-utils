-- bwc_tag:nb_steps=4
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select file.replace('a', 'b') from (values ('xxxx')) t("filename");
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select filename.replacezxcv('a', 'b') from (values ('xxxx')) t("filename");
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select replacezxcv('a', 'b') from (values ('xxxx')) t("filename");
-- bwc_tag:end_query

