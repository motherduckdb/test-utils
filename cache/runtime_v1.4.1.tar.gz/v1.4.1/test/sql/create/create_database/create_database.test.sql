-- bwc_tag:nb_steps=3
-- bwc_tag:expected_result=error

CREATE DATABASE mydb;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

CREATE DATABASE mydb FROM './path';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DROP DATABASE mydb
-- bwc_tag:end_query

