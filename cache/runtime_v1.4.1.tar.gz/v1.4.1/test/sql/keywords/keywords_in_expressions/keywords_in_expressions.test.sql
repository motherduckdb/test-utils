-- bwc_tag:nb_steps=18
-- bwc_tag:skip_query
PRAGMA enable_verification;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA "SCHEMA";
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE TYPE "ENUM" AS ENUM('ALL');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE TABLE "SCHEMA"."TABLE"("COLUMN" "ENUM");
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TYPE E AS ENUM('ALL');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE "SCHEMA"."TABLE"("COLUMN" E);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO "SCHEMA"."TABLE" VALUES ('ALL');
-- bwc_tag:end_query

SELECT "COLUMN" FROM "SCHEMA"."TABLE";
-- bwc_tag:end_query

SELECT "TABLE"."COLUMN" FROM "SCHEMA"."TABLE";
-- bwc_tag:end_query

SELECT "SCHEMA"."TABLE"."COLUMN" FROM "SCHEMA"."TABLE";
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE "SCHEMA"."TABLE";
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE "SCHEMA"."TABLE"("COLUMN" ROW("SOME" ROW("IN" INTEGER)));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO "SCHEMA"."TABLE" VALUES ({'some': {'in': 3}});
-- bwc_tag:end_query

SELECT "COLUMN"."SOME"."IN" FROM "SCHEMA"."TABLE";
-- bwc_tag:end_query

SELECT "TABLE"."COLUMN"."SOME"."IN" FROM "SCHEMA"."TABLE";
-- bwc_tag:end_query

SELECT "SCHEMA"."TABLE"."COLUMN"."SOME"."IN" FROM "SCHEMA"."TABLE";
-- bwc_tag:end_query

SELECT (("SCHEMA"."TABLE"."COLUMN")."SOME")."IN" FROM "SCHEMA"."TABLE";
-- bwc_tag:end_query

SELECT "SCHEMA"."TABLE"."COLUMN"['SOME']['IN'] FROM "SCHEMA"."TABLE";
-- bwc_tag:end_query

