-- bwc_tag:nb_steps=4
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * from read_csv_auto('data/csv/escape.csv', escape=']', header = 0)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * from read_csv_auto('data/csv/escape.csv', header = 0)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT * from read_csv_auto('data/csv/no_opt.csv', delim = ';')
-- bwc_tag:end_query

