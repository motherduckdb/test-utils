-- bwc_tag:nb_steps=21
-- bwc_tag:execute_from_sql
drop table if exists reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/error/banklist.csv', store_rejects=true) order by all limit 5
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop table if exists reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/error/banklist.csv', store_rejects=true) order by all limit 5
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop table if exists reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/error/banklist.csv', store_rejects=true) order by all limit 5
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop table if exists reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/error/banklist.csv', store_rejects=true) order by all limit 5
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop table if exists reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/error/banklist.csv', store_rejects=true) order by all limit 5
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop table if exists reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/error/banklist.csv', store_rejects=true) order by all limit 5
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop table if exists reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/error/banklist.csv', store_rejects=true) order by all limit 5
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop table if exists reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/error/banklist.csv', store_rejects=true) order by all limit 5
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop table if exists reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/error/banklist.csv', store_rejects=true) order by all limit 5
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop table if exists reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/error/banklist.csv', store_rejects=true) order by all limit 5
-- bwc_tag:end_query

select * exclude(scan_id ) from reject_errors order by all limit 5
-- bwc_tag:end_query

