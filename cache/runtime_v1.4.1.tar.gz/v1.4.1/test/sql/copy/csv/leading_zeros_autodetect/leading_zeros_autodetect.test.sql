-- bwc_tag:nb_steps=9
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE leading_zeros AS SELECT * FROM read_csv_auto('data/csv/leading_zeros.csv')
-- bwc_tag:end_query

SELECT CODGEO FROM leading_zeros LIMIT 1;
-- bwc_tag:end_query

SELECT typeof(CODGEO) FROM leading_zeros LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE leading_zeros2 AS SELECT * FROM read_csv_auto('data/csv/leading_zeros2.csv')
-- bwc_tag:end_query

SELECT * FROM leading_zeros2;
-- bwc_tag:end_query

SELECT typeof(comune), typeof(codice_regione), typeof(codice_provincia) FROM leading_zeros2 LIMIT 1;
-- bwc_tag:end_query

select '09001'::int;
-- bwc_tag:end_query

select '00009001'::int;
-- bwc_tag:end_query

