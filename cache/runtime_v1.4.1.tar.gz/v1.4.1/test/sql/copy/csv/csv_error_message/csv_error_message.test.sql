-- bwc_tag:nb_steps=8
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

FROM read_csv('data/csv/15473.csv', delim = ',', columns = {'A' : 'VARCHAR','B' : 'VARCHAR','C' : 'VARCHAR','D' : 'VARCHAR'})
-- bwc_tag:end_query

COPY (SELECT i::VARCHAR i FROM range(103) tbl(i) UNION ALL SELECT 'hello') TO 'output/int_parse_error.csv' (HEADER, DELIMITER '|')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT * FROM read_csv('output/int_parse_error.csv', columns={'i': 'INT'})
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT * FROM read_csv('output/int_parse_error.csv', columns={'i': 'INT'}, header=True, auto_detect=false)
-- bwc_tag:end_query

COPY (SELECT i::VARCHAR i FROM range(103) tbl(i) UNION ALL SELECT 'hello') TO 'output/int_parse_error.csv' (HEADER 0, DELIMITER '|')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT * FROM read_csv('output/int_parse_error.csv', columns={'i': 'INT'}, header=False, auto_detect=false)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT * FROM read_csv('output/int_parse_error.csv', columns={'i': 'INT'}, header=False, auto_detect=false)
-- bwc_tag:end_query

