-- bwc_tag:nb_steps=4
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv_auto('data/csv/null_comparison.csv');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv_auto('data/csv/null_comparison.csv', allow_quoted_nulls=False);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv_auto('data/csv/null_comparison.csv', allow_quoted_nulls=True);
-- bwc_tag:end_query

