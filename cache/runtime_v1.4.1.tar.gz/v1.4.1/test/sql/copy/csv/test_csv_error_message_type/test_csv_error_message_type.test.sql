-- bwc_tag:nb_steps=17
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE venue (
    venueid          SMALLINT        NOT NULL /*PRIMARY KEY*/
    , venuename      VARCHAR (100)
    , venuecity      VARCHAR (30)
    , venuestate     CHAR (2)
    , venueseats     INTEGER
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

copy venue from 'data/csv/venue_pipe.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT * FROM read_csv('data/csv/venue_pipe.csv', types=['SMALLINT','VARCHAR','VARCHAR','VARCHAR','INTEGER']);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT * FROM read_csv('data/csv/venue_pipe.csv', types=['SMALLINT','VARCHAR','VARCHAR','VARCHAR','INTEGER']);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT * FROM read_csv('data/csv/venue_pipe.csv', types={'venueseats':'INTEGER'});
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT * FROM read_csv('data/csv/venue_pipe_big.csv', sample_size = 1);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE venue_2 (
    venueid          SMALLINT        NOT NULL /*PRIMARY KEY*/
    , venuename      VARCHAR (100)
    , venuecity      VARCHAR (30)
    , venuestate     CHAR (2)
    , venueseats     VARCHAR
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO venue_2 SELECT * FROM read_csv('data/csv/venue_pipe_big.csv', sample_size = 1);
-- bwc_tag:end_query

SELECT COUNT(*) from venue_2
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE venue_2
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE venue_2 (
    venueid          SMALLINT        NOT NULL /*PRIMARY KEY*/
    , venuename      VARCHAR (100)
    , venuecity      VARCHAR (30)
    , venuestate     CHAR (2)
    , venueseats     VARCHAR
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO venue_2 SELECT * FROM read_csv('data/csv/venue_pipe_big.csv', sample_size = 1, types={'venueseats': 'VARCHAR'});
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO venue_2 SELECT * FROM read_csv('data/csv/venue_pipe_big.csv', sample_size = -1);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
copy venue_2 from 'data/csv/venue_pipe_big.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT * FROM read_csv('data/csv/venue_pipe_big.csv', sample_size = 1);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO venue SELECT * FROM read_csv('data/csv/venue_pipe.csv');
-- bwc_tag:end_query

