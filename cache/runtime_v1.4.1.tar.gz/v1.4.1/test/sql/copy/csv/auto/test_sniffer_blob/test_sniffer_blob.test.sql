-- bwc_tag:nb_steps=7
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

select count(*) from read_csv('data/csv/test/blob.csv',auto_type_candidates=['blob'])
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select count(*) from read_csv('data/csv/test/blob.csv',types=['blob'], header = 0)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select count(*) from read_csv('data/csv/test/blob.csv',columns={'col1': 'BLOB'})
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table t ( a blob)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY t FROM 'data/csv/test/blob.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select count(*) from read_csv('data/csv/test/blob.csv',columns={'col1': 'BLOB'})
-- bwc_tag:end_query

