-- bwc_tag:nb_steps=5
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE bgzf AS SELECT * FROM read_csv_auto('data/csv/test/bgzf.gz');
-- bwc_tag:end_query

SELECT COUNT(*) FROM bgzf;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE concat AS SELECT * FROM read_csv_auto('data/csv/test/concat.gz');
-- bwc_tag:end_query

SELECT COUNT(*) FROM concat;
-- bwc_tag:end_query

