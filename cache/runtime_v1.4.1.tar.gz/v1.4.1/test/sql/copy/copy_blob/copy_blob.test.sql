-- bwc_tag:nb_steps=9
-- bwc_tag:expected_result=error

COPY (select 'foo') TO 'output/test.blob' (FORMAT BLOB);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

COPY (select 'foo'::BLOB, 10) TO 'output/test.blob' (FORMAT BLOB);
-- bwc_tag:end_query

COPY (select 'foo'::BLOB) TO 'output/test.blob' (FORMAT BLOB);
-- bwc_tag:end_query

select filename LIKE '%test.blob', content, size from read_blob('output/test.blob');
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

COPY (select 'foo'::BLOB) TO 'output/test.blob.gz' (FORMAT BLOB, ASDFGH);
-- bwc_tag:end_query

COPY (select 'foo'::BLOB) TO 'output/test.blob.gz' (FORMAT BLOB);
-- bwc_tag:end_query

select filename LIKE '%test.blob.gz', size from read_blob('output/test.blob.gz');
-- bwc_tag:end_query

COPY (select 'foo'::BLOB) TO 'output/test2.blob' (FORMAT BLOB, COMPRESSION 'GZIP');
-- bwc_tag:end_query

select filename LIKE '%test2.blob', size from read_blob('output/test2.blob');
-- bwc_tag:end_query

