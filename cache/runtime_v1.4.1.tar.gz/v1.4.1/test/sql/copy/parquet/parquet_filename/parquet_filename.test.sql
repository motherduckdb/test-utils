-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=22
LOAD 'parquet';
-- bwc_tag:end_query

select i, j, replace(filename, '\', '/') from parquet_scan('data/parquet-testing/glob*/t?.parquet', FILENAME=1) order by i;
-- bwc_tag:end_query

select i, j, replace(filename, '\', '/') as file from parquet_scan('data/parquet-testing/glob*/t?.parquet', FILENAME=1) where file='data/parquet-testing/glob2/t1.parquet';
-- bwc_tag:end_query

SELECT count(filename) FROM parquet_scan('data/parquet-testing/p2.parquet', FILENAME=1) where id < 1000;
-- bwc_tag:end_query

SELECT count(id) FROM parquet_scan('data/parquet-testing/p2.parquet', FILENAME=1) where filename >= 'data';
-- bwc_tag:end_query

select replace(filename, '\', '/') from parquet_scan('data/parquet-testing/glob*/t?.parquet', FILENAME=1) where i=2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test_csv AS SELECT 1 as id, 'test_csv_content' as filename;
-- bwc_tag:end_query

COPY test_csv TO 'output/filename_as_column.csv' WITH HEADER;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT id, filename FROM read_csv_auto('output/filename_as_column.csv',  FILENAME=1);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT 1 as id, 'test' as filename;
-- bwc_tag:end_query

COPY test TO 'output/filename_as_column.parquet';
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM parquet_scan('output/filename_as_column.parquet', FILENAME=1);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test_copy (i INT, j VARCHAR, filename VARCHAR);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test_copy FROM read_parquet('data/parquet-testing/glob/t1.parquet', filename=1, binary_as_string=1);
-- bwc_tag:end_query

SELECT i, j, replace(filename, '\', '/') FROM test_copy
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test_copy FROM read_parquet('data/parquet-testing/glob/t1.parquet', filename=1);
-- bwc_tag:end_query

SELECT i, j, replace(filename, '\', '/') FROM test_copy
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

COPY test_copy FROM 'data/parquet-testing/glob/t1.parquet';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test_table_large AS SELECT * FROM range(0,10000) tbl(i);
-- bwc_tag:end_query

COPY test_table_large TO 'output/test_table_large.parquet' (ROW_GROUP_SIZE 1000);
-- bwc_tag:end_query

SELECT sum(i), max(regexp_replace(filename, '^.*/', '')) FROM parquet_scan('output/test_table_large.parquet', FILENAME=1) where i>5000;
-- bwc_tag:end_query

SELECT i, j, replace(filename, '\', '/') as file FROM parquet_scan(['data/parquet-testing/glob/t1.parquet', 'data/parquet-testing/glob/t1.parquet', 'data/parquet-testing/glob/t2.parquet'], FILENAME=1) where file like '%t1%'
-- bwc_tag:end_query

