-- bwc_tag:needed_extensions=parquet;json
-- bwc_tag:nb_steps=4
LOAD 'parquet';
-- bwc_tag:end_query

LOAD 'json';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE json_tbl AS FROM 'data/parquet-testing/json_convertedtype.parquet';
-- bwc_tag:end_query

SELECT json_extract(TX_JSON[1], 'block_hash') FROM json_tbl
-- bwc_tag:end_query

