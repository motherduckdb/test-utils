-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=10
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:skip_query
pragma enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table some_bools (val boolean);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into some_bools values (TRUE)
-- bwc_tag:end_query

select count(*) from some_bools where val = 1;
-- bwc_tag:end_query

select count(*) from some_bools where val = '1'::bool;
-- bwc_tag:end_query

SELECT has_image_link FROM parquet_scan('data/parquet-testing/bug1588.parquet') where has_image_link = 1
-- bwc_tag:end_query

SELECT COUNT(*) FROM parquet_scan('data/parquet-testing/bug1588.parquet') WHERE has_image_link = 1
-- bwc_tag:end_query

SELECT COUNT(*) FROM parquet_scan('data/parquet-testing/bug1588.parquet') WHERE has_image_link = '1'::bool
-- bwc_tag:end_query

SELECT COUNT(*) FROM parquet_scan('data/parquet-testing/bug1588.parquet') WHERE (has_image_link = 1 AND (has_image_alt_text = 0 OR is_image_alt_text_empty = 1))
-- bwc_tag:end_query

