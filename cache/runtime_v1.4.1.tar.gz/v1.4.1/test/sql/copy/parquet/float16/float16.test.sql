-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=6
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

select type, type_length, logical_type from parquet_schema('data/parquet-testing/float16.parquet') where name = 'x'
-- bwc_tag:end_query

select typeof(x) from read_parquet('data/parquet-testing/float16.parquet') limit 1;
-- bwc_tag:end_query

select x from read_parquet('data/parquet-testing/float16.parquet') order by x;
-- bwc_tag:end_query

select x from read_parquet('data/parquet-testing/float16.parquet') where x > 1.1 order by x;
-- bwc_tag:end_query

