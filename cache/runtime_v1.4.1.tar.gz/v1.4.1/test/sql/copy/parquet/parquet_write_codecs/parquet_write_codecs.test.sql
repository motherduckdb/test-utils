-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=32
LOAD 'parquet';
-- bwc_tag:end_query

COPY (SELECT 42, 'hello') TO 'output/UNCOMPRESSED.parquet' (FORMAT 'parquet', CODEC 'UNCOMPRESSED');
-- bwc_tag:end_query

SELECT * FROM parquet_scan('output/UNCOMPRESSED.parquet');
-- bwc_tag:end_query

COPY (FROM "data/parquet-testing/userdata1.parquet") TO 'output/userdata-UNCOMPRESSED.parquet' (FORMAT 'parquet', CODEC 'UNCOMPRESSED', ROW_GROUP_SIZE 10);
-- bwc_tag:end_query

FROM "output/userdata-UNCOMPRESSED.parquet";
-- bwc_tag:end_query

COPY (SELECT 42, 'hello') TO 'output/SNAPPY.parquet' (FORMAT 'parquet', CODEC 'SNAPPY');
-- bwc_tag:end_query

SELECT * FROM parquet_scan('output/SNAPPY.parquet');
-- bwc_tag:end_query

COPY (FROM "data/parquet-testing/userdata1.parquet") TO 'output/userdata-SNAPPY.parquet' (FORMAT 'parquet', CODEC 'SNAPPY', ROW_GROUP_SIZE 10);
-- bwc_tag:end_query

FROM "output/userdata-SNAPPY.parquet";
-- bwc_tag:end_query

COPY (SELECT 42, 'hello') TO 'output/GZIP.parquet' (FORMAT 'parquet', CODEC 'GZIP');
-- bwc_tag:end_query

SELECT * FROM parquet_scan('output/GZIP.parquet');
-- bwc_tag:end_query

COPY (FROM "data/parquet-testing/userdata1.parquet") TO 'output/userdata-GZIP.parquet' (FORMAT 'parquet', CODEC 'GZIP', ROW_GROUP_SIZE 10);
-- bwc_tag:end_query

FROM "output/userdata-GZIP.parquet";
-- bwc_tag:end_query

COPY (SELECT 42, 'hello') TO 'output/ZSTD.parquet' (FORMAT 'parquet', CODEC 'ZSTD');
-- bwc_tag:end_query

SELECT * FROM parquet_scan('output/ZSTD.parquet');
-- bwc_tag:end_query

COPY (FROM "data/parquet-testing/userdata1.parquet") TO 'output/userdata-ZSTD.parquet' (FORMAT 'parquet', CODEC 'ZSTD', ROW_GROUP_SIZE 10);
-- bwc_tag:end_query

FROM "output/userdata-ZSTD.parquet";
-- bwc_tag:end_query

COPY (SELECT 42, 'hello') TO 'output/LZ4.parquet' (FORMAT 'parquet', CODEC 'LZ4');
-- bwc_tag:end_query

SELECT * FROM parquet_scan('output/LZ4.parquet');
-- bwc_tag:end_query

COPY (FROM "data/parquet-testing/userdata1.parquet") TO 'output/userdata-LZ4.parquet' (FORMAT 'parquet', CODEC 'LZ4', ROW_GROUP_SIZE 10);
-- bwc_tag:end_query

FROM "output/userdata-LZ4.parquet";
-- bwc_tag:end_query

COPY (SELECT 42, 'hello') TO 'output/LZ4_RAW.parquet' (FORMAT 'parquet', CODEC 'LZ4_RAW');
-- bwc_tag:end_query

SELECT * FROM parquet_scan('output/LZ4_RAW.parquet');
-- bwc_tag:end_query

COPY (FROM "data/parquet-testing/userdata1.parquet") TO 'output/userdata-LZ4_RAW.parquet' (FORMAT 'parquet', CODEC 'LZ4_RAW', ROW_GROUP_SIZE 10);
-- bwc_tag:end_query

FROM "output/userdata-LZ4_RAW.parquet";
-- bwc_tag:end_query

COPY (SELECT 42, 'hello') TO 'output/BROTLI.parquet' (FORMAT 'parquet', CODEC 'BROTLI');
-- bwc_tag:end_query

SELECT * FROM parquet_scan('output/BROTLI.parquet');
-- bwc_tag:end_query

COPY (FROM "data/parquet-testing/userdata1.parquet") TO 'output/userdata-BROTLI.parquet' (FORMAT 'parquet', CODEC 'BROTLI', ROW_GROUP_SIZE 10);
-- bwc_tag:end_query

FROM "output/userdata-BROTLI.parquet";
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

COPY (SELECT 42, 'hello') TO 'output/gzip.parquet' (FORMAT 'parquet', CODEC 'BLABLABLA');
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

COPY (SELECT 42, 'hello') TO 'output/gzip.parquet' (FORMAT 'parquet', CODEC);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

COPY (SELECT 42, 'hello') TO 'output/gzip.parquet' (FORMAT 'parquet', CODEC 3);
-- bwc_tag:end_query

