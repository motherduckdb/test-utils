-- bwc_tag:nb_steps=10
SET default_null_order='nulls_first';
-- bwc_tag:end_query

-- bwc_tag:skip_query
pragma enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
pragma verify_parallelism
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE strings(
	g INTEGER,
	x VARCHAR,
	y VARCHAR
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO strings VALUES
	(1,'a','/'),
	(1,'b','-'),
	(2,'i','/'),
	(2,NULL,'-'),
	(2,'j','+'),
	(3,'p','/'),
	(4,'x','/'),
	(4,'y','-'),
	(4,'z','+');
-- bwc_tag:end_query

SELECT g, STRING_AGG(DISTINCT y, ',' ORDER BY y DESC) FILTER (WHERE g < 4)
FROM strings
GROUP BY g
ORDER BY 1
-- bwc_tag:end_query

SELECT g, count(y), STRING_AGG(DISTINCT y, ',' ORDER BY y DESC) FILTER (WHERE g < 4), sum(1)
FROM strings
GROUP BY g
ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT g, STRING_AGG(DISTINCT y ORDER BY y, '_' ) FILTER (WHERE g < 4)
FROM strings
GROUP BY g
ORDER BY 1
-- bwc_tag:end_query

SET order_by_non_integer_literal=true
-- bwc_tag:end_query

SELECT g, STRING_AGG(DISTINCT y ORDER BY y, '_' ) FILTER (WHERE g < 4)
FROM strings
GROUP BY g
ORDER BY 1
-- bwc_tag:end_query

