-- bwc_tag:nb_steps=13
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select skewness()
-- bwc_tag:end_query

select skewness(NULL)
-- bwc_tag:end_query

select skewness(1)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select skewness(*)
-- bwc_tag:end_query

select skewness (10) from range (5)
-- bwc_tag:end_query

select skewness (10) from range (5) where 1 == 0
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select skewness(i) from (values (-2e307), (0), (2e307)) tbl(i)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table aggr(k int, v decimal(10,2), v2 decimal(10, 2));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into aggr values
    (1, 10, null),
    (2, 10, 11),
    (2, 10, 15),
    (2, 10, 18),
    (2, 20, 22),
    (2, 20, 25),
    (2, 25, null),
    (2, 30, 35),
    (2, 30, 40),
    (2, 30, 50),
    (2, 30, 51);
-- bwc_tag:end_query

select skewness(k), skewness(v), skewness(v2) from aggr
-- bwc_tag:end_query

select skewness(v2) from aggr group by v ORDER BY ALL
-- bwc_tag:end_query

select skewness(v2) over (partition by v)
    from aggr order by v;
-- bwc_tag:end_query

