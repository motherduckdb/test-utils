-- bwc_tag:nb_steps=38
SET default_null_order='nulls_first';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA verify_external
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table quantiles as select range r, random() FROM range(10000) union all values (NULL, 0.1), (NULL, 0.5), (NULL, 0.9) order by 2;
-- bwc_tag:end_query

SELECT quantile_disc(r, [0.1, 0.5, 0.9]) FROM quantiles
-- bwc_tag:end_query

SELECT quantile_disc(case when r is null then null else [r] end, [0.1, 0.5, 0.9]) FROM quantiles
-- bwc_tag:end_query

SELECT quantile_disc(case when r is null then null else {'i': r} end, [0.1, 0.5, 0.9]) FROM quantiles
-- bwc_tag:end_query

SELECT quantile_disc(d::decimal(4,1), [0.1, 0.5, 0.9])
FROM range(0,100) tbl(d)
-- bwc_tag:end_query

SELECT quantile_disc(d::decimal(8,1), [0.1, 0.5, 0.9])
FROM range(0,100) tbl(d)
-- bwc_tag:end_query

SELECT quantile_disc(d::decimal(12,1), [0.1, 0.5, 0.9])
FROM range(0,100) tbl(d)
-- bwc_tag:end_query

SELECT quantile_disc(d::decimal(18,1), [0.1, 0.5, 0.9])
FROM range(0,100) tbl(d)
-- bwc_tag:end_query

SELECT quantile_disc(d::decimal(24,1), [0.1, 0.5, 0.9])
FROM range(0,100) tbl(d)
-- bwc_tag:end_query

SELECT quantile_disc(col, [-.25, -.5, -.75])
FROM VALUES (11000), (3100), (2900), (2800), (2600), (2500) AS tab(col);
-- bwc_tag:end_query

SELECT quantile_disc(d::VARCHAR, [0.1, 0.5, 0.9])
FROM range(0,100) tbl(d)
-- bwc_tag:end_query

SELECT mod(r,10) as g, quantile_disc(r, [0.1, 0.5, 0.9]) FROM quantiles GROUP BY 1 ORDER BY 1
-- bwc_tag:end_query

SELECT quantile_disc(1, [0.1, 0.5, 0.9]) FROM quantiles
-- bwc_tag:end_query

SELECT quantile_disc(r, [0.1, 0.5, 0.9]) FROM quantiles WHERE 1=0
-- bwc_tag:end_query

SELECT quantile_disc(r, []) FROM quantiles
-- bwc_tag:end_query

SELECT quantile_disc('2021-01-01'::TIMESTAMP + interval (r) hour, [0.1, 0.5, 0.9]) FROM quantiles
-- bwc_tag:end_query

SELECT quantile_disc('1990-01-01'::DATE + interval (r) day, [0.1, 0.5, 0.9]) FROM quantiles
-- bwc_tag:end_query

SELECT quantile_disc('00:00:00'::TIME + interval (r) second, [0.1, 0.5, 0.9]) FROM quantiles
-- bwc_tag:end_query

SELECT quantile_disc(interval (r) second, [0.1, 0.5, 0.9]) FROM quantiles
-- bwc_tag:end_query

SELECT quantile_disc(('2021-01-01'::TIMESTAMP + interval (r) hour)::TIMESTAMPTZ, [0.1, 0.5, 0.9]) FROM quantiles
-- bwc_tag:end_query

-- bwc_tag:skip_query
pragma threads=4
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA verify_parallelism
-- bwc_tag:end_query

SELECT quantile_disc(r, [0.1, 0.5, 0.9]) FROM quantiles
-- bwc_tag:end_query

SELECT mod(r,10) as g, quantile_disc(r, [0.1, 0.5, 0.9]) FROM quantiles GROUP BY 1 ORDER BY 1
-- bwc_tag:end_query

SELECT quantile_disc(1, [0.1, 0.5, 0.9]) FROM quantiles
-- bwc_tag:end_query

SELECT quantile_disc(r, [0.1, 0.5, 0.9]) FROM quantiles WHERE 1=0
-- bwc_tag:end_query

SELECT quantile_disc(r, []) FROM quantiles
-- bwc_tag:end_query

SELECT quantile_disc(col, [0.1, 0.32, 0.33, 0.34, 0.49, .5, .51, 0.75, 0.9, 0.999, 1])
FROM VALUES (0), (1), (2), (10) AS tab(col);
-- bwc_tag:end_query

SELECT quantile_disc(42::UTINYINT, 0.5);
-- bwc_tag:end_query

SELECT quantile_disc(col, ARRAY_VALUE(0.5, 0.4, 0.1)) AS percentile 
FROM VALUES (0), (1), (2), (10) AS tab(col);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT quantile_disc(r, [-0.1, 0.5, 0.9]) FROM quantiles
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT quantile_disc(r, (0.1, 0.5, 1.1)) FROM quantiles
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT quantile_disc(r, [0.1, 0.5, NULL]) FROM quantiles
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT quantile_disc(r, ["0.1", "0.5", "0.9"]) FROM quantiles
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT quantile_disc(r, [0.1, 0.5, 0.9], 50) FROM quantiles
-- bwc_tag:end_query

