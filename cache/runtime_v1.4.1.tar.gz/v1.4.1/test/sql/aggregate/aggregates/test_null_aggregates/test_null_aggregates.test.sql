-- bwc_tag:nb_steps=104
SET default_null_order='nulls_first';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t1(c0 BIGINT, c1 SMALLINT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(NULL,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(NULL,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(NULL,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(NULL,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(NULL,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(NULL,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(NULL,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(NULL,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(-9121942514766415310,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(-9113483941634330359,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(-8718457747090493475,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(-7650527153348320600,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(-7511073704802549520,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(-7342137292157212364,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(-7003121677824953185,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(-6971852266038069200,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(-6873545755554765972,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(-6355311124878824053,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(-6350463272352412486,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(-5908442705000090253,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(-5897662788702027960,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(-5877879044803815845,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(-5732980609151508408,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(-5361272612100082873,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(-5336571579832669145,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(-4928993529687100359,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(-4468905900574568755,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(-4170492860397664351,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(-3684174996218175685,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(-3550425917959859111,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(-3538537641982313134,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(-3509778083052175642,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(-3297429447844697659,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(-3285304895013369375,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(-2783073089603195828,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(-2422155131602272083,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(-2411133157184452856,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(-2353272908390735004,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(-2242558770815087701,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(-1554405226393925625,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(-1337520990873830579,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(-1217288122333132479,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(-829779308050048379,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(-783860634233596188,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(-750940733896551510,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(-595923232719547231,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(-542467477806120649,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(-424237581585430344,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(-214362279664766533,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(-71301914094672848,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(85486376371946746,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(88239714065746993,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(587212336705139504,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(672222439154311688,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(831201880315087268,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(995204053540447006,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(1246914698489704287,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(1546231510864932275,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(1791765016181687769,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(1799302827895858725,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(2026591599286391832,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(2195119737828970803,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(2342493223442167775,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(2453343748991321803,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(2499109626526694126,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(2753988324592681474,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(2810878285747130284,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(2848885963459816804,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(2915647809434477614,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(3475034101394730335,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(3626542162137919338,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(3877673001272535186,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(4007330825134180665,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(4077358421272316858,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(4690678276679226532,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(4866304904348119643,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(5214401850561094529,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(5272799208960207736,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(5530918740051863299,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(5569314186296520615,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(5740904173463435848,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(5849452934504718062,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(6218815181136940951,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(6275945720557189700,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(6279008355318181000,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(7017987158241964732,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(7237035290160030660,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(7374688146326987272,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(7612353589185494102,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(7958180433948844465,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(8093404925372580611,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(8165972772169640480,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(8531143325322891078,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(8658728983219000078,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(8730638167239698291,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(8757751876611013998,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(8994059213096666367,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(9034558451786630908,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(9049770455330813268,NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES(9196517019233481682,NULL);
-- bwc_tag:end_query

SELECT c0, sum(c1), min(c1), max(c1) FROM t1 GROUP BY c0 ORDER BY 1, 2, 3, 4
-- bwc_tag:end_query

