-- bwc_tag:nb_steps=16
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(grp INTEGER, i INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (1, 10), (2, 15), (1, 30), (2, 20)
-- bwc_tag:end_query

SELECT FIRST(i ORDER BY i) FROM integers
-- bwc_tag:end_query

SELECT FIRST(i ORDER BY i, i, i) FROM integers
-- bwc_tag:end_query

SELECT FIRST(i ORDER BY i, i DESC, i) FROM integers
-- bwc_tag:end_query

SELECT FIRST(i ORDER BY i DESC) FROM integers
-- bwc_tag:end_query

SELECT FIRST(i ORDER BY i DESC, i ASC) FROM integers
-- bwc_tag:end_query

SELECT FIRST(i ORDER BY i), FIRST(i ORDER BY i DESC) FROM integers
-- bwc_tag:end_query

SELECT grp, FIRST(i ORDER BY i) FROM integers GROUP BY grp ORDER BY ALL
-- bwc_tag:end_query

SELECT grp, FIRST(i ORDER BY grp, i, grp DESC, i DESC) FROM integers GROUP BY grp ORDER BY ALL
-- bwc_tag:end_query

SELECT grp, FIRST(i ORDER BY i DESC) FROM integers GROUP BY grp ORDER BY ALL
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE user_causes (
    user_id INT,
    cause VARCHAR,
    "date" DATE
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO user_causes (user_id, cause, "date") VALUES
(1, 'Environmental', '2024-03-18'),
(1, 'Environmental', '2024-02-18'),
(1, 'Health', '2024-01-18'),
(1, 'Social', '2023-12-18'),
(1, NULL, '2023-11-19');
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT 
    user_id, 
    list(DISTINCT cause ORDER BY "date" DESC) FILTER(cause IS NOT NULL) AS causes
FROM user_causes 
GROUP BY user_id;
-- bwc_tag:end_query

SELECT 
    user_id, 
    list(DISTINCT cause ORDER BY cause DESC) FILTER(cause IS NOT NULL) AS causes
FROM user_causes 
GROUP BY user_id;
-- bwc_tag:end_query

