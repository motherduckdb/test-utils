-- bwc_tag:nb_steps=12
-- bwc_tag:execute_from_sql
create table a (i int primary key);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table b (i int references a);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

insert into b values (1)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into a values (1);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into b values (1)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop table b;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop table a;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table a (i int);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

create table b (i int references a);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop table a
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table a (i int, j int, primary key(i,j));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

create table b (i int references a);
-- bwc_tag:end_query

