-- bwc_tag:nb_steps=7
-- bwc_tag:execute_from_sql
create table a (a int not null, constraint pk_a primary key (A));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table b (a int references a (a));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop table b;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop table a;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table a (i int primary key);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table b (i int references A (i));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table c (i int primary key, j int references C (i));
-- bwc_tag:end_query

