-- bwc_tag:nb_steps=6
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

with RECURSIVE parents_tab (id , value , parent )
as MATERIALIZED (values (1, 1, 2), (2, 2, 4), (3, 1, 4), (4, 2, -1), (5, 1, 2), (6, 2, 7), (7, 1, -1)
),
parents_tab2(id , value , parent )
as MATERIALIZED (values (1, 1, 2), (2, 2, 4), (3, 1, 4), (4, 2, -1), (5, 1, 2), (6, 2, 7), (7, 1, -1)
),
parents as MATERIALIZED (
    select * from parents_tab
    union all
    select id, value+2, parent from parents_tab2
)
select * from parents ORDER BY id, value, parent;
-- bwc_tag:end_query

with RECURSIVE parents_tab (id , value , parent )
as MATERIALIZED (values (1, 1, 2), (2, 2, 4), (3, 1, 4), (4, 2, -1), (5, 1, 2), (6, 2, 7), (7, 1, -1)
),
parents_tab2(id , value , parent )
as MATERIALIZED (values (1, 1, 2), (2, 2, 4), (3, 1, 4), (4, 2, -1), (5, 1, 2), (6, 2, 7), (7, 1, -1)
)
select * from parents_tab
union all
select id, value+2, parent from parents_tab2 ORDER BY id, value, parent;
-- bwc_tag:end_query

with parents_tab (id , value , parent )
as MATERIALIZED (values (1, 1, 2), (2, 2, 4), (3, 1, 4), (4, 2, -1), (5, 1, 2), (6, 2, 7), (7, 1, -1)
),
parents_tab2(id , value , parent )
as MATERIALIZED (values (1, 1, 2), (2, 2, 4), (3, 1, 4), (4, 2, -1), (5, 1, 2), (6, 2, 7), (7, 1, -1)
),
parents as MATERIALIZED (
    select * from parents_tab
    union all
    select id, value+2, parent from parents_tab2
)
select * from parents ORDER BY id, value, parent;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create view vparents as
with RECURSIVE parents_tab (id , value , parent )
as MATERIALIZED (values (1, 1, 2), (2, 2, 4), (3, 1, 4), (4, 2, -1), (5, 1, 2), (6, 2, 7), (7, 1, -1)
),
parents_tab2 (id , value , parent )
as MATERIALIZED (values (1, 1, 2), (2, 2, 4), (3, 1, 4), (4, 2, -1), (5, 1, 2), (6, 2, 7), (7, 1, -1)
)
select * from parents_tab
union all
select id, value+2, parent from parents_tab2;
-- bwc_tag:end_query

select * from vparents ORDER BY id, value, parent;
-- bwc_tag:end_query

