-- bwc_tag:nb_steps=27
SET default_null_order='nulls_first';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

(VALUES (1, 3), (2, 4));
-- bwc_tag:end_query

SELECT * FROM (VALUES (NULL, NULL), (3, 4), (3, 7)) v1;
-- bwc_tag:end_query

SELECT * FROM (VALUES (1, 2, 3), (1, 2, 3)) v1;
-- bwc_tag:end_query

SELECT * FROM (VALUES (1 + 1, 2, 3), (1 + 3, 2, 3)) v1;
-- bwc_tag:end_query

SELECT * FROM (VALUES ((SELECT 42), 2, 3), (1 + 3,2,3)) v1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test (a INTEGER, b INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (1, 2), (3, 4);
-- bwc_tag:end_query

SELECT * FROM (VALUES ((SELECT MIN(a) FROM test), 2, 3), ((SELECT MAX(b) FROM test), 2, 3)) v1;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM (VALUES ('hello', 2), (1 + 3, '5'), (DATE '1992-09-20', 3)) v1;
-- bwc_tag:end_query

SELECT * FROM (VALUES (DATE '1992-09-20', 3), (NULL, NULL)) v1;
-- bwc_tag:end_query

SELECT * FROM (VALUES (NULL, NULL)) v1;
-- bwc_tag:end_query

SELECT * FROM (VALUES (NULL, NULL), (3, 4)) v1;
-- bwc_tag:end_query

SELECT * FROM (VALUES (3), ('42')) v1;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM (VALUES (3), ('hello')) v1;
-- bwc_tag:end_query

SELECT typeof(x) FROM (VALUES (DATE '1992-01-01'), ('1992-01-01')) v1(x) LIMIT 1;
-- bwc_tag:end_query

SELECT * FROM (VALUES (NULL), ('hello')) v1;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM (VALUES (1, 2, 3), (1,2)) v1;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM (VALUES (DEFAULT, 2, 3), (1,2)) v1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE varchars(v VARCHAR);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO varchars VALUES (1), ('hello'), (DEFAULT);
-- bwc_tag:end_query

SELECT * FROM varchars ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO varchars VALUES (1, 2), ('hello', 3), (DEFAULT, DEFAULT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO varchars (v) VALUES (1, 2), ('hello', 3), (DEFAULT, DEFAULT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO varchars (v) VALUES (1, 2), ('hello'), (DEFAULT, DEFAULT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO varchars (v) VALUES (DEFAULT IS NULL);
-- bwc_tag:end_query

