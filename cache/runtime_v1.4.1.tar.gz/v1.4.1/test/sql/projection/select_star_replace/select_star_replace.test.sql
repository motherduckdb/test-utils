-- bwc_tag:nb_steps=11
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER, j INTEGER, k INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (1, 2, 3)
-- bwc_tag:end_query

SELECT * REPLACE i+100 AS i FROM integers
-- bwc_tag:end_query

SELECT * EXCLUDE (j, k) REPLACE (i+100 AS i), * EXCLUDE (j) REPLACE (i+100 AS i), * EXCLUDE (j, k) REPLACE (i+101 AS i) FROM integers
-- bwc_tag:end_query

SELECT * REPLACE (i+100 AS i, j+200 AS "J") FROM integers
-- bwc_tag:end_query

SELECT integers.* REPLACE (i+100 AS i) FROM integers
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * REPLACE (i+100 AS i, i+200 AS i) FROM integers
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * REPLACE (i+100 AS blabla) FROM integers
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT integers.* REPLACE (i+100 AS blabla) FROM integers
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * EXCLUDE (i) REPLACE (i+100 AS i) FROM integers
-- bwc_tag:end_query

