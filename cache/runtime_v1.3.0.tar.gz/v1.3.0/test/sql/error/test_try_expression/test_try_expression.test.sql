-- bwc_tag:nb_steps=15
-- bwc_tag:skip_query
pragma enable_verification;
-- bwc_tag:end_query

select TRY('abc'::INTEGER)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select ~CAST('abc' as INTEGER)
-- bwc_tag:end_query

select TRY(~CAST('abc' as INTEGER))
-- bwc_tag:end_query

select TRY(CAST('abc' as INTEGER) IS NULL);
-- bwc_tag:end_query

select TRY(CAST('abc' as INTEGER) IS NOT NULL);
-- bwc_tag:end_query

select TRY(CAST('abc' as INTEGER) == 'abc')
-- bwc_tag:end_query

select TRY(CAST('abc' as INTEGER) == 'abc')
-- bwc_tag:end_query

select TRY(CAST('abc' as INTEGER) != 'abc')
-- bwc_tag:end_query

select TRY(ln(0));
-- bwc_tag:end_query

with cte as (
	select * from (VALUES
		('123'),
		('test'),
		('235')
	) t(a)
)
select try(a::INTEGER) from cte
-- bwc_tag:end_query

with cte as (
	select i % 5 i from range(100_000) t(i)
),
cte2 as (
	select if(i == 0, NULL, i) res from cte
)
select count(res) from cte2;
-- bwc_tag:end_query

with cte as (
	select i % 5 i from range(100_000) t(i)
),
cte2 as (
	select TRY(if(i == 0, 'abc', i::VARCHAR)::BIGINT) res from cte
)
select count(res) from cte2;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select try(if(random() > 2.0, '123', 'abc')::TINYINT)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select try(CAST((select 'ABC') as INTEGER))
-- bwc_tag:end_query

