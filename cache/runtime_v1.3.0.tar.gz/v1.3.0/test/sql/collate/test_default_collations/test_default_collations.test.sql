-- bwc_tag:nb_steps=8
-- bwc_tag:execute_from_sql
PRAGMA default_collation='NOCASE'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE collate_test(s VARCHAR)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO collate_test VALUES ('hEllO'), ('WöRlD'), ('wozld')
-- bwc_tag:end_query

SELECT COUNT(*) FROM collate_test WHERE 'BlA'='bLa'
-- bwc_tag:end_query

SELECT * FROM collate_test WHERE s='hello'
-- bwc_tag:end_query

SELECT * FROM collate_test ORDER BY s
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA default_collation='NOCASE.NOACCENT'
-- bwc_tag:end_query

SELECT * FROM collate_test ORDER BY s
-- bwc_tag:end_query

