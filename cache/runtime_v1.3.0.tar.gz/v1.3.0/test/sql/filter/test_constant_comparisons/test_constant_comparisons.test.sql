-- bwc_tag:nb_steps=24
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(a INTEGER, b INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (2, 12)
-- bwc_tag:end_query

SELECT * FROM integers WHERE 2=2
-- bwc_tag:end_query

SELECT * FROM integers WHERE 2=3
-- bwc_tag:end_query

SELECT * FROM integers WHERE 2<>3
-- bwc_tag:end_query

SELECT * FROM integers WHERE 2<>2
-- bwc_tag:end_query

SELECT * FROM integers WHERE 2>1
-- bwc_tag:end_query

SELECT * FROM integers WHERE 2>2
-- bwc_tag:end_query

SELECT * FROM integers WHERE 2>=2
-- bwc_tag:end_query

SELECT * FROM integers WHERE 2>=3
-- bwc_tag:end_query

SELECT * FROM integers WHERE 2<3
-- bwc_tag:end_query

SELECT * FROM integers WHERE 2<2
-- bwc_tag:end_query

SELECT * FROM integers WHERE 2<=2
-- bwc_tag:end_query

SELECT * FROM integers WHERE 2<=1
-- bwc_tag:end_query

SELECT a=NULL FROM integers
-- bwc_tag:end_query

SELECT NULL=a FROM integers
-- bwc_tag:end_query

SELECT * FROM integers WHERE 2 IN (2, 3, 4, 5)
-- bwc_tag:end_query

SELECT * FROM integers WHERE 2 NOT IN (2, 3, 4, 5)
-- bwc_tag:end_query

SELECT * FROM integers WHERE 2 IN (((1*2)+(1*0))*1, 3, 4, 5)
-- bwc_tag:end_query

SELECT * FROM integers WHERE 2 IN ((1+1)*2, 3, 4, 5)
-- bwc_tag:end_query

SELECT CASE WHEN 1 THEN 13 ELSE 12 END;
-- bwc_tag:end_query

SELECT * FROM integers WHERE CASE WHEN 2=2 THEN true ELSE false END;
-- bwc_tag:end_query

SELECT * FROM integers WHERE CASE WHEN 2=3 THEN true ELSE false END;
-- bwc_tag:end_query

