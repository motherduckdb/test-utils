-- bwc_tag:nb_steps=50
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE vals1 AS SELECT i AS i, i AS j FROM range(0, 11, 1) t1(i)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO vals1 SELECT i, i+1 FROM vals1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO vals1 SELECT DISTINCT(i), i-1 FROM vals1 ORDER by i
-- bwc_tag:end_query

SELECT * FROM vals1 WHERE i=5 AND j>=i
-- bwc_tag:end_query

SELECT * FROM vals1 WHERE i>9 AND j>=i
-- bwc_tag:end_query

SELECT * FROM vals1 WHERE i>=10 AND j>=i
-- bwc_tag:end_query

SELECT * FROM vals1 WHERE i<1 AND j>=i
-- bwc_tag:end_query

SELECT * FROM vals1 WHERE i<=0 AND j>=i
-- bwc_tag:end_query

SELECT * FROM vals1 WHERE i=5 AND j<=i
-- bwc_tag:end_query

SELECT * FROM vals1 WHERE i>9 AND j<=i
-- bwc_tag:end_query

SELECT * FROM vals1 WHERE i>=10 AND j<=i
-- bwc_tag:end_query

SELECT * FROM vals1 WHERE i<1 AND j<=i
-- bwc_tag:end_query

SELECT * FROM vals1 WHERE i<=0 AND j<=i
-- bwc_tag:end_query

SELECT * FROM vals1 WHERE i=5 AND j>i
-- bwc_tag:end_query

SELECT * FROM vals1 WHERE i>9 AND j>i
-- bwc_tag:end_query

SELECT * FROM vals1 WHERE i>=10 AND j>i
-- bwc_tag:end_query

SELECT * FROM vals1 WHERE i<1 AND j>i
-- bwc_tag:end_query

SELECT * FROM vals1 WHERE i<=0 AND j>i
-- bwc_tag:end_query

SELECT * FROM vals1 WHERE i=5 AND j<i
-- bwc_tag:end_query

SELECT * FROM vals1 WHERE i>9 AND j<i
-- bwc_tag:end_query

SELECT * FROM vals1 WHERE i>=10 AND j<i
-- bwc_tag:end_query

SELECT * FROM vals1 WHERE i<1 AND j<i
-- bwc_tag:end_query

SELECT * FROM vals1 WHERE i<=0 AND j<i
-- bwc_tag:end_query

SELECT * FROM vals1 WHERE j>=i AND i=5
-- bwc_tag:end_query

SELECT * FROM vals1 WHERE j>=i AND i>9
-- bwc_tag:end_query

SELECT * FROM vals1 WHERE j>=i AND i>=10
-- bwc_tag:end_query

SELECT * FROM vals1 WHERE j>=i AND i<1
-- bwc_tag:end_query

SELECT * FROM vals1 WHERE j>=i AND i<=0
-- bwc_tag:end_query

SELECT * FROM vals1 WHERE j<=i AND i=5
-- bwc_tag:end_query

SELECT * FROM vals1 WHERE j<=i AND i>9
-- bwc_tag:end_query

SELECT * FROM vals1 WHERE j<=i AND i>=10
-- bwc_tag:end_query

SELECT * FROM vals1 WHERE j<=i AND i<1
-- bwc_tag:end_query

SELECT * FROM vals1 WHERE j<=i AND i<=0
-- bwc_tag:end_query

SELECT * FROM vals1 WHERE j>i AND i=5
-- bwc_tag:end_query

SELECT * FROM vals1 WHERE j>i AND i>9
-- bwc_tag:end_query

SELECT * FROM vals1 WHERE j>i AND i>=10
-- bwc_tag:end_query

SELECT * FROM vals1 WHERE j>i AND i<1
-- bwc_tag:end_query

SELECT * FROM vals1 WHERE j>i AND i<=0
-- bwc_tag:end_query

SELECT * FROM vals1 WHERE j<i AND i=5
-- bwc_tag:end_query

SELECT * FROM vals1 WHERE j<i AND i>9
-- bwc_tag:end_query

SELECT * FROM vals1 WHERE j<i AND i>=10
-- bwc_tag:end_query

SELECT * FROM vals1 WHERE j<i AND i<1
-- bwc_tag:end_query

SELECT * FROM vals1 WHERE j<i AND i<=0
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE vals2(k BIGINT, l BIGINT)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO vals2 SELECT * FROM vals1
-- bwc_tag:end_query

SELECT * FROM vals1, vals2 WHERE i>9 AND j<=l AND k>=i AND l<11
ORDER BY 2 DESC, 4 DESC
-- bwc_tag:end_query

SELECT * FROM vals1, vals2 WHERE i>9 AND j>=i AND k>=j ORDER by l
-- bwc_tag:end_query

SELECT * FROM vals1, vals2 WHERE i>9 AND k>=j AND j>=i AND l>=k
-- bwc_tag:end_query

SELECT * FROM vals1, vals2 WHERE i<1 AND k<=j AND j<=i AND l<=k
-- bwc_tag:end_query

