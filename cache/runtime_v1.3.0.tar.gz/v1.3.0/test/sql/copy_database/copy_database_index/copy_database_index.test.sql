-- bwc_tag:nb_steps=14
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

ATTACH DATABASE ':memory:' AS db1;
-- bwc_tag:end_query

USE db1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test(a INTEGER, b INTEGER, c VARCHAR(10));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE INDEX i_index ON test(a);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test SELECT range, 88, 'hello' FROM range(10000);
-- bwc_tag:end_query

EXPLAIN ANALYZE SELECT a, b, c FROM db1.test WHERE a = 42;
-- bwc_tag:end_query

SELECT a, b, c FROM db1.test WHERE a = 42;
-- bwc_tag:end_query

COPY FROM DATABASE db1 TO memory
-- bwc_tag:end_query

USE memory
-- bwc_tag:end_query

SELECT * FROM test WHERE a = 42;
-- bwc_tag:end_query

EXPLAIN ANALYZE SELECT * FROM test WHERE a = 42;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP INDEX i_index;
-- bwc_tag:end_query

EXPLAIN ANALYZE SELECT * FROM test WHERE a = 42;
-- bwc_tag:end_query

