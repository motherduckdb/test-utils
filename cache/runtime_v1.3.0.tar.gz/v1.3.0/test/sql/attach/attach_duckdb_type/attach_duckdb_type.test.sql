-- bwc_tag:nb_steps=5
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

ATTACH 'output/first.db' (TYPE DUCKDB);
-- bwc_tag:end_query

SELECT database_name FROM duckdb_databases() ORDER BY 1;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

ATTACH 'output/error.db' (TYPE DUCKDB, HELLO, OPTION 2);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

ATTACH 'output/error.db' (HELLO, OPTION 2);
-- bwc_tag:end_query

