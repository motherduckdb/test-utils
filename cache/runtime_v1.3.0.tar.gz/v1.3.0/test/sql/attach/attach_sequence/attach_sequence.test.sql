-- bwc_tag:nb_steps=10
ATTACH DATABASE 'output/attach_seq.db' AS db1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE seq;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE TABLE db1.integers(i INTEGER DEFAULT nextval('seq'))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE db1.seq
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE db1.integers(i INTEGER DEFAULT nextval('db1.seq'))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('db1.seq')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('seq')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE TABLE integers(i INTEGER DEFAULT nextval('db1.seq'))
-- bwc_tag:end_query

detach db1;
-- bwc_tag:end_query

ATTACH DATABASE 'output/attach_seq.db' AS db1;
-- bwc_tag:end_query

