-- bwc_tag:nb_steps=17
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

ATTACH 'output/version_1_2_0.db' (STORAGE_VERSION 'v1.2.0');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE version_1_2_0.lists(l integer[], initial integer);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO version_1_2_0.lists VALUES ([1], -1), ([1, 2, 3], -2), (NULL, -3), ([-1, NULL, 2], -3);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW version_1_2_0.reduced_lists AS
	SELECT list_reduce(l, LAMBDA x, y : x + y, initial) AS r FROM version_1_2_0.lists;
-- bwc_tag:end_query

FROM version_1_2_0.reduced_lists;
-- bwc_tag:end_query

DETACH version_1_2_0
-- bwc_tag:end_query

ATTACH 'output/version_1_2_0.db'
-- bwc_tag:end_query

FROM version_1_2_0.reduced_lists;
-- bwc_tag:end_query

ATTACH 'output/version_1_3_0.db' (STORAGE_VERSION 'v1.3.0');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE version_1_3_0.lists(l integer[], initial integer);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO version_1_3_0.lists VALUES ([1], -1), ([1, 2, 3], -2), (NULL, -3), ([-1, NULL, 2], -3);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW version_1_3_0.reduced_lists AS
	SELECT list_reduce(l, LAMBDA x, y : x + y, initial) AS r FROM version_1_3_0.lists;
-- bwc_tag:end_query

FROM version_1_3_0.reduced_lists;
-- bwc_tag:end_query

DETACH version_1_3_0
-- bwc_tag:end_query

ATTACH 'output/version_1_3_0.db'
-- bwc_tag:end_query

FROM version_1_3_0.reduced_lists;
-- bwc_tag:end_query

