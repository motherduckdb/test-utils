-- bwc_tag:nb_steps=6
-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER PRIMARY KEY)
-- bwc_tag:end_query

-- bwc_tag:skip_query
BEGIN TRANSACTION
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (1);
-- bwc_tag:end_query

-- bwc_tag:skip_query
ROLLBACK
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (1);
-- bwc_tag:end_query

SELECT * FROM integers
-- bwc_tag:end_query

