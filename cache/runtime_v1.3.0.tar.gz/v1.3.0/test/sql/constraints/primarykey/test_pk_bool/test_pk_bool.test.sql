-- bwc_tag:nb_steps=5
-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER, j BOOLEAN, PRIMARY KEY(i, j))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (1, false), (1, true), (2, false)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO integers VALUES (1, false)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (2, true)
-- bwc_tag:end_query

SELECT * FROM integers ORDER BY 1, 2
-- bwc_tag:end_query

