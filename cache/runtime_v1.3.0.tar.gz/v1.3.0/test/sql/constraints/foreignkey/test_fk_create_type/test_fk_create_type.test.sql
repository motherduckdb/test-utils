-- bwc_tag:nb_steps=8
-- bwc_tag:execute_from_sql
create type custom_type as integer;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table parent (
	id custom_type primary key
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table child (
	parent custom_type references parent
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop table child;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table child (
	parent integer references parent
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop table child;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create type another_custom_type as integer;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table child (
	parent another_custom_type references parent
);
-- bwc_tag:end_query

