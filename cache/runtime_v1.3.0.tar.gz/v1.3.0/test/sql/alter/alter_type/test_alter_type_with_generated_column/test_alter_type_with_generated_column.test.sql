-- bwc_tag:nb_steps=6
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test(i AS (1), j INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (1), (2)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE test ALTER i TYPE VARCHAR
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test ALTER j TYPE VARCHAR
-- bwc_tag:end_query

SELECT * FROM test
-- bwc_tag:end_query

