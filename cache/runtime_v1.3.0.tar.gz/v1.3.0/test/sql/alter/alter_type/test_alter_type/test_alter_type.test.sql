-- bwc_tag:nb_steps=18
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test(i INTEGER, j INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (1, 1), (2, 2)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test ALTER i SET DATA TYPE VARCHAR
-- bwc_tag:end_query

SELECT * FROM test ORDER BY ALL
-- bwc_tag:end_query

SELECT * FROM test WHERE i = '1'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test ALTER i SET DATA TYPE INTEGER
-- bwc_tag:end_query

SELECT * FROM test WHERE i = 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA disable_verification
-- bwc_tag:end_query

SELECT stats(i) FROM test LIMIT 1
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE test ALTER not_a_column SET DATA TYPE INTEGER
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tbl (col STRUCT(i INT));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO tbl SELECT {'i': range} FROM range(5000);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE tbl ALTER col TYPE USING struct_insert(col, a := 42, b := NULL::VARCHAR);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO tbl VALUES ({'i': 10000, 'a': NULL, 'b': 'hello'});
-- bwc_tag:end_query

SELECT col FROM tbl ORDER BY col DESC LIMIT 3;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE tbl ALTER col TYPE;
-- bwc_tag:end_query

