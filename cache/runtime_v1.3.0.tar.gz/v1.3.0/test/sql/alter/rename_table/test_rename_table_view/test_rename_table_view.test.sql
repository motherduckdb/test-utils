-- bwc_tag:nb_steps=5
-- bwc_tag:execute_from_sql
CREATE TABLE tbl(i INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO tbl VALUES (999), (100)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW v1 AS SELECT * FROM tbl
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE v1 RENAME TO v2
-- bwc_tag:end_query

SELECT * FROM v1
-- bwc_tag:end_query

