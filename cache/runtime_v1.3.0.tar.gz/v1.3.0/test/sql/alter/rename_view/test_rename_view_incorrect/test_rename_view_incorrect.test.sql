-- bwc_tag:nb_steps=5
-- bwc_tag:execute_from_sql
CREATE TABLE tbl(i INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW vw AS SELECT * FROM tbl
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW vw2 AS SELECT 1729 AS i
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER VIEW non_view RENAME TO vw
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER VIEW vw2 RENAME TO vw
-- bwc_tag:end_query

