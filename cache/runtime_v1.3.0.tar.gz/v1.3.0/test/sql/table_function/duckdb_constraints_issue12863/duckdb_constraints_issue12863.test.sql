-- bwc_tag:nb_steps=8
-- bwc_tag:skip_query
pragma enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE a (ID int PRIMARY KEY);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE b (id int REFERENCES A);
-- bwc_tag:end_query

SELECT constraint_name, unique_constraint_name FROM information_schema.referential_constraints;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA s1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE s1.a (ID int PRIMARY KEY);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE s1.b (id int REFERENCES s1.A);
-- bwc_tag:end_query

SELECT COUNT(*) FROM information_schema.referential_constraints;
-- bwc_tag:end_query

