-- bwc_tag:nb_steps=48
-- bwc_tag:skip_query
PRAGMA enable_verification;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tbl(a int);
-- bwc_tag:end_query

WITH RECURSIVE tbl(a) USING KEY (a) AS (SELECT 1 UNION SELECT a.a+1 FROM tbl AS a, (SELECT * FROM recurring.tbl AS d WHERE d.a = 1) AS b WHERE a.a < 2) SELECT * FROM tbl;
-- bwc_tag:end_query

WITH RECURSIVE tbl2(a, b) USING KEY (a) AS (SELECT 5, 1 UNION SELECT a, b + 1 FROM recurring.tbl2 WHERE b < a) SELECT * FROM tbl2;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

WITH RECURSIVE tbl(a) USING KEY (b) AS (SELECT 1 UNION SELECT a.a+1 FROM tbl AS a, (SELECT * FROM recurring.tbl AS d WHERE d.a = 1) AS b WHERE a.a < 2) SELECT * FROM tbl;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

WITH RECURSIVE tbl(a) USING KEY (a) AS (SELECT 1 UNION ALL SELECT a+1 FROM tbl) SELECT * FROM tbl;
-- bwc_tag:end_query

WITH RECURSIVE tbl2(a,b) USING KEY (a) AS (SELECT 1, NULL UNION SELECT a.a+1, a.b FROM tbl2 AS a, (SELECT * FROM recurring.tbl2) AS b WHERE a.a < 2) SELECT * FROM tbl2;
-- bwc_tag:end_query

WITH RECURSIVE tbl(a,b,c) USING KEY (a) AS (SELECT * FROM (VALUES (1, 2, 3), (2,2,5)) UNION SELECT a+1, b+1, c FROM tbl WHERE b < 4) SELECT * FROM  tbl;
-- bwc_tag:end_query

WITH RECURSIVE tbl(a,b,c) USING KEY (b) AS (SELECT * FROM (VALUES (1, 2, 3), (2,3,2)) UNION SELECT a, b+1, c FROM tbl WHERE b < 4) SELECT * FROM  tbl;
-- bwc_tag:end_query

WITH RECURSIVE tbl(a,b,c) USING KEY (a) AS (SELECT * FROM (VALUES (1, 2, 3), (2,3,2)) UNION SELECT a, b+1, c FROM tbl WHERE b < 4) SELECT * FROM  tbl;
-- bwc_tag:end_query

WITH RECURSIVE tbl(a,b,c) USING KEY (b,c) AS (SELECT * FROM (VALUES (1, 2, 3), (2,3,3)) UNION SELECT a, b+1, c FROM tbl WHERE b < 4) SELECT * FROM  tbl;
-- bwc_tag:end_query

WITH RECURSIVE tbl(a,b,c) USING KEY (a,b,c) AS (SELECT * FROM (VALUES (1, 2, 3), (2,3,3)) UNION SELECT a, b+1, c FROM tbl WHERE b < 4) SELECT * FROM  tbl;
-- bwc_tag:end_query

WITH RECURSIVE tbl(a,b,c) USING KEY (a) AS (SELECT * FROM (VALUES (1, 2, 3), (1,3,3)) UNION SELECT a, b+1, c FROM tbl WHERE b < 4) SELECT * FROM  tbl;
-- bwc_tag:end_query

WITH RECURSIVE tbl(a,b,c) USING KEY (a,b,c) AS (SELECT * FROM (VALUES (1, 2, 3), (1,3,3)) UNION SELECT a, b+1, c FROM tbl WHERE b < 4) SELECT * FROM  tbl;
-- bwc_tag:end_query

WITH RECURSIVE tbl(a,b,c) USING KEY (a) AS (
	SELECT 1, NULL, NULL
	UNION
	(SELECT DISTINCT ON (tbl.a) tbl.a+1, rec1.a, rec2.b
	FROM tbl, recurring.tbl AS rec1, recurring.tbl AS rec2
	WHERE tbl.a < 5
	ORDER BY tbl.a ASC, rec1.a DESC NULLS LAST, rec2.b DESC NULLS LAST
	)
) SELECT * FROM tbl;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM  recurring.tbl;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

WITH RECURSIVE tbl2(a) AS (SELECT 1 UNION SELECT a.a + 1 FROM tbl2 AS a, recurring.tbl2 AS b WHERE a.a < 2) SELECT * FROM tbl2;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

WITH RECURSIVE tbl2(a,b) AS (SELECT 1, NULL UNION SELECT a.a+1, a.b FROM tbl2 AS a, (SELECT * FROM recurring.tbl2) AS b WHERE a.a < 2) SELECT * FROM tbl2;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

WITH RECURSIVE tbl(a, b) USING KEY (a) AS (SELECT 5, 1 UNION SELECT a, b + 1 FROM tbl WHERE b < a),
tbl1(a,b) AS (SELECT * FROM recurring.tbl) SELECT * FROM tbl1;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

WITH RECURSIVE tbl(a, b) USING KEY (a) AS (SELECT  * FROM ((VALUES (5, 1), (6,1)) UNION SELECT a, b + 1 FROM recurring.tbl WHERE b < a) WHERE a = 5),
tbl1(a,b) AS (SELECT * FROM recurring.tbl) SELECT * FROM tbl1;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

WITH RECURSIVE tbl2(a) AS (SELECT 1 UNION SELECT a.a+1 FROM tbl2 AS a, (SELECT * FROM recurring.tbl2) AS b WHERE a.a < 2) SELECT * FROM tbl2;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

WITH RECURSIVE tbl(a, b) USING KEY (a) AS (SELECT 5, 1 UNION SELECT a, b + 1 FROM tbl WHERE b < a),tbl1(a,b) AS (SELECT * FROM recurring.tbl) SELECT * FROM tbl1;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

WITH RECURSIVE tbl(a, b) USING KEY (a) AS MATERIALIZED (SELECT 5, 1 UNION SELECT a, b + 1 FROM tbl WHERE b < a),tbl1(a,b) AS (SELECT * FROM recurring.tbl) SELECT * FROM tbl1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE nodes (node int);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO nodes VALUES (0), (1), (2), (3), (4), (5), (6);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE edges (here int, there int);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO edges VALUES  (0,4), (4,0),
						  (0,3), (3,0),
						  (1,4), (4,1),
						  (3,4), (4,3),
						  (2,5), (5,2);
-- bwc_tag:end_query

WITH RECURSIVE cc(node, comp) USING KEY (node) AS (
	SELECT n.node, n.node AS comp
	FROM nodes AS n
		UNION
	(SELECT DISTINCT ON (u.node) u.node, v.comp
	FROM recurring.cc AS u, cc AS v, edges AS e
	WHERE (e.here, e.there) = (u.node, v.node)
	AND v.comp < u.comp
	ORDER BY u.node asc, v.comp asc)
)
TABLE cc ORDER BY node;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE edges (here   char(2), -- source node
  							   there  char(2), -- target node
  							   length int,  -- edge weight
  							   PRIMARY KEY (here, there));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO edges(here, there, length) VALUES
  ('v0', 'v1', 9),
  ('v0', 'v2', 3),
  ('v1', 'v2', 6),
  ('v1', 'v4', 2),
  ('v2', 'v1', 2),
  ('v2', 'v3', 1),
  ('v3', 'v2', 2),
  ('v3', 'v4', 2);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE nodes;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE VIEW nodes(node) AS
  SELECT e.here
  FROM   edges AS e
   UNION
  SELECT e.there
  FROM   edges AS e;
-- bwc_tag:end_query

WITH RECURSIVE bellman(knode, distance) USING KEY (knode) AS (
  -- distance is 0 from source, ∞ from any other node
  SELECT n.node AS knode,
         CASE WHEN n.node = 'v0' THEN 0 ELSE 50000000 END AS distance
  FROM   nodes AS n
  UNION
  (SELECT DISTINCT ON (knode) rec.knode AS knode, n.distance + e.length AS distance
  FROM   bellman AS n, edges AS e, recurring.bellman AS rec
  WHERE  (e.here, e.there) = (n.knode, rec.knode)
  AND    rec.distance > n.distance + e.length
  ORDER BY distance)
)
SELECT n.knode || CASE WHEN n.knode = 'v0' THEN ' (source)' ELSE '' END AS node,
       n.distance
FROM   bellman AS n
ORDER BY n.knode;
-- bwc_tag:end_query

WITH RECURSIVE tbl(n) USING KEY (n) AS (SELECT 1 UNION SELECT n+1 FROM tbl WHERE n < 3000) SELECT SUM(n) FROM tbl
-- bwc_tag:end_query

WITH RECURSIVE tbl (a, b) USING KEY (a) AS (SELECT 1 , 1 UNION SELECT a, b+1 FROM tbl WHERE b < 3), tbl2(a,b) AS (SELECT 1, 1 UNION SELECT a, b+1 FROM tbl2 WHERE b < 3) SELECT * FROM tbl;
-- bwc_tag:end_query

WITH RECURSIVE tbl (a, b) USING KEY (a) AS (SELECT 1 , 1 UNION SELECT a, b+1 FROM tbl WHERE b < 3), tbl2(a,b) AS (SELECT 1, 1 UNION SELECT a, b+1 FROM tbl2 WHERE b < 3) SELECT * FROM tbl2;
-- bwc_tag:end_query

WITH RECURSIVE tbl2(a,b) AS (SELECT 1, 1 UNION SELECT a, b+1 FROM tbl2 WHERE b < 3), tbl (a, b) USING KEY (a) AS (SELECT 1 , 1 UNION SELECT a, b+1 FROM tbl WHERE b < 3) SELECT * FROM tbl2;
-- bwc_tag:end_query

WITH RECURSIVE tbl2(a,b) AS (SELECT 1, 1 UNION SELECT a, b+1 FROM tbl2 WHERE b < 3), tbl (a, b) USING KEY (a) AS (SELECT 1 , 1 UNION SELECT a, b+1 FROM tbl WHERE b < 3) SELECT * FROM tbl;
-- bwc_tag:end_query

WITH RECURSIVE tbl(a, b) AS (
	SELECT 1, 1
		UNION
	(WITH RECURSIVE tbl2(a, b) USING KEY (b) AS (
		SELECT a, b+1 FROM tbl WHERE b < 5
			UNION
		SELECT a + 1, b
		FROM tbl2
		WHERE a < 5) SELECT * FROM tbl2))
SELECT * FROM tbl
-- bwc_tag:end_query

WITH RECURSIVE tbl(a, b) USING KEY (b) AS (
	SELECT 1, 1
		UNION
	(WITH RECURSIVE tbl2(a, b) AS (
		SELECT a, b+1 FROM tbl WHERE b < 5
			UNION
		SELECT a + 1, b
		FROM tbl2
		WHERE a < 5) SELECT * FROM tbl2 ORDER BY a))
SELECT * FROM tbl
-- bwc_tag:end_query

WITH RECURSIVE tbl(a, b) USING KEY (b) AS (
	SELECT 1, 1
		UNION
	(SELECT * FROM (WITH RECURSIVE tbl2(a, b) AS (
		SELECT a, b+1 FROM tbl WHERE b < 5
			UNION
		SELECT a + 1, b
		FROM tbl2
		WHERE a < 5) SELECT * FROM tbl2 ORDER BY a, b)))
SELECT * FROM tbl
-- bwc_tag:end_query

WITH RECURSIVE tbl(a,b) USING KEY (a) AS (SELECT 1, 1 UNION SELECT a, b+1 FROM tbl WHERE b < 5),
tbl2(a,b) AS (SELECT 1, 1 UNION SELECT a, b+1 FROM tbl2 WHERE b < 5)
SELECT *
FROM tbl2
-- bwc_tag:end_query

WITH RECURSIVE tbl(a,b) USING KEY (a) AS (SELECT 1, 1 UNION SELECT a, b+1 FROM tbl WHERE b < 5),
tbl2(a,b) AS (SELECT 1, 1 UNION SELECT a, b+1 FROM tbl2 WHERE b < 5)
SELECT *
FROM tbl
-- bwc_tag:end_query

WITH RECURSIVE tbl(a,b) AS (SELECT 1, 1 UNION SELECT a, b+1 FROM tbl WHERE b < 5),
tbl2(a,b) USING KEY (a) AS (SELECT 1, 1 UNION SELECT a, b+1 FROM tbl2 WHERE b < 5)
SELECT *
FROM tbl2
-- bwc_tag:end_query

WITH RECURSIVE tbl(a,b) AS (SELECT 1, 1 UNION SELECT a, b+1 FROM tbl WHERE b < 5),
tbl2(a,b) USING KEY (a) AS (SELECT 1, 1 UNION SELECT a, b+1 FROM tbl2 WHERE b < 5)
SELECT *
FROM tbl
-- bwc_tag:end_query

WITH RECURSIVE tbl(a, b, c) USING KEY (a) AS ((SELECT [], 1, 3 UNION SELECT [1], 2, 4) UNION SELECT a || [b], b + 1, c FROM tbl WHERE b < 5) SELECT * FROM tbl ORDER BY len(a)
-- bwc_tag:end_query

WITH RECURSIVE tbl(a, b) USING KEY (a) AS (SELECT 'string', 1 UNION SELECT a, b + 1 FROM tbl WHERE b < 5) SELECT * FROM tbl
-- bwc_tag:end_query

select  *
  from    range(1, 4) as _(l),
  lateral (
    with recursive cte(a, b) using key (a) as (
      select 1, 0
        union
      select a, b + 1
      from   recurring.cte
      where  b < l
    )
    table cte
  ) ORDER BY l
-- bwc_tag:end_query

