-- bwc_tag:nb_steps=1
with
    system_types as (
        select distinct
            type_name as label,
            'type' as type_label,
            1000 as priority,
            null as context
        from duckdb_types()
        where database_name = 'system'
    ),
    custom_types as (
        select distinct
            type_name as label,
            'type' as type_label,
            1000 as priority,
            schema_name as context
        from duckdb_types()
        where
            database_name not in ('system', 'temp')
            and type_name not in (select label from system_types)
    )
select *
from system_types
union all
select *
from custom_types
-- bwc_tag:end_query

