-- bwc_tag:nb_steps=9
-- bwc_tag:execute_from_sql
PRAGMA enable_logging('FileSystem');
-- bwc_tag:end_query

copy (select 1 as a) to 'output/par.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM 'output/par.csv'
-- bwc_tag:end_query

SELECT type, log_level, scope, fs, parse_filename(path), op, bytes, pos FROM duckdb_logs_parsed('FileSystem') ORDER BY timestamp
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
pragma truncate_duckdb_logs
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA enable_logging('QueryLog');
-- bwc_tag:end_query

SELECT 'hallo' as value;
-- bwc_tag:end_query

SELECT type, log_level, scope, message FROM duckdb_logs_parsed('QueryLog') ORDER BY timestamp
-- bwc_tag:end_query

SELECT type, log_level, scope, message FROM duckdb_logs WHERE type='QueryLog';
-- bwc_tag:end_query

