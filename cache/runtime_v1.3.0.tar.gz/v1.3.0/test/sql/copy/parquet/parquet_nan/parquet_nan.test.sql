-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=6
LOAD 'parquet';
-- bwc_tag:end_query

select * from parquet_scan('data/parquet-testing/nan-float.parquet') order by 1
-- bwc_tag:end_query

select * from parquet_scan('data/parquet-testing/arrow_nan.parquet') where f='nan';
-- bwc_tag:end_query

select * from parquet_scan('data/parquet-testing/arrow_nan.parquet') where f>10;
-- bwc_tag:end_query

select * from parquet_scan('data/parquet-testing/arrow_nan.parquet') where d='nan';
-- bwc_tag:end_query

select * from parquet_scan('data/parquet-testing/arrow_nan.parquet') where d>10;
-- bwc_tag:end_query

