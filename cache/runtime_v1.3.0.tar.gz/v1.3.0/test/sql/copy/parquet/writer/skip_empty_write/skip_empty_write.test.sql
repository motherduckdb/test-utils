-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=19
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE empty_tbl(i INT, j VARCHAR);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tbl AS FROM range(10000) t(i) UNION ALL SELECT 100000
-- bwc_tag:end_query

copy (select 42 where 42=84) to 'output/empty.parquet' (WRITE_EMPTY_FILE false)
-- bwc_tag:end_query

SELECT COUNT(*) FROM glob('output/empty.parquet')
-- bwc_tag:end_query

SET preserve_insertion_order=true
-- bwc_tag:end_query

copy (select 42 where 42=84) to 'output/empty.parquet' (WRITE_EMPTY_FILE false, RETURN_STATS)
-- bwc_tag:end_query

copy empty_tbl to 'output/empty.parquet' (WRITE_EMPTY_FILE false, RETURN_STATS)
-- bwc_tag:end_query

copy empty_tbl to 'output/empty.parquet' (WRITE_EMPTY_FILE false, RETURN_FILES)
-- bwc_tag:end_query

copy (from tbl where i = 20000) to 'output/empty.parquet' (WRITE_EMPTY_FILE false, RETURN_STATS)
-- bwc_tag:end_query

SET preserve_insertion_order=false
-- bwc_tag:end_query

copy (select 42 where 42=84) to 'output/empty.parquet' (WRITE_EMPTY_FILE false, RETURN_STATS)
-- bwc_tag:end_query

copy empty_tbl to 'output/empty.parquet' (WRITE_EMPTY_FILE false, RETURN_STATS)
-- bwc_tag:end_query

copy empty_tbl to 'output/empty.parquet' (WRITE_EMPTY_FILE false, RETURN_FILES)
-- bwc_tag:end_query

copy (from tbl where i = 20000) to 'output/empty.parquet' (WRITE_EMPTY_FILE false, RETURN_STATS)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

copy tbl to 'output/empty.parquet' (WRITE_EMPTY_FILE false, ROW_GROUPS_PER_FILE 1)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

copy empty_tbl to 'output/empty.parquet' (WRITE_EMPTY_FILE false, PARTITION_BY (i))
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

copy tbl to 'output/empty.parquet' (WRITE_EMPTY_FILE false, PER_THREAD_OUTPUT)
-- bwc_tag:end_query

