-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=47
LOAD 'parquet';
-- bwc_tag:end_query

copy (select
    (r1.range*10)::BIGINT r,
    r::smallint r_int16,
    r::integer r_int32,
    r::double r_double,
    r::float r_float,
    'string_' || r::VARCHAR r_string,
    ('blob_' || r::VARCHAR)::BLOB r_blob
from range(100) r1, range(1000) order by r) to 'output/bloom1.parquet' (format parquet, ROW_GROUP_SIZE 10000, dictionary_size_limit 1000);
-- bwc_tag:end_query

select column_id, BOOL_AND(bloom_filter_offset > 4), BOOL_AND(bloom_filter_length > 1)  from parquet_metadata('output/bloom1.parquet') group by column_id order by column_id;
-- bwc_tag:end_query

SELECT BOOL_AND(bloom_filter_excludes) FROM parquet_bloom_probe('output/bloom1.parquet', 'r', '201');
-- bwc_tag:end_query

SELECT BOOL_AND(bloom_filter_excludes) FROM parquet_bloom_probe('output/bloom1.parquet', 'r', '112121212');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO assert_bloom_filter_hit(file, col, val) AS TABLE
    SELECT COUNT(*) > 0 AND COUNT(*) < MAX(row_group_id+1) FROM parquet_bloom_probe(file, col, val) WHERE NOT bloom_filter_excludes;
-- bwc_tag:end_query

FROM assert_bloom_filter_hit('output/bloom1.parquet', 'r', '200');
-- bwc_tag:end_query

FROM assert_bloom_filter_hit('output/bloom1.parquet', 'r', 200);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

FROM assert_bloom_filter_hit('output/bloom10000.parquet', 'r', '200');
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

FROM assert_bloom_filter_hit('output/bloom1.parquet', 'r2', '200');
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

FROM assert_bloom_filter_hit('output/bloom1.parquet', NULL, '200');
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

FROM assert_bloom_filter_hit('output/bloom1.parquet', 'r', NULL);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

FROM assert_bloom_filter_hit('output/bloom1.parquet', 'r', 'a');
-- bwc_tag:end_query

FROM assert_bloom_filter_hit('output/bloom1.parquet', 'r_int16', 200);
-- bwc_tag:end_query

FROM assert_bloom_filter_hit('output/bloom1.parquet', 'r_int32', 200);
-- bwc_tag:end_query

FROM assert_bloom_filter_hit('output/bloom1.parquet', 'r_float', 200);
-- bwc_tag:end_query

FROM assert_bloom_filter_hit('output/bloom1.parquet', 'r_double', 200);
-- bwc_tag:end_query

FROM assert_bloom_filter_hit('output/bloom1.parquet', 'r_string', 'string_200');
-- bwc_tag:end_query

FROM assert_bloom_filter_hit('output/bloom1.parquet', 'r_blob', 'blob_200'::BLOB);
-- bwc_tag:end_query

copy (select (r1.range*10)::BIGINT r,
from range(100) r1, range(100) order by r) to 'output/bloom2.parquet' (format parquet, ROW_GROUP_SIZE 10000, dictionary_size_limit 10);
-- bwc_tag:end_query

select row_group_id, bloom_filter_offset IS NOT NULL, bloom_filter_length IS NOT NULL from parquet_metadata('output/bloom2.parquet') order by row_group_id;
-- bwc_tag:end_query

copy (select (r1.range*10)::BIGINT r,
from range(100) r1, range(100) order by r) to 'output/bloom3.parquet' (format parquet, ROW_GROUP_SIZE 10000, dictionary_size_limit 99);
-- bwc_tag:end_query

select row_group_id, bloom_filter_offset  IS NOT NULL, bloom_filter_length  IS NOT NULL  from parquet_metadata('output/bloom3.parquet') order by row_group_id;
-- bwc_tag:end_query

copy (select (r1.range*10)::BIGINT r,
from range(100) r1, range(100) order by r) to 'output/bloom4.parquet' (format parquet, ROW_GROUP_SIZE 10000, dictionary_size_limit 100);
-- bwc_tag:end_query

select row_group_id, bloom_filter_offset IS NOT NULL, bloom_filter_length  IS NOT NULL  from parquet_metadata('output/bloom4.parquet') order by row_group_id;
-- bwc_tag:end_query

copy (select (r1.range*10)::BIGINT r,
from range(100) r1, range(100) order by r) to 'output/bloom5.parquet' (format parquet, ROW_GROUP_SIZE 10000, dictionary_size_limit 1000);
-- bwc_tag:end_query

select row_group_id, bloom_filter_offset IS NOT NULL, bloom_filter_length  IS NOT NULL  from parquet_metadata('output/bloom5.parquet') order by row_group_id;
-- bwc_tag:end_query

copy (select (r1.range*10)::BIGINT r,
from range(100) r1, range(100) order by r) to 'output/bloom6.parquet' (format parquet, ROW_GROUP_SIZE 10000, dictionary_size_limit 1000, bloom_filter_false_positive_ratio 0.01);
-- bwc_tag:end_query

select row_group_id, bloom_filter_length from parquet_metadata('output/bloom6.parquet') order by row_group_id;
-- bwc_tag:end_query

copy (select (r1.range*10)::BIGINT r,
from range(100) r1, range(100) order by r) to 'output/bloom7.parquet' (format parquet, ROW_GROUP_SIZE 10000, dictionary_size_limit 1000, bloom_filter_false_positive_ratio 0.5);
-- bwc_tag:end_query

select row_group_id, bloom_filter_length from parquet_metadata('output/bloom7.parquet') order by row_group_id;
-- bwc_tag:end_query

copy (select (r1.range*10)::BIGINT r,
from range(100) r1, range(100) order by r) to 'output/bloom8.parquet' (format parquet, ROW_GROUP_SIZE 10000, dictionary_size_limit 1000, bloom_filter_false_positive_ratio 0.001);
-- bwc_tag:end_query

select row_group_id, bloom_filter_length from parquet_metadata('output/bloom8.parquet') order by row_group_id;
-- bwc_tag:end_query

copy (select (r1.range*10)::BIGINT r,
from range(100) r1, range(100) order by r) to 'output/bloom8.parquet' (format parquet, ROW_GROUP_SIZE 10000, dictionary_size_limit 1000, bloom_filter_false_positive_ratio 0.0001);
-- bwc_tag:end_query

select row_group_id, bloom_filter_length from parquet_metadata('output/bloom8.parquet') order by row_group_id;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

copy (select (r1.range*10)::BIGINT r,
from range(100) r1, range(100) order by r) to 'output/bloom8.parquet' (format parquet, ROW_GROUP_SIZE 10000, dictionary_size_limit -1, bloom_filter_false_positive_ratio 0.0001);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

copy (select (r1.range*10)::BIGINT r,
from range(100) r1, range(100) order by r) to 'output/bloom8.parquet' (format parquet, ROW_GROUP_SIZE 10000, dictionary_size_limit 1000, bloom_filter_false_positive_ratio 0);
-- bwc_tag:end_query

copy (select (r1.range*10)::VARCHAR r,
from range(100) r1, range(100) order by r) to 'output/bloom9.parquet' (format parquet, ROW_GROUP_SIZE 10000, string_dictionary_page_size_limit 10);
-- bwc_tag:end_query

select row_group_id, bloom_filter_offset IS NOT NULL, bloom_filter_length IS NOT NULL from parquet_metadata('output/bloom9.parquet') order by row_group_id;
-- bwc_tag:end_query

copy (select (r1.range*10)::VARCHAR r,
from range(100) r1, range(100) order by r) to 'output/bloom9.parquet' (format parquet, ROW_GROUP_SIZE 10000, string_dictionary_page_size_limit 100000);
-- bwc_tag:end_query

select row_group_id, bloom_filter_offset IS NOT NULL, bloom_filter_length IS NOT NULL from parquet_metadata('output/bloom9.parquet') order by row_group_id;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

copy (select (r1.range*10)::VARCHAR r,
from range(100) r1, range(100) order by r) to 'output/bloom9.parquet' (format parquet, ROW_GROUP_SIZE 10000, string_dictionary_page_size_limit 4294967295);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

copy (select (r1.range*10)::VARCHAR r,
from range(100) r1, range(100) order by r) to 'output/bloom9.parquet' (format parquet, ROW_GROUP_SIZE 10000, string_dictionary_page_size_limit 0);
-- bwc_tag:end_query

copy (select repeat('abc', 500_000) || (range % 10) s from range(100)) to 'output/my.parquet';
-- bwc_tag:end_query

select encodings from parquet_metadata('output/my.parquet');
-- bwc_tag:end_query

copy (select repeat('abc', 500_000) || (range % 10) s from range(100)) to 'output/my.parquet' (STRING_DICTIONARY_PAGE_SIZE_LIMIT 4_000_000);
-- bwc_tag:end_query

select encodings = 'RLE_DICTIONARY' from parquet_metadata('output/my.parquet');
-- bwc_tag:end_query

