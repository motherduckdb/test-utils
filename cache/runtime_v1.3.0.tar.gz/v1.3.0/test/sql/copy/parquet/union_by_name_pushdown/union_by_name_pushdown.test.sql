-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=9
LOAD 'parquet';
-- bwc_tag:end_query

COPY (SELECT 42 AS i, 84 AS j) TO 'output/union_by_name_pushdown1.parquet'
-- bwc_tag:end_query

COPY (SELECT 128 AS j, 33 AS k) TO 'output/union_by_name_pushdown2.parquet'
-- bwc_tag:end_query

SELECT * FROM read_parquet(['output/union_by_name_pushdown1.parquet', 'output/union_by_name_pushdown2.parquet'], union_by_name=True)
-- bwc_tag:end_query

SELECT k FROM read_parquet(['output/union_by_name_pushdown1.parquet', 'output/union_by_name_pushdown2.parquet'], union_by_name=True)
-- bwc_tag:end_query

SELECT i FROM read_parquet(['output/union_by_name_pushdown1.parquet', 'output/union_by_name_pushdown2.parquet'], union_by_name=True)
-- bwc_tag:end_query

SELECT * FROM read_parquet(['output/union_by_name_pushdown1.parquet', 'output/union_by_name_pushdown2.parquet'], union_by_name=True) WHERE k>0
-- bwc_tag:end_query

SELECT * FROM read_parquet(['output/union_by_name_pushdown1.parquet', 'output/union_by_name_pushdown2.parquet'], union_by_name=True) WHERE k>0 OR k IS NULL
-- bwc_tag:end_query

SELECT * FROM read_parquet(['output/union_by_name_pushdown1.parquet', 'output/union_by_name_pushdown2.parquet'], union_by_name=True) WHERE i>0
-- bwc_tag:end_query

