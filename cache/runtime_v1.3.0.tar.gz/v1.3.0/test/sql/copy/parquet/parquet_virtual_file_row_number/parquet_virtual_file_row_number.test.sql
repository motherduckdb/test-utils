-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=4
LOAD 'parquet';
-- bwc_tag:end_query

select file_row_number from 'data/parquet-testing/glob/t1.parquet'
-- bwc_tag:end_query

select file_row_number from 'data/parquet-testing/glob/t1.parquet' where file_row_number=0
-- bwc_tag:end_query

select i, j, replace(filename, '\', '/'), file_row_number from 'data/parquet-testing/glob*/t?.parquet' order by i;
-- bwc_tag:end_query

