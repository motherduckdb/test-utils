-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=5
LOAD 'parquet';
-- bwc_tag:end_query

select name from parquet_schema( 'data/parquet-testing/bug13053.parquet') offset 1;
-- bwc_tag:end_query

SELECT column_name FROM (DESCRIBE FROM 'data/parquet-testing/bug13053.parquet')
-- bwc_tag:end_query

select name from parquet_schema( 'data/parquet-testing/bug13053-2.parquet') offset 1;
-- bwc_tag:end_query

SELECT column_name FROM (DESCRIBE FROM 'data/parquet-testing/bug13053-2.parquet')
-- bwc_tag:end_query

