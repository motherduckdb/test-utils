-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=2
LOAD 'parquet';
-- bwc_tag:end_query

FROM 'data/parquet-testing/out_of_range_stats.parquet'
-- bwc_tag:end_query

