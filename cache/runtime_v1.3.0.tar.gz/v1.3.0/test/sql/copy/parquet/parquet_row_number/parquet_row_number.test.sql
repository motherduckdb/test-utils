-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=16
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

LOAD 'parquet';
-- bwc_tag:end_query

select min(file_row_number), max(file_row_number), avg(file_row_number),  count(*) from parquet_scan('data/parquet-testing/lineitem-top10000.gzip.parquet', file_row_number=1);
-- bwc_tag:end_query

select l_orderkey from parquet_scan('data/parquet-testing/lineitem-top10000.gzip.parquet', file_row_number=1) where file_row_number=42;
-- bwc_tag:end_query

select sum(row_number_lag), min(row_number_lag), max(row_number_lag)  from (select file_row_number - LAG(file_row_number) OVER (ORDER BY file_row_number) as row_number_lag from parquet_scan('data/parquet-testing/lineitem-top10000.gzip.parquet', file_row_number=1));
-- bwc_tag:end_query

select min(file_row_number), max(file_row_number), avg(file_row_number), count(*) from parquet_scan('data/parquet-testing/manyrowgroups.parquet', file_row_number=1);
-- bwc_tag:end_query

select sum(row_number_lag), min(row_number_lag), max(row_number_lag)  from (select file_row_number - LAG(file_row_number) OVER (ORDER BY file_row_number) as row_number_lag from parquet_scan('data/parquet-testing/manyrowgroups.parquet', file_row_number=1));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA disable_verification
-- bwc_tag:end_query

select row_group_id, row_group_num_rows, stats_min, stats_max from parquet_metadata('data/parquet-testing/file_row_number.parquet') order by row_group_id
-- bwc_tag:end_query

select stats(seq) from parquet_scan('data/parquet-testing/file_row_number.parquet') limit 1
-- bwc_tag:end_query

select min(file_row_number), max(file_row_number), count(*) from parquet_scan('data/parquet-testing/file_row_number.parquet', file_row_number=1) where seq > 6500;
-- bwc_tag:end_query

select first(stats(file_row_number)) from parquet_scan('data/parquet-testing/lineitem-top10000.gzip.parquet', file_row_number=1);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA explain_output = OPTIMIZED_ONLY;
-- bwc_tag:end_query

explain select 1 from parquet_scan('data/parquet-testing/lineitem-top10000.gzip.parquet', file_row_number=1) where file_row_number > 10000;
-- bwc_tag:end_query

explain select 1 from parquet_scan('data/parquet-testing/lineitem-top10000.gzip.parquet', file_row_number=1) where file_row_number < 0;
-- bwc_tag:end_query

explain select 1 from parquet_scan('data/parquet-testing/lineitem-top10000.gzip.parquet', file_row_number=1) where file_row_number is null;
-- bwc_tag:end_query

