-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=11
LOAD 'parquet';
-- bwc_tag:end_query

COPY (SELECT {'f': f, 'i': i} struct_val FROM (VALUES ('f1', 42::INT), ('f1', 8::INT), ('f1', NULL::INT)) t(f, i)) TO 'output/multi_file_filter_f1.parquet'
-- bwc_tag:end_query

COPY (SELECT {'i': i, 'f2': f} struct_val FROM (VALUES (42::BIGINT, 'f2'), (124::BIGINT, 'f2'), (NULL::BIGINT, 'f2')) t(i, f)) TO 'output/multi_file_filter_f2.parquet'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW integer_file_first AS FROM read_parquet(['output/multi_file_filter_f1.parquet', 'output/multi_file_filter_f2.parquet'])
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW bigint_file_first AS FROM read_parquet(['output/multi_file_filter_f2.parquet', 'output/multi_file_filter_f1.parquet'])
-- bwc_tag:end_query

SELECT struct_val.i
FROM integer_file_first
ORDER BY ALL
-- bwc_tag:end_query

SELECT struct_val.f, struct_val.i
FROM integer_file_first
WHERE struct_val.i='042'
-- bwc_tag:end_query

SELECT struct_val.i
FROM bigint_file_first
WHERE struct_val.i='042'
ORDER BY ALL
-- bwc_tag:end_query

SELECT struct_val.f, struct_val.i
FROM integer_file_first
WHERE struct_val.i>10
ORDER BY ALL
-- bwc_tag:end_query

SELECT struct_val.i
FROM bigint_file_first
WHERE struct_val.i>'10'
ORDER BY ALL
-- bwc_tag:end_query

SELECT struct_val.f, struct_val.i
FROM integer_file_first
WHERE struct_val.i IS NULL
-- bwc_tag:end_query

