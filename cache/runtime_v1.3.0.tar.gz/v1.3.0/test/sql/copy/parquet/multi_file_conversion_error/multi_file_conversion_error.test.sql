-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=6
LOAD 'parquet';
-- bwc_tag:end_query

copy (select 42 as a) to 'output/conversion_error1.parquet';
-- bwc_tag:end_query

copy (select blob 'hello world' as a) to 'output/conversion_error2.parquet';
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM read_parquet(['output/conversion_error1.parquet', 'output/conversion_error2.parquet'])
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INT);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

COPY integers FROM 'output/conversion_error*.parquet'
-- bwc_tag:end_query

