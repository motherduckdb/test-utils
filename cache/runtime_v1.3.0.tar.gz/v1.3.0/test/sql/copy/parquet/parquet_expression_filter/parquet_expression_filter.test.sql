-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=7
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tbl AS
SELECT i, 'thisisalongstring'||(i%5000)::VARCHAR AS str
FROM range(100000) t(i);
-- bwc_tag:end_query

COPY tbl TO 'output/parquet_expr.parquet'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW parq AS FROM 'output/parquet_expr.parquet'
-- bwc_tag:end_query

SELECT COUNT(*) FROM parq
WHERE least(str, 'thisisalongstring50') = str
-- bwc_tag:end_query

SELECT COUNT(*) FROM parq
WHERE least(str, 'thisisalongstring50') = str AND str >= 'this'
-- bwc_tag:end_query

SELECT COUNT(*) FROM parq
WHERE least(str, 'thisisalongstring50') = str AND str >= 'thisisalongstring2000' AND str <= 'thisisalongstring4000'
-- bwc_tag:end_query

