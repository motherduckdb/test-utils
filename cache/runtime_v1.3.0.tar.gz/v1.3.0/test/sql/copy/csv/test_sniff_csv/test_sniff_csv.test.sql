-- bwc_tag:nb_steps=24
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

SELECT quote, escape from sniff_csv('data/csv/16857.csv', ignore_errors = true);
-- bwc_tag:end_query

SELECT quote, escape from sniff_csv('data/csv/16857.csv');
-- bwc_tag:end_query

SELECT escape,quote, delimiter from sniff_csv('data/csv/later_quotes.csv');
-- bwc_tag:end_query

SELECT Prompt FROM sniff_csv('data/csv/real/lineitem_sample.csv');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/real/lineitem_sample.csv', auto_detect=false, delim='|', quote='"', escape='"', new_line='\n', skip=0, comment='', header=false, columns={'column00': 'BIGINT', 'column01': 'BIGINT', 'column02': 'BIGINT', 'column03': 'BIGINT', 'column04': 'BIGINT', 'column05': 'DOUBLE', 'column06': 'DOUBLE', 'column07': 'DOUBLE', 'column08': 'VARCHAR', 'column09': 'VARCHAR', 'column10': 'DATE', 'column11': 'DATE', 'column12': 'DATE', 'column13': 'VARCHAR', 'column14': 'VARCHAR', 'column15': 'VARCHAR'}, dateformat='%Y-%m-%d')  limit 1;
-- bwc_tag:end_query

FROM sniff_csv('data/csv/real/lineitem_sample.csv');
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

FROM sniff_csv('data/csv/real/non_ecziste.csv');
-- bwc_tag:end_query

FROM sniff_csv('data/csv/error/mismatch/big_bad.csv', sample_size=1);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

FROM read_csv('data/csv/error/mismatch/big_bad.csv', auto_detect=false, delim=',', quote='"', escape='"', new_line='\n', skip=0, header=0, columns={'column0': 'BIGINT', 'column1': 'VARCHAR'}, sample_size=1);
-- bwc_tag:end_query

FROM sniff_csv('data/csv/error/mismatch/big_bad.csv', sample_size=10000);
-- bwc_tag:end_query

FROM sniff_csv('data/csv/error/mismatch/big_bad.csv', sample_size=-1);
-- bwc_tag:end_query

FROM sniff_csv('data/csv/test/dateformat.csv')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/test/dateformat.csv', auto_detect=false, delim=',', quote='"', escape='"', new_line='\n', skip=0, header=false, columns={'column0': 'DATE'}, dateformat='%d/%m/%Y');
-- bwc_tag:end_query

FROM sniff_csv('data/csv/auto/time_date_timestamp_yyyy.mm.dd.csv')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/auto/time_date_timestamp_yyyy.mm.dd.csv', auto_detect=false, delim=',', quote='"', escape='"', new_line='\n', skip=0, header=true, columns={'a': 'BIGINT', 'b': 'VARCHAR', 't': 'TIME', 'd': 'DATE', 'ts': 'TIMESTAMP'}, dateformat='%Y.%m.%d', timestampformat='%Y.%m.%d %H:%M:%S');
-- bwc_tag:end_query

FROM sniff_csv('data/csv/inconsistent_cells.csv')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/inconsistent_cells.csv', auto_detect=false, delim=',', quote='"', escape='"', new_line='\n', skip=3, header=false, columns={'column0': 'BIGINT', 'column1': 'BIGINT', 'column2': 'BIGINT', 'column3': 'BIGINT', 'column4': 'BIGINT'});
-- bwc_tag:end_query

FROM sniff_csv('data/csv/timings.csv')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/timings.csv', auto_detect=false, delim='|', quote='"', escape='\', new_line='\n', skip=0, header=true, columns={'tool': 'VARCHAR', 'sf': 'BIGINT', 'day': 'DATE', 'batch_type': 'VARCHAR', 'q': 'VARCHAR', 'parameters': 'VARCHAR', 'time': 'DOUBLE'}, dateformat='%Y-%m-%d') order by all limit 1;
-- bwc_tag:end_query

FROM sniff_csv('data/csv/auto/backslash_escape.csv')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/auto/backslash_escape.csv', auto_detect=false, delim='|', quote='"', escape='\', new_line='\n', skip=0, header=false, columns={'column0': 'BIGINT', 'column1': 'VARCHAR', 'column2': 'VARCHAR'});
-- bwc_tag:end_query

FROM sniff_csv('data/csv/comments/simple.csv');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/comments/simple.csv', auto_detect=false, delim=';', quote='', escape='', new_line='\n', skip=0, comment='#', header=true, columns={'a': 'BIGINT', 'b': 'BIGINT'});
-- bwc_tag:end_query

