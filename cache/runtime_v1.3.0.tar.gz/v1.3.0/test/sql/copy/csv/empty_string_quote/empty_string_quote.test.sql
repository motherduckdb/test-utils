-- bwc_tag:nb_steps=7
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE customer(c_customer_sk INTEGER, c_customer_id VARCHAR, c_current_cdemo_sk INTEGER, c_current_hdemo_sk INTEGER, c_current_addr_sk INTEGER, c_first_shipto_date_sk INTEGER, c_first_sales_date_sk INTEGER, c_salutation VARCHAR, c_first_name VARCHAR, c_last_name VARCHAR, c_preferred_cust_flag VARCHAR, c_birth_day INTEGER, c_birth_month INTEGER, c_birth_year INTEGER, c_birth_country VARCHAR, c_login VARCHAR, c_email_address VARCHAR, c_last_review_date_sk INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY customer FROM 'data/csv/customer.csv' (FORMAT 'csv', quote '"', delimiter ',', header 0);
-- bwc_tag:end_query

SELECT * FROM customer
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE customer_quoted_nulls(c_customer_sk INTEGER, c_customer_id VARCHAR, c_current_cdemo_sk INTEGER, c_current_hdemo_sk INTEGER, c_current_addr_sk INTEGER, c_first_shipto_date_sk INTEGER, c_first_sales_date_sk INTEGER, c_salutation VARCHAR, c_first_name VARCHAR, c_last_name VARCHAR, c_preferred_cust_flag VARCHAR, c_birth_day INTEGER, c_birth_month INTEGER, c_birth_year INTEGER, c_birth_country VARCHAR, c_login VARCHAR, c_email_address VARCHAR, c_last_review_date_sk INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into customer_quoted_nulls select * from read_csv_auto('data/csv/customer.csv', allow_quoted_nulls=False)
-- bwc_tag:end_query

SELECT COUNT(c_login) FROM customer_quoted_nulls
-- bwc_tag:end_query

