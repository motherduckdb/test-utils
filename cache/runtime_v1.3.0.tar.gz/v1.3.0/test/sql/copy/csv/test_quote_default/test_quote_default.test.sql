-- bwc_tag:nb_steps=3
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
from read_csv('data/csv/test_default_option.csv', columns = {'a':'varchar', 'b':'integer'}, auto_detect = false, header = true) where b = 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
from read_csv('data/csv/test_default_option_2.csv', columns = {'a':'varchar', 'b':'integer'}, auto_detect = false, header = true, delim = '|') where b = 1
-- bwc_tag:end_query

