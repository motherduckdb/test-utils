-- bwc_tag:nb_steps=19
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv('data/csv/unquoted_escape/plain.csv', escape = '\', sep = ',', strict_mode = false, nullstr = '\N');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE special_char(a INT, b STRING);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO special_char VALUES
    (0, E'\\'), (1, E'\t'), (2, E'\n'),
    (3, E'a\\a'), (4, E'b\tb'), (5, E'c\nc'),
    (6, E'\\d'), (7, E'\te'), (8, E'\nf'),
    (9, E'g\\'), (10, E'h\t'), (11, E'i\n'),
    (12, E'\\j'), (13, E'\tk'), (14, E'\nl'),
    (15, E'\\\\'), (16, E'\t\t'), (17, E'\n\n'),
    (18, E'\\\t\n');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT bool_and(b = replace(s, E'\r\n', E'\n'))::int FROM special_char JOIN read_csv('data/csv/unquoted_escape/basic.tsv', quote = '', escape = '\', sep = '\t', strict_mode = false) t (i, s, j) ON i = a;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT bool_and(b = replace(s, E'\r\n', E'\n'))::int FROM special_char JOIN read_csv('data/csv/unquoted_escape/basic.tsv', quote = '', escape = '\', sep = '\t', strict_mode = false) t (i, s, j) ON i = a;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT bool_and(b = replace(s, E'\r\n', E'\n'))::int FROM special_char JOIN read_csv('data/csv/unquoted_escape/basic.tsv', quote = '', escape = '\', sep = '\t', strict_mode = false) t (i, s, j) ON i = a;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT bool_and(b = replace(s, E'\r\n', E'\n'))::int FROM special_char JOIN read_csv('data/csv/unquoted_escape/basic.tsv', quote = '', escape = '\', sep = '\t', strict_mode = false) t (i, s, j) ON i = a;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT bool_and(b = replace(s, E'\r\n', E'\n'))::int FROM special_char JOIN read_csv('data/csv/unquoted_escape/basic.tsv', quote = '', escape = '\', sep = '\t', strict_mode = false) t (i, s, j) ON i = a;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT bool_and(b = replace(s, E'\r\n', E'\n'))::int FROM special_char JOIN read_csv('data/csv/unquoted_escape/basic.tsv', quote = '', escape = '\', sep = '\t', strict_mode = false) t (i, s, j) ON i = a;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT bool_and(b = replace(s, E'\r\n', E'\n'))::int FROM special_char JOIN read_csv('data/csv/unquoted_escape/basic.tsv', quote = '', escape = '\', sep = '\t', strict_mode = false) t (i, s, j) ON i = a;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT bool_and(b = replace(s, E'\r\n', E'\n'))::int FROM special_char JOIN read_csv('data/csv/unquoted_escape/basic.tsv', quote = '', escape = '\', sep = '\t', strict_mode = false) t (i, s, j) ON i = a;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT bool_and(b = replace(s, E'\r\n', E'\n'))::int FROM special_char JOIN read_csv('data/csv/unquoted_escape/basic.tsv', quote = '', escape = '\', sep = '\t', strict_mode = false) t (i, s, j) ON i = a;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT bool_and(b = replace(s, E'\r\n', E'\n'))::int FROM special_char JOIN read_csv('data/csv/unquoted_escape/basic.tsv', quote = '', escape = '\', sep = '\t', strict_mode = false) t (i, s, j) ON i = a;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT bool_and(b = replace(s, E'\r\n', E'\n'))::int FROM special_char JOIN read_csv('data/csv/unquoted_escape/basic.tsv', quote = '', escape = '\', sep = '\t', strict_mode = false) t (i, s, j) ON i = a;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT bool_and(b = replace(s, E'\r\n', E'\n'))::int FROM special_char JOIN read_csv('data/csv/unquoted_escape/basic.tsv', quote = '', escape = '\', sep = '\t', strict_mode = false) t (i, s, j) ON i = a;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT bool_and(b = replace(s, E'\r\n', E'\n'))::int FROM special_char JOIN read_csv('data/csv/unquoted_escape/basic.tsv', quote = '', escape = '\', sep = '\t', strict_mode = false) t (i, s, j) ON i = a;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT bool_and(b = replace(s, E'\r\n', E'\n'))::int FROM special_char JOIN read_csv('data/csv/unquoted_escape/basic.tsv', quote = '', escape = '\', sep = '\t', strict_mode = false) t (i, s, j) ON i = a;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT bool_and(b = replace(s, E'\r\n', E'\n'))::int FROM special_char JOIN read_csv('data/csv/unquoted_escape/basic.tsv', quote = '', escape = '\', sep = '\t', strict_mode = false) t (i, s, j) ON i = a;
-- bwc_tag:end_query

