-- bwc_tag:nb_steps=3
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv_auto('data/csv/empty_first_line.csv', delim=' ');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv_auto('data/csv/empty_first_line.csv', delim='|', auto_detect=false, columns={'column00': 'VARCHAR'}, skip = 1);
-- bwc_tag:end_query

