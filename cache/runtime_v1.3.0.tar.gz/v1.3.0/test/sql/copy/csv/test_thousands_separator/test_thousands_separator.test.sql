-- bwc_tag:nb_steps=22
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/thousands_separator/simple.csv', thousands = NULL, delim = NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/thousands_separator/simple.csv', thousands = '', delim = NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

FROM read_csv('data/csv/thousands_separator/simple.csv', thousands = 'bla', delim = NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

FROM read_csv('data/csv/thousands_separator/simple.csv', thousands = ',', decimal_separator = ',')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

FROM read_csv('data/csv/thousands_separator/simple.csv', thousands = '.')
-- bwc_tag:end_query

SELECT COUNT(*) > 0 AS has_match
FROM sniff_csv('data/csv/thousands_separator/simple.csv', thousands = ',')
WHERE prompt LIKE '%thousands='',''%';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/thousands_separator/simple.csv', thousands = ',', delim = ';', columns = {'a':'double'}, header = False, auto_detect = false)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/thousands_separator/simple.csv', thousands = ',', delim = ';', columns = {'a':'float'}, header = False, auto_detect = false)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/thousands_separator/simple.csv', thousands = ',', delim = ';', columns = {'a':'decimal(32,3)'}, header = False, auto_detect = false)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/thousands_separator/simple.csv', thousands = ',', delim = ';', header = False)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/thousands_separator/simple_quoted.csv', thousands = ',', header = False)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/thousands_separator/simple.csv', thousands = ',', delim = ';', header = False, columns = {'a':'float'})
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/thousands_separator/simple.csv', thousands = ',', delim = ';', header = False, columns = {'a':'decimal(32,3)'})
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/thousands_separator/multi_column.csv', thousands = ',')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/thousands_separator/multi_column_quote.csv', thousands = ',')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE T (name varchar, money double, city varchar);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY T FROM 'data/csv/thousands_separator/multi_column_quote.csv' (THOUSANDS ',') ;
-- bwc_tag:end_query

FROM T;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/thousands_separator/thousands_broken.csv', thousands = ',')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/thousands_separator/integers.csv', thousands = ',')
-- bwc_tag:end_query

select columns from sniff_csv('data/csv/thousands_separator/integers.csv', thousands = ',')
-- bwc_tag:end_query

