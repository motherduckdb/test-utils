-- bwc_tag:nb_steps=32
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test_null_option (col_a INTEGER, col_b VARCHAR(10), col_c VARCHAR(10), col_d VARCHAR(10), col_e VARCHAR);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY test_null_option FROM 'data/csv/test/test_null_option.csv' (NULL 'NULL');
-- bwc_tag:end_query

SELECT * FROM test_null_option ORDER BY 1 LIMIT 3;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DELETE FROM test_null_option;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY test_null_option FROM 'data/csv/test/test_null_option.csv' (NULL '');
-- bwc_tag:end_query

SELECT * FROM test_null_option ORDER BY 1 LIMIT 3;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DELETE FROM test_null_option;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY test_null_option FROM 'data/csv/test/test_null_option.csv' (NULL 'test');
-- bwc_tag:end_query

SELECT * FROM test_null_option ORDER BY 1 LIMIT 3;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DELETE FROM test_null_option;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY test_null_option FROM 'data/csv/test/test_null_option.csv' (NULL 'null');
-- bwc_tag:end_query

SELECT * FROM test_null_option ORDER BY 1 LIMIT 3;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY test_null_option FROM 'data/csv/test/test_null_option.csv' (NULL null);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY test_null_option FROM 'data/csv/test/test_null_option.csv' (NULL 'null,', DELIMITER ',');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY test_null_option FROM 'data/csv/test/test_null_option.csv' (DELIMITER 'null', NULL 'null');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY test_null_option FROM 'data/csv/test/test_null_option.csv' (DELIMITER 'null', NULL 'nu');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY test_null_option FROM 'data/csv/test/test_null_option.csv' (NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test_null_option_2 (col_a INTEGER, col_b INTEGER, col_c VARCHAR(10), col_d VARCHAR(10));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY test_null_option_2 FROM 'data/csv/test/test_null_option.csv' (NULL 'null');
-- bwc_tag:end_query

COPY test_null_option TO 'output/test_null_option_2.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DELETE FROM test_null_option;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY test_null_option FROM 'output/test_null_option_2.csv';
-- bwc_tag:end_query

SELECT * FROM test_null_option ORDER BY 1 LIMIT 3;
-- bwc_tag:end_query

COPY test_null_option TO 'output/test_null_option_3.csv' (NULL '');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DELETE FROM test_null_option;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY test_null_option FROM 'output/test_null_option_3.csv' (NULL '');
-- bwc_tag:end_query

SELECT * FROM test_null_option ORDER BY 1 LIMIT 3;
-- bwc_tag:end_query

COPY test_null_option TO 'output/test_null_option_4.csv' (NULL 'null');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DELETE FROM test_null_option;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY test_null_option FROM 'output/test_null_option_4.csv' (NULL 'null');
-- bwc_tag:end_query

SELECT * FROM test_null_option ORDER BY 1 LIMIT 3;
-- bwc_tag:end_query

