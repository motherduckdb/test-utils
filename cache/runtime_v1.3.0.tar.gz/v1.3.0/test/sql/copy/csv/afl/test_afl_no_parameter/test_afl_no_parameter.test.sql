-- bwc_tag:nb_steps=25
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM 'data/csv/afl/no_parameter/1.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM 'data/csv/afl/no_parameter/2.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM 'data/csv/afl/no_parameter/3.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM 'data/csv/afl/no_parameter/4.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM 'data/csv/afl/no_parameter/5.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM 'data/csv/afl/no_parameter/6.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM 'data/csv/afl/no_parameter/7.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM 'data/csv/afl/no_parameter/8.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM 'data/csv/afl/no_parameter/9.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM 'data/csv/afl/no_parameter/10.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM 'data/csv/afl/no_parameter/11.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM 'data/csv/afl/no_parameter/12.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM 'data/csv/afl/no_parameter/13.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM 'data/csv/afl/no_parameter/14.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM 'data/csv/afl/no_parameter/15.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM 'data/csv/afl/no_parameter/16.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM 'data/csv/afl/no_parameter/17.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM 'data/csv/afl/no_parameter/18.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM 'data/csv/afl/no_parameter/19.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM 'data/csv/afl/no_parameter/20.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM 'data/csv/afl/no_parameter/21.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM 'data/csv/afl/no_parameter/22.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM 'data/csv/afl/no_parameter/23.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM 'data/csv/afl/no_parameter/24.csv'
-- bwc_tag:end_query

