-- bwc_tag:needed_extensions=json
-- bwc_tag:nb_steps=4
LOAD 'json';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

select count(file) from glob('./data/csv/afl/20250226_csv_fuzz_error/*');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/20250226_csv_fuzz_error/case_1.csv', force_not_null=012%0, columns={'a':'JSON'});
-- bwc_tag:end_query

