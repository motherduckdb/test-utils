-- bwc_tag:needed_extensions=icu
-- bwc_tag:nb_steps=19
-- bwc_tag:skip_query
pragma enable_verification
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

copy (
select '2021-05-25 04:55:03.382494 UTC'::timestamp as ts, '2021-05-25 04:55:03.382494 UTC'::timestamptz as tstz
) to 'output/timestamps.csv' ( timestampformat '%A');
-- bwc_tag:end_query

LOAD 'icu';
-- bwc_tag:end_query

SET autoload_known_extensions=false;
-- bwc_tag:end_query

SET TimeZone='UTC'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/timestamp_timezone.csv', columns = {'time':'timestamptz', 'description':'varchar'})
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/timestamp_timezone.csv', auto_type_candidates = ['BOOLEAN', 'BIGINT', 'DOUBLE', 'TIME', 'DATE', 'TIMESTAMP','TIMESTAMPTZ', 'VARCHAR'])
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/timestamp_timezone.csv', auto_type_candidates = ['BOOLEAN', 'BIGINT', 'DOUBLE', 'TIME', 'DATE', 'TIMESTAMPTZ', 'VARCHAR'])
-- bwc_tag:end_query

SELECT columns FROM sniff_csv('data/csv/timestamp_timezone.csv')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM 'data/csv/timestamp_timezone.csv'
-- bwc_tag:end_query

SELECT columns FROM sniff_csv('data/csv/timestamp_with_tz.csv')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM 'data/csv/timestamp_with_tz.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table t as SELECT '1; 2020-01-01 00:00:00+00' as ts from range (10000)
-- bwc_tag:end_query

copy t to 'output/timetz.csv'
-- bwc_tag:end_query

SELECT columns FROM sniff_csv('output/timetz.csv')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into t values ('2; thisisastring')
-- bwc_tag:end_query

copy t to 'output/timetz_2.csv'
-- bwc_tag:end_query

SELECT columns FROM sniff_csv('output/timetz_2.csv')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop table t;
-- bwc_tag:end_query

