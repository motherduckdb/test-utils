-- bwc_tag:nb_steps=4
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE phone_numbers AS SELECT * FROM read_csv_auto('data/csv/phonenumbers.csv')
-- bwc_tag:end_query

SELECT phone FROM phone_numbers;
-- bwc_tag:end_query

SELECT typeof(phone) FROM phone_numbers LIMIT 1;
-- bwc_tag:end_query

