-- bwc_tag:nb_steps=41
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t(t_k0 TINYINT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t VALUES (-128), (127);
-- bwc_tag:end_query

SELECT t_k0, COUNT(*) FROM t GROUP BY t_k0 ORDER BY 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE t;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t(t_k0 SMALLINT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t VALUES (-32768), (32767);
-- bwc_tag:end_query

SELECT t_k0, COUNT(*) FROM t GROUP BY t_k0 ORDER BY 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE t;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t(t_k0 INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t VALUES (-2147483648), (2147483647);
-- bwc_tag:end_query

SELECT t_k0, COUNT(*) FROM t GROUP BY t_k0 ORDER BY 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE t;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t(t_k0 BIGINT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t VALUES (-9223372036854775808), (9223372036854775807);
-- bwc_tag:end_query

SELECT t_k0, COUNT(*) FROM t GROUP BY t_k0 ORDER BY 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE t;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t(t_k0 HUGEINT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t VALUES (-170141183460469231731687303715884105728), (170141183460469231731687303715884105727);
-- bwc_tag:end_query

SELECT t_k0, COUNT(*) FROM t GROUP BY t_k0 ORDER BY 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE t;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t(t_k0 UTINYINT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t VALUES (0), (255);
-- bwc_tag:end_query

SELECT t_k0, COUNT(*) FROM t GROUP BY t_k0 ORDER BY 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE t;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t(t_k0 USMALLINT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t VALUES (0), (65535);
-- bwc_tag:end_query

SELECT t_k0, COUNT(*) FROM t GROUP BY t_k0 ORDER BY 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE t;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t(t_k0 UINTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t VALUES (0), (4294967295);
-- bwc_tag:end_query

SELECT t_k0, COUNT(*) FROM t GROUP BY t_k0 ORDER BY 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE t;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t(t_k0 UBIGINT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t VALUES (0), (18446744073709551615);
-- bwc_tag:end_query

SELECT t_k0, COUNT(*) FROM t GROUP BY t_k0 ORDER BY 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE t;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t(t_k0 UHUGEINT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t VALUES (0), ('340282366920938463463374607431768211455'::UHUGEINT);
-- bwc_tag:end_query

SELECT t_k0, COUNT(*) FROM t GROUP BY t_k0 ORDER BY 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE t;
-- bwc_tag:end_query

