-- bwc_tag:nb_steps=40
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA verify_external
-- bwc_tag:end_query

SELECT median(NULL), median(1)
-- bwc_tag:end_query

SELECT median(NULL), median(1) FROM range(2000)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table quantile as select range r, random() from range(10000) union all values (NULL, 0.1), (NULL, 0.5), (NULL, 0.9) order by 2;
-- bwc_tag:end_query

SELECT median(r)::VARCHAR FROM quantile
-- bwc_tag:end_query

SELECT median(r::float)::VARCHAR FROM quantile
-- bwc_tag:end_query

SELECT median(r::double)::VARCHAR FROM quantile
-- bwc_tag:end_query

SELECT median(r::tinyint)::VARCHAR FROM quantile where r < 100
-- bwc_tag:end_query

SELECT median(r::smallint)::VARCHAR FROM quantile
-- bwc_tag:end_query

SELECT median(r::integer)::VARCHAR FROM quantile
-- bwc_tag:end_query

SELECT median(r::bigint)::VARCHAR FROM quantile
-- bwc_tag:end_query

SELECT median(r::hugeint)::VARCHAR FROM quantile
-- bwc_tag:end_query

SELECT median(r::decimal(10,2))::VARCHAR FROM quantile
-- bwc_tag:end_query

SELECT median(case when r is null then null else [r] end)::VARCHAR FROM quantile
-- bwc_tag:end_query

SELECT median(case when r is null then null else {'i': r} end)::VARCHAR FROM quantile
-- bwc_tag:end_query

SELECT median(r::varchar) FROM quantile
-- bwc_tag:end_query

SELECT median(case when r is null then null else concat('thishasalongprefix_', r::varchar) end) FROM quantile
-- bwc_tag:end_query

SELECT median(NULL) FROM quantile
-- bwc_tag:end_query

SELECT median(42) FROM quantile
-- bwc_tag:end_query

SELECT MEDIAN(range::tinyint)
FROM range(0,10);
-- bwc_tag:end_query

SELECT MEDIAN(range::smallint)
FROM range(0,10);
-- bwc_tag:end_query

SELECT MEDIAN(range::integer)
FROM range(0,10);
-- bwc_tag:end_query

SELECT MEDIAN(range::bigint)
FROM range(0,10);
-- bwc_tag:end_query

SELECT MEDIAN(range::hugeint)
FROM range(0,10);
-- bwc_tag:end_query

SELECT MEDIAN(range::DECIMAL(4,1))
FROM range(0,10);
-- bwc_tag:end_query

SELECT MEDIAN(range::DECIMAL(9,1))
FROM range(0,10);
-- bwc_tag:end_query

SELECT MEDIAN(range::DECIMAL(18,1))
FROM range(0,10);
-- bwc_tag:end_query

SELECT MEDIAN(range::DECIMAL(38,1))
FROM range(0,10);
-- bwc_tag:end_query

SELECT MEDIAN(range::float)
FROM range(0,10);
-- bwc_tag:end_query

SELECT MEDIAN(range::double)
FROM range(0,10);
-- bwc_tag:end_query

SELECT MEDIAN(range::date) 
FROM range('2024-01-01'::date, '2024-01-11'::date, INTERVAL 1 DAY);
-- bwc_tag:end_query

SELECT MEDIAN(range::timestamp) 
FROM range('2024-01-01'::date, '2024-01-11'::date, INTERVAL 1 DAY);
-- bwc_tag:end_query

SELECT MEDIAN(range::timestamp_s) 
FROM range('2024-01-01'::date, '2024-01-11'::date, INTERVAL 1 DAY);
-- bwc_tag:end_query

SELECT MEDIAN(range::timestamp_ms) 
FROM range('2024-01-01'::date, '2024-01-11'::date, INTERVAL 1 DAY);
-- bwc_tag:end_query

SELECT MEDIAN(range::timestamp_ns) 
FROM range('2024-01-01'::date, '2024-01-11'::date, INTERVAL 1 DAY);
-- bwc_tag:end_query

SELECT MEDIAN(range::timestamptz) 
FROM range('2024-01-01'::date, '2024-01-11'::date, INTERVAL 1 DAY);
-- bwc_tag:end_query

SELECT MEDIAN('00:00:00'::TIME + INTERVAL (range) HOUR)
FROM range(0,10);
-- bwc_tag:end_query

SELECT MEDIAN(ttz::TIMETZ)
FROM (VALUES 
	('00:00:00-09'),
	('00:00:00-08'),
	('00:00:00-07'),
	('00:00:00-06'),
	('00:00:00-05'),
	('00:00:00-04'),
	('00:00:00-03'),
	('00:00:00-02'),
	('00:00:00-01'),
	('00:00:00+00'),
) tbl(ttz);
-- bwc_tag:end_query

SELECT MEDIAN(range::varchar) FROM range(0,10);
-- bwc_tag:end_query

