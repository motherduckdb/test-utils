-- bwc_tag:nb_steps=5
-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER);
-- bwc_tag:end_query

SELECT COUNT(*), COUNT(i), STDDEV_SAMP(i), SUM(i), SUM(DISTINCT i), FIRST(i), LAST(i), MAX(i), MIN(i) FROM integers WHERE i > 100
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE emptyaggr(i INTEGER);
-- bwc_tag:end_query

SELECT COUNT(*) FROM emptyaggr
-- bwc_tag:end_query

SELECT SUM(i), COUNT(i), COUNT(DISTINCT i), COUNT(*), AVG(i), COUNT(*)+1, COUNT(i)+1, MIN(i), MIN(i+1), MIN(i)+1 FROM emptyaggr
-- bwc_tag:end_query

