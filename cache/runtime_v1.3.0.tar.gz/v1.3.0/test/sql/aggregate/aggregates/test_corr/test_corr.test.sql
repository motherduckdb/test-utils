-- bwc_tag:nb_steps=12
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select corr()
-- bwc_tag:end_query

select corr(NULL,NULL)
-- bwc_tag:end_query

select corr(1,1)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select corr(*)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table aggr(k int, v decimal(10,2), v2 decimal(10, 2));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into aggr values(1, 10, null),(2, 10, 11), (2, 20, 22), (2, 25, null), (2, 30, 35);
-- bwc_tag:end_query

select k, corr(v, v2) from aggr group by k ORDER BY ALL;
-- bwc_tag:end_query

select  corr(v, v2) from aggr
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
select  corr(v, v2) over (partition by k)
    from aggr;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT corr(a,b) FROM (values (1e301, 0), (-1e301, 0)) tbl(a,b);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT corr(b,a) FROM (values (1e301, 0), (-1e301, 0)) tbl(a,b);
-- bwc_tag:end_query

