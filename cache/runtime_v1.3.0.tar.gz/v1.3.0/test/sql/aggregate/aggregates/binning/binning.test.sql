-- bwc_tag:nb_steps=63
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

SELECT equi_width_bins(0, 10, 2, true)
-- bwc_tag:end_query

SELECT equi_width_bins(1000000, 1000010, 2, true)
-- bwc_tag:end_query

SELECT equi_width_bins(99, 101, 2, true)
-- bwc_tag:end_query

SELECT equi_width_bins(9, 11, 2, true)
-- bwc_tag:end_query

SELECT equi_width_bins(10, 11, 2, true)
-- bwc_tag:end_query

SELECT equi_width_bins(0, 5, 10, true)
-- bwc_tag:end_query

SELECT equi_width_bins(0, 10, 5, true)
-- bwc_tag:end_query

SELECT equi_width_bins(-10, 0, 5, true)
-- bwc_tag:end_query

SELECT equi_width_bins(-10, 10, 5, true)
-- bwc_tag:end_query

SELECT equi_width_bins(0, 9, 5, true)
-- bwc_tag:end_query

SELECT equi_width_bins(0, 1734, 10, true)
-- bwc_tag:end_query

SELECT equi_width_bins(0, 1724, 10, true)
-- bwc_tag:end_query

SELECT equi_width_bins(0, 1734, 10, false)
-- bwc_tag:end_query

SELECT equi_width_bins(0, 39343341, 10, true)
-- bwc_tag:end_query

SELECT equi_width_bins(1, 6000000, 7, true)
-- bwc_tag:end_query

SELECT equi_width_bins(1, 6000000, 7, false)
-- bwc_tag:end_query

SELECT equi_width_bins(-9223372036854775808, 9223372036854775807, 5, true)
-- bwc_tag:end_query

SELECT equi_width_bins(-9223372036854775808, 9223372036854775807, 10, true)
-- bwc_tag:end_query

SELECT equi_width_bins(-9223372036854775808, 9223372036854775807, 20, true)
-- bwc_tag:end_query

SELECT equi_width_bins(-9223372036854775808, 9223372036854775807, 30, true)
-- bwc_tag:end_query

SELECT equi_width_bins(0.0, 9.0, 5, true);
-- bwc_tag:end_query

SELECT equi_width_bins(0.0, 9.0, 7, true);
-- bwc_tag:end_query

SELECT unnest(equi_width_bins(0.0, 9.0, 7, false));
-- bwc_tag:end_query

SELECT equi_width_bins(0.0, 90.0, 5, true);
-- bwc_tag:end_query

SELECT equi_width_bins(0.0, 1.0, 5, true);
-- bwc_tag:end_query

SELECT equi_width_bins(0.0, 1.0, 5, true);
-- bwc_tag:end_query

SELECT equi_width_bins(-1.0, 0.0, 5, true);
-- bwc_tag:end_query

SELECT equi_width_bins(-1.0, 1.0, 5, true);
-- bwc_tag:end_query

SELECT unnest(equi_width_bins(-1e308, 1e308, 5, true));
-- bwc_tag:end_query

select equi_width_bins(0.0, 6.347, 3, true) AS boundaries;
-- bwc_tag:end_query

select equi_width_bins(0.0, 6.347, 7, true) AS boundaries;
-- bwc_tag:end_query

select equi_width_bins(0.0, 6.347, 10, true) AS boundaries;
-- bwc_tag:end_query

select equi_width_bins(0.0, 6.347, 20, true) AS boundaries;
-- bwc_tag:end_query

select equi_width_bins(0.0, 6.347, 30, true) AS boundaries;
-- bwc_tag:end_query

select equi_width_bins(0.0, 3.974, 5, true) AS boundaries;
-- bwc_tag:end_query

select equi_width_bins(0.0, 3.974, 7, true) AS boundaries;
-- bwc_tag:end_query

select equi_width_bins(0.0, 3.974, 10, true) AS boundaries;
-- bwc_tag:end_query

select equi_width_bins(0.0, 3.974, 20, true) AS boundaries;
-- bwc_tag:end_query

select equi_width_bins(0.0, 3.974, 40, true) AS boundaries;
-- bwc_tag:end_query

select equi_width_bins(0, 101, 5, true);
-- bwc_tag:end_query

select equi_width_bins(0, 101.5, 5, true);
-- bwc_tag:end_query

SELECT equi_width_bins(date '1992-01-01', date '2000-01-01', 2, true)
-- bwc_tag:end_query

SELECT equi_width_bins(timestamp '1992-01-01', timestamp '2000-01-01', 2, true)
-- bwc_tag:end_query

SELECT equi_width_bins(timestamp '1992-01-01 12:23:37', timestamp '2000-01-01 04:03:21', 2, true)
-- bwc_tag:end_query

SELECT equi_width_bins(timestamp '1992-01-01 12:23:37', timestamp '2000-01-01 04:03:21', 5, true)
-- bwc_tag:end_query

SELECT equi_width_bins(timestamp '1992-01-01 12:23:37', timestamp '1992-12-01 04:03:21', 4, true)
-- bwc_tag:end_query

SELECT equi_width_bins(timestamp '1992-01-01 12:23:37', timestamp '1992-01-31 04:03:21', 4, true)
-- bwc_tag:end_query

SELECT equi_width_bins(timestamp '1992-01-01 01:23:37.999', timestamp '1992-01-01 23:03:21.3', 4, true)
-- bwc_tag:end_query

SELECT equi_width_bins(timestamp '1992-01-01 01:23:37.999', timestamp '1992-01-01 01:53:21.3', 4, true)
-- bwc_tag:end_query

SELECT equi_width_bins(timestamp '1992-01-01 01:23:01.999', timestamp '1992-01-01 01:23:49.377', 4, true)
-- bwc_tag:end_query

SELECT equi_width_bins(timestamp '1992-01-01 01:23:01.2', timestamp '1992-01-01 01:23:01.943', 4, true)
-- bwc_tag:end_query

select equi_width_bins(timestamp '2024-06-21 15:00:00', timestamp '2024-06-22 9:00:00', 4, true);
-- bwc_tag:end_query

select equi_width_bins(timestamp '2024-06-21 15:00:00', timestamp '2024-07-21 9:00:00', 4, true);
-- bwc_tag:end_query

select equi_width_bins(timestamp '2024-06-21 15:00:00.123456', timestamp '2024-06-21 15:00:00.123458', 10, true);
-- bwc_tag:end_query

SELECT EQUI_WIDTH_BINS(0, 10, 5999, TRUE)
-- bwc_tag:end_query

SELECT EQUI_WIDTH_BINS(0, 10, 5999, false)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT equi_width_bins(-0.0, -1.0, 5, true);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT equi_width_bins(0.0, 'inf'::double, 5, true);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT equi_width_bins(0.0, 'nan'::double, 5, true);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT equi_width_bins(0.0, 1.0, -1, true);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT equi_width_bins(0.0, 1.0, 99999999, true);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT equi_width_bins('a'::VARCHAR, 'z'::VARCHAR, 2, true)
-- bwc_tag:end_query

