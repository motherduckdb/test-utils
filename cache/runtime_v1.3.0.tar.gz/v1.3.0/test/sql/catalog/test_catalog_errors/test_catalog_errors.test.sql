-- bwc_tag:nb_steps=18
-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW vintegers AS SELECT 42;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE OR REPLACE VIEW integers AS SELECT 42;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DROP VIEW integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DROP TABLE blabla
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE blabla RENAME COLUMN i TO k
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DROP TABLE IF EXISTS vintegers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE INDEX i_index ON integers(i);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE INDEX i_index ON integers(i);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE INDEX IF NOT EXISTS i_index ON integers(i);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP INDEX i_index
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DROP INDEX i_index
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP INDEX IF EXISTS i_index
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE UNIQUE INDEX i_index ON integers(i);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE UNIQUE INDEX i_index ON integers(i);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE UNIQUE INDEX IF NOT EXISTS i_index ON integers(i);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE integers;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DROP INDEX i_index
-- bwc_tag:end_query

