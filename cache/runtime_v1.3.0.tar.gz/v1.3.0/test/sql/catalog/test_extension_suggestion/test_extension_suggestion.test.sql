-- bwc_tag:nb_steps=2
SET autoload_known_extensions=false;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT from_json('data/json/array_of_empty_arrays.json');
-- bwc_tag:end_query

