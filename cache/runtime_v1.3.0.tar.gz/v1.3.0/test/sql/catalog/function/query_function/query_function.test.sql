-- bwc_tag:nb_steps=57
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

SELECT * FROM query('SELECT 42');
-- bwc_tag:end_query

FROM query('SELECT 42 AS a');
-- bwc_tag:end_query

FROM query('SELECT 10 + 32;');
-- bwc_tag:end_query

FROM query('SELECT abs(-42)');
-- bwc_tag:end_query

SELECT * FROM query('SELECT * FROM (SELECT 1 + 2)');
-- bwc_tag:end_query

FROM query('SELECT 1, 2, 3');
-- bwc_tag:end_query

FROM query('SELECT 42;;;--- hello;');
-- bwc_tag:end_query

SELECT * FROM query('SELECT ''hello''');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tbl (a INT, b INT, c INT);
-- bwc_tag:end_query

FROM query('SELECT *, 1 + 2 FROM tbl');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO tbl VALUES (1, 2, 3), (4, 5, 6), (7, 8, 9);
-- bwc_tag:end_query

SELECT * FROM query('FROM tbl');
-- bwc_tag:end_query

SELECT * FROM query('SELECT a + b + c FROM tbl');
-- bwc_tag:end_query

SELECT * FROM query('WITH a(i) AS (SELECT 1) SELECT a1.i AS i1, a2.i AS i2 FROM a AS a1, a AS a2');
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM query(NULL);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM query(' ');
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM query('');
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM query('FROM query(FROM)');
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM query('SELECT 1; SELECT 2');
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT query(SELECT 1);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM query('CREATE TABLE tbl (a INT)');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tbl_int AS SELECT 42;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tbl_varchar AS SELECT 'duckdb';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tbl2_varchar AS SELECT '1?ch@racter$';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tbl_empty AS SELECT '';
-- bwc_tag:end_query

FROM query_table('tbl_int');
-- bwc_tag:end_query

FROM query_table(['tbl_int']);
-- bwc_tag:end_query

FROM query_table(tbl);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tbl2 (a INT, b INT, c INT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO tbl2 VALUES (9, 8, 7), (6, 5, 4), (3, 2, 1);
-- bwc_tag:end_query

FROM query_table([tbl, tbl2]);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

FROM query_table();
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

FROM query_table(NULL);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

FROM query_table([]);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

FROM query_table(['']);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

FROM query_table('tbl_int', 'tbl_varchar', tbl2_varchar);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

FROM query_table([tbl_int, tbl2]);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

FROM query_table(not_defined_tbl);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

FROM query_table('FROM query(''select 1 + 2;'')');
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

FROM query_table('FROM query("select 1 + 2;")');
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

FROM query_table('(SELECT 17 + 25)');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE "(SELECT 17 + 25)"(i int);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into "(SELECT 17 + 25)" values (100);
-- bwc_tag:end_query

SELECT * FROM "(SELECT 17 + 25)";
-- bwc_tag:end_query

FROM query_table("(SELECT 17 + 25)");
-- bwc_tag:end_query

FROM query_table('(SELECT 17 + 25)');
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

FROM query_table(SELECT 17 + 25);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

FROM query_table("SELECT 4 + 2");
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

FROM query_table('SELECT 4 + 2');
-- bwc_tag:end_query

SELECT f.* FROM query_table('tbl_int') as f;
-- bwc_tag:end_query

SELECT f.x FROM query_table('tbl_int') as f(x);
-- bwc_tag:end_query

FROM query_table(['tbl_int', 'tbl_varchar', 'tbl_empty', 'tbl2_varchar'], false);
-- bwc_tag:end_query

from query_table([tbl_int, tbl_varchar, tbl_empty, tbl2_varchar], true);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

FROM query_table(true);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

FROM query_table(tbl2, true);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

FROM query_table(['tbl_int', 'tbl_varchar', 'tbl_empty', '(select ''I am a subquery'')'], false);
-- bwc_tag:end_query

