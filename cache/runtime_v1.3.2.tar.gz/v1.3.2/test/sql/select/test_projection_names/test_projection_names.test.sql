-- bwc_tag:nb_steps=14
-- bwc_tag:execute_from_sql
CREATE TABLE integers("COL1" INTEGER, "COL2" INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tbl AS SELECT * FROM integers
-- bwc_tag:end_query

SELECT name FROM pragma_table_info('tbl') ORDER BY name
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE tbl
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tbl AS SELECT COL1, COL2 FROM integers
-- bwc_tag:end_query

SELECT name FROM pragma_table_info('tbl') ORDER BY name
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE tbl
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tbl AS SELECT integers.COL1, integers.COL2 FROM integers
-- bwc_tag:end_query

SELECT name FROM pragma_table_info('tbl') ORDER BY name
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE tbl
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA s1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE s1.integers("COL1" INTEGER, "COL2" INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tbl AS SELECT s1.integers.COL1, s1.integers.COL2 FROM s1.integers
-- bwc_tag:end_query

SELECT name FROM pragma_table_info('tbl') ORDER BY name
-- bwc_tag:end_query

