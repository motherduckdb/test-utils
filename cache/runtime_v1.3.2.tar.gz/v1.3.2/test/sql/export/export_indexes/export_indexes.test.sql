-- bwc_tag:nb_steps=12
-- bwc_tag:skip_query
BEGIN TRANSACTION
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO elaborate_macro(x, y := 7) AS x + y;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tbl (x integer, y varchar);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE UNIQUE INDEX my_index on tbl (elaborate_macro(tbl.x));
-- bwc_tag:end_query

select index_name from duckdb_indexes();
-- bwc_tag:end_query

EXPORT DATABASE 'output/export_macros' (FORMAT CSV);
-- bwc_tag:end_query

-- bwc_tag:skip_query
ROLLBACK
-- bwc_tag:end_query

IMPORT DATABASE 'output/export_macros'
-- bwc_tag:end_query

select index_name from duckdb_indexes();
-- bwc_tag:end_query

SELECT elaborate_macro(28, y := 5)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into tbl VALUES (10, 'hello');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

insert into tbl VALUES (10, 'world');
-- bwc_tag:end_query

