-- bwc_tag:needed_extensions=tpch
-- bwc_tag:nb_steps=5
SELECT * FROM duckdb_extensions();
-- bwc_tag:end_query

SELECT aliases FROM duckdb_extensions() WHERE extension_name='postgres_scanner';
-- bwc_tag:end_query

LOAD 'tpch';
-- bwc_tag:end_query

LOAD tpch;
-- bwc_tag:end_query

SELECT extension_name FROM duckdb_extensions() WHERE loaded AND extension_name='tpch';
-- bwc_tag:end_query

