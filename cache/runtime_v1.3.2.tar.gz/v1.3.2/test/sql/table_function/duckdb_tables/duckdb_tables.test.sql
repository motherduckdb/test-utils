-- bwc_tag:nb_steps=9
SELECT COUNT(*) FROM duckdb_tables();
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE pk(i INTEGER PRIMARY KEY, j VARCHAR, CHECK(i<100))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA myschema;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE myschema.mytable(k DOUBLE)
-- bwc_tag:end_query

CREATE TEMPORARY TABLE mytemp(i INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW v1 AS SELECT 42
-- bwc_tag:end_query

SELECT database_name, schema_name, table_name, temporary, has_primary_key, estimated_size, column_count, index_count, check_constraint_count FROM duckdb_tables() ORDER BY table_name;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM temp.duckdb_tables
-- bwc_tag:end_query

