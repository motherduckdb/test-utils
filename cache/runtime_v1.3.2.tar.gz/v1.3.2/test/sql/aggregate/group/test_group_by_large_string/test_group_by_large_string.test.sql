-- bwc_tag:nb_steps=5
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA verify_external
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test (a VARCHAR, b INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES ('helloworld', 22), ('thisisalongstring', 22), ('helloworld', 21)
-- bwc_tag:end_query

SELECT a, SUM(b) FROM test GROUP BY a ORDER BY a
-- bwc_tag:end_query

