-- bwc_tag:nb_steps=5
-- bwc_tag:skip_query
PRAGMA enable_verification;
-- bwc_tag:end_query

SELECT * FROM (SELECT 1) t0(c0) GROUP BY c0 HAVING c0>0
-- bwc_tag:end_query

SELECT c0 FROM (SELECT 1) t0(c0) GROUP BY ALL HAVING c0>0
-- bwc_tag:end_query

SELECT c0 FROM (SELECT 1, 1 UNION ALL SELECT 1, 2) t0(c0, c1) GROUP BY ALL ORDER BY c0
-- bwc_tag:end_query

SELECT c0 FROM (SELECT 1, 1 UNION ALL SELECT 1, 2) t0(c0, c1) GROUP BY ALL HAVING c1>0 ORDER BY c0
-- bwc_tag:end_query

