-- bwc_tag:nb_steps=2
-- bwc_tag:execute_from_sql
create table tbl as select i%50::BIGINT as i, i%5::BIGINT as j from range(1000000) tbl(i);
-- bwc_tag:end_query

select count(distinct i), min(distinct i), max(distinct i), sum(distinct i), product(distinct i) from tbl group by j order by all;
-- bwc_tag:end_query

