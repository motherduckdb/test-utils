-- bwc_tag:nb_steps=51
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA verify_external
-- bwc_tag:end_query

SELECT SETSEED(0.8675309);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table quantile as select range r, random() from range(10000) union all values (NULL, 0.1), (NULL, 0.5), (NULL, 0.9) order by 2;
-- bwc_tag:end_query

SELECT return_type, count(*) AS defined
FROM duckdb_functions()
WHERE function_name = 'reservoir_quantile'
GROUP BY ALL
HAVING defined <> 2
ORDER BY ALL;
-- bwc_tag:end_query

SELECT CASE
	  WHEN ( approx_quantile between (true_quantile - 100) and (true_quantile + 100) )
		  THEN TRUE
		  ELSE FALSE
	  END
	  FROM (SELECT approx_quantile(r, 0.5) as approx_quantile ,quantile(r,0.5) as true_quantile FROM quantile) AS T
-- bwc_tag:end_query

SELECT CASE
	  WHEN ( approx_quantile between (true_quantile - 100) and (true_quantile + 100) )
		  THEN TRUE
		  ELSE FALSE
	  END
	  FROM (SELECT approx_quantile(r, 1.0) as approx_quantile ,quantile(r, 1.0) as true_quantile FROM quantile) AS T
-- bwc_tag:end_query

SELECT CASE
	  WHEN ( approx_quantile between (true_quantile - 100) and (true_quantile + 100) )
		  THEN TRUE
		  ELSE FALSE
	  END
	  FROM (SELECT approx_quantile(r, 0.0) as approx_quantile ,quantile(r, 0.0) as true_quantile from quantile) AS T
-- bwc_tag:end_query

SELECT approx_quantile(NULL, 0.5)  as approx_quantile ,quantile(NULL, 0.5) as true_quantile
-- bwc_tag:end_query

SELECT CASE
	  WHEN ( approx_quantile between (true_quantile - 100) and (true_quantile + 100) )
		  THEN TRUE
		  ELSE FALSE
	  END
	  FROM (SELECT approx_quantile(42, 0.5)  as approx_quantile ,quantile(42, 0.5)  as true_quantile) AS T
-- bwc_tag:end_query

SELECT approx_quantile(NULL, 0.5)  as approx_quantile ,quantile(NULL, 0.5)  as true_quantile FROM quantile
-- bwc_tag:end_query

SELECT approx_quantile(1, 0.5)  as approx_quantile ,quantile(1, 0.5)  as true_quantile FROM quantile
-- bwc_tag:end_query

SELECT CASE
	  WHEN ( approx_quantile between (true_quantile - 100) and (true_quantile + 100) )
		  THEN TRUE
		  ELSE FALSE
	  END
	  FROM (SELECT approx_quantile(42, 0.5)  as approx_quantile ,quantile(42, 0.5)  as true_quantile) AS T
-- bwc_tag:end_query

SELECT CASE
	  WHEN ( approx_quantile between (true_quantile - 100) and (true_quantile + 100) )
		  THEN TRUE
		  ELSE FALSE
	  END
	  FROM (SELECT approx_quantile(r, 0.1)  as approx_quantile ,quantile(r, 0.1)  as true_quantile from quantile) AS T
-- bwc_tag:end_query

SELECT CASE
	  WHEN ( approx_quantile between (true_quantile - 100) and (true_quantile + 100) )
		  THEN TRUE
		  ELSE FALSE
	  END
	  FROM (SELECT approx_quantile(r, 0.9)  as approx_quantile ,quantile(r, 0.9)  as true_quantile from quantile) AS T
-- bwc_tag:end_query

SELECT approx_quantile('1:02:03.000000+05:30'::TIMETZ, 0.5);
-- bwc_tag:end_query

SELECT [
	(a[1] BETWEEN (q[1] - 100) AND (q[1] + 100)),
	(a[2] BETWEEN (q[2] - 100) AND (q[2] + 100)),
	(a[3] BETWEEN (q[3] - 100) AND (q[3] + 100)),
	]
FROM (
	SELECT approx_quantile(r, [0.25, 0.5, 0.75]) AS a,
		   quantile(r, [0.25, 0.5, 0.75]) AS q,
	FROM quantile
) tbl;
-- bwc_tag:end_query

SELECT [
	(a[1] BETWEEN (q[1] - 100) AND (q[1] + 100)),
	(a[2] BETWEEN (q[2] - 100) AND (q[2] + 100)),
	(a[3] BETWEEN (q[3] - 100) AND (q[3] + 100)),
	]
FROM (
	SELECT reservoir_quantile(r, [0.25, 0.5, 0.75], 4096) AS a,
		   quantile(r, [0.25, 0.5, 0.75]) AS q,
	FROM quantile
) tbl;
-- bwc_tag:end_query

SELECT approx_quantile(col, [0.5, 0.4, 0.1]) AS percentile 
FROM VALUES (0), (1), (2), (10) AS tab(col);
-- bwc_tag:end_query

SELECT approx_quantile(col, ARRAY_VALUE(0.5, 0.4, 0.1)) AS percentile 
FROM VALUES (0), (1), (2), (10) AS tab(col);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT approx_quantile(r, -0.1) FROM quantile
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT approx_quantile(r, 1.1) FROM quantile
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT approx_quantile(r, NULL) FROM quantile
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT approx_quantile(r, r) FROM quantile
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT approx_quantile(r::string, 0.5) FROM quantile
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT approx_quantile(r) FROM quantile
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT approx_quantile(r, 0.1, 0.2) FROM quantile
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT approx_quantile(42, CAST(NULL AS INT[]));
-- bwc_tag:end_query

-- bwc_tag:skip_query
pragma threads=4
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA verify_parallelism
-- bwc_tag:end_query

SELECT CASE
	  WHEN (approx_quantile between (true_quantile - (sumr * 0.01)) and (true_quantile + (sumr * 0.01)))
		  THEN TRUE
		  ELSE FALSE
	  END
	  FROM (SELECT approx_quantile(r, 0.1) as approx_quantile, quantile(r, 0.1) as true_quantile, SUM(r) as sumr from quantile) AS T
-- bwc_tag:end_query

SELECT CASE
	  WHEN (approx_quantile between (true_quantile - (sumr * 0.01)) and (true_quantile + (sumr * 0.01)))
		  THEN TRUE
		  ELSE FALSE
	  END
	  FROM (SELECT approx_quantile(r, 0.9) as approx_quantile, quantile(r, 0.9) as true_quantile, SUM(r) as sumr from quantile) AS T
-- bwc_tag:end_query

SELECT CASE
	  WHEN (approx_quantile between (true_quantile - (sumr * 0.01)) and (true_quantile + (sumr * 0.01)))
		  THEN TRUE
		  ELSE FALSE
	  END
	  FROM (SELECT approx_quantile(r, 0.5) as approx_quantile, quantile(r, 0.5) as true_quantile, SUM(r) as sumr from quantile) AS T
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE repro (i DECIMAL(15,2));
-- bwc_tag:end_query

SELECT approx_quantile(i, 0.5) FROM repro;
-- bwc_tag:end_query

SELECT approx_quantile(i, [0.5]) FROM repro;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA disable_verification;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA disable_verify_external;
-- bwc_tag:end_query

SELECT reservoir_quantile(r, 0.9)  from quantile
-- bwc_tag:end_query

SELECT reservoir_quantile(r, 0.9,1000)  from quantile
-- bwc_tag:end_query

SELECT reservoir_quantile(1, 0.5, 1) FROM quantile
-- bwc_tag:end_query

SELECT RESERVOIR_QUANTILE(b, 0.5)
FROM (SELECT 'a' AS a, 1.0 AS b) y
GROUP BY a
-- bwc_tag:end_query

SELECT APPROX_QUANTILE(b, 0.5)
FROM (
    SELECT 'a' AS a, 1.0 AS b
    UNION ALL SELECT 'a' AS a, 1.0 AS b
    UNION ALL SELECT 'b' AS a, 1.0 AS b
    ) y
GROUP BY a
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT reservoir_quantile(r, r)  from quantile
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT reservoir_quantile(r, NULL)  from quantile
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT reservoir_quantile(r, r, r)  from quantile
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT reservoir_quantile(r, 0.9, NULL)  from quantile
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT reservoir_quantile(r, 0.9, r)  from quantile
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT reservoir_quantile(r, random()::float)  from quantile
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT reservoir_quantile(r, 0.9, random()::float)  from quantile
-- bwc_tag:end_query

SELECT RESERVOIR_QUANTILE(0., 0.9, 1000);
-- bwc_tag:end_query

