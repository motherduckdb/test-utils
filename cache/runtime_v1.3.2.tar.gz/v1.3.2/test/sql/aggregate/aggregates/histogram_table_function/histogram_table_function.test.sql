-- bwc_tag:nb_steps=19
-- bwc_tag:skip_query
pragma enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table integers(i int);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into integers values (42);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into integers values (84);
-- bwc_tag:end_query

SELECT * FROM histogram_values(integers, i, bin_count := 2)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM histogram_values(integers, k)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers FROM range(127)
-- bwc_tag:end_query

SELECT * FROM histogram_values(integers, i, bin_count => 10, technique => 'equi-width')
-- bwc_tag:end_query

SELECT bin, count FROM histogram(integers, i, bin_count := 10, technique := 'equi-width')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (99999999)
-- bwc_tag:end_query

SELECT COUNT(*), AVG(count) FROM histogram_values(integers, i, technique := 'equi-height')
-- bwc_tag:end_query

SELECT * FROM histogram_values(integers, i%2, technique := 'sample')
-- bwc_tag:end_query

SELECT * FROM histogram_values(integers, (i%2)::VARCHAR)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM histogram_values(integers, (i%2)::VARCHAR, technique := 'equi-width')
-- bwc_tag:end_query

SELECT COUNT(*), AVG(count)  FROM histogram_values(integers, i::VARCHAR, technique := 'equi-height')
-- bwc_tag:end_query

SELECT COUNT(bin), AVG(count) FROM histogram(integers, i::VARCHAR, technique := 'equi-height')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table booleans(b bool);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into booleans select case when i%4=0 then true else false end from range(100) t(i)
-- bwc_tag:end_query

SELECT * FROM histogram_values(booleans, b::INTEGER)
-- bwc_tag:end_query

