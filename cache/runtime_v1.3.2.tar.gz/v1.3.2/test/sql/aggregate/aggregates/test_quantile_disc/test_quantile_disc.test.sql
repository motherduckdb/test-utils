-- bwc_tag:nb_steps=68
SET default_null_order='nulls_first';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA verify_external
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE quantile as
SELECT range r, random() AS q
FROM range(10000)
UNION ALL VALUES (NULL, 0.1), (NULL, 0.5), (NULL, 0.9)
ORDER BY 2;
-- bwc_tag:end_query

SELECT quantile_disc(r, 0.5) FROM quantile
-- bwc_tag:end_query

SELECT quantile_disc(r::decimal(10,2), 0.5) FROM quantile
-- bwc_tag:end_query

SELECT quantile_disc(case when r is null then null else [r] end, 0.5) FROM quantile
-- bwc_tag:end_query

SELECT quantile_disc(case when r is null then null else {'i': r} end, 0.5) FROM quantile
-- bwc_tag:end_query

SELECT quantile_disc(r, 1.0) FROM quantile
-- bwc_tag:end_query

SELECT quantile_disc(r, 0.0) FROM quantile
-- bwc_tag:end_query

SELECT quantile_disc(NULL, 0.5) FROM quantile
-- bwc_tag:end_query

SELECT quantile_disc(42, 0.5) FROM quantile
-- bwc_tag:end_query

SELECT quantile_disc(NULL, 0.5)
-- bwc_tag:end_query

SELECT quantile_disc(42, 0.5)
-- bwc_tag:end_query

SELECT quantile_disc(r, 0.1), quantile_disc(r, 0.5), quantile_disc(r, 0.9) from quantile
-- bwc_tag:end_query

SELECT quantile_disc(d::decimal(4,1), 0.1), quantile_disc(d::decimal(4,1), 0.5), quantile_disc(d::decimal(4,1), 0.9)
FROM range(0,100) tbl(d)
-- bwc_tag:end_query

SELECT quantile_disc(d::decimal(8,1), 0.1), quantile_disc(d::decimal(8,1), 0.5), quantile_disc(d::decimal(8,1), 0.9)
FROM range(0,100) tbl(d)
-- bwc_tag:end_query

SELECT quantile_disc(d::decimal(12,1), 0.1), quantile_disc(d::decimal(12,1), 0.5), quantile_disc(d::decimal(12,1), 0.9)
FROM range(0,100) tbl(d)
-- bwc_tag:end_query

SELECT quantile_disc(d::decimal(18,1), 0.1), quantile_disc(d::decimal(18,1), 0.5), quantile_disc(d::decimal(18,1), 0.9)
FROM range(0,100) tbl(d)
-- bwc_tag:end_query

SELECT quantile_disc(d::decimal(24,1), 0.1), quantile_disc(d::decimal(24,1), 0.5), quantile_disc(d::decimal(24,1), 0.9)
FROM range(0,100) tbl(d)
-- bwc_tag:end_query

SELECT quantile_disc(col, -0.5)
FROM VALUES (11000), (3100), (2900), (2800), (2600), (2500) AS tab(col);
-- bwc_tag:end_query

SELECT 
    percentile_disc(0.8) WITHIN GROUP (ORDER BY x DESC),
    quantile_disc(x, 0.8 ORDER BY x DESC),
FROM 
    (VALUES (2), (1)) _(x);
-- bwc_tag:end_query

SELECT quantile_disc(d::VARCHAR, 0.1), quantile_disc(d::VARCHAR, 0.5), quantile_disc(d::VARCHAR, 0.9)
FROM range(0,100) tbl(d)
-- bwc_tag:end_query

SELECT quantile_disc(NULL::VARCHAR, 0.1)
FROM range(0,100) tbl(d)
-- bwc_tag:end_query

SELECT quantile_disc('prefix-' || d::VARCHAR || '-suffix', 0.1)
FROM range(0,100) tbl(d)
-- bwc_tag:end_query

SELECT median(d::VARCHAR)
FROM range(0,100) tbl(d)
-- bwc_tag:end_query

SELECT median(d::VARCHAR)
FROM range(0,100) tbl(d)
WHERE d > 100
-- bwc_tag:end_query

SELECT mod(r,10) as g, quantile_disc(r, 0.1) FROM quantile GROUP BY 1 ORDER BY 1
-- bwc_tag:end_query

SELECT quantile_disc('2021-01-01'::TIMESTAMP + interval (r) hour, 0.5) FROM quantile
-- bwc_tag:end_query

SELECT quantile_disc('1990-01-01'::DATE + interval (r) day, 0.5) FROM quantile
-- bwc_tag:end_query

SELECT quantile_disc('00:00:00'::TIME + interval (r) second, 0.5) FROM quantile
-- bwc_tag:end_query

SELECT quantile_disc(interval (r) second, 0.5) FROM quantile
-- bwc_tag:end_query

SELECT quantile_disc(('2021-01-01'::TIMESTAMP + interval (r) hour)::TIMESTAMPTZ, 0.5) FROM quantile
-- bwc_tag:end_query

SELECT quantile_disc(1, 0.1) FROM quantile
-- bwc_tag:end_query

SELECT quantile_disc(r, 0.1) FROM quantile WHERE 1=0
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT quantile_disc(r, -1.1) FROM quantile
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT quantile_disc(r, 1.1) FROM quantile
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT quantile_disc(r, "string") FROM quantile
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT quantile_disc(r, NULL) FROM quantile
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT quantile_disc(r) FROM quantile
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT quantile_disc(r, 0.1, 50) FROM quantile
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT quantile_cont(r, q) FROM quantile
-- bwc_tag:end_query

-- bwc_tag:skip_query
pragma threads=4
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA verify_parallelism
-- bwc_tag:end_query

SELECT quantile_disc(r, 0.1), quantile_disc(r, 0.5), quantile_disc(r, 0.9) from quantile
-- bwc_tag:end_query

SELECT mod(r,10) as g, quantile_disc(r, 0.1) FROM quantile GROUP BY 1 ORDER BY 1
-- bwc_tag:end_query

SELECT quantile_disc(1, 0.1) FROM quantile
-- bwc_tag:end_query

SELECT quantile_disc(r, 0.1) FROM quantile WHERE 1=0
-- bwc_tag:end_query

with a as (
	select 'NaN'::float as num 
	union all 
	select num::float as num from generate_series(1,99) as tbl(num)
	union all 
	select 'NaN'::float as num
) 
select quantile_disc(num, 0.9) c1 
from a;
-- bwc_tag:end_query

with a as (
	select 'NaN'::float as num 
	union all 
	select num::float as num from generate_series(1,99) as tbl(num)
	union all 
	select 'NaN'::float as num
) 
select quantile_disc(num, 0.9) c1 
from a;
-- bwc_tag:end_query

with a as (
	select 'NaN'::float as num 
	union all 
	select num::float as num from generate_series(1,99) as tbl(num)
	union all 
	select 'NaN'::float as num
) 
select quantile_disc(num, 0.9) c1 
from a;
-- bwc_tag:end_query

with a as (
	select 'NaN'::float as num 
	union all 
	select num::float as num from generate_series(1,99) as tbl(num)
	union all 
	select 'NaN'::float as num
) 
select quantile_disc(num, 0.9) c1 
from a;
-- bwc_tag:end_query

with a as (
	select 'NaN'::float as num 
	union all 
	select num::float as num from generate_series(1,99) as tbl(num)
	union all 
	select 'NaN'::float as num
) 
select quantile_disc(num, 0.9) c1 
from a;
-- bwc_tag:end_query

with a as (
	select 'NaN'::float as num 
	union all 
	select num::float as num from generate_series(1,99) as tbl(num)
	union all 
	select 'NaN'::float as num
) 
select quantile_disc(num, 0.9) c1 
from a;
-- bwc_tag:end_query

with a as (
	select 'NaN'::float as num 
	union all 
	select num::float as num from generate_series(1,99) as tbl(num)
	union all 
	select 'NaN'::float as num
) 
select quantile_disc(num, 0.9) c1 
from a;
-- bwc_tag:end_query

with a as (
	select 'NaN'::float as num 
	union all 
	select num::float as num from generate_series(1,99) as tbl(num)
	union all 
	select 'NaN'::float as num
) 
select quantile_disc(num, 0.9) c1 
from a;
-- bwc_tag:end_query

with a as (
	select 'NaN'::float as num 
	union all 
	select num::float as num from generate_series(1,99) as tbl(num)
	union all 
	select 'NaN'::float as num
) 
select quantile_disc(num, 0.9) c1 
from a;
-- bwc_tag:end_query

with a as (
	select 'NaN'::float as num 
	union all 
	select num::float as num from generate_series(1,99) as tbl(num)
	union all 
	select 'NaN'::float as num
) 
select quantile_disc(num, 0.9) c1 
from a;
-- bwc_tag:end_query

with a as (
	select 'NaN'::double as num 
	union all 
	select num::double as num from generate_series(1,99) as tbl(num)
	union all 
	select 'NaN'::double as num
) 
select quantile_disc(num, 0.9) c1 
from a;
-- bwc_tag:end_query

with a as (
	select 'NaN'::double as num 
	union all 
	select num::double as num from generate_series(1,99) as tbl(num)
	union all 
	select 'NaN'::double as num
) 
select quantile_disc(num, 0.9) c1 
from a;
-- bwc_tag:end_query

with a as (
	select 'NaN'::double as num 
	union all 
	select num::double as num from generate_series(1,99) as tbl(num)
	union all 
	select 'NaN'::double as num
) 
select quantile_disc(num, 0.9) c1 
from a;
-- bwc_tag:end_query

with a as (
	select 'NaN'::double as num 
	union all 
	select num::double as num from generate_series(1,99) as tbl(num)
	union all 
	select 'NaN'::double as num
) 
select quantile_disc(num, 0.9) c1 
from a;
-- bwc_tag:end_query

with a as (
	select 'NaN'::double as num 
	union all 
	select num::double as num from generate_series(1,99) as tbl(num)
	union all 
	select 'NaN'::double as num
) 
select quantile_disc(num, 0.9) c1 
from a;
-- bwc_tag:end_query

with a as (
	select 'NaN'::double as num 
	union all 
	select num::double as num from generate_series(1,99) as tbl(num)
	union all 
	select 'NaN'::double as num
) 
select quantile_disc(num, 0.9) c1 
from a;
-- bwc_tag:end_query

with a as (
	select 'NaN'::double as num 
	union all 
	select num::double as num from generate_series(1,99) as tbl(num)
	union all 
	select 'NaN'::double as num
) 
select quantile_disc(num, 0.9) c1 
from a;
-- bwc_tag:end_query

with a as (
	select 'NaN'::double as num 
	union all 
	select num::double as num from generate_series(1,99) as tbl(num)
	union all 
	select 'NaN'::double as num
) 
select quantile_disc(num, 0.9) c1 
from a;
-- bwc_tag:end_query

with a as (
	select 'NaN'::double as num 
	union all 
	select num::double as num from generate_series(1,99) as tbl(num)
	union all 
	select 'NaN'::double as num
) 
select quantile_disc(num, 0.9) c1 
from a;
-- bwc_tag:end_query

with a as (
	select 'NaN'::double as num 
	union all 
	select num::double as num from generate_series(1,99) as tbl(num)
	union all 
	select 'NaN'::double as num
) 
select quantile_disc(num, 0.9) c1 
from a;
-- bwc_tag:end_query

