-- bwc_tag:nb_steps=17
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

SELECT COUNT(n) FROM test_vector_types(NULL::INT, all_flat=false) t(n);
-- bwc_tag:end_query

SELECT list_aggr(n, 'count') FROM test_vector_types(NULL::INT[], all_flat=false) t(n);
-- bwc_tag:end_query

SELECT COUNT(n) FROM test_vector_types(NULL::VARCHAR, all_flat=false) t(n);
-- bwc_tag:end_query

SELECT COUNT(DISTINCT n) FROM test_vector_types(NULL::INT, all_flat=false) t(n);
-- bwc_tag:end_query

SELECT COUNT(DISTINCT n) FROM test_vector_types(NULL::VARCHAR, all_flat=false) t(n);
-- bwc_tag:end_query

SELECT n, COUNT(n) FROM test_vector_types(NULL::INT, all_flat=false) t(n) GROUP BY n ORDER BY ALL;
-- bwc_tag:end_query

SELECT COUNT(n) FROM test_vector_types(NULL::INT, all_flat=true) t(n);
-- bwc_tag:end_query

SELECT list_aggr(n, 'count') FROM test_vector_types(NULL::INT[], all_flat=true) t(n);
-- bwc_tag:end_query

SELECT COUNT(n) FROM test_vector_types(NULL::VARCHAR, all_flat=true) t(n);
-- bwc_tag:end_query

SELECT COUNT(DISTINCT n) FROM test_vector_types(NULL::INT, all_flat=true) t(n);
-- bwc_tag:end_query

SELECT COUNT(DISTINCT n) FROM test_vector_types(NULL::VARCHAR, all_flat=true) t(n);
-- bwc_tag:end_query

SELECT n, COUNT(n) FROM test_vector_types(NULL::INT, all_flat=true) t(n) GROUP BY n ORDER BY ALL;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE int(i INT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO int FROM range(128);
INSERT INTO int SELECT NULL FROM range(128);
INSERT INTO int FROM range(77);
INSERT INTO int SELECT NULL FROM range(61);
INSERT INTO int FROM range(88);
INSERT INTO int SELECT NULL FROM range(33);
INSERT INTO int FROM range(44);
INSERT INTO int SELECT NULL FROM range(11);
INSERT INTO int FROM range(13);
INSERT INTO int SELECT NULL FROM range(27);
-- bwc_tag:end_query

SELECT COUNT(i), COUNT(rowid) FROM int
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
SELECT rowid // 200 AS g, COUNT(i), COUNT(rowid) FROM int GROUP BY g
-- bwc_tag:end_query

