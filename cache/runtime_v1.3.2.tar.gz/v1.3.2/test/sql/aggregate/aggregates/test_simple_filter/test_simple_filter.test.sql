-- bwc_tag:nb_steps=10
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

SELECT
    count(*) as total_rows,
    count(*) FILTER (WHERE i <= 5) as lte_five,
    count(*) FILTER (WHERE i % 2 = 1) as odds
FROM generate_series(1,11) tbl(i)
-- bwc_tag:end_query

SELECT
    count(*) FILTER (WHERE i % 2 = 1) as odds,
    count(*) FILTER (WHERE i <= 5) as lte_five,
    count(*) as total_rows
FROM generate_series(1,11) tbl(i)
-- bwc_tag:end_query

SELECT
    count(*) FILTER (WHERE i <= 5) as lte_five,
    count(*) FILTER (WHERE i % 2 = 1) as odds,
    count(*) as total_rows
FROM generate_series(1,11) tbl(i)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE issue3105(gender VARCHAR, pay FLOAT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO issue3105 VALUES
	('male', 100),
	('male', 200),
	('male', 300),
	('female', 150),
	('female', 250);
-- bwc_tag:end_query

SELECT
	SUM(pay) FILTER (WHERE gender = 'male'),
	SUM(pay) FILTER (WHERE gender = 'female'),
	SUM(pay)
FROM issue3105;
-- bwc_tag:end_query

SELECT
	SUM(pay),
	SUM(pay) FILTER (WHERE gender = 'male'),
	SUM(pay) FILTER (WHERE gender = 'female')
FROM issue3105;
-- bwc_tag:end_query

SELECT
	SUM(pay) FILTER (WHERE gender = 'male'),
	SUM(pay),
	SUM(pay) FILTER (WHERE gender = 'female')
FROM issue3105;
-- bwc_tag:end_query

SELECT
	SUM(pay) FILTER (gender = 'male'),
	SUM(pay),
	SUM(pay) FILTER (gender = 'female')
FROM issue3105;
-- bwc_tag:end_query

