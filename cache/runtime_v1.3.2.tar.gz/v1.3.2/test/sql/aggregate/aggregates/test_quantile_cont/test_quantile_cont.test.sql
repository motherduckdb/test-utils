-- bwc_tag:nb_steps=67
SET default_null_order='nulls_first';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA verify_external
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table quantile as select range r, random() from range(0,1000000,100) union all values (NULL, 0.1), (NULL, 0.5), (NULL, 0.9) order by 2;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT quantile_cont(r, NULL) FROM quantile
-- bwc_tag:end_query

SELECT quantile_cont(r, 0.5) FROM quantile
-- bwc_tag:end_query

SELECT quantile_cont(r::decimal(10,2), 0.5) FROM quantile
-- bwc_tag:end_query

SELECT quantile_cont(r, 1.0) FROM quantile
-- bwc_tag:end_query

SELECT quantile_cont(r, 0.0) FROM quantile
-- bwc_tag:end_query

SELECT quantile_cont(NULL, 0.5) FROM quantile
-- bwc_tag:end_query

SELECT quantile_cont(42, 0.5) FROM quantile
-- bwc_tag:end_query

SELECT quantile_cont(NULL, 0.5)
-- bwc_tag:end_query

SELECT quantile_cont(42, 0.5)
-- bwc_tag:end_query

SELECT quantile_cont(r, 0.25), quantile_cont(r, 0.5), quantile_cont(r, 0.75) from quantile
-- bwc_tag:end_query

SELECT quantile_cont(d::decimal(4,1), 0.25), quantile_cont(d::decimal(4,1), 0.5), quantile_cont(d::decimal(4,1), 0.75)
FROM range(0,100) tbl(d)
-- bwc_tag:end_query

SELECT quantile_cont(d::decimal(8,1), 0.25), quantile_cont(d::decimal(8,1), 0.5), quantile_cont(d::decimal(8,1), 0.75)
FROM range(0,100) tbl(d)
-- bwc_tag:end_query

SELECT quantile_cont(d::decimal(12,1), 0.25), quantile_cont(d::decimal(12,1), 0.5), quantile_cont(d::decimal(12,1), 0.75)
FROM range(0,100) tbl(d)
-- bwc_tag:end_query

SELECT quantile_cont(d::decimal(18,1), 0.25), quantile_cont(d::decimal(18,1), 0.5), quantile_cont(d::decimal(18,1), 0.75)
FROM range(0,100) tbl(d)
-- bwc_tag:end_query

SELECT quantile_cont(d::decimal(24,1), 0.25), quantile_cont(d::decimal(24,1), 0.5), quantile_cont(d::decimal(24,1), 0.75)
FROM range(0,100) tbl(d)
-- bwc_tag:end_query

SELECT mod(r,1000) as g, quantile_cont(r, 0.25) FROM quantile GROUP BY 1 ORDER BY 1
-- bwc_tag:end_query

SELECT quantile_cont('2021-01-01'::TIMESTAMP + interval (r) second, 0.5) FROM quantile
-- bwc_tag:end_query

SELECT quantile_cont(('1990-01-01'::DATE + interval (r/100) day)::DATE, 0.5) FROM quantile
-- bwc_tag:end_query

SELECT quantile_cont('00:00:00'::TIME + interval (r/100) second, 0.5) FROM quantile
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT quantile_cont(interval (r/100) second, 0.5) FROM quantile
-- bwc_tag:end_query

SELECT quantile_cont(('2021-01-01'::TIMESTAMP + interval (r) second)::TIMESTAMPTZ, 0.5) FROM quantile
-- bwc_tag:end_query

SELECT quantile_cont(1, 0.1) FROM quantile
-- bwc_tag:end_query

SELECT quantile_cont(r, -0.1) FROM quantile
-- bwc_tag:end_query

SELECT 
    percentile_cont(0.8) WITHIN GROUP (ORDER BY x DESC),
    quantile_cont(x, 0.8 ORDER BY x DESC),
FROM 
    (VALUES (2), (1)) _(x);
-- bwc_tag:end_query

SELECT quantile_cont(r, 0.1) FROM quantile WHERE 1=0
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT quantile_cont(r, -1.1) FROM quantile
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT quantile_cont(r, 1.1) FROM quantile
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT quantile_cont(r, "string") FROM quantile
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT quantile_cont(r, NULL) FROM quantile
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT quantile_cont(r::string, 0.5) FROM quantile
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT quantile_cont(r) FROM quantile
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT quantile_cont(r, 0.1, 50) FROM quantile
-- bwc_tag:end_query

-- bwc_tag:skip_query
pragma threads=4
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA verify_parallelism
-- bwc_tag:end_query

SELECT quantile_cont(r, 0.25), quantile_cont(r, 0.5), quantile_cont(r, 0.75) from quantile
-- bwc_tag:end_query

SELECT mod(r,1000) as g, quantile_cont(r, 0.25) FROM quantile GROUP BY 1 ORDER BY 1
-- bwc_tag:end_query

SELECT quantile_cont(1, 0.1) FROM quantile
-- bwc_tag:end_query

SELECT quantile_cont(r, 0.1) FROM quantile WHERE 1=0
-- bwc_tag:end_query

SELECT quantile_cont(t, 0.5) FROM (VALUES (120::TINYINT), (122::TINYINT)) tbl(t)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tinyints(t TINYINT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO tinyints VALUES (-127), (-127);
-- bwc_tag:end_query

SELECT quantile_cont(t, 0.5) FROM tinyints;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
UPDATE tinyints SET t=-t;
-- bwc_tag:end_query

SELECT quantile_cont(t, 0.5) FROM tinyints;
-- bwc_tag:end_query

SELECT quantile_cont(t, 0.5) FROM (VALUES (32764::SMALLINT), (32766::SMALLINT)) tbl(t)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE smallints(t SMALLINT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO smallints VALUES (-32767), (-32767);
-- bwc_tag:end_query

SELECT quantile_cont(t, 0.5) FROM smallints;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
UPDATE smallints SET t=-t;
-- bwc_tag:end_query

SELECT quantile_cont(t, 0.5) FROM smallints;
-- bwc_tag:end_query

SELECT quantile_cont(t, 0.5) FROM (VALUES (2147483642::INTEGER), (2147483644::INTEGER)) tbl(t)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(t INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (-2147483647), (-2147483647);
-- bwc_tag:end_query

SELECT quantile_cont(t, 0.5) FROM integers;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
UPDATE integers SET t=-t;
-- bwc_tag:end_query

SELECT quantile_cont(t, 0.5) FROM integers;
-- bwc_tag:end_query

SELECT quantile_cont(t, 0.5) FROM (VALUES (9223372036854775794::BIGINT), (9223372036854775796::BIGINT)) tbl(t)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE bigints(t BIGINT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO bigints VALUES (-9223372036854775800), (-9223372036854775800);
-- bwc_tag:end_query

SELECT quantile_cont(t, 0.5) FROM bigints;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
UPDATE bigints SET t=-t;
-- bwc_tag:end_query

SELECT quantile_cont(t, 0.5) FROM bigints;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT quantile_cont(r, random()) FROM quantile
-- bwc_tag:end_query

