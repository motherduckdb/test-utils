-- bwc_tag:nb_steps=17
SET default_null_order='nulls_first';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table students (course VARCHAR, type VARCHAR, highest_grade INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into students
		(course, type, highest_grade)
	values
		('CS', 'Bachelor', 8),
		('CS', 'Bachelor', 8),
		('CS', 'PhD', 10),
		('Math', 'Masters', NULL),
		('CS', NULL, 7),
		('CS', NULL, 7),
		('Math', NULL, 8);
-- bwc_tag:end_query

select course, count(*) from students group by cube (course) order by 1, 2;
-- bwc_tag:end_query

select course, type, count(*) from students group by cube (course, type) order by 1, 2, 3;
-- bwc_tag:end_query

select course, type, count(*) from students group by cube ((course, type)) order by 1, 2, 3;
-- bwc_tag:end_query

select course, type, count(*) from students group by cube (course, type, course) order by 1, 2, 3;
-- bwc_tag:end_query

select course, type, highest_grade, count(*) from students group by cube (course, type, highest_grade) order by 1, 2, 3, 4;
-- bwc_tag:end_query

select course, type, count(*) from students group by cube (course), cube (type) order by 1, 2, 3;
-- bwc_tag:end_query

select course as crs, type, count(*) from students group by cube (crs), (), type order by 1, 2, 3;
-- bwc_tag:end_query

select course as crs, type as tp, count(*) from students group by grouping sets (cube (crs)), (), tp order by 1, 2, 3;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select course, count(*) from students group by cube () order by 1, 2;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select course, count(*) from students group by cube (cube (course)) order by 1, 2;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select course, count(*) from students group by cube (grouping_sets (course)) order by 1, 2;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select course, type, count(*) from students group by cube (course, type, course, type, course, type, course, type, course, type, course, type, (course, type), (course, type), course, type) order by 1, 2, 3;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select course, type, count(*) from students group by cube (course, type, course, type, course), cube(type, course, type, course), cube(type, course, type, (course, type), (course, type), course, type) order by 1, 2, 3;
-- bwc_tag:end_query

