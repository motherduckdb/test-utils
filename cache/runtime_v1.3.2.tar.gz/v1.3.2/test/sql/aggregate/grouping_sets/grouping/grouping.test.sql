-- bwc_tag:nb_steps=24
SET default_null_order='nulls_first';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table students (course VARCHAR, type VARCHAR);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into students
		(course, type)
	values
		('CS', 'Bachelor'),
		('CS', 'Bachelor'),
		('CS', 'PhD'),
		('Math', 'Masters'),
		('CS', NULL),
		('CS', NULL),
		('Math', NULL);
-- bwc_tag:end_query

SELECT GROUPING(course), course, COUNT(*) FROM students GROUP BY course ORDER BY 1, 2, 3;
-- bwc_tag:end_query

SELECT GROUPING_ID(course), course, COUNT(*) FROM students GROUP BY course ORDER BY 1, 2, 3;
-- bwc_tag:end_query

SELECT GROUPING(course), GROUPING(type), course, type, COUNT(*) FROM students GROUP BY course, type ORDER BY 1, 2, 3, 4, 5;
-- bwc_tag:end_query

SELECT GROUPING(course), GROUPING(type), course, type, COUNT(*) FROM students GROUP BY CUBE(course, type) ORDER BY 1, 2, 3, 4, 5;
-- bwc_tag:end_query

SELECT GROUPING(course, type), course, type, COUNT(*) FROM students GROUP BY CUBE(course, type) ORDER BY 1, 2, 3, 4;
-- bwc_tag:end_query

SELECT GROUPING(course), GROUPING(type), GROUPING(course)+GROUPING(type), course, type, COUNT(*) FROM students GROUP BY CUBE(course, type) ORDER BY 1, 2, 3, 4, 5;
-- bwc_tag:end_query

SELECT GROUPING(course, type, course, course, type, type, course), course, type, COUNT(*) FROM students GROUP BY CUBE(course, type) ORDER BY 1, 2, 3, 4;
-- bwc_tag:end_query

SELECT GROUPING(students.course), GROUPING(students.type), GROUPING(course)+GROUPING(type), course, type, COUNT(*) FROM students GROUP BY CUBE(course, type) ORDER BY 1, 2, 3, 4, 5;
-- bwc_tag:end_query

SELECT GROUPING(course), GROUPING(type), GROUPING(course)+GROUPING(type), course, type, COUNT(*) FROM students GROUP BY CUBE(students.course, students.type) ORDER BY 1, 2, 3, 4, 5;
-- bwc_tag:end_query

SELECT GROUPING(course), GROUPING(type), course, type, COUNT(*) FROM students GROUP BY CUBE(course, type) HAVING GROUPING(course)=0 ORDER BY 1, 2, 3, 4, 5;
-- bwc_tag:end_query

SELECT GROUPING(course), GROUPING(type), course, type, COUNT(*) FROM students GROUP BY CUBE(course, type) HAVING GROUPING(students.course)=0 ORDER BY 1, 2, 3, 4, 5;
-- bwc_tag:end_query

SELECT course, type, COUNT(*) FROM students GROUP BY CUBE(course, type) ORDER BY GROUPING(course), GROUPING(type), 1, 2, 3;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT GROUPING();
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT GROUPING() FROM students;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT GROUPING(NULL) FROM students;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT GROUPING(course) FROM students;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT GROUPING(course) FROM students GROUP BY ();
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT GROUPING(type) FROM students GROUP BY course;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT GROUPING(course) FROM students WHERE GROUPING(course)=0 GROUP BY course;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT GROUPING(course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course, course), course, type, COUNT(*) FROM students GROUP BY CUBE(course, type) ORDER BY 1, 2, 3, 4;
-- bwc_tag:end_query

