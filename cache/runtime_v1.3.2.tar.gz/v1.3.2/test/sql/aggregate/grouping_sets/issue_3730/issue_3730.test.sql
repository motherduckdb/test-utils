-- bwc_tag:nb_steps=6
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE response(
	id BIGINT,
	response VARCHAR
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO response VALUES
	(1,'yes'),
	(1,'no'),
	(1,'yes'),
	(2,'no'),
	(2,'no');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE user_pq(
	id BIGINT,
	"name" VARCHAR
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO user_pq VALUES
	(1,'alice'),
	(2,'bob');
-- bwc_tag:end_query

SELECT id, response, COUNT(DISTINCT id)
FROM user_pq
JOIN response USING (id)
GROUP BY CUBE (id, response)
ORDER BY 1 NULLS LAST, 2 NULLS LAST, 3 NULLS LAST
-- bwc_tag:end_query

