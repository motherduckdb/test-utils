-- bwc_tag:nb_steps=15
-- bwc_tag:execute_from_sql
CREATE TABLE test(
	s MAP(
		STRUCT(
			n INTEGER,
			m INTEGER
		),
		STRUCT(
			i INTEGER,
			j INTEGER
		)
	)
)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES
	(MAP {ROW(3,3): ROW(1, 1)}),
	(MAP {ROW(4,4): ROW(2, 2)})
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE test DROP COLUMN s.key
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE test DROP COLUMN s.value
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test DROP COLUMN s.value.j
-- bwc_tag:end_query

select * from test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test DROP COLUMN s.key.n
-- bwc_tag:end_query

select * from test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop table test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test(
	s STRUCT(
		a MAP(
			STRUCT(
				n INTEGER,
				m INTEGER
			),
			STRUCT(
				i INTEGER,
				j INTEGER
			)
		)
	)
)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES
	(ROW(MAP {ROW(3,3): ROW(1, 1)})),
	(ROW(MAP {ROW(4,4): ROW(2, 2)}))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test DROP COLUMN s.a.key.m
-- bwc_tag:end_query

select * from test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test DROP COLUMN s.a.value.j
-- bwc_tag:end_query

select * from test;
-- bwc_tag:end_query

