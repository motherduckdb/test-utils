-- bwc_tag:nb_steps=11
WITH cte as (
	select a::STRUCT(i INTEGER, j INTEGER)[] a from
	VALUES
		([ROW(1, 1)]),
		([ROW(2, 2)])
	t(a)
)
SELECT remap_struct(
	a,
	NULL::STRUCT(i INTEGER, j INTEGER, k INTEGER)[],
	{
		'list': (
			'list', {
				'i': 'i',
				'j': 'j'
			}
		)
	},
	{
		'list': {
			'k': NULL::INTEGER
		}
	}
) from cte;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test(
	s STRUCT(
		i INTEGER,
		j INTEGER
	)[]
)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES
	([ROW(1, 1)]),
	([ROW(2, 2)])
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test ADD COLUMN s.element.k INTEGER
-- bwc_tag:end_query

select * from test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop table test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test(
	s STRUCT(
		a STRUCT(
			i INTEGER,
			j INTEGER
		)[]
	)
)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES
	(ROW([ROW(1, 1)])),
	(ROW([ROW(2, 2)]))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test ADD COLUMN s.a.element.k INTEGER
-- bwc_tag:end_query

select * from test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE test ADD COLUMN s.a.not_element INTEGER
-- bwc_tag:end_query

