-- bwc_tag:nb_steps=6
-- bwc_tag:execute_from_sql
CREATE TABLE test(i INTEGER, j INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (1, 1), (2, 2)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE INDEX i_index ON test(i)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE test ALTER i SET DATA TYPE VARCHAR
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP INDEX i_index
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test ALTER i SET DATA TYPE VARCHAR
-- bwc_tag:end_query

