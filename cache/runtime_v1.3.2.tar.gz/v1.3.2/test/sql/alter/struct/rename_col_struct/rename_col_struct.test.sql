-- bwc_tag:nb_steps=13
-- bwc_tag:execute_from_sql
CREATE TABLE test(s STRUCT(i INTEGER, j INTEGER))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (ROW(1, 1)), (ROW(2, 2))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test RENAME s.i TO v1
-- bwc_tag:end_query

SELECT * FROM test
-- bwc_tag:end_query

-- bwc_tag:skip_query
BEGIN
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test RENAME s.j TO v2
-- bwc_tag:end_query

SELECT * FROM test
-- bwc_tag:end_query

-- bwc_tag:skip_query
ROLLBACK
-- bwc_tag:end_query

SELECT * FROM test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE test RENAME s.j TO v1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE test RENAME s.j.x TO v2
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE test RENAME s.i TO v2
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE test RENAME x.i TO v2
-- bwc_tag:end_query

