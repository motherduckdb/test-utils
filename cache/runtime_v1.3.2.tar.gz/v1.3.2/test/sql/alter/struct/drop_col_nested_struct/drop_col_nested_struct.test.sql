-- bwc_tag:nb_steps=8
-- bwc_tag:execute_from_sql
CREATE TABLE test(s STRUCT(i INT, s2 STRUCT(v1 INT, v2 INT)))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (ROW(42, ROW(1, 1))), (ROW(84, ROW(2, 2)))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test DROP s.s2.v1
-- bwc_tag:end_query

SELECT * FROM test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE test DROP COLUMN s.s2.v1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test DROP COLUMN IF EXISTS s.s2.v1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test DROP COLUMN s.s2
-- bwc_tag:end_query

SELECT * FROM test
-- bwc_tag:end_query

