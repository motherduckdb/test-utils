-- bwc_tag:nb_steps=4
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test (a INTEGER[], b INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE test ADD PRIMARY KEY (a)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE test ADD PRIMARY KEY (a, b)
-- bwc_tag:end_query

