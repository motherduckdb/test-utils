-- bwc_tag:nb_steps=19
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

SELECT 'a' LIKE 'A' COLLATE NOCASE
-- bwc_tag:end_query

SELECT 'a' NOT LIKE 'A' COLLATE NOCASE
-- bwc_tag:end_query

SELECT 'A' COLLATE NOCASE LIKE 'a'
-- bwc_tag:end_query

SELECT 'a' LIKE 'A%' COLLATE NOCASE
-- bwc_tag:end_query

SELECT 'A' COLLATE NOCASE LIKE '%A' COLLATE NOCASE
-- bwc_tag:end_query

SELECT 'a' COLLATE NOCASE LIKE '%A%' COLLATE NOCASE
-- bwc_tag:end_query

SELECT 'OX' COLLATE NOACCENT.NOCASE LIKE 'ö%'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t1 (c1 VARCHAR, pattern VARCHAR)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES('A', 'a'),('a', 'A'),('AAAA', 'AaAa'),('aaaa', 'baba')
-- bwc_tag:end_query

SELECT c1 FROM t1 WHERE c1 LIKE pattern
-- bwc_tag:end_query

SELECT c1 FROM t1 WHERE c1 LIKE pattern COLLATE NOCASE
-- bwc_tag:end_query

SELECT 'a%ö' COLLATE NOACCENT LIKE 'a$%ö' ESCAPE '$'
-- bwc_tag:end_query

SELECT 'a%ö' COLLATE NOACCENT NOT LIKE 'a$%ö' ESCAPE '$'
-- bwc_tag:end_query

SELECT 'oX' ILIKE 'Ö%'
-- bwc_tag:end_query

SELECT 'OX' COLLATE NOACCENT ILIKE 'ö%'
-- bwc_tag:end_query

SELECT 'öX' COLLATE NOACCENT NOT ILIKE 'Ö%'
-- bwc_tag:end_query

SELECT 'oX' GLOB 'O*'
-- bwc_tag:end_query

SELECT 'oX' COLLATE NOCASE GLOB 'O*'
-- bwc_tag:end_query

