-- bwc_tag:nb_steps=8
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA threads=4
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA verify_parallelism
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS (SELECT string_agg(range::VARCHAR, '🦆 ') AS s, mod(range, 10000) xx FROM range(50000) GROUP BY xx)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test2 AS (SELECT unnest(string_split(s, ' ')) FROM test)
-- bwc_tag:end_query

SELECT count(*) FROM test2
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test3 AS (SELECT * FROM test ORDER BY xx)
-- bwc_tag:end_query

SELECT count(*) FROM test3
-- bwc_tag:end_query

