-- bwc_tag:nb_steps=27
ATTACH 'output/macro_default_arg.db' (STORAGE_VERSION 'v1.0.0');
-- bwc_tag:end_query

USE macro_default_arg
-- bwc_tag:end_query

set enable_macro_dependencies=true
-- bwc_tag:end_query

-- bwc_tag:skip_query
pragma enable_verification;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO f(x := NULL) AS x+1;
-- bwc_tag:end_query

SELECT f();
-- bwc_tag:end_query

SELECT f(x := 41)
-- bwc_tag:end_query

SELECT f(x := (SELECT 41));
-- bwc_tag:end_query

select f(x:=(select 1 a));
-- bwc_tag:end_query

select f(x:=a) from (select 41) t(a);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table t as select 41 a;
-- bwc_tag:end_query

select f(x:=a) from t;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

create macro my_macro1(a, b := a) as a + b;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table integers (a integer);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create macro my_macro2(a := i) as (
	select min(a) from integers
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into integers values (5), (10), (13)
-- bwc_tag:end_query

select my_macro2(can_not_be_empty)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

drop table integers;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop table integers cascade;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select my_macro2(5);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
Create table t1 (a int, b int);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
Create table t2 (c int, d int);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE MACRO eq(x := NULL, y := NULL) AS x = y
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES (1, 1), (1, 2), (2, 2), (3, 4);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t2 VALUES (4, 1), (2, 10), (6, 2), (2, 6);
-- bwc_tag:end_query

SELECT * FROM t1 as t1_alias inner join (select * from t2) as t2_alias ON (eq(x := t1_alias.a, y := t2_alias.c))
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM t1 as t1_alias inner join (select * from t2) as t2_alias ON (eq(a := t1_alias.a, c := t2_alias.c))
-- bwc_tag:end_query

