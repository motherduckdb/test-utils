-- bwc_tag:nb_steps=14
-- bwc_tag:execute_from_sql
CREATE TABLE "MyTable"(i integer);
-- bwc_tag:end_query

SELECT * FROM mytable;
-- bwc_tag:end_query

SELECT * FROM MyTable;
-- bwc_tag:end_query

SELECT * FROM "MyTable";
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE MyTable ADD COLUMN j INTEGER;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE MyTable RENAME TO "MyOtherTable"
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE MyOtherTable;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE "ABC"(i integer);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE TABLE "AbC"(i integer);
-- bwc_tag:end_query

SELECT * FROM "ABC";
-- bwc_tag:end_query

SELECT * FROM abc; -- error: which table did I mean?
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE abc ADD COLUMN j INTEGER;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE "ABC" ADD COLUMN "J" INTEGER;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE abc
-- bwc_tag:end_query

