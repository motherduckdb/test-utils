-- bwc_tag:nb_steps=7
-- bwc_tag:skip_query
pragma enable_verification;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table tbl(a varchar default 'abc');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into tbl values(DEFAULT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create macro mcr() as table select * from tbl;
-- bwc_tag:end_query

select * from mcr();
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
alter table tbl add column b integer default 5;
-- bwc_tag:end_query

select * from mcr();
-- bwc_tag:end_query

