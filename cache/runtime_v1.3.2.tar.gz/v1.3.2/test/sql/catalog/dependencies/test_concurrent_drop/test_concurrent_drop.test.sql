-- bwc_tag:nb_steps=2
-- bwc_tag:execute_from_sql
create sequence seq;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop sequence seq;
-- bwc_tag:end_query

