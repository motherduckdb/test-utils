-- bwc_tag:nb_steps=23
set storage_compatibility_version='v0.10.2'
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create schema my_schema;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW my_schema.X (a) AS SELECT 'x' as x, 'y' as y;
-- bwc_tag:end_query

select trim(sql, chr(10)) from duckdb_views() where internal = false;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
alter view my_schema.X rename to Y;
-- bwc_tag:end_query

select trim(sql, chr(10)) from duckdb_views() where internal = false;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop schema my_schema cascade;
-- bwc_tag:end_query

select trim(sql, chr(10)) from duckdb_views() where internal = false;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table tbl (
	a integer,
	b varchar
)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create view vw as select * from tbl;
-- bwc_tag:end_query

select trim(sql, chr(10)) from duckdb_views() where internal = false;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
alter table tbl rename column b to x;
-- bwc_tag:end_query

select trim(sql, chr(10)) from duckdb_views() where internal = false;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create or replace view vw (c1, c2) as select * from tbl;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create or replace table "table name" (
	"column name 1" integer,
	"column name 2" varchar
)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create or replace view "view name" as select * from "table name";
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop view vw;
-- bwc_tag:end_query

select trim(sql, chr(10)) from duckdb_views() where internal = false;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop view "view name"
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create schema "schema name";
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW "schema name"."view name" ("other name 1", "column name 2") AS SELECT * FROM "table name";
-- bwc_tag:end_query

select trim(sql, chr(10)) from duckdb_views() where internal = false;
-- bwc_tag:end_query

