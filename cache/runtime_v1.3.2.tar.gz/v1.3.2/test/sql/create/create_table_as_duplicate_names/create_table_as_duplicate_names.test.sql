-- bwc_tag:nb_steps=14
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
SELECT * FROM range(5) tbl1(i) JOIN range(5) tbl2(i) ON tbl1.i=tbl2.i;
-- bwc_tag:end_query

SELECT i, i FROM range(5) tbl(i)
-- bwc_tag:end_query

SELECT * FROM (SELECT i, i FROM range(5) tbl(i)) tbl;
-- bwc_tag:end_query

SELECT * FROM (SELECT i, i, i, i FROM range(5) tbl(i)) tbl;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t1 AS SELECT i, i FROM range(5) tbl(i)
-- bwc_tag:end_query

SELECT * FROM t1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t2 AS SELECT i, i, i, i FROM range(5) tbl(i)
-- bwc_tag:end_query

SELECT * FROM (SELECT i, i, i, i FROM range(5) tbl(i)) tbl;
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
SELECT * FROM (SELECT * FROM range(5) tbl1(i) JOIN range(5) tbl2(i) ON tbl1.i=tbl2.i) tbl;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t3 AS SELECT tbl1.i, tbl2.i FROM range(5) tbl1(i) JOIN range(5) tbl2(i) ON tbl1.i=tbl2.i;
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
SELECT * FROM t3
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t4 AS SELECT * FROM range(5) tbl1(i) JOIN range(5) tbl2(i) ON tbl1.i=tbl2.i;
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
SELECT * FROM t4
-- bwc_tag:end_query

