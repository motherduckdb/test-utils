-- bwc_tag:nb_steps=6
-- bwc_tag:execute_from_sql
CREATE TABLE departments (
    department_id INTEGER PRIMARY KEY,
    department_name VARCHAR(100) NOT NULL
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE employees (
    employee_id INTEGER PRIMARY KEY,
    employee_name VARCHAR(100) NOT NULL,
    department_id INT REFERENCES departments(department_id)
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

drop table departments
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE departments RENAME TO old_departments
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

drop table departments
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE employees RENAME TO old_employees
-- bwc_tag:end_query

