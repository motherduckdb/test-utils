-- bwc_tag:nb_steps=6
-- bwc_tag:execute_from_sql
CREATE TABLE numbers(a integer, b integer, c integer, d integer, e integer, PRIMARY KEY(a,b,c,d,e))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO numbers VALUES (1,1,1,1,1), (1,1,1,1,1)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO numbers VALUES (1,1,1,1,1),(1,2,1,1,1),(1,1,2,1,1),(2,2,2,2,2)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO numbers VALUES (1,1,1,1,1),(1,1,1,1,4);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO numbers VALUES (1,1,1,1,4);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

UPDATE numbers SET c=1 WHERE c=2
-- bwc_tag:end_query

