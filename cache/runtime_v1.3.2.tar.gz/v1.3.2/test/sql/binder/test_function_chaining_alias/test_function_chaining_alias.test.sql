-- bwc_tag:nb_steps=18
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

SELECT 'test' || ' more testing' AS added, added.substr(5) AS my_substr
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE varchars(v VARCHAR);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO varchars VALUES ('>>%Test<<'), ('%FUNCTION%'), ('Chaining')
-- bwc_tag:end_query

SELECT v.lower() FROM varchars
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT
	v.trim('><') AS trim_inequality,
	only_alphabet.lower() AS lower,
	trim_inequality.replace('%', '') AS only_alphabet,
FROM varchars
-- bwc_tag:end_query

SELECT
	v.trim('><') AS trim_inequality,
	trim_inequality.replace('%', '') AS only_alphabet,
	only_alphabet.lower() AS lower
FROM varchars
-- bwc_tag:end_query

SELECT
	varchars.v.trim('><') AS trim_inequality,
	trim_inequality.replace('%', '') AS only_alphabet,
	only_alphabet.lower() AS lower
FROM varchars
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DELETE FROM varchars
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO varchars VALUES ('Test Function Chaining Alias');
-- bwc_tag:end_query

SELECT
	v.split(' ')::VARCHAR strings,
	strings.lower() lower,
	lower.upper() upper
FROM varchars
-- bwc_tag:end_query

SELECT
	v.split(' ') strings,
	strings.apply(lambda x: x.lower()).filter(lambda x: x[1] == 't') lower,
	strings.apply(lambda x: x.upper()).filter(lambda x: x[1] == 'T') upper,
	lower + upper AS mix_case_srings
FROM varchars
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PREPARE v1 AS 
SELECT
	(?.split(' ')::VARCHAR).lower() lstrings,
	(?.split(' ')::VARCHAR).upper() ustrings,
	list_concat(lstrings::VARCHAR[], ustrings::VARCHAR[]) AS mix_case_srings
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
EXECUTE v1('Hello World', 'test function chaining')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO varchars VALUES ('Another longggggg String');
-- bwc_tag:end_query

SELECT
	v.split(' ') strings,
	strings.apply(lambda x: x.lower()).filter(lambda x: x[1] == 't' OR x[1] == 'a') lower,
	strings.apply(lambda x: x.upper()).filter(lambda x: x[1] == 'T' OR x[1] == 'A') upper,
	lower + upper AS mix_case_srings
FROM varchars
WHERE mix_case_srings[1] = 'test'
-- bwc_tag:end_query

SELECT
	v.split(' ') strings,
	strings.apply(lambda x: x.lower()).filter(lambda x: x[1] == 't' OR x[1] == 'a') lower,
	strings.apply(lambda x: x.upper()).filter(lambda x: x[1] == 'T' OR x[1] == 'A') upper,
	lower + upper AS mix_case_srings
FROM varchars
WHERE mix_case_srings[1] = 'another'
-- bwc_tag:end_query

WITH test AS (
    SELECT 'woot' AS my_column
)
FROM test
SELECT
	my_column.substr(2) AS partial_woot,
	partial_woot.substr(2) AS more_partially_woot
WHERE
    more_partially_woot = 'ot';
-- bwc_tag:end_query

