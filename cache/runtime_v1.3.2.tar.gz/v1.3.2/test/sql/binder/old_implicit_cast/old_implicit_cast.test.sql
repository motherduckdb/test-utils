-- bwc_tag:nb_steps=8
-- bwc_tag:execute_from_sql
CREATE TABLE integers AS SELECT 42 AS i, '5' AS v;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT i >= v FROM integers
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT i[1] FROM integers
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT [i, v] FROM integers
-- bwc_tag:end_query

SET old_implicit_casting=true
-- bwc_tag:end_query

SELECT i[1] FROM integers
-- bwc_tag:end_query

SELECT i >= v FROM integers
-- bwc_tag:end_query

SELECT [i, v] FROM integers
-- bwc_tag:end_query

