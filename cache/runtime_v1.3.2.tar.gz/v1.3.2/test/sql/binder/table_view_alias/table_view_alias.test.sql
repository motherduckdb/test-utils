-- bwc_tag:nb_steps=10
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA s1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW s1.v AS SELECT 42 c;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE s1.t AS SELECT 42 c
-- bwc_tag:end_query

SELECT s1.v.c, v.c, c FROM s1.v
-- bwc_tag:end_query

SELECT s1.t.c, t.c, c FROM s1.t
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT s1.t.c, t.c, c FROM s1.t AS t
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT s1.x.c FROM s1.v AS x
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT s1.v.c FROM s1.v AS x
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT s1.v.c FROM s1.v AS v
-- bwc_tag:end_query

