-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=6
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t1(part_key INT, val INT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 SELECT i%2, i FROM range(10) t(i);
-- bwc_tag:end_query

COPY t1 TO 'output/hive_filters' (FORMAT PARQUET, PARTITION_BY part_key, HIVE_FILE_PATTERN false, WRITE_PARTITION_COLUMNS true);
-- bwc_tag:end_query

SELECT file.replace('output', '').replace('\', '/') FROM GLOB('output/hive_filters/*.parquet') ORDER BY ALL
-- bwc_tag:end_query

FROM 'output/hive_filters/*.parquet' EXCEPT ALL FROM t1
-- bwc_tag:end_query

