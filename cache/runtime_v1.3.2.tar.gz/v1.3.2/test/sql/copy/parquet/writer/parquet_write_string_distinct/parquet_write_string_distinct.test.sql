-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=4
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

COPY (SELECT 'hello' FROM range(10)) TO 'output/string_dict.parquet';
-- bwc_tag:end_query

SELECT stats_distinct_count FROM parquet_metadata('output/string_dict.parquet');
-- bwc_tag:end_query

