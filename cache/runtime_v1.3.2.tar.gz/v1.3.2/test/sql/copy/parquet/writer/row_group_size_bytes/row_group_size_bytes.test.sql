-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=14
LOAD 'parquet';
-- bwc_tag:end_query

SET preserve_insertion_order=false
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

copy (select 42) to 'output/tbl.parquet' (ROW_GROUP_SIZE_BYTES)
-- bwc_tag:end_query

copy (
    select range c0,
           range c1,
           range c2,
           range c3,
           range c4,
           range c5,
           range c6,
           range c7,
    from range(50000)
) to 'output/tbl.parquet' (ROW_GROUP_SIZE_BYTES '1mb')
-- bwc_tag:end_query

select max(row_group_num_rows) from parquet_metadata('output/tbl.parquet')
-- bwc_tag:end_query

select min(row_group_bytes) != 0 from parquet_metadata('output/tbl.parquet')
-- bwc_tag:end_query

copy (
    select range c0,
           range c1,
           range c2,
           range c3,
           range c4,
           range c5,
           range c6,
           range c7,
    from range(50000)
) to 'output/tbl.parquet' (ROW_GROUP_SIZE_BYTES 500000)
-- bwc_tag:end_query

select max(row_group_num_rows) from parquet_metadata('output/tbl.parquet')
-- bwc_tag:end_query

copy (
    select range c0,
           range c1,
           range c2,
           range c3,
           range c4,
           range c5,
           range c6,
           range c7,
    from range(50000)
) to 'output/tbl.parquet' (ROW_GROUP_SIZE 10000, ROW_GROUP_SIZE_BYTES '1GB')
-- bwc_tag:end_query

select max(row_group_num_rows) from parquet_metadata('output/tbl.parquet')
-- bwc_tag:end_query

copy (
    select range || repeat('0', 50) c0
    from range(50000)
) to 'output/tbl.parquet' (ROW_GROUP_SIZE_BYTES 200000)
-- bwc_tag:end_query

select max(row_group_num_rows) from parquet_metadata('output/tbl.parquet')
-- bwc_tag:end_query

copy (
    select range || repeat('0', 50) c0
    from range(50000)
) to 'output/tbl.parquet' (ROW_GROUP_SIZE_BYTES 650000)
-- bwc_tag:end_query

select max(row_group_num_rows) from parquet_metadata('output/tbl.parquet')
-- bwc_tag:end_query

