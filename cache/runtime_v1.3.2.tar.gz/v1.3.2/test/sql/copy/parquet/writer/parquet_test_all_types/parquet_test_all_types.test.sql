-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=20
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE all_types AS
SELECT * EXCLUDE (bit, "union") REPLACE (
	case when extract(month from interval) <> 0 then interval '1 month 1 day 12:13:34.123' else interval end AS interval
)
FROM test_all_types();
-- bwc_tag:end_query

COPY all_types TO "output/all_types.parquet" (FORMAT PARQUET);
-- bwc_tag:end_query

SELECT * REPLACE (
	hugeint::DOUBLE AS hugeint,
	uhugeint::DOUBLE AS uhugeint,
	time_tz::TIME::TIMETZ AS time_tz
)
FROM all_types
-- bwc_tag:end_query

SELECT *
FROM 'output/all_types.parquet'
-- bwc_tag:end_query

explain select "TINYINT" from 'output/all_types.parquet' 
WHERE "TINYINT" IN (127);
-- bwc_tag:end_query

explain select "SMALLINT" from 'output/all_types.parquet' 
WHERE "SMALLINT" IN (127);
-- bwc_tag:end_query

explain select "INT" from 'output/all_types.parquet' 
WHERE "INT" IN (127);
-- bwc_tag:end_query

explain select "BIGINT" from 'output/all_types.parquet' 
WHERE "BIGINT" IN (127);
-- bwc_tag:end_query

explain select "UTINYINT" from 'output/all_types.parquet' 
WHERE "UTINYINT" IN (127);
-- bwc_tag:end_query

explain select "USMALLINT" from 'output/all_types.parquet' 
WHERE "USMALLINT" IN (127);
-- bwc_tag:end_query

explain select "UINT" from 'output/all_types.parquet' 
WHERE "UINT" IN (127);
-- bwc_tag:end_query

explain select "UBIGINT" from 'output/all_types.parquet' 
WHERE "UBIGINT" IN (127);
-- bwc_tag:end_query

explain select "HUGEINT" from 'output/all_types.parquet' 
WHERE "HUGEINT" IN (127);
-- bwc_tag:end_query

explain select "UHUGEINT" from 'output/all_types.parquet' 
WHERE "UHUGEINT" IN (127);
-- bwc_tag:end_query

explain select "FLOAT" from 'output/all_types.parquet' 
WHERE "FLOAT" IN (127);
-- bwc_tag:end_query

explain select "DOUBLE" from 'output/all_types.parquet' 
WHERE "DOUBLE" IN (127);
-- bwc_tag:end_query

explain select "VARCHAR" from 'output/all_types.parquet' 
WHERE "VARCHAR" IN ('🦆🦆🦆🦆🦆🦆');
-- bwc_tag:end_query

explain select "bool" from 'output/all_types.parquet' 
WHERE "bool" IN (true);
-- bwc_tag:end_query

