-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=15
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM read_parquet('data/parquet-testing/hive-partitioning/union_by_name/*/*.parquet', hive_partitioning=1)
-- bwc_tag:end_query

SELECT i, j, k, x
FROM read_parquet('data/parquet-testing/hive-partitioning/union_by_name/*/*.parquet', hive_partitioning=0, union_by_name=1)
ORDER BY j, x NULLS LAST
-- bwc_tag:end_query

SELECT i, j, k, x
FROM read_parquet('data/parquet-testing/hive-partitioning/union_by_name/*/*.parquet', hive_partitioning=1, union_by_name=1)
ORDER BY j
-- bwc_tag:end_query

SELECT i, j, k, x
FROM read_parquet('data/parquet-testing/hive-partitioning/union_by_name/*/*.parquet', hive_partitioning=1, union_by_name=1)
WHERE x=2
ORDER BY j
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE selected_values AS SELECT 2 x
-- bwc_tag:end_query

SELECT i, j, k, x
FROM read_parquet('data/parquet-testing/hive-partitioning/union_by_name/*/*.parquet', hive_partitioning=1, union_by_name=1)
WHERE x=(SELECT MAX(x) FROM selected_values)
ORDER BY j
-- bwc_tag:end_query

SELECT i, j, k, x
FROM read_parquet('data/parquet-testing/hive-partitioning/union_by_name/*/f2.parquet', hive_partitioning=1, union_by_name=1)
ORDER BY j
-- bwc_tag:end_query

SELECT i, j, k, x
FROM read_parquet('data/parquet-testing/hive-partitioning/union_by_name/*/f2.parquet', hive_partitioning=1, union_by_name=1)
WHERE k IS NULL
ORDER BY j
-- bwc_tag:end_query

SELECT i, j, k, x
FROM read_parquet('data/parquet-testing/hive-partitioning/union_by_name/*/f2.parquet', hive_partitioning=1, union_by_name=1)
WHERE k IS NOT DISTINCT FROM NULL
ORDER BY j
-- bwc_tag:end_query

SELECT i, j, k, x
FROM read_parquet('data/parquet-testing/hive-partitioning/union_by_name/*/f2.parquet', hive_partitioning=1, union_by_name=1)
WHERE k>0
ORDER BY j
-- bwc_tag:end_query

SELECT i, j, k, x, filename.replace('\', '/').split('/')[-2]
FROM read_parquet('data/parquet-testing/hive-partitioning/union_by_name/*/f2.parquet', hive_partitioning=1, union_by_name=1, filename=1)
WHERE k>0
ORDER BY j
-- bwc_tag:end_query

SELECT i, j, k, x, filename.replace('\', '/').split('/')[-2]
FROM read_parquet('data/parquet-testing/hive-partitioning/union_by_name/*/f2.parquet', hive_partitioning=1, union_by_name=1, filename=1)
WHERE filename.replace('\', '/') >= 'data/parquet-testing/hive-partitioning/union_by_name/x=2'
ORDER BY j
-- bwc_tag:end_query

SELECT i, j, k, x, filename.replace('\', '/').split('/')[-2]
FROM read_parquet('data/parquet-testing/hive-partitioning/union_by_name/*/f2.parquet', hive_partitioning=1, union_by_name=1, filename=1)
WHERE filename.replace('\', '/') < 'data/parquet-testing/hive-partitioning/union_by_name/x=2'
ORDER BY j
-- bwc_tag:end_query

SELECT i, j, k, x, filename.replace('\', '/').split('/')[-2]
FROM read_parquet('data/parquet-testing/hive-partitioning/union_by_name/*/f2.parquet', hive_partitioning=1, union_by_name=1, filename=1)
WHERE filename.replace('\', '/') < 'data/parquet-testing/hive-partitioning/union_by_name/x=1'
ORDER BY j
-- bwc_tag:end_query

