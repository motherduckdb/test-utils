-- bwc_tag:nb_steps=2
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/customer.4.csv', auto_detect=false, delim='|', quote='"', escape='"', new_line='\n', skip=0, header=false,  columns = {'c_custkey': 'BIGINT', 'c_name': 'VARCHAR', 'c_address': 'VARCHAR', 'c_nationkey': 'INTEGER', 'c_phone': 'VARCHAR', 'c_acctbal': 'DECIMAL(15, 2)', 'c_mktsegment': 'VARCHAR', 'c_comment': 'VARCHAR'}, parallel=true, buffer_size = 300);
-- bwc_tag:end_query

