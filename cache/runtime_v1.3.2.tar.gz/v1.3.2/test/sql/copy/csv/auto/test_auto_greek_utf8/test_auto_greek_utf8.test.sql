-- bwc_tag:nb_steps=6
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA verify_parallelism
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE greek_utf8 AS SELECT i, nfc_normalize(j) j, k FROM read_csv_auto ('data/csv/real/greek_utf8.csv') t(i, j, k)
-- bwc_tag:end_query

SELECT COUNT(*) FROM greek_utf8;
-- bwc_tag:end_query

SELECT * FROM greek_utf8 ORDER BY 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT i, nfc_normalize(j) j, k FROM 'data/csv/real/greek_utf8.csv' t(i, j, k)
-- bwc_tag:end_query

