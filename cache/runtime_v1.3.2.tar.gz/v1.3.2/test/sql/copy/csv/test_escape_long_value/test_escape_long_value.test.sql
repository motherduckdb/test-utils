-- bwc_tag:nb_steps=73
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE T AS FROM read_csv('data/csv/big_escape.csv', buffer_size = 28, quote = '"', escape = '"', delim = ';', columns = {'a':'INTEGER','b':'INTEGER', 'c':'VARCHAR'}, auto_detect = false)
-- bwc_tag:end_query

select count(*) from T;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE T;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE T AS FROM read_csv('data/csv/big_escape.csv', buffer_size = 29, quote = '"', escape = '"', delim = ';', columns = {'a':'INTEGER','b':'INTEGER', 'c':'VARCHAR'}, auto_detect = false)
-- bwc_tag:end_query

select count(*) from T;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE T;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE T AS FROM read_csv('data/csv/big_escape.csv', buffer_size = 30, quote = '"', escape = '"', delim = ';', columns = {'a':'INTEGER','b':'INTEGER', 'c':'VARCHAR'}, auto_detect = false)
-- bwc_tag:end_query

select count(*) from T;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE T;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE T AS FROM read_csv('data/csv/big_escape.csv', buffer_size = 31, quote = '"', escape = '"', delim = ';', columns = {'a':'INTEGER','b':'INTEGER', 'c':'VARCHAR'}, auto_detect = false)
-- bwc_tag:end_query

select count(*) from T;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE T;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE T AS FROM read_csv('data/csv/big_escape.csv', buffer_size = 32, quote = '"', escape = '"', delim = ';', columns = {'a':'INTEGER','b':'INTEGER', 'c':'VARCHAR'}, auto_detect = false)
-- bwc_tag:end_query

select count(*) from T;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE T;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE T AS FROM read_csv('data/csv/big_escape.csv', buffer_size = 33, quote = '"', escape = '"', delim = ';', columns = {'a':'INTEGER','b':'INTEGER', 'c':'VARCHAR'}, auto_detect = false)
-- bwc_tag:end_query

select count(*) from T;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE T;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE T AS FROM read_csv('data/csv/big_escape.csv', buffer_size = 34, quote = '"', escape = '"', delim = ';', columns = {'a':'INTEGER','b':'INTEGER', 'c':'VARCHAR'}, auto_detect = false)
-- bwc_tag:end_query

select count(*) from T;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE T;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE T AS FROM read_csv('data/csv/big_escape.csv', buffer_size = 35, quote = '"', escape = '"', delim = ';', columns = {'a':'INTEGER','b':'INTEGER', 'c':'VARCHAR'}, auto_detect = false)
-- bwc_tag:end_query

select count(*) from T;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE T;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE T AS FROM read_csv('data/csv/big_escape.csv', buffer_size = 36, quote = '"', escape = '"', delim = ';', columns = {'a':'INTEGER','b':'INTEGER', 'c':'VARCHAR'}, auto_detect = false)
-- bwc_tag:end_query

select count(*) from T;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE T;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE T AS FROM read_csv('data/csv/big_escape.csv', buffer_size = 37, quote = '"', escape = '"', delim = ';', columns = {'a':'INTEGER','b':'INTEGER', 'c':'VARCHAR'}, auto_detect = false)
-- bwc_tag:end_query

select count(*) from T;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE T;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE T AS FROM read_csv('data/csv/big_escape.csv', buffer_size = 38, quote = '"', escape = '"', delim = ';', columns = {'a':'INTEGER','b':'INTEGER', 'c':'VARCHAR'}, auto_detect = false)
-- bwc_tag:end_query

select count(*) from T;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE T;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE T AS FROM read_csv('data/csv/big_escape.csv', buffer_size = 39, quote = '"', escape = '"', delim = ';', columns = {'a':'INTEGER','b':'INTEGER', 'c':'VARCHAR'}, auto_detect = false)
-- bwc_tag:end_query

select count(*) from T;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE T;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE T AS FROM read_csv('data/csv/big_escape.csv', buffer_size = 40, quote = '"', escape = '"', delim = ';', columns = {'a':'INTEGER','b':'INTEGER', 'c':'VARCHAR'}, auto_detect = false)
-- bwc_tag:end_query

select count(*) from T;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE T;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE T AS FROM read_csv('data/csv/big_escape.csv', buffer_size = 41, quote = '"', escape = '"', delim = ';', columns = {'a':'INTEGER','b':'INTEGER', 'c':'VARCHAR'}, auto_detect = false)
-- bwc_tag:end_query

select count(*) from T;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE T;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE T AS FROM read_csv('data/csv/big_escape.csv', buffer_size = 42, quote = '"', escape = '"', delim = ';', columns = {'a':'INTEGER','b':'INTEGER', 'c':'VARCHAR'}, auto_detect = false)
-- bwc_tag:end_query

select count(*) from T;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE T;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE T AS FROM read_csv('data/csv/big_escape.csv', buffer_size = 43, quote = '"', escape = '"', delim = ';', columns = {'a':'INTEGER','b':'INTEGER', 'c':'VARCHAR'}, auto_detect = false)
-- bwc_tag:end_query

select count(*) from T;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE T;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE T AS FROM read_csv('data/csv/big_escape.csv', buffer_size = 44, quote = '"', escape = '"', delim = ';', columns = {'a':'INTEGER','b':'INTEGER', 'c':'VARCHAR'}, auto_detect = false)
-- bwc_tag:end_query

select count(*) from T;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE T;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE T AS FROM read_csv('data/csv/big_escape.csv', buffer_size = 45, quote = '"', escape = '"', delim = ';', columns = {'a':'INTEGER','b':'INTEGER', 'c':'VARCHAR'}, auto_detect = false)
-- bwc_tag:end_query

select count(*) from T;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE T;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE T AS FROM read_csv('data/csv/big_escape.csv', buffer_size = 46, quote = '"', escape = '"', delim = ';', columns = {'a':'INTEGER','b':'INTEGER', 'c':'VARCHAR'}, auto_detect = false)
-- bwc_tag:end_query

select count(*) from T;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE T;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE T AS FROM read_csv('data/csv/big_escape.csv', buffer_size = 47, quote = '"', escape = '"', delim = ';', columns = {'a':'INTEGER','b':'INTEGER', 'c':'VARCHAR'}, auto_detect = false)
-- bwc_tag:end_query

select count(*) from T;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE T;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE T AS FROM read_csv('data/csv/big_escape.csv', buffer_size = 48, quote = '"', escape = '"', delim = ';', columns = {'a':'INTEGER','b':'INTEGER', 'c':'VARCHAR'}, auto_detect = false)
-- bwc_tag:end_query

select count(*) from T;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE T;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE T AS FROM read_csv('data/csv/big_escape.csv', buffer_size = 49, quote = '"', escape = '"', delim = ';', columns = {'a':'INTEGER','b':'INTEGER', 'c':'VARCHAR'}, auto_detect = false)
-- bwc_tag:end_query

select count(*) from T;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE T;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE long_escaped_value (a INTEGER, b INTEGER, c VARCHAR);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY long_escaped_value FROM 'data/csv/test/long_escaped_value.csv' (DELIMITER '🦆', AUTO_DETECT FALSE, QUOTE '"', ESCAPE '"');
-- bwc_tag:end_query

SELECT * FROM long_escaped_value
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE long_escaped_value_unicode (a INTEGER, b INTEGER, c VARCHAR);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY long_escaped_value_unicode FROM 'data/csv/test/long_escaped_value_unicode.csv';
-- bwc_tag:end_query

SELECT * FROM long_escaped_value_unicode
-- bwc_tag:end_query

