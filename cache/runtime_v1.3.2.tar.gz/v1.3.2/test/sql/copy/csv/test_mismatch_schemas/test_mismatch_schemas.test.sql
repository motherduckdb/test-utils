-- bwc_tag:nb_steps=9
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv(['data/csv/multiple_files/more_columns/file_1.csv','data/csv/multiple_files/more_columns/file_2.csv',
'data/csv/multiple_files/more_columns/file_3.csv','data/csv/multiple_files/more_columns/file_4.csv'])
ORDER BY ALL;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT * FROM read_csv(['data/csv/multiple_files/more_columns/file_1.csv','data/csv/multiple_files/more_columns/file_2.csv',
'data/csv/multiple_files/more_columns/file_3.csv','data/csv/multiple_files/more_columns/file_no_header.csv'])
ORDER BY ALL;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT * FROM read_csv(['data/csv/multiple_files/more_columns/file_1.csv','data/csv/multiple_files/more_columns/file_2.csv',
'data/csv/multiple_files/more_columns/file_3.csv','data/csv/multiple_files/more_columns/file_5.csv'])
ORDER BY ALL;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT * FROM read_csv(['data/csv/multiple_files/more_columns/file_2.csv','data/csv/multiple_files/more_columns/file_1.csv',
'data/csv/multiple_files/more_columns/file_3.csv','data/csv/multiple_files/more_columns/file_4.csv'])
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv(['data/csv/multiple_files/different_order/file_1.csv','data/csv/multiple_files/different_order/file_2.csv'])
ORDER BY ALL;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv(['data/csv/multiple_files/more_columns/file_1.csv','data/csv/multiple_files/more_columns/file_6.csv'])
ORDER BY ALL;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT * FROM read_csv(['data/csv/multiple_files/more_columns/file_6.csv','data/csv/multiple_files/more_columns/file_1.csv'])
ORDER BY ALL;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv(['data/csv/multiple_files/more_columns/file_6.csv','data/csv/multiple_files/more_columns/file_6.csv'])
ORDER BY ALL;
-- bwc_tag:end_query

