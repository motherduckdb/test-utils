-- bwc_tag:nb_steps=3
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select count(*) from read_csv_auto('data/csv/borked_date.csv', header = 0)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select count(*) from read_csv_auto('data/csv/big_not_bool.csv', header = 0)
-- bwc_tag:end_query

