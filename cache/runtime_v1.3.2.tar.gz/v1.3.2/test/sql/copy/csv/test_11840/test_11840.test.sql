-- bwc_tag:nb_steps=3
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM 'data/csv/date_specificity.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select d FROM 'data/csv/special_date.csv'
-- bwc_tag:end_query

