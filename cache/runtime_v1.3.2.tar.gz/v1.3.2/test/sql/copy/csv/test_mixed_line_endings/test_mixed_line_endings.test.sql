-- bwc_tag:nb_steps=3
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test (a INTEGER, b VARCHAR, c INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into test select * from read_csv_auto('data/csv/test/mixed_line_endings.csv', strict_mode=false);
-- bwc_tag:end_query

