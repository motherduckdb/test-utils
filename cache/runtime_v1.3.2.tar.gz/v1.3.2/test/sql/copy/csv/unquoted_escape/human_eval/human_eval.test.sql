-- bwc_tag:needed_extensions=httpfs;json
-- bwc_tag:nb_steps=82
LOAD 'httpfs';
-- bwc_tag:end_query

LOAD 'json';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE human_eval_jsonl AS
SELECT REPLACE(COLUMNS(*), '    ', E'\t') FROM read_ndjson_auto(
'https://raw.githubusercontent.com/openai/human-eval/refs/heads/master/data/HumanEval.jsonl.gz');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DELETE FROM human_eval_jsonl WHERE split_part(task_id, '/', 2)::int >= 10;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE human_eval_csv(task_id TEXT, prompt TEXT, entry_point TEXT, canonical_solution TEXT, test TEXT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE human_eval_tsv(task_id TEXT, prompt TEXT, entry_point TEXT, canonical_solution TEXT, test TEXT);
-- bwc_tag:end_query

TRUNCATE human_eval_csv;
-- bwc_tag:end_query

TRUNCATE human_eval_tsv;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO human_eval_csv
SELECT replace(COLUMNS(*), E'\r\n', E'\n')
FROM read_csv('data/csv/unquoted_escape/human_eval.csv', quote = '', escape = '\', sep = ',', header = false, strict_mode = false);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO human_eval_tsv
SELECT replace(COLUMNS(*), E'\r\n', E'\n')
FROM read_csv('data/csv/unquoted_escape/human_eval.tsv', quote = '', escape = '\', sep = '\t', header = false, strict_mode = false);
-- bwc_tag:end_query

SELECT count(*), bool_and(
    j.task_id = c.task_id AND j.task_id = t.task_id AND
    j.prompt = c.prompt AND j.prompt = t.prompt AND
    j.entry_point = c.entry_point AND j.entry_point = t.entry_point AND
    j.canonical_solution = c.canonical_solution AND j.canonical_solution = t.canonical_solution AND
    j.test = c.test AND j.test = t.test
)::int
FROM human_eval_jsonl j, human_eval_csv c, human_eval_tsv t
WHERE j.task_id = c.task_id AND j.task_id = t.task_id
-- bwc_tag:end_query

TRUNCATE human_eval_csv;
-- bwc_tag:end_query

TRUNCATE human_eval_tsv;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO human_eval_csv
SELECT replace(COLUMNS(*), E'\r\n', E'\n')
FROM read_csv('data/csv/unquoted_escape/human_eval.csv', quote = '', escape = '\', sep = ',', header = false, strict_mode = false);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO human_eval_tsv
SELECT replace(COLUMNS(*), E'\r\n', E'\n')
FROM read_csv('data/csv/unquoted_escape/human_eval.tsv', quote = '', escape = '\', sep = '\t', header = false, strict_mode = false);
-- bwc_tag:end_query

SELECT count(*), bool_and(
    j.task_id = c.task_id AND j.task_id = t.task_id AND
    j.prompt = c.prompt AND j.prompt = t.prompt AND
    j.entry_point = c.entry_point AND j.entry_point = t.entry_point AND
    j.canonical_solution = c.canonical_solution AND j.canonical_solution = t.canonical_solution AND
    j.test = c.test AND j.test = t.test
)::int
FROM human_eval_jsonl j, human_eval_csv c, human_eval_tsv t
WHERE j.task_id = c.task_id AND j.task_id = t.task_id
-- bwc_tag:end_query

TRUNCATE human_eval_csv;
-- bwc_tag:end_query

TRUNCATE human_eval_tsv;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO human_eval_csv
SELECT replace(COLUMNS(*), E'\r\n', E'\n')
FROM read_csv('data/csv/unquoted_escape/human_eval.csv', quote = '', escape = '\', sep = ',', header = false, strict_mode = false);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO human_eval_tsv
SELECT replace(COLUMNS(*), E'\r\n', E'\n')
FROM read_csv('data/csv/unquoted_escape/human_eval.tsv', quote = '', escape = '\', sep = '\t', header = false, strict_mode = false);
-- bwc_tag:end_query

SELECT count(*), bool_and(
    j.task_id = c.task_id AND j.task_id = t.task_id AND
    j.prompt = c.prompt AND j.prompt = t.prompt AND
    j.entry_point = c.entry_point AND j.entry_point = t.entry_point AND
    j.canonical_solution = c.canonical_solution AND j.canonical_solution = t.canonical_solution AND
    j.test = c.test AND j.test = t.test
)::int
FROM human_eval_jsonl j, human_eval_csv c, human_eval_tsv t
WHERE j.task_id = c.task_id AND j.task_id = t.task_id
-- bwc_tag:end_query

TRUNCATE human_eval_csv;
-- bwc_tag:end_query

TRUNCATE human_eval_tsv;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO human_eval_csv
SELECT replace(COLUMNS(*), E'\r\n', E'\n')
FROM read_csv('data/csv/unquoted_escape/human_eval.csv', quote = '', escape = '\', sep = ',', header = false, strict_mode = false);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO human_eval_tsv
SELECT replace(COLUMNS(*), E'\r\n', E'\n')
FROM read_csv('data/csv/unquoted_escape/human_eval.tsv', quote = '', escape = '\', sep = '\t', header = false, strict_mode = false);
-- bwc_tag:end_query

SELECT count(*), bool_and(
    j.task_id = c.task_id AND j.task_id = t.task_id AND
    j.prompt = c.prompt AND j.prompt = t.prompt AND
    j.entry_point = c.entry_point AND j.entry_point = t.entry_point AND
    j.canonical_solution = c.canonical_solution AND j.canonical_solution = t.canonical_solution AND
    j.test = c.test AND j.test = t.test
)::int
FROM human_eval_jsonl j, human_eval_csv c, human_eval_tsv t
WHERE j.task_id = c.task_id AND j.task_id = t.task_id
-- bwc_tag:end_query

TRUNCATE human_eval_csv;
-- bwc_tag:end_query

TRUNCATE human_eval_tsv;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO human_eval_csv
SELECT replace(COLUMNS(*), E'\r\n', E'\n')
FROM read_csv('data/csv/unquoted_escape/human_eval.csv', quote = '', escape = '\', sep = ',', header = false, strict_mode = false);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO human_eval_tsv
SELECT replace(COLUMNS(*), E'\r\n', E'\n')
FROM read_csv('data/csv/unquoted_escape/human_eval.tsv', quote = '', escape = '\', sep = '\t', header = false, strict_mode = false);
-- bwc_tag:end_query

SELECT count(*), bool_and(
    j.task_id = c.task_id AND j.task_id = t.task_id AND
    j.prompt = c.prompt AND j.prompt = t.prompt AND
    j.entry_point = c.entry_point AND j.entry_point = t.entry_point AND
    j.canonical_solution = c.canonical_solution AND j.canonical_solution = t.canonical_solution AND
    j.test = c.test AND j.test = t.test
)::int
FROM human_eval_jsonl j, human_eval_csv c, human_eval_tsv t
WHERE j.task_id = c.task_id AND j.task_id = t.task_id
-- bwc_tag:end_query

TRUNCATE human_eval_csv;
-- bwc_tag:end_query

TRUNCATE human_eval_tsv;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO human_eval_csv
SELECT replace(COLUMNS(*), E'\r\n', E'\n')
FROM read_csv('data/csv/unquoted_escape/human_eval.csv', quote = '', escape = '\', sep = ',', header = false, strict_mode = false);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO human_eval_tsv
SELECT replace(COLUMNS(*), E'\r\n', E'\n')
FROM read_csv('data/csv/unquoted_escape/human_eval.tsv', quote = '', escape = '\', sep = '\t', header = false, strict_mode = false);
-- bwc_tag:end_query

SELECT count(*), bool_and(
    j.task_id = c.task_id AND j.task_id = t.task_id AND
    j.prompt = c.prompt AND j.prompt = t.prompt AND
    j.entry_point = c.entry_point AND j.entry_point = t.entry_point AND
    j.canonical_solution = c.canonical_solution AND j.canonical_solution = t.canonical_solution AND
    j.test = c.test AND j.test = t.test
)::int
FROM human_eval_jsonl j, human_eval_csv c, human_eval_tsv t
WHERE j.task_id = c.task_id AND j.task_id = t.task_id
-- bwc_tag:end_query

TRUNCATE human_eval_csv;
-- bwc_tag:end_query

TRUNCATE human_eval_tsv;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO human_eval_csv
SELECT replace(COLUMNS(*), E'\r\n', E'\n')
FROM read_csv('data/csv/unquoted_escape/human_eval.csv', quote = '', escape = '\', sep = ',', header = false, strict_mode = false);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO human_eval_tsv
SELECT replace(COLUMNS(*), E'\r\n', E'\n')
FROM read_csv('data/csv/unquoted_escape/human_eval.tsv', quote = '', escape = '\', sep = '\t', header = false, strict_mode = false);
-- bwc_tag:end_query

SELECT count(*), bool_and(
    j.task_id = c.task_id AND j.task_id = t.task_id AND
    j.prompt = c.prompt AND j.prompt = t.prompt AND
    j.entry_point = c.entry_point AND j.entry_point = t.entry_point AND
    j.canonical_solution = c.canonical_solution AND j.canonical_solution = t.canonical_solution AND
    j.test = c.test AND j.test = t.test
)::int
FROM human_eval_jsonl j, human_eval_csv c, human_eval_tsv t
WHERE j.task_id = c.task_id AND j.task_id = t.task_id
-- bwc_tag:end_query

TRUNCATE human_eval_csv;
-- bwc_tag:end_query

TRUNCATE human_eval_tsv;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO human_eval_csv
SELECT replace(COLUMNS(*), E'\r\n', E'\n')
FROM read_csv('data/csv/unquoted_escape/human_eval.csv', quote = '', escape = '\', sep = ',', header = false, strict_mode = false);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO human_eval_tsv
SELECT replace(COLUMNS(*), E'\r\n', E'\n')
FROM read_csv('data/csv/unquoted_escape/human_eval.tsv', quote = '', escape = '\', sep = '\t', header = false, strict_mode = false);
-- bwc_tag:end_query

SELECT count(*), bool_and(
    j.task_id = c.task_id AND j.task_id = t.task_id AND
    j.prompt = c.prompt AND j.prompt = t.prompt AND
    j.entry_point = c.entry_point AND j.entry_point = t.entry_point AND
    j.canonical_solution = c.canonical_solution AND j.canonical_solution = t.canonical_solution AND
    j.test = c.test AND j.test = t.test
)::int
FROM human_eval_jsonl j, human_eval_csv c, human_eval_tsv t
WHERE j.task_id = c.task_id AND j.task_id = t.task_id
-- bwc_tag:end_query

TRUNCATE human_eval_csv;
-- bwc_tag:end_query

TRUNCATE human_eval_tsv;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO human_eval_csv
SELECT replace(COLUMNS(*), E'\r\n', E'\n')
FROM read_csv('data/csv/unquoted_escape/human_eval.csv', quote = '', escape = '\', sep = ',', header = false, strict_mode = false);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO human_eval_tsv
SELECT replace(COLUMNS(*), E'\r\n', E'\n')
FROM read_csv('data/csv/unquoted_escape/human_eval.tsv', quote = '', escape = '\', sep = '\t', header = false, strict_mode = false);
-- bwc_tag:end_query

SELECT count(*), bool_and(
    j.task_id = c.task_id AND j.task_id = t.task_id AND
    j.prompt = c.prompt AND j.prompt = t.prompt AND
    j.entry_point = c.entry_point AND j.entry_point = t.entry_point AND
    j.canonical_solution = c.canonical_solution AND j.canonical_solution = t.canonical_solution AND
    j.test = c.test AND j.test = t.test
)::int
FROM human_eval_jsonl j, human_eval_csv c, human_eval_tsv t
WHERE j.task_id = c.task_id AND j.task_id = t.task_id
-- bwc_tag:end_query

TRUNCATE human_eval_csv;
-- bwc_tag:end_query

TRUNCATE human_eval_tsv;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO human_eval_csv
SELECT replace(COLUMNS(*), E'\r\n', E'\n')
FROM read_csv('data/csv/unquoted_escape/human_eval.csv', quote = '', escape = '\', sep = ',', header = false, strict_mode = false);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO human_eval_tsv
SELECT replace(COLUMNS(*), E'\r\n', E'\n')
FROM read_csv('data/csv/unquoted_escape/human_eval.tsv', quote = '', escape = '\', sep = '\t', header = false, strict_mode = false);
-- bwc_tag:end_query

SELECT count(*), bool_and(
    j.task_id = c.task_id AND j.task_id = t.task_id AND
    j.prompt = c.prompt AND j.prompt = t.prompt AND
    j.entry_point = c.entry_point AND j.entry_point = t.entry_point AND
    j.canonical_solution = c.canonical_solution AND j.canonical_solution = t.canonical_solution AND
    j.test = c.test AND j.test = t.test
)::int
FROM human_eval_jsonl j, human_eval_csv c, human_eval_tsv t
WHERE j.task_id = c.task_id AND j.task_id = t.task_id
-- bwc_tag:end_query

TRUNCATE human_eval_csv;
-- bwc_tag:end_query

TRUNCATE human_eval_tsv;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO human_eval_csv
SELECT replace(COLUMNS(*), E'\r\n', E'\n')
FROM read_csv('data/csv/unquoted_escape/human_eval.csv', quote = '', escape = '\', sep = ',', header = false, strict_mode = false);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO human_eval_tsv
SELECT replace(COLUMNS(*), E'\r\n', E'\n')
FROM read_csv('data/csv/unquoted_escape/human_eval.tsv', quote = '', escape = '\', sep = '\t', header = false, strict_mode = false);
-- bwc_tag:end_query

SELECT count(*), bool_and(
    j.task_id = c.task_id AND j.task_id = t.task_id AND
    j.prompt = c.prompt AND j.prompt = t.prompt AND
    j.entry_point = c.entry_point AND j.entry_point = t.entry_point AND
    j.canonical_solution = c.canonical_solution AND j.canonical_solution = t.canonical_solution AND
    j.test = c.test AND j.test = t.test
)::int
FROM human_eval_jsonl j, human_eval_csv c, human_eval_tsv t
WHERE j.task_id = c.task_id AND j.task_id = t.task_id
-- bwc_tag:end_query

TRUNCATE human_eval_csv;
-- bwc_tag:end_query

TRUNCATE human_eval_tsv;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO human_eval_csv
SELECT replace(COLUMNS(*), E'\r\n', E'\n')
FROM read_csv('data/csv/unquoted_escape/human_eval.csv', quote = '', escape = '\', sep = ',', header = false, strict_mode = false);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO human_eval_tsv
SELECT replace(COLUMNS(*), E'\r\n', E'\n')
FROM read_csv('data/csv/unquoted_escape/human_eval.tsv', quote = '', escape = '\', sep = '\t', header = false, strict_mode = false);
-- bwc_tag:end_query

SELECT count(*), bool_and(
    j.task_id = c.task_id AND j.task_id = t.task_id AND
    j.prompt = c.prompt AND j.prompt = t.prompt AND
    j.entry_point = c.entry_point AND j.entry_point = t.entry_point AND
    j.canonical_solution = c.canonical_solution AND j.canonical_solution = t.canonical_solution AND
    j.test = c.test AND j.test = t.test
)::int
FROM human_eval_jsonl j, human_eval_csv c, human_eval_tsv t
WHERE j.task_id = c.task_id AND j.task_id = t.task_id
-- bwc_tag:end_query

TRUNCATE human_eval_csv;
-- bwc_tag:end_query

TRUNCATE human_eval_tsv;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO human_eval_csv
SELECT replace(COLUMNS(*), E'\r\n', E'\n')
FROM read_csv('data/csv/unquoted_escape/human_eval.csv', quote = '', escape = '\', sep = ',', header = false, strict_mode = false);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO human_eval_tsv
SELECT replace(COLUMNS(*), E'\r\n', E'\n')
FROM read_csv('data/csv/unquoted_escape/human_eval.tsv', quote = '', escape = '\', sep = '\t', header = false, strict_mode = false);
-- bwc_tag:end_query

SELECT count(*), bool_and(
    j.task_id = c.task_id AND j.task_id = t.task_id AND
    j.prompt = c.prompt AND j.prompt = t.prompt AND
    j.entry_point = c.entry_point AND j.entry_point = t.entry_point AND
    j.canonical_solution = c.canonical_solution AND j.canonical_solution = t.canonical_solution AND
    j.test = c.test AND j.test = t.test
)::int
FROM human_eval_jsonl j, human_eval_csv c, human_eval_tsv t
WHERE j.task_id = c.task_id AND j.task_id = t.task_id
-- bwc_tag:end_query

TRUNCATE human_eval_csv;
-- bwc_tag:end_query

TRUNCATE human_eval_tsv;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO human_eval_csv
SELECT replace(COLUMNS(*), E'\r\n', E'\n')
FROM read_csv('data/csv/unquoted_escape/human_eval.csv', quote = '', escape = '\', sep = ',', header = false, strict_mode = false);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO human_eval_tsv
SELECT replace(COLUMNS(*), E'\r\n', E'\n')
FROM read_csv('data/csv/unquoted_escape/human_eval.tsv', quote = '', escape = '\', sep = '\t', header = false, strict_mode = false);
-- bwc_tag:end_query

SELECT count(*), bool_and(
    j.task_id = c.task_id AND j.task_id = t.task_id AND
    j.prompt = c.prompt AND j.prompt = t.prompt AND
    j.entry_point = c.entry_point AND j.entry_point = t.entry_point AND
    j.canonical_solution = c.canonical_solution AND j.canonical_solution = t.canonical_solution AND
    j.test = c.test AND j.test = t.test
)::int
FROM human_eval_jsonl j, human_eval_csv c, human_eval_tsv t
WHERE j.task_id = c.task_id AND j.task_id = t.task_id
-- bwc_tag:end_query

TRUNCATE human_eval_csv;
-- bwc_tag:end_query

TRUNCATE human_eval_tsv;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO human_eval_csv
SELECT replace(COLUMNS(*), E'\r\n', E'\n')
FROM read_csv('data/csv/unquoted_escape/human_eval.csv', quote = '', escape = '\', sep = ',', header = false, strict_mode = false);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO human_eval_tsv
SELECT replace(COLUMNS(*), E'\r\n', E'\n')
FROM read_csv('data/csv/unquoted_escape/human_eval.tsv', quote = '', escape = '\', sep = '\t', header = false, strict_mode = false);
-- bwc_tag:end_query

SELECT count(*), bool_and(
    j.task_id = c.task_id AND j.task_id = t.task_id AND
    j.prompt = c.prompt AND j.prompt = t.prompt AND
    j.entry_point = c.entry_point AND j.entry_point = t.entry_point AND
    j.canonical_solution = c.canonical_solution AND j.canonical_solution = t.canonical_solution AND
    j.test = c.test AND j.test = t.test
)::int
FROM human_eval_jsonl j, human_eval_csv c, human_eval_tsv t
WHERE j.task_id = c.task_id AND j.task_id = t.task_id
-- bwc_tag:end_query

