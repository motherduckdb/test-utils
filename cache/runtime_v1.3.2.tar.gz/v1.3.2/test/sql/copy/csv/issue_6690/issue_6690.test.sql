-- bwc_tag:nb_steps=3
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv_auto('data/csv/comma_decimal_null.csv',SEP=',',SAMPLE_SIZE=-1,decimal_separator=',')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT FINANZ_STATO_FSC FROM read_csv_auto('data/csv/comma_decimal_null.csv',SEP=',',SAMPLE_SIZE=-1,decimal_separator=',')
-- bwc_tag:end_query

