-- bwc_tag:nb_steps=6
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TYPE bla AS ENUM ('Y', 'N');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select * from read_csv_auto('data/csv/response.csv', header = 0)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/response.csv', columns={'response': 'bla'}, nullstr = 'Null');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv_auto('data/csv/response.csv', types={'column0': 'bla'}, nullstr = 'Null', header = 0);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

FROM read_csv_auto('data/csv/response.csv', auto_type_candidates=['bla'], nullstr = 'Null');
-- bwc_tag:end_query

