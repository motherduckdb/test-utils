-- bwc_tag:needed_extensions=json
-- bwc_tag:nb_steps=4
LOAD 'json';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/5194/crashes/case_0.csv', auto_detect=false, buffer_size=8, columns={'a': 'integer','b': 'integer','c': 'integer'}, header=true, maximum_line_size=0);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/5194/crashes/case_4.csv', buffer_size=30, delim=';', union_by_name=false, header=false, null_padding=true);
-- bwc_tag:end_query

