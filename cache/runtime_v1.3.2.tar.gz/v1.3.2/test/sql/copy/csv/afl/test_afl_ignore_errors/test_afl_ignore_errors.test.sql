-- bwc_tag:nb_steps=56
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/1.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/2.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/3.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/4.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/5.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/6.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/7.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/8.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/9.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/10.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/11.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/12.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/13.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/14.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/15.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/16.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/17.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/18.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/19.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/20.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/21.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/22.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/23.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/24.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/25.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/26.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/27.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/28.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/29.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/30.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/31.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/32.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/33.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/34.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/35.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/36.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/37.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/38.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/39.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/40.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/41.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/42.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/43.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/44.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/45.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/46.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/47.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/48.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/49.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/50.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/51.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/52.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/53.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/54.csv', ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/ignore_errors/55.csv', ignore_errors = true)
-- bwc_tag:end_query

