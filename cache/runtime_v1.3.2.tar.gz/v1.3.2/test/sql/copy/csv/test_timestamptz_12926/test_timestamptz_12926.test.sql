-- bwc_tag:nb_steps=7
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

FROM read_csv('data/csv/timestamp_tz.csv', dtypes = [TIMESTAMPTZ]);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/timestamp_tz.csv', dtypes = [TIMESTAMPTZ], timestampformat = '%d/%m/%Y');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test (column0 timestamptz);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO test SELECT * FROM 'data/csv/timestamp_tz.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test SELECT * FROM  read_csv('data/csv/timestamp_tz.csv', dtypes = [TIMESTAMPTZ], timestampformat = '%d/%m/%Y');
-- bwc_tag:end_query

FROM test
-- bwc_tag:end_query

