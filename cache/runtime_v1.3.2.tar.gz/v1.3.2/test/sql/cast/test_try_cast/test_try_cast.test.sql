-- bwc_tag:nb_steps=9
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

SELECT TRY_CAST('hello' as INTEGER)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT CAST('hello' as INTEGER)
-- bwc_tag:end_query

SELECT TRY_CAST(3 as BIGINT), CAST(3 AS BIGINT), TRY_CAST(2 as BIGINT), CAST(3 AS INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE try_cast(try_cast INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO try_cast VALUES (3);
-- bwc_tag:end_query

SELECT try_cast FROM try_cast;
-- bwc_tag:end_query

SELECT try_cast(try_cast as bigint) FROM try_cast;
-- bwc_tag:end_query

SELECT try_cast(try_cast(try_cast as integer) as integer) FROM try_cast;
-- bwc_tag:end_query

