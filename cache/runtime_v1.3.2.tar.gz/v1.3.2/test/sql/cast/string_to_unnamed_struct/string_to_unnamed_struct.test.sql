-- bwc_tag:nb_steps=13
select [row('a'), $$(abc)$$]
-- bwc_tag:end_query

select [row('a', 'b', 'c'), $$(abc, def, ghi)$$]
-- bwc_tag:end_query

select [row('a'),$$()$$]
-- bwc_tag:end_query

select [row('a'),$$('')$$]
-- bwc_tag:end_query

select [row({'amount': 21}), $$({'amount': 42})$$]
-- bwc_tag:end_query

select [row(row(21)), $$((42))$$]
-- bwc_tag:end_query

select [row(row(21), {'amount': 42}), $$((42), {amount: 21})$$]
-- bwc_tag:end_query

select [row([7,8,9], [10,11,12]), $$([1,2,3], [4,5,6])$$]
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select [row([4,5,6]), $$([1,2,3],)$$]
-- bwc_tag:end_query

select [row([4,5,6], 'abc'), $$([1,2,3],)$$]
-- bwc_tag:end_query

select [{'a': [4,5,6], 'b': 'abc'}, $${'a': [1,2,3],'b':}$$]
-- bwc_tag:end_query

select [
	[
		row(
			row(
				'  test  '
			)
		),
		{'a': {
			'inner':
				'\  test  \'
			}
		}
	],
	$$[(("  test  ")), {'a': (\\  test  \\)}]$$
]
-- bwc_tag:end_query

select [
	row('test'),
	$$(NULL)$$,
	$$('null')$$,
	$$('nUlL')$$,
	$$(NuLl)$$,
	$$("NULLz")$$,
	$$("NULL")$$
] a, a::VARCHAR::STRUCT(a VARCHAR)[] b, a == b
-- bwc_tag:end_query

