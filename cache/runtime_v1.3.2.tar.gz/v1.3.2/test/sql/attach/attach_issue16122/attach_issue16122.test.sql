-- bwc_tag:nb_steps=7
-- bwc_tag:load_db=issue16122

ATTACH 'output/issue16122.db' AS issue16122;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table mytable (C1 VARCHAR(10));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into mytable values ('a');
-- bwc_tag:end_query

attach 'output/issue16122_new.db' as TOMERGE;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table TOMERGE.mytable (C1 VARCHAR(10));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into TOMERGE.mytable SELECT * FROM mytable;
-- bwc_tag:end_query

select * from TOMERGE.mytable;
-- bwc_tag:end_query

