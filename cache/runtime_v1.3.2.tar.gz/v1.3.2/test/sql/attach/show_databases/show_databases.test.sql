-- bwc_tag:nb_steps=8
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

ATTACH DATABASE ':memory:' AS new_database;
-- bwc_tag:end_query

SHOW DATABASES
-- bwc_tag:end_query

SELECT name FROM pragma_database_list ORDER BY name
-- bwc_tag:end_query

USE new_database
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tbl AS SELECT 42 i
-- bwc_tag:end_query

SELECT * FROM new_database.tbl
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

USE blablabla
-- bwc_tag:end_query

