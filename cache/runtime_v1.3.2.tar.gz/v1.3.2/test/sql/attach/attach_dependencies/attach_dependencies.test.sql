-- bwc_tag:nb_steps=16
-- bwc_tag:load_db=fk

ATTACH 'output/fk.db' AS fk;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE pk_tbl (id INTEGER PRIMARY KEY, name VARCHAR UNIQUE);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE fk_tbl (id INTEGER REFERENCES pk_tbl(id));
-- bwc_tag:end_query

-- bwc_tag:load_db=alter_column

ATTACH 'output/alter_column.db' AS alter_column;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tbl_alter_column (id INT, other INT, nn_col INT NOT NULL, rm INT, rename_c INT, my_def INT, drop_def INT DEFAULT 10, new_null_col INT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE tbl_alter_column ADD COLUMN k INTEGER;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE tbl_alter_column ALTER other SET DATA TYPE VARCHAR USING concat(other, '_', 'yay');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE tbl_alter_column ALTER COLUMN nn_col DROP NOT NULL;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE tbl_alter_column DROP rm;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE tbl_alter_column RENAME rename_c TO my_new_col;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE tbl_alter_column ALTER COLUMN my_def SET DEFAULT 10;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE tbl_alter_column ALTER COLUMN drop_def DROP DEFAULT;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE tbl_alter_column ALTER COLUMN new_null_col SET NOT NULL;
-- bwc_tag:end_query

-- bwc_tag:load_db=other

ATTACH 'output/other.db' AS other;
-- bwc_tag:end_query

ATTACH 'output/fk.db';
-- bwc_tag:end_query

ATTACH 'output/alter_column.db';
-- bwc_tag:end_query

