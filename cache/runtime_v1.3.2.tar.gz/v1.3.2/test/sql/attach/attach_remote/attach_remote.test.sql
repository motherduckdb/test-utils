-- bwc_tag:needed_extensions=httpfs
-- bwc_tag:nb_steps=4
LOAD 'httpfs';
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

ATTACH 'https://duckdb.org/non_existing.db' AS db2 (READ_ONLY)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

ATTACH 'https://duckdb.org/non_existing.db' AS db2
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

ATTACH 'https://duckdb.org/non_existing.db' AS db2 (READ_WRITE)
-- bwc_tag:end_query

