-- bwc_tag:nb_steps=7
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

ATTACH 'output/attach_same_db.db' AS db1
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

ATTACH 'output/attach_same_db.db' AS db2
-- bwc_tag:end_query

-- bwc_tag:skip_query
BEGIN
-- bwc_tag:end_query

DETACH db1
-- bwc_tag:end_query

ATTACH 'output/attach_same_db.db' AS db1
-- bwc_tag:end_query

-- bwc_tag:skip_query
COMMIT
-- bwc_tag:end_query

