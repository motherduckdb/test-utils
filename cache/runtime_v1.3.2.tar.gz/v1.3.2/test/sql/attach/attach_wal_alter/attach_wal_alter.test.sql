-- bwc_tag:nb_steps=14
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

ATTACH DATABASE 'output/wal_crash.db' as db1;
-- bwc_tag:end_query

USE db1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t2(c1 INT);
-- bwc_tag:end_query

CHECKPOINT;
-- bwc_tag:end_query

SET wal_autocheckpoint='1TB';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA disable_checkpoint_on_shutdown;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE t2 ALTER c1 SET DEFAULT 0;
-- bwc_tag:end_query

ATTACH DATABASE ':memory:' as db2;
-- bwc_tag:end_query

USE db2;
-- bwc_tag:end_query

detach db1;
-- bwc_tag:end_query

ATTACH DATABASE 'output/wal_crash.db' as db1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO db1.t2 DEFAULT VALUES
-- bwc_tag:end_query

SELECT * FROM db1.t2
-- bwc_tag:end_query

