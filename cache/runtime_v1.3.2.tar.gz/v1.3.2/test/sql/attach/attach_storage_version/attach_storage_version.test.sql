-- bwc_tag:nb_steps=34
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

ATTACH 'output/version_1_2_0.db' (STORAGE_VERSION 'v1.2.0');
-- bwc_tag:end_query

SELECT tags['storage_version'] FROM duckdb_databases() WHERE database_name='version_1_2_0'
-- bwc_tag:end_query

DETACH version_1_2_0
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

ATTACH 'output/version_1_2_0.db' (STORAGE_VERSION 'v1.0.0');
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

ATTACH 'output/version_1_2_0.db' (STORAGE_VERSION 'non_existant');
-- bwc_tag:end_query

ATTACH 'output/version_1_2_0.db' (STORAGE_VERSION 'v1.2.0');
-- bwc_tag:end_query

SELECT tags['storage_version'] FROM duckdb_databases() WHERE database_name='version_1_2_0'
-- bwc_tag:end_query

DETACH version_1_2_0
-- bwc_tag:end_query

ATTACH 'output/version_1_2_0.db';
-- bwc_tag:end_query

SELECT tags['storage_version'] FROM duckdb_databases() WHERE database_name='version_1_2_0'
-- bwc_tag:end_query

DETACH version_1_2_0
-- bwc_tag:end_query

set storage_compatibility_version='v0.10.2'
-- bwc_tag:end_query

ATTACH 'output/default_version.db';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE default_version.tbl(i VARCHAR);
-- bwc_tag:end_query

SELECT tags['storage_version'] FROM duckdb_databases() WHERE database_name='default_version'
-- bwc_tag:end_query

DETACH default_version
-- bwc_tag:end_query

ATTACH 'output/default_version.db' (STORAGE_VERSION 'v1.2.0');
-- bwc_tag:end_query

SELECT tags['storage_version'] FROM duckdb_databases() WHERE database_name='default_version'
-- bwc_tag:end_query

SET force_compression = 'zstd';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO default_version.tbl VALUES ('abcd'), ('efgh'), ('hello'), ('world'), (NULL);
-- bwc_tag:end_query

CHECKPOINT default_version
-- bwc_tag:end_query

DETACH default_version
-- bwc_tag:end_query

ATTACH 'output/default_version.db'
-- bwc_tag:end_query

SELECT tags['storage_version'] FROM duckdb_databases() WHERE database_name='default_version'
-- bwc_tag:end_query

FROM default_version.tbl
-- bwc_tag:end_query

DETACH default_version
-- bwc_tag:end_query

ATTACH 'output/default_version.db' (STORAGE_VERSION 'v1.2.0')
-- bwc_tag:end_query

FROM default_version.tbl
-- bwc_tag:end_query

DETACH default_version
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

ATTACH 'output/default_version.db' (STORAGE_VERSION 'v1.0.0')
-- bwc_tag:end_query

SET storage_compatibility_version = 'v1.2.0'
-- bwc_tag:end_query

ATTACH 'output/modified_default_setting.db';
-- bwc_tag:end_query

SELECT tags['storage_version'] FROM duckdb_databases() WHERE database_name='modified_default_setting'
-- bwc_tag:end_query

