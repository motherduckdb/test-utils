-- bwc_tag:nb_steps=8
-- bwc_tag:execute_from_sql
CREATE SCHEMA test_schema;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TYPE main_int AS int32;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TYPE test_schema.test_int AS int32;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test_schema.test_t1 (i INT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE main_t1 (i INT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE main_t1 ADD COLUMN j test_int;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test_schema.test_t1 ADD COLUMN not_found main_int;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test_schema.test_t1 ADD COLUMN l test_int;
-- bwc_tag:end_query

