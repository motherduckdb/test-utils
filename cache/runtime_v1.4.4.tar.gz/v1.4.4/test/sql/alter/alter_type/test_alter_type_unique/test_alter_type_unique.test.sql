-- bwc_tag:nb_steps=5
-- bwc_tag:execute_from_sql
CREATE TABLE test(i INTEGER UNIQUE, j INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (1, 1), (2, 2)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE test ALTER i SET DATA TYPE VARCHAR
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test ALTER j SET DATA TYPE VARCHAR
-- bwc_tag:end_query

SELECT * FROM test
-- bwc_tag:end_query

