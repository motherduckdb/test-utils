-- bwc_tag:nb_steps=16
-- bwc_tag:execute_from_sql
CREATE TABLE test(s STRUCT(i INTEGER, j INTEGER))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (ROW(1, 1)), (ROW(2, 2))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test ADD COLUMN s.k INTEGER
-- bwc_tag:end_query

SELECT * FROM test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test ADD COLUMN s.l INTEGER DEFAULT 42
-- bwc_tag:end_query

SELECT * FROM test
-- bwc_tag:end_query

-- bwc_tag:skip_query
BEGIN
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test ADD COLUMN s.m INTEGER DEFAULT 42
-- bwc_tag:end_query

SELECT * FROM test
-- bwc_tag:end_query

-- bwc_tag:skip_query
ROLLBACK
-- bwc_tag:end_query

SELECT * FROM test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE test ADD COLUMN s.i VARCHAR
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test ADD COLUMN IF NOT EXISTS s.i VARCHAR
-- bwc_tag:end_query

SELECT * FROM test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE test ADD COLUMN s.i.a INTEGER
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE test ADD COLUMN s.x.a INTEGER
-- bwc_tag:end_query

