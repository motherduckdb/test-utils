-- bwc_tag:nb_steps=7
-- bwc_tag:skip_query
PRAGMA enable_verification;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test (
	a INT NOT NULL,
	b INT GENERATED ALWAYS AS (a) VIRTUAL,
	c INT,
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (5, 4);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE test ADD PRIMARY KEY (b);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE test ADD PRIMARY KEY (b, c);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test ADD PRIMARY KEY (c);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO test VALUES (1, 4);
-- bwc_tag:end_query

