-- bwc_tag:nb_steps=7
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(i integer)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers SELECT * FROM range(50000);
-- bwc_tag:end_query

SELECT i FROM integers WHERE i = 100
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DELETE FROM integers WHERE i = 42;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE integers ADD PRIMARY KEY (i);
-- bwc_tag:end_query

SELECT i FROM integers WHERE i = 100
-- bwc_tag:end_query

