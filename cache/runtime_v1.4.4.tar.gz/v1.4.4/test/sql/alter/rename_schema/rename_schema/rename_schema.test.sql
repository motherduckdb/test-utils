-- bwc_tag:nb_steps=1
-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER SCHEMA a RENAME TO b;
-- bwc_tag:end_query

