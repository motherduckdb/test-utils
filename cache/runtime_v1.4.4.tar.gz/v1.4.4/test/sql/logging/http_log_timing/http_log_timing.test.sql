-- bwc_tag:needed_extensions=httpfs
-- bwc_tag:nb_steps=5
LOAD 'httpfs';
-- bwc_tag:end_query

CALL enable_logging('HTTP')
-- bwc_tag:end_query

SET http_retries=2
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

FROM "http://localhost:2338/test.csv"
-- bwc_tag:end_query

SELECT 
	request.type, 
	request.duration_ms >= 0,
	request.duration_ms <= 1000 * 1000
FROM 
	duckdb_logs_parsed('HTTP')
WHERE 
	request.type='HEAD'
-- bwc_tag:end_query

