-- bwc_tag:nb_steps=4
ATTACH 'output/attach_vacuum.db' AS db1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE db1.integers(i INTEGER);
-- bwc_tag:end_query

CHECKPOINT db1
-- bwc_tag:end_query

VACUUM db1.integers
-- bwc_tag:end_query

