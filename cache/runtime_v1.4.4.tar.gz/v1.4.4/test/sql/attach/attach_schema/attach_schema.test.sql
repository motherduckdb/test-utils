-- bwc_tag:nb_steps=5
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

ATTACH DATABASE ':memory:' AS new_database;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE SCHEMA new_database.s1.xxx;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE SCHEMA IF NOT EXISTS new_database.s1.xxx;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA new_database.s1;
-- bwc_tag:end_query

