-- bwc_tag:nb_steps=9
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

DETACH DATABASE system
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

DETACH DATABASE temp
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE SCHEMA system.eek
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE TABLE system.main.integers(i INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE VIEW system.main.integers AS SELECT 42
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE SEQUENCE system.main.seq
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE MACRO system.main.my_macro(a,b) AS a+b
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE TYPE system.main.rainbow AS ENUM ('red', 'orange', 'yellow', 'green', 'blue', 'purple');
-- bwc_tag:end_query

