-- bwc_tag:nb_steps=15
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

ATTACH 'output/attach_or_replace.db' AS db1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE db1.all_types AS SELECT * FROM test_all_types();
-- bwc_tag:end_query

ATTACH 'output/attach_or_replace_new.db' AS db2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE db2.all_types_new AS SELECT * FROM test_all_types();
-- bwc_tag:end_query

DETACH db2;
-- bwc_tag:end_query

ATTACH OR REPLACE 'output/attach_or_replace.db' AS db1;
-- bwc_tag:end_query

SELECT * FROM db1.all_types;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

ATTACH OR REPLACE 'output/attach_or_replace.db' AS db2;
-- bwc_tag:end_query

SELECT * FROM db1.all_types;
-- bwc_tag:end_query

ATTACH OR REPLACE 'output/attach_or_replace_new.db' AS db1;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM db1.all_types;
-- bwc_tag:end_query

SELECT * FROM db1.all_types_new;
-- bwc_tag:end_query

ATTACH 'output/attach_or_replace.db' AS db2;
-- bwc_tag:end_query

SELECT * FROM db2.all_types;
-- bwc_tag:end_query

