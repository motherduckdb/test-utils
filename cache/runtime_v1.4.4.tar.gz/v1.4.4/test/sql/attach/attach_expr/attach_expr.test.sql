-- bwc_tag:nb_steps=5
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

SET VARIABLE db_type='DUCKDB'
-- bwc_tag:end_query

ATTACH ':memory:' AS db1 (TYPE getvariable('db_type'))
-- bwc_tag:end_query

SET VARIABLE db_type='UNKNOWN_TYPE'
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

ATTACH ':memory:' AS db2 (TYPE getvariable('db_type'))
-- bwc_tag:end_query

