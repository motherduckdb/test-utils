-- bwc_tag:nb_steps=5
-- bwc_tag:execute_from_sql
CREATE TABLE t1(i INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES (41), (42), (43)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW v1 AS SELECT i AS j FROM t1 WHERE i < 43
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DELETE FROM v1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

UPDATE v1 SET j=1;
-- bwc_tag:end_query

