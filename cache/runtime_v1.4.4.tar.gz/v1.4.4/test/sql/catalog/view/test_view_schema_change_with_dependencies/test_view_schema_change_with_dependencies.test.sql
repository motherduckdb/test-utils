-- bwc_tag:nb_steps=27
set storage_compatibility_version='v1.0.0'
-- bwc_tag:end_query

set enable_view_dependencies=true
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t1(i INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES (41), (42), (43)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW v1 AS SELECT * FROM t1
-- bwc_tag:end_query

SELECT * FROM v1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DROP TABLE t1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE t1 CASCADE
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t1(i DATE)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM v1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE t1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t1(i INTEGER, j INTEGER)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM v1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE t1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t1(k INTEGER)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM v1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE t1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t1(i INTEGER)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM v1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW v1 AS SELECT * FROM t1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE t1 ALTER i TYPE VARCHAR;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop view v1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE t1 ALTER i TYPE VARCHAR;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW v1 AS SELECT * FROM t1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE t1 RENAME i TO j
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop view v1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE t1 RENAME i TO j
-- bwc_tag:end_query

