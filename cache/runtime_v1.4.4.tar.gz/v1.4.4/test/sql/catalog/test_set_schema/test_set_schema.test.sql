-- bwc_tag:nb_steps=121
-- bwc_tag:execute_from_sql
CREATE SCHEMA test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA out_of_path;
-- bwc_tag:end_query

SET SESSION schema = 'test';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE main.main_table(j INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test_table(i INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE out_of_path.oop_table(k INTEGER);
-- bwc_tag:end_query

SELECT * FROM test.test_table;
-- bwc_tag:end_query

SELECT * FROM test_table;
-- bwc_tag:end_query

SELECT * FROM main_table;
-- bwc_tag:end_query

SELECT * FROM out_of_path.oop_table;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM out_of_path.test_table;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM main.test_table;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO main.test_table (i) VALUES (1);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test_table (i) VALUES (1);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test.test_table (i) VALUES (2), (3);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO main_table (j) VALUES (4);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO main.main_table (j) VALUES (5), (6);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO oop_table (k) VALUES (7);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO out_of_path.oop_table (k) VALUES (8), (9);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DELETE FROM main.test_table WHERE i=3;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DELETE FROM test.main_table WHERE i=5;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DELETE FROM oop_table WHERE k=8;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DELETE FROM test.test_table WHERE i=1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DELETE FROM test_table WHERE i=2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DELETE FROM main.main_table WHERE j=4;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DELETE FROM main_table WHERE j=5;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DELETE FROM out_of_path.oop_table WHERE k=8;
-- bwc_tag:end_query

SELECT i FROM test_table;
-- bwc_tag:end_query

SELECT j FROM main.main_table;
-- bwc_tag:end_query

SELECT k FROM out_of_path.oop_table;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

UPDATE main.test_table SET i=10 WHERE i=1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
UPDATE test_table SET i=30 WHERE i=3;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
UPDATE test.test_table SET i=300 WHERE i=30;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
UPDATE main_table SET j=60 WHERE j=6;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
UPDATE main.main_table SET j=600 WHERE j=60;
-- bwc_tag:end_query

SELECT i FROM test_table;
-- bwc_tag:end_query

SELECT j FROM main_table;
-- bwc_tag:end_query

CREATE TEMP TABLE test_temp_table(i INTEGER);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM memory.main.test_temp_table;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM test.test_temp_table;
-- bwc_tag:end_query

SELECT * FROM test_temp_table;
-- bwc_tag:end_query

SELECT * FROM temp.test_temp_table;
-- bwc_tag:end_query

SELECT abs(i) FROM test_table;
-- bwc_tag:end_query

SELECT sum(i) FROM test_table;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW test_view AS SELECT * FROM test_table;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW main.main_view AS SELECT * FROM main.main_table;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW out_of_path.oop_view AS SELECT * FROM out_of_path.oop_table;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM main.test_view;
-- bwc_tag:end_query

SELECT * FROM test.test_view;
-- bwc_tag:end_query

SELECT * FROM test_view;
-- bwc_tag:end_query

SELECT * FROM main.main_view;
-- bwc_tag:end_query

SELECT * FROM main_view;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM oop_view;
-- bwc_tag:end_query

SELECT * FROM out_of_path.oop_view;
-- bwc_tag:end_query

SET SESSION schema = 'main';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE VIEW bad_test_view AS SELECT * FROM test_table;
-- bwc_tag:end_query

SELECT * FROM test.test_view;
-- bwc_tag:end_query

SET SESSION schema = 'test';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DROP VIEW main.test_view
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP VIEW test_view
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP VIEW main_view
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DROP VIEW oop_view
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP VIEW out_of_path.oop_view
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO test_macro(a, b) AS a + b;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO test_macro2(c, d) AS c * d;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO main.main_macro(a, b) AS a - b;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO out_of_path.oop_macro(a, b) AS a * b;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT main.test_macro(1, 2);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT oop_macro(1, 2);
-- bwc_tag:end_query

SELECT main_macro(1, 2);
-- bwc_tag:end_query

SELECT main.main_macro(1, 2);
-- bwc_tag:end_query

SELECT test.test_macro(1, 2);
-- bwc_tag:end_query

SELECT test_macro(1, 2);
-- bwc_tag:end_query

SELECT out_of_path.oop_macro(1, 2);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DROP MACRO main.test_macro;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP MACRO test_macro;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP MACRO test.test_macro2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP MACRO main_macro;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DROP MACRO oop_macro;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP MACRO out_of_path.oop_macro;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE test_sequence;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE test_sequence2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE main.main_sequence;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE out_of_path.oop_sequence;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT main.nextval('main.test_sequence');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT main.nextval('test.test_sequence');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT main.nextval('test_sequence');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT main.nextval('main.main_sequence');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT main.nextval('main_sequence');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT main.nextval('oop_sequence');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT main.nextval('out_of_path.oop_sequence');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DROP SEQUENCE main.test_sequence;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP SEQUENCE test_sequence;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP SEQUENCE test.test_sequence2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP SEQUENCE main_sequence;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DROP SEQUENCE oop_sequence;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP SEQUENCE out_of_path.oop_sequence;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE main.test_table ADD COLUMN k INTEGER;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE main.main_table ADD COLUMN k INTEGER;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE main_table ADD COLUMN l INTEGER;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test_table ADD COLUMN m INTEGER;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test.test_table ADD COLUMN n INTEGER;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE oop_table ADD COLUMN o INTEGER;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE out_of_path.oop_table ADD COLUMN p INTEGER;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DROP TABLE main.test_table;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DROP TABLE test.main_table;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test_table;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE main_table;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DROP TABLE oop_table;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE out_of_path.oop_table;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test_table2(i INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test.test_table2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test_table3(i INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE IF EXISTS test_table3;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE IF EXISTS test_table3;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test_table4(i INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE IF EXISTS test.test_table4;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE IF EXISTS test.test_table4;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE main.main_table2(i INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE IF EXISTS main.main_table2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE IF EXISTS main.main_table2;
-- bwc_tag:end_query

