-- bwc_tag:nb_steps=3
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

with cte AS (SELECT 42 "A")
select a from cte
-- bwc_tag:end_query

with "CTE" AS (SELECT 42)
select * from cte
-- bwc_tag:end_query

