-- bwc_tag:nb_steps=4
-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE TABLE integers(i INTEGER, PRIMARY KEY(j))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE TABLE integers(i INTEGER, PRIMARY KEY(i, i))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE TABLE integers(i INTEGER, PRIMARY KEY(i), PRIMARY KEY(i)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE TABLE integers(i INTEGER PRIMARY KEY, PRIMARY KEY(i)
-- bwc_tag:end_query

