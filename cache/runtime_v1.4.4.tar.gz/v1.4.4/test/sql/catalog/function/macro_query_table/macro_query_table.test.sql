-- bwc_tag:nb_steps=7
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create macro min_from_tbl(tbl, col) as (select min(col) from query_table(tbl::VARCHAR));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table integers as from range(100) t(i)
-- bwc_tag:end_query

SELECT min_from_tbl(integers, i)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT min_from_tbl(integers, k)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT min_from_tbl(integers2, i)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT min_from_tbl(tbl_name, i) from (values ('integers')) t(tbl_name);
-- bwc_tag:end_query

