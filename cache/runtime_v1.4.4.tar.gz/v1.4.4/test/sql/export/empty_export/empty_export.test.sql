-- bwc_tag:nb_steps=2
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

EXPORT DATABASE 'output/empty_export' (FORMAT CSV)
-- bwc_tag:end_query

