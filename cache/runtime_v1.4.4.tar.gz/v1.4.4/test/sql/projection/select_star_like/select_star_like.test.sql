-- bwc_tag:nb_steps=26
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(col1 INTEGER, col2 INTEGER, k INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (1, 2, 3)
-- bwc_tag:end_query

SELECT COLUMNS(lambda x: x LIKE 'col%') FROM integers
-- bwc_tag:end_query

SELECT * LIKE 'col%' FROM integers
-- bwc_tag:end_query

SELECT * NOT LIKE 'col%' FROM integers
-- bwc_tag:end_query

SELECT * ILIKE 'COL%' FROM integers
-- bwc_tag:end_query

SELECT * SIMILAR TO '.*col.*' FROM integers
-- bwc_tag:end_query

SELECT * EXCLUDE (col1) SIMILAR TO '.*col.*' FROM integers
-- bwc_tag:end_query

SELECT c2, c1 FROM (
SELECT * SIMILAR TO 'number(\d+)' AS 'c\1' FROM (SELECT 1 AS number1, 2 AS number2, 3 AS end)
)
-- bwc_tag:end_query

SELECT val FROM (
SELECT * NOT LIKE '%number%' AS val FROM (SELECT 1 AS number1, 2 AS number2, 3 AS end)
)
-- bwc_tag:end_query

SELECT * LIKE '\_%' ESCAPE '\' AS val FROM (SELECT 1 AS number1, 2 AS _number2)
-- bwc_tag:end_query

SELECT * NOT LIKE '\_%' ESCAPE '\' AS val FROM (SELECT 1 AS number1, 2 AS _number2)
-- bwc_tag:end_query

SELECT * ILIKE '\_NUM%' ESCAPE '\' AS val FROM (SELECT 1 AS number1, 2 AS _number2)
-- bwc_tag:end_query

SELECT * NOT ILIKE '\_NUM%' ESCAPE '\' AS val FROM (SELECT 1 AS number1, 2 AS _number2)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * SIMILAR TO pattern FROM integers, (SELECT '.*col.*') t(pattern)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * + 42 FROM integers
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * REPLACE (col1 + 42 AS col1) SIMILAR TO '.*col.*' FROM integers
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * RENAME (col1 AS other_) SIMILAR TO '.*col.*' FROM integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t1(id INTEGER, col1 INTEGER, col2 INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES (1, 10, 20)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t2(name VARCHAR, category VARCHAR, col2 INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t2 VALUES ('foo', 'bar', 30)
-- bwc_tag:end_query

SELECT t1.* LIKE 'col%' FROM t1, t2
-- bwc_tag:end_query

SELECT t2.* LIKE 'col%' FROM t1, t2
-- bwc_tag:end_query

SELECT t1.* LIKE 'col%', t2.* LIKE 'col%' FROM t1, t2
-- bwc_tag:end_query

