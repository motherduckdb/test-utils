-- bwc_tag:nb_steps=6
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE T0(C1 INT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE T1(C1 INT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO T0(C1) VALUES (1);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO T1(C1) VALUES (1);
-- bwc_tag:end_query

WITH CTE AS MATERIALIZED (
SELECT A1, * FROM T0
  LEFT JOIN (
    SELECT C1 AS A1 FROM T1
  ) ON T0.C1 = A1
) SELECT A1 FROM CTE;
-- bwc_tag:end_query

