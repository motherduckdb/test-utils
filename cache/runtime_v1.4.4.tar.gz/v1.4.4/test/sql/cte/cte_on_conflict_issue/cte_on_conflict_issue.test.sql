-- bwc_tag:nb_steps=3
-- bwc_tag:execute_from_sql
CREATE TABLE t1 (
    t1c1 BIGINT,
    t1c2 BIGINT,
    PRIMARY KEY (t1c1, t1c2)
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t2 (
    t2c1 BIGINT
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

WITH
cte1 AS (
    SELECT 42 AS cte1c1, [84] AS cte1c2
),
cte2 AS (
    SELECT *
    FROM t2 s
)
INSERT OR REPLACE INTO t1
SELECT * FROM cte2;
-- bwc_tag:end_query

