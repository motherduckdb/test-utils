-- bwc_tag:nb_steps=16
-- bwc_tag:skip_query
PRAGMA enable_verification;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA "SCH""EMA";
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TYPE "EN""UM" AS ENUM('ALL');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE "SCH""EMA"."TA""BLE"("COL""UMN" "EN""UM");
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO "SCH""EMA"."TA""BLE" VALUES ('ALL');
-- bwc_tag:end_query

SELECT "COL""UMN" FROM "SCH""EMA"."TA""BLE";
-- bwc_tag:end_query

SELECT "TA""BLE"."COL""UMN" FROM "SCH""EMA"."TA""BLE";
-- bwc_tag:end_query

SELECT "SCH""EMA"."TA""BLE"."COL""UMN" FROM "SCH""EMA"."TA""BLE";
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE "SCH""EMA"."TA""BLE";
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE "SCH""EMA"."TA""BLE"("COL""UMN" ROW("SO""ME" ROW("I""N" INTEGER)));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO "SCH""EMA"."TA""BLE" VALUES ({'so"me': {'i"n': 3}});
-- bwc_tag:end_query

SELECT "COL""UMN"."SO""ME"."I""N" FROM "SCH""EMA"."TA""BLE";
-- bwc_tag:end_query

SELECT "TA""BLE"."COL""UMN"."SO""ME"."I""N" FROM "SCH""EMA"."TA""BLE";
-- bwc_tag:end_query

SELECT "SCH""EMA"."TA""BLE"."COL""UMN"."SO""ME"."I""N" FROM "SCH""EMA"."TA""BLE";
-- bwc_tag:end_query

SELECT (("SCH""EMA"."TA""BLE"."COL""UMN")."SO""ME")."I""N" FROM "SCH""EMA"."TA""BLE";
-- bwc_tag:end_query

SELECT "SCH""EMA"."TA""BLE"."COL""UMN"['SO"ME']['I"N'] FROM "SCH""EMA"."TA""BLE";
-- bwc_tag:end_query

