-- bwc_tag:nb_steps=9
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

ATTACH 'output/copy_database_simple.db' AS db1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE db1.test(a INTEGER, b INTEGER, c VARCHAR(10));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO db1.test VALUES (42, 88, 'hello');
-- bwc_tag:end_query

ATTACH 'output/other_copy_database_simple.db' AS db2;
-- bwc_tag:end_query

COPY FROM DATABASE db1 TO db2
-- bwc_tag:end_query

SELECT * FROM db2.test;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

COPY FROM DATABASE dbxx TO memory
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

COPY FROM DATABASE db1 TO dbxx
-- bwc_tag:end_query

