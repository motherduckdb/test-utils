-- bwc_tag:nb_steps=6
select $${
	a:{
		b:{
			b:300
		},
		c:12
	},
	c:{
		a:"\{DuckParty\}"
	}
}$$::STRUCT(
	a STRUCT(
		b STRUCT(
			a INT,
			b VARCHAR
		),
		c INT
	),
	b INT,
	c STRUCT(
		a VARCHAR,
		b STRUCT(
			a INT
		)
	)
)
-- bwc_tag:end_query

select $${"  test  ": 42}$$::STRUCT("  test  " INTEGER) a, a::VARCHAR::STRUCT("  test  " INTEGER) b, a == b
-- bwc_tag:end_query

select $${"  \"test\"  ": 42}$$::STRUCT("  ""test""  " INTEGER) a, a::VARCHAR::STRUCT("  ""test""  " INTEGER) b, a == b
-- bwc_tag:end_query

select $${"  \'test\'  ": 42}$$::STRUCT("  'test'  " INTEGER) a, a::VARCHAR::STRUCT("  'test'  " INTEGER) b, a == b
-- bwc_tag:end_query

select $${"\\  test  \\": 42}$$::STRUCT("\  test  \" INTEGER) a, a::VARCHAR::STRUCT("\  test  \" INTEGER) b, a == b
-- bwc_tag:end_query

select $${"test": \\  test  \\}$$::STRUCT("test" VARCHAR) a, a::VARCHAR::STRUCT("test" VARCHAR) b, a == b
-- bwc_tag:end_query

