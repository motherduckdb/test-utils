-- bwc_tag:nb_steps=133
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

select '1e2'::tinyint;
-- bwc_tag:end_query

select '1.23e2'::tinyint;
-- bwc_tag:end_query

select '1.234e2'::tinyint;
-- bwc_tag:end_query

select '1.235e2'::tinyint;
-- bwc_tag:end_query

select '1e-2'::tinyint;
-- bwc_tag:end_query

select '123.456e-2'::tinyint;
-- bwc_tag:end_query

select '1584.92e-2'::tinyint;
-- bwc_tag:end_query

select '1214.235e-2'::tinyint;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select '10e40'::tinyint;
-- bwc_tag:end_query

select '1e2'::smallint;
-- bwc_tag:end_query

select '1.23e2'::smallint;
-- bwc_tag:end_query

select '1.234e2'::smallint;
-- bwc_tag:end_query

select '1.235e2'::smallint;
-- bwc_tag:end_query

select '1e-2'::smallint;
-- bwc_tag:end_query

select '123.456e-2'::smallint;
-- bwc_tag:end_query

select '1584.92e-2'::smallint;
-- bwc_tag:end_query

select '1214.235e-2'::smallint;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select '10e40'::smallint;
-- bwc_tag:end_query

select '1e2'::integer;
-- bwc_tag:end_query

select '1.23e2'::integer;
-- bwc_tag:end_query

select '1.234e2'::integer;
-- bwc_tag:end_query

select '1.235e2'::integer;
-- bwc_tag:end_query

select '1e-2'::integer;
-- bwc_tag:end_query

select '123.456e-2'::integer;
-- bwc_tag:end_query

select '1584.92e-2'::integer;
-- bwc_tag:end_query

select '1214.235e-2'::integer;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select '10e40'::integer;
-- bwc_tag:end_query

select '1e2'::bigint;
-- bwc_tag:end_query

select '1.23e2'::bigint;
-- bwc_tag:end_query

select '1.234e2'::bigint;
-- bwc_tag:end_query

select '1.235e2'::bigint;
-- bwc_tag:end_query

select '1e-2'::bigint;
-- bwc_tag:end_query

select '123.456e-2'::bigint;
-- bwc_tag:end_query

select '1584.92e-2'::bigint;
-- bwc_tag:end_query

select '1214.235e-2'::bigint;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select '10e40'::bigint;
-- bwc_tag:end_query

select '1e2'::hugeint;
-- bwc_tag:end_query

select '1.23e2'::hugeint;
-- bwc_tag:end_query

select '1.234e2'::hugeint;
-- bwc_tag:end_query

select '1.235e2'::hugeint;
-- bwc_tag:end_query

select '1e-2'::hugeint;
-- bwc_tag:end_query

select '123.456e-2'::hugeint;
-- bwc_tag:end_query

select '1584.92e-2'::hugeint;
-- bwc_tag:end_query

select '1214.235e-2'::hugeint;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select '10e40'::hugeint;
-- bwc_tag:end_query

select '-1e2'::tinyint;
-- bwc_tag:end_query

select '-1.23456e2'::tinyint;
-- bwc_tag:end_query

select '-0.158492e2'::tinyint;
-- bwc_tag:end_query

select '-1.235e2'::tinyint;
-- bwc_tag:end_query

select '-100e-2'::tinyint;
-- bwc_tag:end_query

select '-50.23456e-2'::tinyint;
-- bwc_tag:end_query

select '-1584.92e-2'::tinyint;
-- bwc_tag:end_query

select '-1.235e-2'::tinyint;
-- bwc_tag:end_query

select '5.5e-1'::bigint;
-- bwc_tag:end_query

select '9.5e-5'::tinyint;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select '-10e40'::tinyint;
-- bwc_tag:end_query

select '-1e2'::smallint;
-- bwc_tag:end_query

select '-1.23456e2'::smallint;
-- bwc_tag:end_query

select '-0.158492e2'::smallint;
-- bwc_tag:end_query

select '-1.235e2'::smallint;
-- bwc_tag:end_query

select '-100e-2'::smallint;
-- bwc_tag:end_query

select '-50.23456e-2'::smallint;
-- bwc_tag:end_query

select '-1584.92e-2'::smallint;
-- bwc_tag:end_query

select '-1.235e-2'::smallint;
-- bwc_tag:end_query

select '5.5e-1'::bigint;
-- bwc_tag:end_query

select '9.5e-5'::smallint;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select '-10e40'::smallint;
-- bwc_tag:end_query

select '-1e2'::integer;
-- bwc_tag:end_query

select '-1.23456e2'::integer;
-- bwc_tag:end_query

select '-0.158492e2'::integer;
-- bwc_tag:end_query

select '-1.235e2'::integer;
-- bwc_tag:end_query

select '-100e-2'::integer;
-- bwc_tag:end_query

select '-50.23456e-2'::integer;
-- bwc_tag:end_query

select '-1584.92e-2'::integer;
-- bwc_tag:end_query

select '-1.235e-2'::integer;
-- bwc_tag:end_query

select '5.5e-1'::bigint;
-- bwc_tag:end_query

select '9.5e-5'::integer;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select '-10e40'::integer;
-- bwc_tag:end_query

select '-1e2'::bigint;
-- bwc_tag:end_query

select '-1.23456e2'::bigint;
-- bwc_tag:end_query

select '-0.158492e2'::bigint;
-- bwc_tag:end_query

select '-1.235e2'::bigint;
-- bwc_tag:end_query

select '-100e-2'::bigint;
-- bwc_tag:end_query

select '-50.23456e-2'::bigint;
-- bwc_tag:end_query

select '-1584.92e-2'::bigint;
-- bwc_tag:end_query

select '-1.235e-2'::bigint;
-- bwc_tag:end_query

select '5.5e-1'::bigint;
-- bwc_tag:end_query

select '9.5e-5'::bigint;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select '-10e40'::bigint;
-- bwc_tag:end_query

select '-1e2'::hugeint;
-- bwc_tag:end_query

select '-1.23456e2'::hugeint;
-- bwc_tag:end_query

select '-0.158492e2'::hugeint;
-- bwc_tag:end_query

select '-1.235e2'::hugeint;
-- bwc_tag:end_query

select '-100e-2'::hugeint;
-- bwc_tag:end_query

select '-50.23456e-2'::hugeint;
-- bwc_tag:end_query

select '-1584.92e-2'::hugeint;
-- bwc_tag:end_query

select '-1.235e-2'::hugeint;
-- bwc_tag:end_query

select '5.5e-1'::bigint;
-- bwc_tag:end_query

select '9.5e-5'::hugeint;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select '-10e40'::hugeint;
-- bwc_tag:end_query

select '12.7e1'::TINYINT, '-12.8e1'::TINYINT;
-- bwc_tag:end_query

select '3276.7e1'::SMALLINT, '-3276.8e1'::SMALLINT;
-- bwc_tag:end_query

select '214748364.7e1'::INTEGER, '-214748364.8e1'::INTEGER;
-- bwc_tag:end_query

select '922337203685477580.7e1'::BIGINT, '-922337203685477580.8e1'::BIGINT;
-- bwc_tag:end_query

select '17014118346046923173168730371588410572.7e1'::HUGEINT, '-17014118346046923173168730371588410572.8e1'::HUGEINT;
-- bwc_tag:end_query

select '25.5e1'::UTINYINT;
-- bwc_tag:end_query

select '6553.5e1'::USMALLINT;
-- bwc_tag:end_query

select '429496729.5e1'::UINTEGER;
-- bwc_tag:end_query

select '1844674407370955161.5e1'::UBIGINT;
-- bwc_tag:end_query

select '34028236692093846346337460743176821145.5e1'::UHUGEINT;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select '12.8e1'::TINYINT;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select '3276.8e1'::SMALLINT;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select '214748364.8e1'::INTEGER;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select '922337203685477580.8e1'::BIGINT;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select '17014118346046923173168730371588410572.8e1'::HUGEINT;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select '-12.9e1'::TINYINT;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select '-3276.9e1'::SMALLINT;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select '-214748364.9e1'::INTEGER;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select '-922337203685477580.9e1'::BIGINT;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select '-17014118346046923173168730371588410572.9e1'::HUGEINT;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select '25.6e1'::UTINYINT;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select '6553.6e1'::USMALLINT;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select '429496729.6e1'::UINTEGER;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select '1844674407370955161.6e1'::UBIGINT;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select '1e100000'::int;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select '1e-100000'::int;
-- bwc_tag:end_query

select '0.00000000000000000000000000000009223372036854775807e50'::BIGINT;
-- bwc_tag:end_query

select '-0.00000000000000000000000000000009223372036854775807e50'::BIGINT;
-- bwc_tag:end_query

select '0.00000000000170141183460469231731687303715884105727e50'::HUGEINT;
-- bwc_tag:end_query

select '-0.00000000000170141183460469231731687303715884105727e50'::HUGEINT;
-- bwc_tag:end_query

select '15123456789e-32768'::int;
-- bwc_tag:end_query

select '0e32767'::int;
-- bwc_tag:end_query

