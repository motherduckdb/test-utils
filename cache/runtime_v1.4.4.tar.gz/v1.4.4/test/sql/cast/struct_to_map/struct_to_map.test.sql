-- bwc_tag:nb_steps=43
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

SELECT {"name": 'Alice', "city": 'NYC'}::MAP(VARCHAR, VARCHAR);
-- bwc_tag:end_query

SELECT {"age": 25, "score": 100}::MAP(VARCHAR, INT);
-- bwc_tag:end_query

SELECT col::MAP(VARCHAR, INT)
FROM VALUES ({"duck": 1}),({"duck": 2}),({"duck": 3}),({"duck": 4}),({"duck": 5})
AS tab(col);
-- bwc_tag:end_query

SELECT {"name": 'Alice', "age": 25, "score": 95}::MAP(VARCHAR, VARCHAR);
-- bwc_tag:end_query

SELECT col::MAP(INT, INT)
FROM VALUES ({"1": 1}),({"2": 2}),({"3": 3}),({"4": 4}),({"5": 5})
AS tab(col);
-- bwc_tag:end_query

SELECT {"123456789": 42}::MAP(BIGINT, INT);
-- bwc_tag:end_query

SELECT {"3.14": 100}::MAP(DOUBLE, INT);
-- bwc_tag:end_query

SELECT {"age": 25, "score": 100}::MAP(VARCHAR, VARCHAR);
-- bwc_tag:end_query

SELECT {"small": 1, "big": 999999999}::MAP(VARCHAR, BIGINT);
-- bwc_tag:end_query

SELECT {"pi": 3, "e": 2}::MAP(VARCHAR, DOUBLE);
-- bwc_tag:end_query

SELECT {"1": 100, "2": 200}::MAP(INT, BIGINT);
-- bwc_tag:end_query

SELECT (NULL::STRUCT(name VARCHAR, age INT))::MAP(VARCHAR, VARCHAR);
-- bwc_tag:end_query

SELECT {"name": 'Alice', "age": NULL}::MAP(VARCHAR, VARCHAR);
-- bwc_tag:end_query

SELECT {"a": NULL, "b": NULL, "c": 'value'}::MAP(VARCHAR, VARCHAR);
-- bwc_tag:end_query

SELECT x::MAP(VARCHAR, INT) FROM (SELECT {"constant": 42} as x FROM range(5));
-- bwc_tag:end_query

SELECT {"person": {"name": 'Alice', "age": 25}}::MAP(VARCHAR, STRUCT(name VARCHAR, age INT));
-- bwc_tag:end_query

SELECT {"numbers": [1,2,3], "letters": ['a','b']}::MAP(VARCHAR, VARCHAR[]);
-- bwc_tag:end_query

SELECT {meta: MAP{'key': 'value'}}::MAP(VARCHAR, MAP(VARCHAR, VARCHAR));
-- bwc_tag:end_query

SELECT col::MAP(VARCHAR, MAP(VARCHAR, INT))
FROM VALUES ({ data: MAP{'count': 10, 'total': 100} })
AS tab(col);
-- bwc_tag:end_query

SELECT {"value": 42}::MAP(VARCHAR, INT)
FROM range(1, 1001)
LIMIT 5;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
pragma debug_verify_vector='dictionary_expression'
-- bwc_tag:end_query

SELECT TRY_CAST(col AS MAP(VARCHAR, integer))
FROM (
    SELECT CASE WHEN (i % 5 == 0) THEN NULL else {'a': i::varchar} END as col
    FROM range(1, 1001) t(i)
)
LIMIT 5;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
pragma debug_verify_vector='none'
-- bwc_tag:end_query

SELECT {"single": 'value'}::MAP(VARCHAR, VARCHAR);
-- bwc_tag:end_query

SELECT {
    "f1": 1, "f2": 2, "f3": 3, "f4": 4, "f5": 5,
    "f6": 6, "f7": 7, "f8": 8, "f9": 9, "f10": 10
}::MAP(VARCHAR, INT);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT (1, 2, 3)::MAP(INT, INT);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT col::MAP(INT, INT)
FROM VALUES ({"duck": 1}),({"goose": 2})
AS tab(col);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT {"number": 'not_a_number'}::MAP(VARCHAR, INT);
-- bwc_tag:end_query

SELECT {"first name": 'Alice', "last name": 'Smith'}::MAP(VARCHAR, VARCHAR);
-- bwc_tag:end_query

SELECT {"key-with-dashes": 1, "key_with_underscores": 2, "key.with.dots": 3}::MAP(VARCHAR, INT);
-- bwc_tag:end_query

SELECT {"测试": 'test', "🦆": 'duck'}::MAP(VARCHAR, VARCHAR);
-- bwc_tag:end_query

SELECT {"CamelCase": 1, "lowercase": 2, "UPPERCASE": 3}::MAP(VARCHAR, INT);
-- bwc_tag:end_query

SELECT col::MAP(VARCHAR, INT)
FROM (
    SELECT {"value": i} as col 
    FROM range(1, 1001) t(i)
) 
LIMIT 5;
-- bwc_tag:end_query

SELECT col::MAP(VARCHAR, VARCHAR)
FROM VALUES 
    ({"a": '1'}),
    ({"A": '1', "b": '2'}),
    ({"a": '1', "B": '2', "c": '3'}),
    ({"x": 'single'}),
    ({"many": '1', "fields": '2', "here": '3', "total": '4', "five": '5'})
AS tab(col);
-- bwc_tag:end_query

SELECT {
    "tinyint": 1::TINYINT,
    "smallint": 2::SMALLINT, 
    "int": 3::INT,
    "bigint": 4::BIGINT
}::MAP(VARCHAR, BIGINT);
-- bwc_tag:end_query

SELECT {
    "varchar": 'hello'::VARCHAR,
    "text": 'world'::TEXT
}::MAP(VARCHAR, VARCHAR);
-- bwc_tag:end_query

SELECT {
    "date": '2023-01-01'::DATE,
    "time": '12:00:00'::TIME
}::MAP(VARCHAR, VARCHAR);
-- bwc_tag:end_query

SELECT {"true_val": true, "false_val": false}::MAP(VARCHAR, VARCHAR);
-- bwc_tag:end_query

SELECT {"price": 19.99::DECIMAL(10,2)}::MAP(VARCHAR, VARCHAR);
-- bwc_tag:end_query

SELECT *
FROM VALUES ({"status": 'active'}), ({"status": 'inactive'})
AS tab(col)
WHERE (col::MAP(VARCHAR, VARCHAR))['status'] = 'active';
-- bwc_tag:end_query

SELECT COUNT(*)
FROM VALUES ({"type": 'A'}), ({"type": 'B'}), ({"type": 'A'})
AS tab(col)
WHERE (col::MAP(VARCHAR, VARCHAR))['type'] = 'A';
-- bwc_tag:end_query

SELECT col::MAP(VARCHAR, MAP(VARCHAR, INT))
FROM VALUES ({ nested: MAP { 'inner_key': 707 } })
AS tab(col);
-- bwc_tag:end_query

