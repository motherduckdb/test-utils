-- bwc_tag:nb_steps=80
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

SELECT (1=1)::VARCHAR, (1=0)::VARCHAR, NULL::BOOLEAN::VARCHAR
-- bwc_tag:end_query

SELECT 1::TINYINT::VARCHAR, 12::TINYINT::VARCHAR, (-125)::TINYINT::VARCHAR
-- bwc_tag:end_query

SELECT 1::SMALLINT::VARCHAR, 12442::SMALLINT::VARCHAR, (-32153)::SMALLINT::VARCHAR
-- bwc_tag:end_query

SELECT 1::INTEGER::VARCHAR, 12442952::INTEGER::VARCHAR, (-2000000111)::INTEGER::VARCHAR
-- bwc_tag:end_query

SELECT 1::BIGINT::VARCHAR, 1244295295289253::BIGINT::VARCHAR, (-2000000111551166)::BIGINT::VARCHAR
-- bwc_tag:end_query

SELECT 2::FLOAT::VARCHAR, 0.5::FLOAT::VARCHAR, (-128.5)::FLOAT::VARCHAR
-- bwc_tag:end_query

SELECT 2::DOUBLE::VARCHAR, 0.5::DOUBLE::VARCHAR, (-128.5)::DOUBLE::VARCHAR
-- bwc_tag:end_query

SELECT '0xF'::INTEGER, '0x0'::INTEGER, '0xFEE'::INTEGER, '0xfee'::INTEGER, '0x00FEE'::INTEGER
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT '0x'::INT
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT '0X'::INT
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT '0xHELLO'::INT
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT '0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF'::INT
-- bwc_tag:end_query

SELECT '0x7F'::TINYINT, '0x7FFF'::SMALLINT, '0x7FFFFFFF'::INT, '0x7FFFFFFFFFFFFFFF'::BIGINT
-- bwc_tag:end_query

SELECT '0xFF'::UINT8, '0xFFFF'::UINT16, '0xFFFFFFFF'::UINT32, '0xFFFFFFFFFFFFFFFF'::UINT64
-- bwc_tag:end_query

SELECT '0x000000000000000000000000000000000000000000000000000000000000000000'::INT
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT '0x80'::TINYINT
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT '0x8000'::SMALLINT
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT '0x80000000'::INT
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT '0x8000000000000000'::BIGINT
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT '0x100'::UINT8
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT '0x10000'::UINT16
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT '0x100000000'::UINT32
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT '0x10000000000000000'::UINT64
-- bwc_tag:end_query

SELECT TRY_CAST('0x80' AS TINYINT)
-- bwc_tag:end_query

SELECT TRY_CAST('0x8000' AS SMALLINT)
-- bwc_tag:end_query

SELECT TRY_CAST('0x80000000' AS INT)
-- bwc_tag:end_query

SELECT TRY_CAST('0x8000000000000000' AS BIGINT)
-- bwc_tag:end_query

SELECT TRY_CAST('0x100' AS UINT8)
-- bwc_tag:end_query

SELECT TRY_CAST('0x10000' AS UINT16)
-- bwc_tag:end_query

SELECT TRY_CAST('0x100000000' AS UINT32)
-- bwc_tag:end_query

SELECT TRY_CAST('0x10000000000000000' AS UINT64)
-- bwc_tag:end_query

SELECT '0.5'::TINYINT;
-- bwc_tag:end_query

SELECT '-0.5'::TINYINT;
-- bwc_tag:end_query

SELECT '0.5'::SMALLINT;
-- bwc_tag:end_query

SELECT '-0.5'::SMALLINT;
-- bwc_tag:end_query

SELECT '0.5'::INTEGER;
-- bwc_tag:end_query

SELECT '-0.5'::INTEGER;
-- bwc_tag:end_query

SELECT '0.5'::BIGINT;
-- bwc_tag:end_query

SELECT '-0.5'::BIGINT;
-- bwc_tag:end_query

SELECT '0.5'::HUGEINT;
-- bwc_tag:end_query

SELECT '-0.5'::HUGEINT;
-- bwc_tag:end_query

SELECT '0x1e'::TINYINT;
-- bwc_tag:end_query

SELECT '0x1e'::SMALLINT;
-- bwc_tag:end_query

SELECT '0x1e'::INTEGER;
-- bwc_tag:end_query

SELECT '0x1e'::BIGINT;
-- bwc_tag:end_query

SELECT '0xfade'::INT;
-- bwc_tag:end_query

SELECT '0Xfade'::INT;
-- bwc_tag:end_query

SELECT '0xFADE'::INT;
-- bwc_tag:end_query

SELECT '0XFADE'::INT;
-- bwc_tag:end_query

SELECT '0xFaDe'::INT;
-- bwc_tag:end_query

SELECT '0xFaDE'::INT;
-- bwc_tag:end_query

SELECT '0XFaDe'::INT;
-- bwc_tag:end_query

SELECT '0xfAdE'::INT;
-- bwc_tag:end_query

SELECT '0'::TINYINT;
-- bwc_tag:end_query

SELECT '0'::SMALLINT;
-- bwc_tag:end_query

SELECT '0'::INTEGER;
-- bwc_tag:end_query

SELECT '0'::BIGINT;
-- bwc_tag:end_query

SELECT '0'::HUGEINT;
-- bwc_tag:end_query

SELECT '0'::DECIMAL;
-- bwc_tag:end_query

SELECT ('infinity'::timestamp)::VARCHAR
-- bwc_tag:end_query

SELECT ('-infinity'::timestamp)::VARCHAR
-- bwc_tag:end_query

SELECT TRY_CAST('infinity' AS timestamp)
-- bwc_tag:end_query

SELECT TRY_CAST('-infinity' AS timestamp)
-- bwc_tag:end_query

SELECT ('infinity'::timestamp_ms)::VARCHAR
-- bwc_tag:end_query

SELECT ('-infinity'::timestamp_ms)::VARCHAR
-- bwc_tag:end_query

SELECT TRY_CAST('infinity' AS timestamp_ms)
-- bwc_tag:end_query

SELECT TRY_CAST('-infinity' AS timestamp_ms)
-- bwc_tag:end_query

SELECT ('infinity'::timestamp_ns)::VARCHAR
-- bwc_tag:end_query

SELECT ('-infinity'::timestamp_ns)::VARCHAR
-- bwc_tag:end_query

SELECT TRY_CAST('infinity' AS timestamp_ns)
-- bwc_tag:end_query

SELECT TRY_CAST('-infinity' AS timestamp_ns)
-- bwc_tag:end_query

SELECT ('infinity'::timestamp_s)::VARCHAR
-- bwc_tag:end_query

SELECT ('-infinity'::timestamp_s)::VARCHAR
-- bwc_tag:end_query

SELECT TRY_CAST('infinity' AS timestamp_s)
-- bwc_tag:end_query

SELECT TRY_CAST('-infinity' AS timestamp_s)
-- bwc_tag:end_query

SELECT ('infinity'::timestamptz)::VARCHAR
-- bwc_tag:end_query

SELECT ('-infinity'::timestamptz)::VARCHAR
-- bwc_tag:end_query

SELECT TRY_CAST('infinity' AS timestamptz)
-- bwc_tag:end_query

SELECT TRY_CAST('-infinity' AS timestamptz)
-- bwc_tag:end_query

