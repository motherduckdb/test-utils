-- bwc_tag:nb_steps=46
SELECT $${name: value, age: 30}$$::STRUCT(name VARCHAR, age INT);
-- bwc_tag:end_query

SELECT $${name: John, city: "New York"}$$::STRUCT(name VARCHAR, city VARCHAR);
-- bwc_tag:end_query

SELECT $${quote_at_start: "\"test\"", age: 30}$$::STRUCT(quote_at_start VARCHAR, age INT);
-- bwc_tag:end_query

SELECT $${user_name: Alice, status: active}$$::STRUCT(user_name VARCHAR, status VARCHAR);
-- bwc_tag:end_query

SELECT $${special_characters: "comma, backslash\\", age: 30}$$::STRUCT(special_characters VARCHAR, age INT);
-- bwc_tag:end_query

SELECT $${a: 10, b: "hello world"}$$::STRUCT(a INT, b VARCHAR);
-- bwc_tag:end_query

SELECT $${first_name: "John", last_name: "Doe", age: 28}$$::STRUCT(first_name VARCHAR, last_name VARCHAR, age INT);
-- bwc_tag:end_query

SELECT $${first name: John, age: 30}$$::STRUCT("first name" VARCHAR, age INT);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT $${name: "John "Doe"}$$::STRUCT(name VARCHAR);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT $${name: John, age, 30}$$::STRUCT(name VARCHAR, age INT);
-- bwc_tag:end_query

SELECT $${user,name: Alice, age: 30}$$::STRUCT("user,name" VARCHAR, age INT);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT $${name: Alice, age: 30})$$::STRUCT(name VARCHAR, age INT);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT $${"backslash\name": value}$$::STRUCT("backslash\name" VARCHAR);
-- bwc_tag:end_query

SELECT $${backslash\name: value}$$::STRUCT("backslash\name" VARCHAR) a, a::VARCHAR::STRUCT("backslash\name" VARCHAR) b, a == b;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT $${name: test, value: 30}$$::STRUCT("name:" VARCHAR, value INT);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT $${name\:: test, value: 30}$$::STRUCT("name:" VARCHAR, value INT);
-- bwc_tag:end_query

SELECT $${"name\:": test, value: 30}$$::STRUCT("name:" VARCHAR, value INT);
-- bwc_tag:end_query

SELECT $${{name}: John, age: 3}$$::STRUCT("{name}" VARCHAR, age INT);
-- bwc_tag:end_query

SELECT $${{\"name\"}: John, age: 3}$$::STRUCT("{""name""}" VARCHAR, age INT);
-- bwc_tag:end_query

SELECT $${{\'name\'}: John, age: 3}$$::STRUCT("{'name'}" VARCHAR, age INT);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT $${name: "John, age: 30}$$::STRUCT(name VARCHAR, age INT);
-- bwc_tag:end_query

SELECT $${}$$::STRUCT(name VARCHAR, age INT);
-- bwc_tag:end_query

SELECT $${name : John, age : 30}$$::STRUCT(name VARCHAR, age INT);
-- bwc_tag:end_query

SELECT $${path: "C:\\Users\\John"}$$::STRUCT(path VARCHAR);
-- bwc_tag:end_query

SELECT $${description: "Special characters: \\, \", \', (, )"}$$::STRUCT(description VARCHAR);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT $${first\ name: "John", age: 30}$$::STRUCT("first name" VARCHAR, age INT);
-- bwc_tag:end_query

SELECT $${"first\ name": "John", age: 30}$$::STRUCT("first name" VARCHAR, age INT);
-- bwc_tag:end_query

SELECT $${\"quote at start\": "value", age: 30}$$::STRUCT("""quote at start""" VARCHAR, age INT);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT $${backslash\\name: "John Doe", age: 30}$$::STRUCT("backslash\name" VARCHAR, age INT);
-- bwc_tag:end_query

SELECT $${"backslash\\name": "John Doe", age: 30}$$::STRUCT("backslash\name" VARCHAR, age INT);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT $${user\,name: "Alice", age: 25}$$::STRUCT("user,name" VARCHAR, age INT);
-- bwc_tag:end_query

SELECT $${"user\,name": "Alice", age: 25}$$::STRUCT("user,name" VARCHAR, age INT);
-- bwc_tag:end_query

SELECT $${"user,name": "Alice", age: 25}$$::STRUCT("user,name" VARCHAR, age INT);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT $${user\(name\): "Alice", status: "active"}$$::STRUCT("user(name)" VARCHAR, status VARCHAR);
-- bwc_tag:end_query

SELECT $${"user\(name\)": "Alice", status: "active"}$$::STRUCT("user(name)" VARCHAR, status VARCHAR);
-- bwc_tag:end_query

SELECT $${user(name): "Alice", status: "active"}$$::STRUCT("user(name)" VARCHAR, status VARCHAR);
-- bwc_tag:end_query

SELECT $${"user\ name\ ": "Alice", "age ": 25}$$::STRUCT("user name " VARCHAR, "age " INT);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT $${user\ name\ : "Alice", age\ : 25}$$::STRUCT("user name " VARCHAR, "age " INT);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT $${"quote"start": "value", age: 30}$$::STRUCT("quote""start" VARCHAR, age INT);
-- bwc_tag:end_query

SELECT $${backslash\name: "John", age: 30}$$::STRUCT("backslash\name" VARCHAR, age INT);
-- bwc_tag:end_query

SELECT $${user(name: "Alice", age: 25}$$::STRUCT("user(name" VARCHAR, age INT);
-- bwc_tag:end_query

SELECT $${\": "value", age: 30}$$::STRUCT("""" VARCHAR, age INTEGER)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT $${\\: "escaped", age: 30}$$::STRUCT("\" VARCHAR, age INT);
-- bwc_tag:end_query

SELECT $${"\\": "escaped", age: 30}$$::STRUCT("\" VARCHAR, age INT);
-- bwc_tag:end_query

SELECT $${@: "value", age: 30}$$::STRUCT("@" VARCHAR, age INT);
-- bwc_tag:end_query

select $$[{'a': test}, {'a': NULL}, {'a': 'null'}, {'a': 'nUlL'}, {'a': NULL}, {'a': NULLz}, {'a': 'NULL'}]$$::STRUCT(a VARCHAR)[] a, a::VARCHAR::STRUCT(a VARCHAR)[] b, a == b
-- bwc_tag:end_query

