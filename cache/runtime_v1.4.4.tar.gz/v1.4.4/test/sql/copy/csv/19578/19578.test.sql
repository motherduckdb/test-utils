-- bwc_tag:nb_steps=3
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

SELECT Delimiter, Quote, Escape FROM sniff_csv("data/19578.csv");
-- bwc_tag:end_query

SELECT Delimiter, Quote, Escape FROM sniff_csv("data/19578.csv",  strict_mode=false);
-- bwc_tag:end_query

