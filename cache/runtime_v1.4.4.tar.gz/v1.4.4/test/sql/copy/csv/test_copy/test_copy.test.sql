-- bwc_tag:nb_steps=57
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test (a INTEGER, b INTEGER, c VARCHAR(10));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY test FROM 'data/csv/test/test.csv';
-- bwc_tag:end_query

SELECT COUNT(a), SUM(a) FROM test;
-- bwc_tag:end_query

SELECT * FROM test ORDER BY 1 LIMIT 3;
-- bwc_tag:end_query

COPY test TO 'output/test2.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test2 (a INTEGER, b INTEGER, c VARCHAR(10));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY test2 FROM 'output/test2.csv' ;
-- bwc_tag:end_query

SELECT * FROM test2 ORDER BY 1 LIMIT 3;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test_too_few_rows (a INTEGER, b INTEGER, c VARCHAR, d INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY test_too_few_rows FROM 'output/test2.csv' (NULL_PADDING 0);
-- bwc_tag:end_query

COPY (SELECT a,b FROM test WHERE a < 4000) TO 'output/test3.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test3 (a INTEGER, b INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY test3 FROM 'output/test3.csv';
-- bwc_tag:end_query

SELECT * FROM test3 ORDER BY 1 LIMIT 3;
-- bwc_tag:end_query

COPY test (a,c) TO 'output/test4.csv' (DELIMITER ',', HEADER false);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test4 (a INTEGER, b INTEGER, c VARCHAR(10));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY test4 (a,c) FROM 'output/test4.csv' (DELIM ',');
-- bwc_tag:end_query

SELECT * FROM test4 ORDER BY 1 LIMIT 3;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY test4 (a,c) FROM 'output/test4.csv' (SEP ',', HEADER 0.2);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY test4 (a,c) FROM 'output/test4.csv' (SEP);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY test4 (a,c) FROM 'output/test4.csv' (SEP 1);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY test4 (a,c) FROM 'output/test4.csv' (FORMAT 'csv', FORMAT 'some_other_copy_function');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY test4 (a,c) FROM 'output/test4.csv' (FORMAT 'some_other_copy_function', FORMAT 'csv');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY test4 (a,c) FROM 'output/test4.csv' (ESCAPE 1);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY test4 (a,c) FROM 'output/test4.csv' (ESCAPE);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY test4 (a,c) FROM 'output/test4.csv' (QUOTE 1);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY test4 (a,c) FROM 'output/test4.csv' (QUOTE);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY test4 (a,c) FROM 'output/test4.csv' (FORMAT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY test4 (a,c) FROM 'output/test4.csv' (ENCODING);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY test4 (a,c) FROM 'output/test4.csv' (ENCODING 42);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY test4 (a,c) FROM 'output/test4.csv' (ENCODING 'utf-42');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY test4 (a,c) FROM 'output/test4.csv' (MAGIC '42');
-- bwc_tag:end_query

COPY test TO 'output/test_crlf.csv' (new_line  '\r\n');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select count(*) from 'output/test_crlf.csv'
-- bwc_tag:end_query

COPY test TO 'output/test_r.csv' (new_line  '\r');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select count(*) from 'output/test_r.csv'
-- bwc_tag:end_query

COPY test TO 'output/test_n.csv' (new_line  '\n');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select count(*) from 'output/test_n.csv'
-- bwc_tag:end_query

COPY test TO 'output/test_crlfe.csv' (new_line  e'\r\n');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select count(*) from 'output/test_crlfe.csv'
-- bwc_tag:end_query

COPY test TO 'output/test_re.csv' (new_line  e'\r');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select count(*) from 'output/test_re.csv'
-- bwc_tag:end_query

COPY test TO 'output/test_en.csv' (new_line  e'\n');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select count(*) from 'output/test_en.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test (a INTEGER, b INTEGER, c VARCHAR(10));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY test FROM 'data/csv/test/test_pipe.csv' (SEPARATOR '|');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY test FROM 'data/csv/test/too_many_values.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY test FROM 'data/csv/test/test_null_csv.csv' DELIMITER '|';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY test FROM 'data/csv/test/invalid_utf.csv' DELIMITER '|';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE empty_table (a INTEGER, b INTEGER, c VARCHAR(10));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY empty_table FROM 'data/csv/test/empty.csv' (HEADER 0);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE unterminated (a VARCHAR);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY unterminated FROM 'data/csv/test/unterminated.csv' (HEADER 0, AUTO_DETECT FALSE, strict_mode TRUE);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE vsize (a INTEGER, b INTEGER, c VARCHAR(10));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY vsize FROM 'data/csv/test/vsize.csv';
-- bwc_tag:end_query

