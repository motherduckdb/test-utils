-- bwc_tag:nb_steps=5
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE dates(d DATE);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY dates FROM 'data/csv/glob/a?/*.csv' (AUTO_DETECT 1);
-- bwc_tag:end_query

SELECT * FROM dates ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY dates FROM read_csv('data/csv/glob/*/a*a.csv', auto_detect=1)
-- bwc_tag:end_query

