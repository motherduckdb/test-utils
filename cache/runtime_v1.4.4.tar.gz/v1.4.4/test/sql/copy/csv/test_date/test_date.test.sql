-- bwc_tag:nb_steps=11
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE date_test(d date);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY date_test FROM 'data/csv/test/date.csv';
-- bwc_tag:end_query

SELECT cast(d as string) FROM date_test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
Select * from read_csv('data/csv/custom_date.csv', header=true, dateformat='%m/%d/%Y, %-I:%-M %p', types = ['BIGINT', 'DATE'] );
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
Select * from read_csv('data/csv/custom_date.csv', header=true, dateformat='%m/%d/%Y, %-I:%-M %p');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
Select * from read_csv('data/csv/custom_date.csv', header=true, timestampformat='%m/%d/%Y, %-I:%-M %p', types = ['BIGINT', 'TIMESTAMP'] );
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
Select * from read_csv('data/csv/custom_date.csv', header=true, timestampformat='%m/%d/%Y, %-I:%-M %p');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select typeof(#1),typeof(#2),typeof(#3) FROM 'data/csv/versions.csv' limit 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select typeof(#1) FROM read_csv('data/csv/dates_special_format.csv', dateformat = '%b %-d, %Y', columns = {'Date': 'DATE'}) limit 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select typeof(#1) FROM read_csv('data/csv/dates_special_format.csv', dateformat = '%b %-d, %Y') limit 1;
-- bwc_tag:end_query

