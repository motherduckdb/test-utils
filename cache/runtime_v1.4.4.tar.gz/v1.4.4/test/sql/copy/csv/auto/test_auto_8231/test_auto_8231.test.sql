-- bwc_tag:nb_steps=4
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create view locations_header_trailing_comma as SELECT * from read_csv_auto('data/csv/locations_row_trailing_comma.csv', null_padding=True)
-- bwc_tag:end_query

SELECT * from locations_header_trailing_comma
-- bwc_tag:end_query

describe locations_header_trailing_comma;
-- bwc_tag:end_query

