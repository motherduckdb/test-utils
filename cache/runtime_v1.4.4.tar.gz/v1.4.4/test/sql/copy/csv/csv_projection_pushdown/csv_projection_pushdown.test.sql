-- bwc_tag:nb_steps=10
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tbl(i INT, j VARCHAR, k DATE);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO tbl VALUES (42, 'hello world', NULL),  (NULL, NULL, DATE '1992-01-01'), (100, 'thisisalongstring', DATE '2000-01-01');
-- bwc_tag:end_query

COPY tbl TO 'output/projection_pushdown.csv' (FORMAT CSV);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW v1 AS FROM read_csv_auto('output/projection_pushdown.csv', filename=True)
-- bwc_tag:end_query

SELECT COUNT(*) FROM v1
-- bwc_tag:end_query

SELECT i, j, k FROM v1 ORDER BY i NULLS LAST
-- bwc_tag:end_query

SELECT j FROM v1 ORDER BY j NULLS LAST
-- bwc_tag:end_query

SELECT j FROM v1 ORDER BY j NULLS LAST
-- bwc_tag:end_query

SELECT filename.replace('\', '/').split('/')[-1] FROM v1 LIMIT 1
-- bwc_tag:end_query

