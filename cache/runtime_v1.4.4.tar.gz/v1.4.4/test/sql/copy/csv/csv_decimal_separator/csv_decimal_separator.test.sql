-- bwc_tag:nb_steps=17
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE TABLE decimal_separators AS SELECT * FROM read_csv_auto('data/csv/decimal_separators/decimal_separators.csv', column_types={'commas': 'double', 'periods': 'double'}, delim=';', decimal_separator=',')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE decimal_separators AS SELECT * FROM read_csv_auto('data/csv/decimal_separators/decimal_separators.csv', column_types={'commas': 'double'}, delim=';', decimal_separator=',')
-- bwc_tag:end_query

SELECT commas, periods FROM decimal_separators;
-- bwc_tag:end_query

SELECT typeof(commas), typeof(periods) FROM decimal_separators limit 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE TABLE decimal_separators2 AS SELECT * FROM read_csv_auto('data/csv/decimal_separators/decimal_separators.csv',  column_types={'commas': 'decimal', 'periods': 'decimal'}, delim=';', decimal_separator='.')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE TABLE decimal_separators2 AS SELECT * FROM read_csv_auto('data/csv/decimal_separators/decimal_separators.csv',  column_types={'commas': 'float', 'periods': 'decimal'}, delim=';', decimal_separator='.')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE decimal_separators2 AS SELECT * FROM read_csv_auto('data/csv/decimal_separators/decimal_separators.csv', column_types={'commas': 'decimal'}, delim=';', decimal_separator=',')
-- bwc_tag:end_query

SELECT commas, periods FROM decimal_separators2;
-- bwc_tag:end_query

SELECT typeof(commas), typeof(periods) FROM decimal_separators2 limit 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE decimal_separators3 AS SELECT * FROM read_csv_auto('data/csv/decimal_separators/decimal_separators.csv',  column_types={'periods': 'decimal'}, delim=';')
-- bwc_tag:end_query

SELECT commas, periods FROM decimal_separators3;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE decimal_separators4 AS SELECT * FROM read_csv_auto('data/csv/decimal_separators/decimal_separators_csv.csv', column_types={'commas': 'double'}, quote='"',delim=',',decimal_separator=',')
-- bwc_tag:end_query

SELECT commas, periods FROM decimal_separators4;
-- bwc_tag:end_query

SELECT typeof(commas), typeof(periods) FROM decimal_separators4 limit 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT * FROM read_csv_auto('data/csv/decimal_separators/invalid_char.csv', column_types={'foo': 'double'}, decimal_separator='ö')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT * FROM read_csv_auto('data/csv/decimal_separators/mixed_format_fail.csv', column_types={'foo': 'double'}, decimal_separator=',', skip=0)
-- bwc_tag:end_query

