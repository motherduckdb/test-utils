-- bwc_tag:nb_steps=6
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

COPY (
    SELECT
        -- The string must start with a hash to reproduce the issue
        '#hash start' AS first_column,
        1 AS second_column
    UNION ALL
    SELECT
        -- Quoted value can go anywhere between rows 1 and 2048 just not 1 or 2048. It must be between the hashes
        '"my, quoted value"' AS first_column,
        1 AS second_column
    UNION ALL
    -- These rows make the csv 2048 rows long which is required to reproduce
    SELECT
        'any value' AS first_column,
        1 AS second_column
    FROM range(0, 2045)
    UNION ALL
    SELECT
        -- This hash value must be somewhere in the string just not at the beginning
        'hash not at start #' AS column_value,
     1 AS second_column
) TO 'output/test.csv' (format csv, header 1);
-- bwc_tag:end_query

SELECT columns, comment FROM sniff_csv('output/test.csv', null_padding = true)
-- bwc_tag:end_query

SELECT columns, comment FROM sniff_csv('output/test.csv', null_padding = true, comment = '#')
-- bwc_tag:end_query

COPY (
    SELECT
        -- The string must start with a hash to reproduce the issue
        '#hash start' AS first_column,
        1 AS second_column
    UNION ALL
    SELECT
        -- Quoted value can go anywhere between rows 1 and 2048 just not 1 or 2048. It must be between the hashes
        '"my, quoted value"' AS first_column,
        1 AS second_column
    UNION ALL
    -- These rows make the csv 2048 rows long which is required to reproduce
    SELECT
        'any value' AS first_column,
        1 AS second_column
    FROM range(0, 2045)
    UNION ALL
    SELECT
        -- This hash value must be somewhere in the string just not at the beginning
        'hash not at start #' AS column_value,
     1 AS second_column
) TO 'output/test_2.csv' (format csv, header 1, QUOTE '');
-- bwc_tag:end_query

SELECT columns, comment FROM sniff_csv('output/test_2.csv')
-- bwc_tag:end_query

