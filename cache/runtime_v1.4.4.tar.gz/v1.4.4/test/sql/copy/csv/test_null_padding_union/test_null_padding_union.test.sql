-- bwc_tag:nb_steps=8
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

SET default_null_order='nulls_first';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create view v as
SELECT a, b, c, d
FROM  read_csv('data/csv/union-by-name/null_padding/*.csv', UNION_BY_NAME=TRUE, sample_size = 1, null_padding = 1)
ORDER BY a,b,c,d
-- bwc_tag:end_query

select * from v limit 10;
-- bwc_tag:end_query

select count(*) from v where a is null
-- bwc_tag:end_query

select count(*) from v where b is null
-- bwc_tag:end_query

select count(*) from v where c is null
-- bwc_tag:end_query

select count(*) from v where d is null
-- bwc_tag:end_query

