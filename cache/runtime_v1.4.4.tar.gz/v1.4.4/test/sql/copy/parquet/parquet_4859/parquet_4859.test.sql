-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=2
LOAD 'parquet';
-- bwc_tag:end_query

select "repositoryTopics.edges" from "data/parquet-testing/bug4859.parquet"
-- bwc_tag:end_query

