-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=3
LOAD 'parquet';
-- bwc_tag:end_query

SELECT COUNT(*) FROM 'data/parquet-testing/out_of_range_stats.parquet'
-- bwc_tag:end_query

select COUNT(*) from parquet_scan('data/parquet-testing/glob*/t?.parquet')
-- bwc_tag:end_query

