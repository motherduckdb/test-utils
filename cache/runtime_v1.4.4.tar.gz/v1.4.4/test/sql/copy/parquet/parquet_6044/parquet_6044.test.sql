-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=3
LOAD 'parquet';
-- bwc_tag:end_query

copy (select 0.9 AS a) to 'output/tiny_decimal.parquet' (format 'parquet', codec 'zstd');
-- bwc_tag:end_query

SELECT * FROM 'output/tiny_decimal.parquet'
-- bwc_tag:end_query

