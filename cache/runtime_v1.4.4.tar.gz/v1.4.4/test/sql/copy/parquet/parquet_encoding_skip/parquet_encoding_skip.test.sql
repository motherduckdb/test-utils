-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=9
LOAD 'parquet';
-- bwc_tag:end_query

COPY (SELECT i id, i AS bigint, i::SMALLINT AS tinyint, i::DOUBLE dbl, 'prefix_' || i::VARCHAR str, 'constant' const_str FROM range(3000) t(i)) TO 'output/skip.parquet'  (PARQUET_VERSION 'v1');
-- bwc_tag:end_query

SELECT * FROM 'output/skip.parquet' WHERE id>2995
-- bwc_tag:end_query

COPY (SELECT i id, [i, i + 1, i + 2] l, {'a': i, 'l': [i, i + 1, i + 2]} struct_1, [{'a': i}, {'a': i + 1}, {'a': i + 2}] struct_2 FROM range(3000) t(i)) TO 'output/skip_nested.parquet'  (PARQUET_VERSION 'v1');
-- bwc_tag:end_query

SELECT * FROM 'output/skip_nested.parquet' WHERE id>2995
-- bwc_tag:end_query

COPY (SELECT i id, i AS bigint, i::SMALLINT AS tinyint, i::DOUBLE dbl, 'prefix_' || i::VARCHAR str, 'constant' const_str FROM range(3000) t(i)) TO 'output/skip.parquet'  (PARQUET_VERSION 'v2');
-- bwc_tag:end_query

SELECT * FROM 'output/skip.parquet' WHERE id>2995
-- bwc_tag:end_query

COPY (SELECT i id, [i, i + 1, i + 2] l, {'a': i, 'l': [i, i + 1, i + 2]} struct_1, [{'a': i}, {'a': i + 1}, {'a': i + 2}] struct_2 FROM range(3000) t(i)) TO 'output/skip_nested.parquet'  (PARQUET_VERSION 'v2');
-- bwc_tag:end_query

SELECT * FROM 'output/skip_nested.parquet' WHERE id>2995
-- bwc_tag:end_query

