-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=4
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT
	'test' AS user,
	'2025' AS year
-- bwc_tag:end_query

COPY (
	SELECT
		*
	FROM
		test
) TO 'output/partition_by_test.parquet' (
	FORMAT PARQUET,
	PARTITION_BY user
)
-- bwc_tag:end_query

select * from 'output/partition_by_test.parquet'
-- bwc_tag:end_query

