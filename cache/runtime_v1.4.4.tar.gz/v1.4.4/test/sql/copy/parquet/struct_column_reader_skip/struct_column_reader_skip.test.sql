-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=3
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

SELECT my_map['A'], * FROM parquet_scan('data/parquet-testing/struct_skip_test.parquet') where filter == '0'
-- bwc_tag:end_query

