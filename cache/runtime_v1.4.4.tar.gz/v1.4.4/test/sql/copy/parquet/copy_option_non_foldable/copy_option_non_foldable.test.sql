-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=4
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PREPARE statement2 as COPY (
	SELECT
		42 AS number,
		true AS is_even
) TO 'output/non_foldable_copy_option.parquet' (
	FORMAT parquet,
	KV_METADATA {
		number: random()
	}
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
EXECUTE statement2;
-- bwc_tag:end_query

select * from 'output/non_foldable_copy_option.parquet'
-- bwc_tag:end_query

