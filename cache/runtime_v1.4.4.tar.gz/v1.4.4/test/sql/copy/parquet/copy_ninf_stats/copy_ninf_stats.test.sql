-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=3
LOAD 'parquet';
-- bwc_tag:end_query

copy (select '-infinity'::double ninf) to 'output/ninf.parquet';
-- bwc_tag:end_query

SELECT stats_min, stats_max FROM parquet_metadata('output/ninf.parquet')
-- bwc_tag:end_query

