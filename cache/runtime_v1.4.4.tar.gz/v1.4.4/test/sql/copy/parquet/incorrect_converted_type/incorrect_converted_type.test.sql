-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=12
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM 'data/parquet-testing/broken/broken_bigint.parquet';
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM 'data/parquet-testing/broken/broken_date.parquet';
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM 'data/parquet-testing/broken/broken_int.parquet';
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM 'data/parquet-testing/broken/broken_smallint.parquet';
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM 'data/parquet-testing/broken/broken_timestamp.parquet';
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM 'data/parquet-testing/broken/broken_timestamp_ms.parquet';
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM 'data/parquet-testing/broken/broken_tinyint.parquet';
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM 'data/parquet-testing/broken/broken_ubigint.parquet';
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM 'data/parquet-testing/broken/broken_uinteger.parquet';
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM 'data/parquet-testing/broken/broken_usmallint.parquet';
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM 'data/parquet-testing/broken/broken_utinyint.parquet';
-- bwc_tag:end_query

