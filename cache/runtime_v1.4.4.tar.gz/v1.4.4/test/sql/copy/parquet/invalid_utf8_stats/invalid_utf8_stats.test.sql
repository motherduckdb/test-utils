-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=2
LOAD 'parquet';
-- bwc_tag:end_query

FROM 'data/parquet-testing/invalid_utf8_stats.parquet'
-- bwc_tag:end_query

