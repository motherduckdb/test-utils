-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=18
LOAD 'parquet';
-- bwc_tag:end_query

SELECT * FROM parquet_scan('data/parquet-testing/arrow/alltypes_dictionary.parquet');
-- bwc_tag:end_query

COPY (SELECT * FROM parquet_scan('data/parquet-testing/arrow/alltypes_dictionary.parquet')) TO 'output/alltypes_dictionary.parquet' (FORMAT 'PARQUET')
-- bwc_tag:end_query

SELECT * FROM parquet_scan('output/alltypes_dictionary.parquet');
-- bwc_tag:end_query

SELECT * FROM parquet_scan('data/parquet-testing/bug687_nulls.parquet') LIMIT 10;
-- bwc_tag:end_query

COPY (SELECT * FROM parquet_scan('data/parquet-testing/bug687_nulls.parquet')) TO 'output/bug687_nulls.parquet' (FORMAT 'PARQUET')
-- bwc_tag:end_query

SELECT * FROM parquet_scan('output/bug687_nulls.parquet') LIMIT 10;
-- bwc_tag:end_query

COPY (SELECT true as x UNION ALL SELECT true) TO 'output/bug1637_booleans.parquet' (FORMAT 'PARQUET');
-- bwc_tag:end_query

SELECT COUNT(*) FROM parquet_scan('output/bug1637_booleans.parquet') WHERE x;
-- bwc_tag:end_query

SELECT * FROM parquet_scan('data/parquet-testing/userdata1.parquet') ORDER BY 1 LIMIT 10;
-- bwc_tag:end_query

COPY (SELECT * FROM parquet_scan('data/parquet-testing/userdata1.parquet')) TO 'output/userdata1.parquet' (FORMAT 'PARQUET')
-- bwc_tag:end_query

SELECT * FROM parquet_scan('output/userdata1.parquet') ORDER BY 1 LIMIT 10;
-- bwc_tag:end_query

COPY (SELECT * FROM parquet_scan('data/parquet-testing/userdata1.parquet')) TO 'output/userdata1-gzip.parquet' (FORMAT 'PARQUET', CODEC 'GZIP')
-- bwc_tag:end_query

SELECT * FROM parquet_scan('output/userdata1-gzip.parquet') ORDER BY 1 LIMIT 10;
-- bwc_tag:end_query

COPY (SELECT * FROM parquet_scan('data/parquet-testing/userdata1.parquet')) TO 'output/userdata1-uncompressed.parquet' (FORMAT 'PARQUET', CODEC 'UNCOMPRESSED')
-- bwc_tag:end_query

SELECT * FROM parquet_scan('output/userdata1-uncompressed.parquet') ORDER BY 1 LIMIT 10;
-- bwc_tag:end_query

COPY (SELECT * FROM parquet_scan('data/parquet-testing/userdata1.parquet')) TO 'output/userdata1-zstd.parquet' (FORMAT 'PARQUET', CODEC 'ZSTD')
-- bwc_tag:end_query

SELECT * FROM parquet_scan('output/userdata1-zstd.parquet') ORDER BY 1 LIMIT 10;
-- bwc_tag:end_query

