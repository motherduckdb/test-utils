-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=7
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

COPY (
	SELECT
		i//50 id,
		{'a': i, 'b': 21} s
	FROM range(100) t(i)
) TO 'output/hive_partitioned_struct_col' (FORMAT PARQUET, PARTITION_BY (id))
-- bwc_tag:end_query

SELECT * FROM read_parquet('output/hive_partitioned_struct_col/**/*.parquet', hive_partitioning=1) WHERE s.a=42
-- bwc_tag:end_query

SELECT s.a FROM read_parquet('output/hive_partitioned_struct_col/**/*.parquet', hive_partitioning=1) WHERE s.a=42
-- bwc_tag:end_query

COPY (SELECT i id, {'a': i//2} s FROM range(100) t(i)) TO 'output/hive_partitioned_struct' (FORMAT PARQUET, PARTITION_BY (s))
-- bwc_tag:end_query

SELECT * FROM read_parquet('output/hive_partitioned_struct/**/*.parquet', hive_partitioning=1, hive_types={'s': 'STRUCT(a INT)'}) WHERE s.a=42 ORDER BY ALL
-- bwc_tag:end_query

