-- bwc_tag:nb_steps=20
-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE TABLE routes (
	route_id TEXT PRIMARY KEY,
	agency_id TEXT,
	FOREIGN KEY (agency_id) REFERENCES agency
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE agency (
	agency_id TEXT PRIMARY KEY,
	agency_name TEXT UNIQUE NOT NULL
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE TABLE routes (
	route_id TEXT PRIMARY KEY,
	agency_id TEXT,
	FOREIGN KEY (route_id, agency_id) REFERENCES agency
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE routes (
	route_id TEXT PRIMARY KEY,
	agency_id TEXT,
	FOREIGN KEY (agency_id) REFERENCES agency
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO routes VALUES (1, 1);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO agency VALUES (1, 1);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO routes VALUES (1, 1);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DROP TABLE agency;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE routes;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE agency;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE agency (
	agency_id TEXT,
	agency_name TEXT NOT NULL
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE TABLE routes (
	route_id TEXT PRIMARY KEY,
	agency_id TEXT,
	FOREIGN KEY (agency_id) REFERENCES agency
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE routes (
	route_id TEXT PRIMARY KEY,
	agency_id TEXT,
	FOREIGN KEY (agency_id) REFERENCES routes
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO routes VALUES (1, NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO routes VALUES (2, 2);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO routes VALUES (2, 1);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE routes;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE agency;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE agency (
	agency_id TEXT,
	agency_id_2 TEXT,
	agency_name TEXT NOT NULL,
	PRIMARY KEY (agency_id, agency_id_2)
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE routes (
	route_id TEXT PRIMARY KEY,
	agency_id TEXT,
	FOREIGN KEY (route_id, agency_id) REFERENCES agency
);
-- bwc_tag:end_query

