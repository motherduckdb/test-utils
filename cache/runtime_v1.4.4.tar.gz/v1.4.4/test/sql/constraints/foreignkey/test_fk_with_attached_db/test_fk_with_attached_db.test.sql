-- bwc_tag:nb_steps=10
SET checkpoint_threshold = '10.0 GB';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA disable_checkpoint_on_shutdown;
-- bwc_tag:end_query

ATTACH 'output/attach_fk_db.db' AS db1;
-- bwc_tag:end_query

USE db1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE IF NOT EXISTS t1 (
  cache_key VARCHAR PRIMARY KEY,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE IF NOT EXISTS t2 (
  cache_key VARCHAR NOT NULL,
  dose DOUBLE NOT NULL,
  PRIMARY KEY (cache_key, dose),
  FOREIGN KEY (cache_key) REFERENCES t1 (cache_key)
);
-- bwc_tag:end_query

ATTACH ':memory:' AS other;
-- bwc_tag:end_query

USE other;
-- bwc_tag:end_query

DETACH db1;
-- bwc_tag:end_query

ATTACH 'output/attach_fk_db.db' AS db2;
-- bwc_tag:end_query

