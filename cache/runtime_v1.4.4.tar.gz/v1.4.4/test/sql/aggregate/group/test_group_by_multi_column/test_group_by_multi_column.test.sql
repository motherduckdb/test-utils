-- bwc_tag:nb_steps=3
-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER, j INTEGER, k INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (1, 1, 2), (1, 2, 2), (1, 1, 2), (2, 1, 2), (1, 2, 4), (1, 2, NULL);
-- bwc_tag:end_query

SELECT i, j, SUM(k), COUNT(*), COUNT(k) FROM integers GROUP BY i, j ORDER BY 1, 2
-- bwc_tag:end_query

