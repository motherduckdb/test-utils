-- bwc_tag:nb_steps=31
SELECT AVG(3), AVG(NULL)
-- bwc_tag:end_query

SELECT AVG(3::SMALLINT), AVG(NULL::SMALLINT)
-- bwc_tag:end_query

SELECT AVG(3::DOUBLE), AVG(NULL::DOUBLE)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE seq;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT AVG(nextval('seq'))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT AVG(nextval('seq'))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (1), (2), (3)
-- bwc_tag:end_query

SELECT AVG(i), AVG(1), AVG(DISTINCT i), AVG(NULL) FROM integers
-- bwc_tag:end_query

SELECT AVG(i) FROM integers WHERE i > 100
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE intervals(itvl INTERVAL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO intervals VALUES 
	('1 day'), 
	('30 days'), 
	('30 days'), 
	('30 days'), 
	('30 days')
-- bwc_tag:end_query

SELECT AVG(itvl), AVG(DISTINCT itvl) FROM intervals
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE interval_tbl (f1 interval);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO interval_tbl (f1) VALUES 
	('@ 1 minute'),
	('@ 5 hour'),
	('@ 10 day'),
	('@ 34 year'),
	('@ 3 months'),
	('@ 14 seconds ago'),
	('1 day 2 hours 3 minutes 4 seconds'),
	('6 years'),
	('5 months'),
	('5 months 12 hours');
-- bwc_tag:end_query

select avg(f1) from interval_tbl;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT AVG()
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT AVG(1, 2, 3)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT AVG(AVG(1))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE vals(i INTEGER, j DOUBLE, k HUGEINT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO vals VALUES (NULL, NULL, NULL)
-- bwc_tag:end_query

SELECT AVG(i), AVG(j), AVG(k) FROM vals;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE timestamps AS 
	SELECT range AS ts
	FROM range('2024-11-01'::DATE, '2024-12-01'::DATE, INTERVAL 1 DAY)
-- bwc_tag:end_query

SELECT AVG(ts::DATE) 
FROM timestamps
-- bwc_tag:end_query

SELECT AVG(ts) 
FROM timestamps
-- bwc_tag:end_query

SELECT AVG(ts::TIMESTAMPTZ) 
FROM timestamps
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE times AS 
	SELECT range AS ts
	FROM range('2024-11-01'::DATE, '2024-11-02'::DATE, INTERVAL 7 MINUTES)
-- bwc_tag:end_query

SELECT AVG(ts::TIME) 
FROM times
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE timetzs (ttz TIMETZ);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO timetzs VALUES
	(NULL),
	('00:00:00+1559'),
	('00:00:00+1558'),
	('02:30:00'),
	('02:30:00+04'),
	('02:30:00+04:30'),
	('02:30:00+04:30:45'),
	('16:15:03.123456'),
	('02:30:00+1200'),
	('02:30:00-1200'),
	('24:00:00-1558'),
	('24:00:00-1559'),
;
-- bwc_tag:end_query

SELECT AVG(ttz) FROM timetzs;
-- bwc_tag:end_query

