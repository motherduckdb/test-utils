-- bwc_tag:nb_steps=12
SELECT weighted_avg(3, 3), weighted_avg(3, NULL), weighted_avg(NULL, 3), weighted_avg(NULL, NULL)
-- bwc_tag:end_query

SELECT weighted_avg(3, 0), weighted_avg(3, 0.0), weighted_avg(0, 3), weighted_avg(0.0, 3)
-- bwc_tag:end_query

SELECT wavg(3, 3)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE students(name TEXT, grade INTEGER, etcs INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO students VALUES ('Alice', 8, 6), ('Alice', 6, 2), ('Bob', 6, 3), ('Bob', 8, 3), ('Bob', 6, 6);
-- bwc_tag:end_query

SELECT name, weighted_avg(grade, etcs) FROM students GROUP BY name ORDER BY name
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO students VALUES ('Alice', 42, 0);
-- bwc_tag:end_query

SELECT name, weighted_avg(grade, etcs) FROM students GROUP BY name ORDER BY name
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO students VALUES ('Alice', 42, NULL);
-- bwc_tag:end_query

SELECT name, weighted_avg(grade, etcs) FROM students GROUP BY name ORDER BY name
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO students VALUES ('Alice', NULL, 42);
-- bwc_tag:end_query

SELECT name, weighted_avg(grade, etcs) FROM students GROUP BY name ORDER BY name
-- bwc_tag:end_query

