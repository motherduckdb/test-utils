-- bwc_tag:nb_steps=3
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

WITH my_data as (
        SELECT 'text1'::varchar(1000) as my_column union all
        SELECT 'text1'::varchar(1000) as my_column union all
        SELECT 'text1'::varchar(1000) as my_column
    )
        SELECT string_agg(my_column,', ') as my_string_agg
        FROM my_data
-- bwc_tag:end_query

WITH my_data as (
        SELECT 1 as dummy,  'text1'::varchar(1000) as my_column union all
        SELECT 1 as dummy,  'text1'::varchar(1000) as my_column union all
        SELECT 1 as dummy,  'text1'::varchar(1000) as my_column
    )
        SELECT string_agg(my_column,', ') as my_string_agg
        FROM my_data
        GROUP BY
            dummy
-- bwc_tag:end_query

