-- bwc_tag:nb_steps=13
SET default_null_order='nulls_first';
-- bwc_tag:end_query

SELECT NULL as a, NULL as b, NULL as c, NULL as d, 1 as id UNION SELECT 'Кирилл' as a, 'Müller' as b, '我是谁' as c, 'ASCII' as d, 2 as id ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test (a INTEGER, s VARCHAR);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (11, 'hello'), (12, 'world'), (11, NULL)
-- bwc_tag:end_query

SELECT COUNT(*), COUNT(s) FROM test;
-- bwc_tag:end_query

SELECT a, COUNT(*), COUNT(s) FROM test GROUP BY a ORDER BY a;
-- bwc_tag:end_query

SELECT s, SUM(a) FROM test GROUP BY s ORDER BY s;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (11, 'hello'), (12, 'world')
-- bwc_tag:end_query

SELECT COUNT(*), COUNT(s), COUNT(DISTINCT s) FROM test;
-- bwc_tag:end_query

SELECT a, COUNT(*), COUNT(s), COUNT(DISTINCT s) FROM test GROUP BY a ORDER BY a;
-- bwc_tag:end_query

SELECT a, COUNT(*), COUNT(s), COUNT(DISTINCT s) FROM test WHERE s IS NOT NULL GROUP BY a ORDER BY a;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test_strings(s VARCHAR);
INSERT INTO test_strings VALUES ('aaaaaaaahello'), ('bbbbbbbbbbbbbbbbbbbbhello'), ('ccccccccccccccchello'), ('aaaaaaaaaaaaaaaaaaaaaaaahello');;
-- bwc_tag:end_query

SELECT MIN(s), MAX(s) FROM test_strings;
-- bwc_tag:end_query

