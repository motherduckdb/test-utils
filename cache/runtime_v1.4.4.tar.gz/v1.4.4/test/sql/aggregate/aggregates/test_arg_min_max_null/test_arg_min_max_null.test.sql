-- bwc_tag:nb_steps=31
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA verify_external
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select arg_min_null()
-- bwc_tag:end_query

select arg_min_null(NULL,NULL)
-- bwc_tag:end_query

select arg_min_null(1,1)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select arg_min_null(*)
-- bwc_tag:end_query

select arg_min_null(i,i) from range (100) tbl(i);
-- bwc_tag:end_query

select arg_min_null(i,i) from range (100) tbl(i) where 1 = 0;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select arg_max_null()
-- bwc_tag:end_query

select arg_max_null(NULL,NULL)
-- bwc_tag:end_query

select arg_max_null(1,1)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select arg_max_null(*)
-- bwc_tag:end_query

select arg_max_null(i,i) from range (100) tbl(i);
-- bwc_tag:end_query

select arg_max_null(i,i) from range (100) tbl(i) where 1 = 0;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table args (a integer, b integer)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into args values (1,1), (2,2), (8,8), (10,10)
-- bwc_tag:end_query

select arg_min_null(a,b), arg_max_null(a,b) from args;
-- bwc_tag:end_query

select arg_min_null(a,b), arg_max_null(a,b) from args group by a%2 ORDER BY arg_min_null(a,b);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into args values (NULL, 0), (NULL, 12)
-- bwc_tag:end_query

select arg_min_null(a,b), arg_max_null(a,b) from args;
-- bwc_tag:end_query

select arg_min_null(a,b), arg_max_null(a,b) from args group by a%2 ORDER BY arg_min_null(a,b);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE blobs (b BYTEA, a BIGINT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO blobs VALUES('\xaa\xff\xaa',5), ('\xAA\xFF\xAA\xAA\xFF\xAA',30), ('\xAA\xFF\xAA\xAA\xFF\xAA\xAA\xFF\xAA',20)
-- bwc_tag:end_query

select arg_min_null(b,a), arg_max_null(b,a)  from blobs ;
-- bwc_tag:end_query

select arg_min_null(a,b), arg_max_null(a,b)  from blobs;
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
select arg_min_null(a,b) over ( partition by a%2) from args;
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
select arg_max_null(a,b) over ( partition by a%2) from args;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table names (name string, salary integer)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into names values ('Pedro',10), ('Hannes',20), ('Mark',15), ('Hubert-Blaine-Wolfeschlegelsteinhausenbergerdorff',30)
-- bwc_tag:end_query

select arg_min_null(name,salary),arg_max_null(name,salary)  from names;
-- bwc_tag:end_query

select arg_min_null(salary,name),arg_max_null(salary,name)  from names;
-- bwc_tag:end_query

