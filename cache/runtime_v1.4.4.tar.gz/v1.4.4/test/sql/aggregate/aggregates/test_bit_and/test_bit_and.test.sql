-- bwc_tag:nb_steps=16
SELECT BIT_AND(3), BIT_AND(NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE seq;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT BIT_AND(nextval('seq'))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT BIT_AND(nextval('seq'))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (3), (7), (15), (31), (3), (15)
-- bwc_tag:end_query

SELECT BIT_AND(i), BIT_AND(1), BIT_AND(DISTINCT i), BIT_AND(NULL) FROM integers
-- bwc_tag:end_query

SELECT BIT_AND(i) FROM integers WHERE i > 100
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT BIT_AND()
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT BIT_AND(1, 2, 3)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT BIT_AND(BIT_AND(1))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE bits(b BIT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO bits VALUES ('1110101011'), ('0111010101'), ('0101011101'), ('1111111111'), ('0100010011'), ('1100110011')
-- bwc_tag:end_query

SELECT BIT_AND(b) FROM bits
-- bwc_tag:end_query

SELECT BIT_AND(b) FROM bits WHERE get_bit(b, 2) = 1;
-- bwc_tag:end_query

SELECT BIT_AND('010110'::BIT)
-- bwc_tag:end_query

