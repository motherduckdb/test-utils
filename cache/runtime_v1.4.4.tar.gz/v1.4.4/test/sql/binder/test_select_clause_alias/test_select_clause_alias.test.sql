-- bwc_tag:nb_steps=10
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (1), (2), (3);
-- bwc_tag:end_query

SELECT i + 1 AS a, a + 1 AS b FROM integers ORDER BY b
-- bwc_tag:end_query

SELECT i + 1 AS a, a + a AS b, b + b AS c, c + c AS d FROM integers ORDER BY b
-- bwc_tag:end_query

SELECT i + 1 AS i, i + 1 AS b FROM integers ORDER BY b
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT a + 1 AS b, i + 1 AS a FROM integers
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT RANDOM() AS a, a + 1 AS b FROM integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table orders as
select
    cast(random()*100 as integer) + 1 as customer_id,
    date '2020-01-01' + interval (cast(random()*365*10 as integer)) days as order_date,
    cast(random()*1000 as integer) as order_amount,
from range(0, 1000)
order by order_date;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select
    (select distinct date_trunc('month', order_date) from orders) as month,
    (select sum(order_amount) from orders where date_trunc('month', order_date) = month) as revenue;
-- bwc_tag:end_query

