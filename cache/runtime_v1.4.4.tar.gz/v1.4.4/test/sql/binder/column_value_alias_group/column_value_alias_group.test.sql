-- bwc_tag:nb_steps=7
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table test(a int);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into test values (2), (1), (3);
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
select a as "user" from test group by "user";
-- bwc_tag:end_query

select a as "user" from test group by "user" having "user"=1;
-- bwc_tag:end_query

select a as "user" from test order by "user";
-- bwc_tag:end_query

select a as "user" from test group by "user" order by "user";
-- bwc_tag:end_query

