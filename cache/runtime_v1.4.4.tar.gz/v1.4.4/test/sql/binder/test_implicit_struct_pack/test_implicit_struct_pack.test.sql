-- bwc_tag:nb_steps=15
-- bwc_tag:skip_query
pragma enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table test as select range i from range(3)
-- bwc_tag:end_query

select test from test
-- bwc_tag:end_query

select test from main.test
-- bwc_tag:end_query

select main.test from main.test
-- bwc_tag:end_query

SELECT t FROM test AS t
-- bwc_tag:end_query

select t from (SELECT * FROM test) AS t
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select main.test from main.test t
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select main.t from main.test t
-- bwc_tag:end_query

WITH data AS (
    SELECT 1 as a, 2 as b, 3 as c
)
SELECT d FROM data d
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table main as select 3 test
-- bwc_tag:end_query

select main.test from main, test
-- bwc_tag:end_query

select test from main, test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table structs as select {test: 4} main
-- bwc_tag:end_query

select main.test from structs, test
-- bwc_tag:end_query

