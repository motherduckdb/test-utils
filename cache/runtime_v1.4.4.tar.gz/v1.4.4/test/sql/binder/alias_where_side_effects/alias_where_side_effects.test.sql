-- bwc_tag:nb_steps=2
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select count(*) from (select random() as num from range(20) where num > 0.9) where num <= 0.9
-- bwc_tag:end_query

