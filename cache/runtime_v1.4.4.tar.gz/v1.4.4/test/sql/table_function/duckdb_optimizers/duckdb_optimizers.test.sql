-- bwc_tag:nb_steps=2
SELECT * FROM duckdb_optimizers();
-- bwc_tag:end_query

SELECT name FROM duckdb_optimizers() WHERE name='join_order';
-- bwc_tag:end_query

