-- bwc_tag:nb_steps=21
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

with recursive t as MATERIALIZED (select 1 as x union select x+1 from t where x < 3) select * from t order by x
-- bwc_tag:end_query

with recursive t(x) as MATERIALIZED (select 1 union select x+1 from t where x < 3) select * from t order by x
-- bwc_tag:end_query

with recursive t(x) as MATERIALIZED (select 1 union select x+1 from t where x < 3) select zz from t t1(zz) order by zz
-- bwc_tag:end_query

with recursive t(x) as MATERIALIZED (select 1 union select zzz+1 from t t1(zzz) where zzz < 3) select zz from t t1(zz) order by zz
-- bwc_tag:end_query

with recursive t as MATERIALIZED (select 1 as x union select x from t) select * from t
-- bwc_tag:end_query

with recursive t as MATERIALIZED (select 1 as x union select x+1 from t as m where m.x < 3) select * from t order by x
-- bwc_tag:end_query

with recursive t as MATERIALIZED (select 1 as x union select m.x+f.x from t as m, t as f where m.x < 3) select * from t order by x
-- bwc_tag:end_query

with recursive t as MATERIALIZED (select 1 as x, 'hello' as y union select x+1, y || '-' || 'hello' from t where x < 3) select * from t order by x;
-- bwc_tag:end_query

with recursive t as MATERIALIZED (select 1 as x union select x+1 from t where x < 3) select min(a1.x) from t a1, t a2;
-- bwc_tag:end_query

with recursive t as MATERIALIZED (select 1 as x union select x+(SELECT 1) from t where x < 3) select * from t order by x;
-- bwc_tag:end_query

with recursive t as MATERIALIZED (select 1 as x union select x+(SELECT 1+t.x) from t where x < 5) select * from t order by x;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table integers as with recursive t as MATERIALIZED (select 1 as x union select x+1 from t where x < 3) select * from t;
-- bwc_tag:end_query

with recursive t as MATERIALIZED (select (select min(x) from integers) as x union select x+1 from t where x < 3) select * from t order by x;
-- bwc_tag:end_query

with recursive t as MATERIALIZED (select 1 as x union select sum(x+1) from t where x < 3) select * from t order by 1 nulls last
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

with recursive t as MATERIALIZED (select 1 as x union select sum(x+1) from t where x < 3 order by x) select * from t
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

with recursive t as MATERIALIZED (select 1 as x union select sum(x+1) from t where x < 3 LIMIT 1) select * from t
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

with recursive t as MATERIALIZED (select 1 as x union select sum(x+1) from t where x < 3 OFFSET 1) select * from t
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

with recursive t as MATERIALIZED (select 1 as x union select sum(x+1) from t where x < 3 LIMIT 1 OFFSET 1) select * from t
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create view vr as (with recursive t(x) as MATERIALIZED (select 1 union select x+1 from t where x < 3) select * from t order by x)
-- bwc_tag:end_query

select * from vr
-- bwc_tag:end_query

