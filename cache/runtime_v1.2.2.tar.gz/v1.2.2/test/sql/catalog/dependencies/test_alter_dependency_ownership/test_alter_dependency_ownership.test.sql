-- bwc_tag:nb_steps=134
-- bwc_tag:execute_from_sql
CREATE SEQUENCE sequence1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tablename (
    colname integer
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER SEQUENCE sequence1 OWNED BY tablename;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE tablename;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT nextval('sequence1');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE main.sequence1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE main.tablename (
    colname integer
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER SEQUENCE main.sequence1 OWNED BY main.tablename;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE main.tablename;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT nextval('main.sequence1');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE sequence1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tablename (
    colname integer
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER SEQUENCE sequence1 OWNED BY tablename;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP SEQUENCE sequence1 CASCADE;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM tablename;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE sequence1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tablename (
    colname integer
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER SEQUENCE sequence1 OWNED BY tablename;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DROP SEQUENCE sequence1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE tablename;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE sequence1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tablename (
    colname integer
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tablename2 (
    colname integer
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER SEQUENCE sequence1 OWNED BY tablename OWNED BY tablename2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER SEQUENCE sequence1 OWNED BY tablename;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER SEQUENCE sequence1 OWNED BY tablename2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE tablename;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE tablename2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE sequence1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tablename (
    colname integer
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER SEQUENCE sequence1 OWNED BY tablename;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER SEQUENCE sequence1 OWNED BY tablename;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE tablename;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE sequence1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE sequence2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE sequence3;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tablename (
    colname integer
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER SEQUENCE sequence1 OWNED BY tablename;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER SEQUENCE sequence2 OWNED BY tablename;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER SEQUENCE sequence3 OWNED BY tablename;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE tablename;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT nextval('sequence1');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT nextval('sequence2');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT nextval('sequence3');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE sequence1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE sequence2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tablename (
    colname integer DEFAULT nextval('sequence1'),
    colname2 integer DEFAULT nextval('sequence2'),
    colname3 integer,
    colname4 float,
    colname5 string
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER SEQUENCE sequence1 OWNED BY tablename;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO tablename VALUES(default, default, 10, 2.0, 'aaaa');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO tablename VALUES(default, default, 20, 3.0, 'bbbb');
-- bwc_tag:end_query

SELECT colname, colname2, colname3, colname4, colname5 FROM tablename;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE tablename;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP SEQUENCE sequence2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE sequence1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tablename (
    colname integer
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER SEQUENCE sequence1 OWNED BY tablename;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE tablename RENAME TO new_tablename;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tablename (
    colname integer
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER SEQUENCE sequence1 OWNED BY tablename;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DROP SEQUENCE sequence1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE OR REPLACE SEQUENCE sequence1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER SEQUENCE sequence1 OWNED BY new_tablename;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE tablename;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE new_tablename;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE sequence1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tablename (
    colname integer
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER SEQUENCE sequence1 OWNED BY tablename;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE tablename ADD COLUMN colname2 integer DEFAULT nextval('sequence1')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER SEQUENCE sequence1 OWNED BY tablename;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DROP SEQUENCE sequence1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE tablename;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE sequence1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tablename (
    colname integer,
    colname2 integer DEFAULT nextval('sequence1')
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER SEQUENCE sequence1 OWNED BY tablename;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE tablename DROP colname2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DROP SEQUENCE sequence1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE tablename;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE sequence1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tablename (
    colname integer DEFAULT nextval('sequence1')
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER SEQUENCE sequence1 OWNED BY tablename;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE tablename ALTER colname TYPE float;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DROP SEQUENCE sequence1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE tablename;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE sequence1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tablename (
    colname integer DEFAULT nextval('sequence1'),
    colname2 integer DEFAULT nextval('sequence1'),
    colname3 integer DEFAULT nextval('sequence1'),
    colname4 integer DEFAULT nextval('sequence1')
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER SEQUENCE sequence1 OWNED BY tablename;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE tablename DROP colname4;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DROP SEQUENCE sequence1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE tablename DROP colname3;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DROP SEQUENCE sequence1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE tablename DROP colname2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DROP SEQUENCE sequence1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE tablename;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE sequence1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tablename (
    colname integer DEFAULT nextval('sequence1')
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER SEQUENCE sequence1 OWNED BY tablename;
-- bwc_tag:end_query

-- bwc_tag:skip_query
BEGIN TRANSACTION;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE tablename;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

select nextval('sequence1');
-- bwc_tag:end_query

-- bwc_tag:skip_query
ROLLBACK;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select nextval('sequence1');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DROP SEQUENCE sequence1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE tablename;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE sequence1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW v1_sequence1(a) AS SELECT 42;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER SEQUENCE sequence1 OWNED BY v1_sequence1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DROP SEQUENCE sequence1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP VIEW v1_sequence1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT nextval('sequence1');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE sequence1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE sequence2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER SEQUENCE sequence1 OWNED BY sequence2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DROP SEQUENCE sequence1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP SEQUENCE sequence2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT nextval('sequence1');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE sequence1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE sequence2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER SEQUENCE sequence1 OWNED BY sequence2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER SEQUENCE sequence2 OWNED BY sequence1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP SEQUENCE sequence2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE sequence1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE sequence2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE sequence3;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE sequence4;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER SEQUENCE sequence2 OWNED BY sequence1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER SEQUENCE sequence3 OWNED BY sequence2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER SEQUENCE sequence1 OWNED BY sequence3;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER SEQUENCE sequence3 OWNED BY sequence4;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP SEQUENCE sequence1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP SEQUENCE sequence4;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT nextval('sequence1');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT nextval('sequence2');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT nextval('sequence3');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT nextval('sequence4');
-- bwc_tag:end_query

