-- bwc_tag:nb_steps=2
-- bwc_tag:execute_from_sql
create sequence minseq INCREMENT BY -1 MINVALUE -5 MAXVALUE 5 CYCLE;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('minseq') from generate_series(0,20);
-- bwc_tag:end_query

