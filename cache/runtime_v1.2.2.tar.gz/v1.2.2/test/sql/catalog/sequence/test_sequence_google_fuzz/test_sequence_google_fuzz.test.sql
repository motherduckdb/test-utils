-- bwc_tag:nb_steps=1
-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

;creAte
sequence
uGeõó±õõõõ.õõõ.õ;creAte
sequence
uGeõõõõõ..õ;creAte
sequence
uGeõõõõõ..õ;creAte
sequence
uGeõõõõ
-- bwc_tag:end_query

