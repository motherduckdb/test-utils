-- bwc_tag:nb_steps=15
-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DROP SCHEMA main CASCADE;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP SCHEMA test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE SCHEMA test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA IF NOT EXISTS test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test.hello(i INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE TABLE test2.hello(i INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test.hello VALUES (2), (3), (4)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM hello
-- bwc_tag:end_query

SELECT * FROM test.hello
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DROP SCHEMA test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP SCHEMA test CASCADE;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP SCHEMA IF EXISTS test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DROP SCHEMA test;
-- bwc_tag:end_query

