-- bwc_tag:nb_steps=79
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:expected_result=unknown

SELECT NULL FROM sniff_csv('data/csv/14512.csv', sep := NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

SELECT NULL FROM read_csv('data/csv/14512.csv', sep := NULL)
-- bwc_tag:end_query

-- bwc_tag:expected_result=unknown

SELECT NULL FROM sniff_csv('data/csv/14512.csv', delim := NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

SELECT NULL FROM read_csv('data/csv/14512.csv', delim := NULL)
-- bwc_tag:end_query

-- bwc_tag:expected_result=unknown

SELECT NULL FROM sniff_csv('data/csv/14512.csv', quote := NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

SELECT NULL FROM read_csv('data/csv/14512.csv', quote := NULL)
-- bwc_tag:end_query

-- bwc_tag:expected_result=unknown

SELECT NULL FROM sniff_csv('data/csv/14512.csv', new_line := NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

SELECT NULL FROM read_csv('data/csv/14512.csv', new_line := NULL)
-- bwc_tag:end_query

-- bwc_tag:expected_result=unknown

SELECT NULL FROM sniff_csv('data/csv/14512.csv', escape := NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

SELECT NULL FROM read_csv('data/csv/14512.csv', escape := NULL)
-- bwc_tag:end_query

-- bwc_tag:expected_result=unknown

SELECT NULL FROM sniff_csv('data/csv/14512.csv', nullstr := NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

SELECT NULL FROM read_csv('data/csv/14512.csv', nullstr := NULL)
-- bwc_tag:end_query

-- bwc_tag:expected_result=unknown

SELECT NULL FROM sniff_csv('data/csv/14512.csv', columns := NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

SELECT NULL FROM read_csv('data/csv/14512.csv', columns := NULL)
-- bwc_tag:end_query

-- bwc_tag:expected_result=unknown

SELECT NULL FROM sniff_csv('data/csv/14512.csv', auto_type_candidates := NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

SELECT NULL FROM read_csv('data/csv/14512.csv', auto_type_candidates := NULL)
-- bwc_tag:end_query

-- bwc_tag:expected_result=unknown

SELECT NULL FROM sniff_csv('data/csv/14512.csv', header := NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

SELECT NULL FROM read_csv('data/csv/14512.csv', header := NULL)
-- bwc_tag:end_query

-- bwc_tag:expected_result=unknown

SELECT NULL FROM sniff_csv('data/csv/14512.csv', auto_detect := NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

SELECT NULL FROM read_csv('data/csv/14512.csv', auto_detect := NULL)
-- bwc_tag:end_query

-- bwc_tag:expected_result=unknown

SELECT NULL FROM sniff_csv('data/csv/14512.csv', sample_size := NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

SELECT NULL FROM read_csv('data/csv/14512.csv', sample_size := NULL)
-- bwc_tag:end_query

-- bwc_tag:expected_result=unknown

SELECT NULL FROM sniff_csv('data/csv/14512.csv', all_varchar := NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

SELECT NULL FROM read_csv('data/csv/14512.csv', all_varchar := NULL)
-- bwc_tag:end_query

-- bwc_tag:expected_result=unknown

SELECT NULL FROM sniff_csv('data/csv/14512.csv', dateformat := NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

SELECT NULL FROM read_csv('data/csv/14512.csv', dateformat := NULL)
-- bwc_tag:end_query

-- bwc_tag:expected_result=unknown

SELECT NULL FROM sniff_csv('data/csv/14512.csv', timestampformat := NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

SELECT NULL FROM read_csv('data/csv/14512.csv', timestampformat := NULL)
-- bwc_tag:end_query

-- bwc_tag:expected_result=unknown

SELECT NULL FROM sniff_csv('data/csv/14512.csv', normalize_names := NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

SELECT NULL FROM read_csv('data/csv/14512.csv', normalize_names := NULL)
-- bwc_tag:end_query

-- bwc_tag:expected_result=unknown

SELECT NULL FROM sniff_csv('data/csv/14512.csv', compression := NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

SELECT NULL FROM read_csv('data/csv/14512.csv', compression := NULL)
-- bwc_tag:end_query

-- bwc_tag:expected_result=unknown

SELECT NULL FROM sniff_csv('data/csv/14512.csv', skip := NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

SELECT NULL FROM read_csv('data/csv/14512.csv', skip := NULL)
-- bwc_tag:end_query

-- bwc_tag:expected_result=unknown

SELECT NULL FROM sniff_csv('data/csv/14512.csv', max_line_size := NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

SELECT NULL FROM read_csv('data/csv/14512.csv', max_line_size := NULL)
-- bwc_tag:end_query

-- bwc_tag:expected_result=unknown

SELECT NULL FROM sniff_csv('data/csv/14512.csv', maximum_line_size := NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

SELECT NULL FROM read_csv('data/csv/14512.csv', maximum_line_size := NULL)
-- bwc_tag:end_query

-- bwc_tag:expected_result=unknown

SELECT NULL FROM sniff_csv('data/csv/14512.csv', ignore_errors := NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

SELECT NULL FROM read_csv('data/csv/14512.csv', ignore_errors := NULL)
-- bwc_tag:end_query

-- bwc_tag:expected_result=unknown

SELECT NULL FROM sniff_csv('data/csv/14512.csv', store_rejects := NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

SELECT NULL FROM read_csv('data/csv/14512.csv', store_rejects := NULL)
-- bwc_tag:end_query

-- bwc_tag:expected_result=unknown

SELECT NULL FROM sniff_csv('data/csv/14512.csv', rejects_table := NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

SELECT NULL FROM read_csv('data/csv/14512.csv', rejects_table := NULL)
-- bwc_tag:end_query

-- bwc_tag:expected_result=unknown

SELECT NULL FROM sniff_csv('data/csv/14512.csv', rejects_scan := NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

SELECT NULL FROM read_csv('data/csv/14512.csv', rejects_scan := NULL)
-- bwc_tag:end_query

-- bwc_tag:expected_result=unknown

SELECT NULL FROM sniff_csv('data/csv/14512.csv', rejects_limit := NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

SELECT NULL FROM read_csv('data/csv/14512.csv', rejects_limit := NULL)
-- bwc_tag:end_query

-- bwc_tag:expected_result=unknown

SELECT NULL FROM sniff_csv('data/csv/14512.csv', force_not_null := NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

SELECT NULL FROM read_csv('data/csv/14512.csv', force_not_null := NULL)
-- bwc_tag:end_query

-- bwc_tag:expected_result=unknown

SELECT NULL FROM sniff_csv('data/csv/14512.csv', buffer_size := NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

SELECT NULL FROM read_csv('data/csv/14512.csv', buffer_size := NULL)
-- bwc_tag:end_query

-- bwc_tag:expected_result=unknown

SELECT NULL FROM sniff_csv('data/csv/14512.csv', decimal_separator := NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

SELECT NULL FROM read_csv('data/csv/14512.csv', decimal_separator := NULL)
-- bwc_tag:end_query

-- bwc_tag:expected_result=unknown

SELECT NULL FROM sniff_csv('data/csv/14512.csv', parallel := NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

SELECT NULL FROM read_csv('data/csv/14512.csv', parallel := NULL)
-- bwc_tag:end_query

-- bwc_tag:expected_result=unknown

SELECT NULL FROM sniff_csv('data/csv/14512.csv', null_padding := NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

SELECT NULL FROM read_csv('data/csv/14512.csv', null_padding := NULL)
-- bwc_tag:end_query

-- bwc_tag:expected_result=unknown

SELECT NULL FROM sniff_csv('data/csv/14512.csv', allow_quoted_nulls := NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

SELECT NULL FROM read_csv('data/csv/14512.csv', allow_quoted_nulls := NULL)
-- bwc_tag:end_query

-- bwc_tag:expected_result=unknown

SELECT NULL FROM sniff_csv('data/csv/14512.csv', column_types := NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

SELECT NULL FROM read_csv('data/csv/14512.csv', column_types := NULL)
-- bwc_tag:end_query

-- bwc_tag:expected_result=unknown

SELECT NULL FROM sniff_csv('data/csv/14512.csv', dtypes := NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

SELECT NULL FROM read_csv('data/csv/14512.csv', dtypes := NULL)
-- bwc_tag:end_query

-- bwc_tag:expected_result=unknown

SELECT NULL FROM sniff_csv('data/csv/14512.csv', types := NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

SELECT NULL FROM read_csv('data/csv/14512.csv', types := NULL)
-- bwc_tag:end_query

-- bwc_tag:expected_result=unknown

SELECT NULL FROM sniff_csv('data/csv/14512.csv', names := NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

SELECT NULL FROM read_csv('data/csv/14512.csv', names := NULL)
-- bwc_tag:end_query

-- bwc_tag:expected_result=unknown

SELECT NULL FROM sniff_csv('data/csv/14512.csv', column_names := NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

SELECT NULL FROM read_csv('data/csv/14512.csv', column_names := NULL)
-- bwc_tag:end_query

-- bwc_tag:expected_result=unknown

SELECT NULL FROM sniff_csv('data/csv/14512.csv', comment := NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

SELECT NULL FROM read_csv('data/csv/14512.csv', comment := NULL)
-- bwc_tag:end_query

-- bwc_tag:expected_result=unknown

SELECT NULL FROM sniff_csv('data/csv/14512.csv', encoding := NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

SELECT NULL FROM read_csv('data/csv/14512.csv', encoding := NULL)
-- bwc_tag:end_query

-- bwc_tag:expected_result=unknown

SELECT NULL FROM sniff_csv('data/csv/14512.csv', strict_mode := NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

SELECT NULL FROM read_csv('data/csv/14512.csv', strict_mode := NULL)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT NULL FROM sniff_csv(NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT NULL FROM read_csv(NULL)
-- bwc_tag:end_query

