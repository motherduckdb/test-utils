-- bwc_tag:nb_steps=42
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/no_header.csv');
-- bwc_tag:end_query

SELECT column0, column1, column2 FROM test ORDER BY column0;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/single_header.csv');
-- bwc_tag:end_query

SELECT number, text, date FROM test ORDER BY number;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/skip_row.csv');
-- bwc_tag:end_query

SELECT number, text, date FROM test ORDER BY number;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/multiple_skip_row.csv');
-- bwc_tag:end_query

SELECT number, text, date FROM test ORDER BY number;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/varchar_multi_line.csv', header = 0);
-- bwc_tag:end_query

SELECT * FROM test ORDER BY column0;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/varchar_single_line.csv', header = 0);
-- bwc_tag:end_query

SELECT column0, column1 FROM test ORDER BY column0;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/mixed_single_line.csv');
-- bwc_tag:end_query

SELECT column0, column1 FROM test ORDER BY column0;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/single_value.csv');
-- bwc_tag:end_query

SELECT * FROM test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/single_numeric.csv');
-- bwc_tag:end_query

SELECT * FROM test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto('data/csv/auto/utf8bom.csv');
-- bwc_tag:end_query

SELECT * FROM test;
-- bwc_tag:end_query

SELECT id FROM test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE my_varchars(a VARCHAR, b VARCHAR, c VARCHAR);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO my_varchars VALUES ('Hello', 'Beautiful', 'World');
-- bwc_tag:end_query

COPY my_varchars TO 'output/varchar_header.csv' (HEADER 1);
-- bwc_tag:end_query

COPY my_varchars TO 'output/varchar_no_header.csv' (HEADER 0);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY my_varchars FROM 'output/varchar_header.csv' ;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY my_varchars FROM 'output/varchar_no_header.csv' (HEADER 0);
-- bwc_tag:end_query

FROM my_varchars ;
-- bwc_tag:end_query

COPY my_varchars TO 'output/big_varchar.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY my_varchars FROM 'output/big_varchar.csv';
-- bwc_tag:end_query

FROM my_varchars;
-- bwc_tag:end_query

