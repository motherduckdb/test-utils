-- bwc_tag:nb_steps=3
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT typeof(#1), typeof(#2), typeof(#3), typeof(#4), typeof(#5), typeof(#6), typeof(#7), typeof(#8), typeof(#9), typeof(#10), typeof(#11), typeof(#12), typeof(#13)
FROM read_csv(['data/csv/union-by-name/gabor/Post/*.csv', 'data/csv/union-by-name/gabor/Comment/*.csv'], union_by_name=true)
LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv(['data/csv/union-by-name/gabor/Post/*.csv', 'data/csv/union-by-name/gabor/Comment/*.csv'], union_by_name=true)
ORDER BY ALL
LIMIT 1;
-- bwc_tag:end_query

