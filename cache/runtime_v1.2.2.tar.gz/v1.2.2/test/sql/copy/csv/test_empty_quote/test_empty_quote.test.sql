-- bwc_tag:nb_steps=5
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE no_quote(a VARCHAR, b VARCHAR);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY no_quote FROM 'data/csv/no_quote.csv' ( QUOTE '', ESCAPE '', DELIM '|');
-- bwc_tag:end_query

SELECT * FROM no_quote;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv('data/csv/no_quote.csv', auto_detect=1, quote='');
-- bwc_tag:end_query

