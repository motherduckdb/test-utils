-- bwc_tag:nb_steps=3
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE sales (
    salesid INTEGER  NOT NULL PRIMARY KEY,
    listid INTEGER NOT NULL,
    sellerid INTEGER NOT NULL,
    buyerid  INTEGER NOT NULL,
    eventid INTEGER NOT NULL,
    dateid  SMALLINT  NOT NULL,
    qtysold   SMALLINT  NOT NULL,
    pricepaid DECIMAL (8,2),
    commission DECIMAL (8,2),
    saletime TIMESTAMP);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY sales FROM 'data/csv/sales_snippet.csv' (TIMESTAMPFORMAT '%m/%d/%Y %I:%M:%S', IGNORE_ERRORS true);
-- bwc_tag:end_query

