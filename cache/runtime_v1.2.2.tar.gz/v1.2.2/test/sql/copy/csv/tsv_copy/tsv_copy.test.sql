-- bwc_tag:nb_steps=6
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE people(id INTEGER, name VARCHAR);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO people VALUES (1, 'Mark'), (2, 'Hannes');
-- bwc_tag:end_query

COPY people TO 'output/test.tsv' WITH (DELIMITER '\t');
-- bwc_tag:end_query

SELECT * FROM 'output/test.tsv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv('output/test.tsv', sep='\t', columns={'id': 'INTEGER', 'name': 'VARCHAR'})
-- bwc_tag:end_query

