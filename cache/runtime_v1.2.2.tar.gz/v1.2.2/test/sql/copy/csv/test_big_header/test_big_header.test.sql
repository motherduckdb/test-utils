-- bwc_tag:nb_steps=8
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test (foo INTEGER, bar VARCHAR(10), baz VARCHAR(10), bam VARCHAR(10));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY test FROM 'data/csv/test/big_header.csv' (DELIMITER '	', HEADER false, SKIP 2);
-- bwc_tag:end_query

SELECT COUNT(bam) FROM test WHERE bam = '!';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test SELECT * FROM read_csv('data/csv/test/big_header.csv', HEADER=FALSE, SKIP=2, DELIM='	', columns=STRUCT_PACK(foo := 'INTEGER', bar := 'VARCHAR', baz := 'VARCHAR', bam := 'VARCHAR'));
-- bwc_tag:end_query

SELECT COUNT(bam) FROM test WHERE bam = '!';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test SELECT * FROM read_csv_auto('data/csv/test/big_header.csv', HEADER=FALSE, SKIP=2, DELIM='	');
-- bwc_tag:end_query

SELECT COUNT(bam) FROM test WHERE bam = '!';
-- bwc_tag:end_query

