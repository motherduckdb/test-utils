-- bwc_tag:nb_steps=6
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
from read_csv('data/csv/headers/undetected_type.csv', delim = ';')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
from 'data/csv/headers/all_varchar.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
from 'data/csv/headers/single_line.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
from 'data/csv/headers/borked_type.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
from 'data/csv/headers/integer.csv'
-- bwc_tag:end_query

