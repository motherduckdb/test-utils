-- bwc_tag:nb_steps=6
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

SELECT columns from sniff_csv('data/csv/header_only.csv', header=True, ignore_errors=True)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT abs_file_name FROM read_csv('data/csv/header_only.csv', header=True, ignore_errors=True)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT REGEXP_MATCHES(abs_file_name, 'foo')
  FROM ( SELECT abs_file_name FROM read_csv('data/csv/header_only.csv', header=True, ignore_errors=True))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT REGEXP_MATCHES(abs_file_name, 'foo')
  FROM ( SELECT abs_file_name FROM read_csv(['data/csv/header_only.csv','data/csv/header_only.csv'], header=True, ignore_errors=True))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT REGEXP_MATCHES(abs_file_name, 'foo')
  FROM ( SELECT abs_file_name FROM read_csv(['data/csv/header_only.csv','data/csv/bool.csv','data/csv/header_only.csv'], header=True, ignore_errors=True))
-- bwc_tag:end_query

