-- bwc_tag:needed_extensions=httpfs
-- bwc_tag:nb_steps=4
LOAD 'httpfs';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

from sniff_csv('https://github.com/duckdb/duckdb/raw/main/data/csv/who.csv.gz');
-- bwc_tag:end_query

from sniff_csv('https://github.com/duckdb/duckdb/raw/main/data/csv/who.csv.gz?v=1');
-- bwc_tag:end_query

