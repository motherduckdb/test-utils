-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=4
LOAD 'parquet';
-- bwc_tag:end_query

DESCRIBE 'data/parquet-testing/delta_byte_array.parquet'
-- bwc_tag:end_query

DESCRIBE "data/parquet-testing/delta_byte_array.parquet"
-- bwc_tag:end_query

DESCRIBE FROM read_parquet("data/parquet-testing/delta_byte_array.parquet")
-- bwc_tag:end_query

