-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=5
LOAD 'parquet';
-- bwc_tag:end_query

select * 
from parquet_scan('data/parquet-testing/hive-partitioning/empty_string/*/*.parquet')
ORDER BY ALL
-- bwc_tag:end_query

select *
from parquet_scan('data/parquet-testing/hive-partitioning/empty_string/*/*.parquet')
WHERE key IS NULL
-- bwc_tag:end_query

select *
from parquet_scan('data/parquet-testing/hive-partitioning/empty_string/*/*.parquet')
WHERE key='a'
-- bwc_tag:end_query

select *
from parquet_scan('data/parquet-testing/hive-partitioning/empty_string/*/*.parquet')
WHERE key=''
-- bwc_tag:end_query

