-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=6
LOAD 'parquet';
-- bwc_tag:end_query

SELECT COUNT(*), MIN(i), MAX(i), SUM(i) FROM parquet_scan('data/parquet-testing/manyrowgroups.parquet') t(i)
-- bwc_tag:end_query

SELECT COUNT(*), MIN(i), MAX(i), SUM(i) FROM parquet_scan('data/parquet-testing/manyrowgroups*') t(i)
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA threads=4
-- bwc_tag:end_query

SELECT COUNT(*), MIN(i), MAX(i), SUM(i) FROM parquet_scan('data/parquet-testing/manyrowgroups.parquet') t(i)
-- bwc_tag:end_query

SELECT COUNT(*), MIN(i), MAX(i), SUM(i) FROM parquet_scan('data/parquet-testing/manyrowgroups*') t(i)
-- bwc_tag:end_query

