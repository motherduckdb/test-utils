-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=2
LOAD 'parquet';
-- bwc_tag:end_query

select *, epoch_ms(dt2*1000) 
from read_parquet('data/parquet-testing/bug4903.parquet')
where dt2 <= -9214570800
limit 10
-- bwc_tag:end_query

