-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=30
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE timestamps(d TIMESTAMP)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO timestamps VALUES
    (TIMESTAMP '1992-01-01 12:03:27'),
    (TIMESTAMP '1900-01-01 03:08:47'),
    (NULL),
    (TIMESTAMP '2020-09-27 13:12:01')
-- bwc_tag:end_query

SELECT * FROM timestamps
-- bwc_tag:end_query

COPY timestamps TO 'output/timestamps.parquet' (FORMAT 'parquet');
-- bwc_tag:end_query

SELECT * FROM 'output/timestamps.parquet'
-- bwc_tag:end_query

SELECT * FROM 'output/timestamps.parquet' WHERE d='1992-01-01 12:03:27'
-- bwc_tag:end_query

SELECT typeof(d) FROM 'output/timestamps.parquet' LIMIT 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE timestamps(d TIMESTAMP_MS)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO timestamps VALUES
    (TIMESTAMP '1992-01-01 12:03:27'),
    (TIMESTAMP '1900-01-01 03:08:47'),
    (NULL),
    (TIMESTAMP '2020-09-27 13:12:01')
-- bwc_tag:end_query

SELECT * FROM timestamps
-- bwc_tag:end_query

COPY timestamps TO 'output/timestamps.parquet' (FORMAT 'parquet');
-- bwc_tag:end_query

SELECT * FROM 'output/timestamps.parquet'
-- bwc_tag:end_query

SELECT * FROM 'output/timestamps.parquet' WHERE d='1992-01-01 12:03:27'
-- bwc_tag:end_query

SELECT typeof(d) FROM 'output/timestamps.parquet' LIMIT 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE timestamps(d TIMESTAMP_S)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO timestamps VALUES
    (TIMESTAMP '1992-01-01 12:03:27'),
    (TIMESTAMP '1900-01-01 03:08:47'),
    (NULL),
    (TIMESTAMP '2020-09-27 13:12:01')
-- bwc_tag:end_query

SELECT * FROM timestamps
-- bwc_tag:end_query

COPY timestamps TO 'output/timestamps.parquet' (FORMAT 'parquet');
-- bwc_tag:end_query

SELECT * FROM 'output/timestamps.parquet'
-- bwc_tag:end_query

SELECT * FROM 'output/timestamps.parquet' WHERE d='1992-01-01 12:03:27'
-- bwc_tag:end_query

SELECT typeof(d) FROM 'output/timestamps.parquet' LIMIT 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE timestamps(d TIMESTAMP_NS)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO timestamps VALUES
    ('1992-01-01 12:03:27.123456789'),
    ('1900-01-01 03:08:47.987654321'),
    (NULL),
    ('2020-09-27 13:12:01')
-- bwc_tag:end_query

SELECT * FROM timestamps
-- bwc_tag:end_query

COPY timestamps TO 'output/timestamps.parquet' (FORMAT 'parquet');
-- bwc_tag:end_query

SELECT * FROM 'output/timestamps.parquet'
-- bwc_tag:end_query

SELECT * FROM 'output/timestamps.parquet' WHERE d='1992-01-01 12:03:27.123456789'
-- bwc_tag:end_query

SELECT typeof(d) FROM 'output/timestamps.parquet' LIMIT 1
-- bwc_tag:end_query

