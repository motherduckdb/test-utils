-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=4
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE lists as SELECT i as id, [i] as list from range(0,10000) tbl(i);
-- bwc_tag:end_query

COPY lists to 'output/list_bug_test.parquet';
-- bwc_tag:end_query

SELECT list from 'output/list_bug_test.parquet' where id = 5000;
-- bwc_tag:end_query

