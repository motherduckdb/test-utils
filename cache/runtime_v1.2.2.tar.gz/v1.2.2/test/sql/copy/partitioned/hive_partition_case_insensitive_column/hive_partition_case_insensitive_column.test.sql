-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=2
LOAD 'parquet';
-- bwc_tag:end_query

SELECT * FROM  'data/parquet-testing/hive-partitioning/ci-column-names/**/*.parquet' ORDER BY ALL
-- bwc_tag:end_query

