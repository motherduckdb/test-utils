-- bwc_tag:nb_steps=8
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER);
-- bwc_tag:end_query

SELECT i AS 'hello world' FROM integers
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT i 'hello world' FROM integers
-- bwc_tag:end_query

SELECT i "hello world" FROM integers
-- bwc_tag:end_query

SELECT i AS "hello world" FROM integers
-- bwc_tag:end_query

SELECT "hello world".i FROM integers AS 'hello world'
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT "hello world".i FROM integers 'hello world'
-- bwc_tag:end_query

