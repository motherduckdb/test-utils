-- bwc_tag:nb_steps=14
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE depdelay_minutes(depdelay_minutes INTEGER);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM depdelay
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT depdelay FROM depdelay_minutes
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE lineitem(i INTEGER);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM li
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM lineitem_long
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select jaro_winkler_('x', 'y');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create schema s1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table s1.my_lineitem(i int);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select * from my_lineitem;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select * from m_lineitem;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table s1.orders(i int)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select * from ord
-- bwc_tag:end_query

