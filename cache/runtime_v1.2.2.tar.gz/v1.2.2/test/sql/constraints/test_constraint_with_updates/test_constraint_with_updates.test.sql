-- bwc_tag:nb_steps=17
-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER, j INTEGER CHECK(i + j < 5), k INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (1, 2, 4)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
UPDATE integers SET k=7
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
UPDATE integers SET i=i, j=3
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
UPDATE integers SET i=i, j=3
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

UPDATE integers SET i=i, i=10
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

UPDATE integers SET i=i, j=10
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
UPDATE integers SET j=2
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

UPDATE integers SET j=10
-- bwc_tag:end_query

SELECT * FROM integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER NOT NULL, j INTEGER NOT NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (1, 2)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
UPDATE integers SET j=3
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

UPDATE integers SET i=NULL
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

UPDATE integers SET j=NULL
-- bwc_tag:end_query

SELECT * FROM integers
-- bwc_tag:end_query

