-- bwc_tag:nb_steps=27
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tbl1 AS SELECT 1;
-- bwc_tag:end_query

SELECT * FROM tbl1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tbl2 AS SELECT 2 AS f;
-- bwc_tag:end_query

SELECT * FROM tbl2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE tbl3 AS SELECT 3;
-- bwc_tag:end_query

SELECT * FROM tbl3;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE TABLE tbl1 AS SELECT 3;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE tbl1 AS SELECT 4;
-- bwc_tag:end_query

SELECT * FROM tbl1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE tbl1 AS SELECT 'hello' UNION ALL SELECT 'world';
-- bwc_tag:end_query

SELECT * FROM tbl1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE tbl1 AS SELECT 5 WHERE false;
-- bwc_tag:end_query

SELECT * FROM tbl1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE TABLE tbl4 IF NOT EXISTS AS SELECT 4;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE OR REPLACE TABLE tbl4 IF NOT EXISTS AS SELECT 4;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tbl4(col1, col2) AS SELECT 1, 'hello';
-- bwc_tag:end_query

SELECT * FROM tbl4;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE tbl4(col1, col2) AS SELECT 2, 'duck';
-- bwc_tag:end_query

SELECT * FROM tbl4;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE IF NOT EXISTS tbl5(col1, col2) AS SELECT 3, 'database';
-- bwc_tag:end_query

SELECT * FROM tbl5;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE tbl5(col1, "col need ' quote") AS SELECT 3.5, 'quote';
-- bwc_tag:end_query

SELECT * FROM tbl5;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tbl6(col1) AS SELECT 4 ,'mismatch';
-- bwc_tag:end_query

SELECT * FROM tbl6;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE TABLE tbl7(col1, col2) AS SELECT 5;
-- bwc_tag:end_query

