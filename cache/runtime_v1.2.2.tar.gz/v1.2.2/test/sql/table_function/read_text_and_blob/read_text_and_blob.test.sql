-- bwc_tag:nb_steps=9
SELECT COUNT(*) FROM read_text('test/sql/table_function/files/*.txt');
-- bwc_tag:end_query

SELECT COUNT(*) FROM read_blob('test/sql/table_function/files/*');
-- bwc_tag:end_query

SELECT * FROM read_text('test/sql/table_function/files/nonexistentfile.txt') ORDER BY ALL;
-- bwc_tag:end_query

SELECT parse_path(filename) FROM read_text('test/sql/table_function/files/nonexistentfile.txt') ORDER BY ALL;
-- bwc_tag:end_query

SELECT parse_path(filename) FROM read_text(['test/sql/table_function/files/one.txt', 'test/sql/table_function/files/two.txt']) ORDER BY ALL;
-- bwc_tag:end_query

SELECT parse_path(filename), size, content FROM read_blob('test/sql/table_function/files/four.blob');
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT parse_path(filename), size, content FROM read_text('test/sql/table_function/files/four.blob');
-- bwc_tag:end_query

SELECT size, parse_path(filename), content  FROM read_text('test/sql/table_function/files/*.txt') ORDER BY filename, size;
-- bwc_tag:end_query

SELECT last_modified > '2024-01-01' AND last_modified < '2500-01-01' FROM read_blob('test/sql/table_function/files/*');
-- bwc_tag:end_query

