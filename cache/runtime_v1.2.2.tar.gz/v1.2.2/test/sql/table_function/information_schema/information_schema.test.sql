-- bwc_tag:nb_steps=30
SELECT * FROM INFORMATION_SCHEMA.SCHEMATA;
-- bwc_tag:end_query

SELECT * FROM information_schema.schemata;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA scheme;
-- bwc_tag:end_query

SELECT COUNT(*) FROM information_schema.schemata WHERE schema_name='scheme'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE scheme.integers (i INTEGER);
-- bwc_tag:end_query

SELECT table_type FROM information_schema.tables WHERE table_schema='scheme' AND table_name='integers' AND table_catalog IS NOT NULL
-- bwc_tag:end_query

SELECT ordinal_position, column_name, data_type FROM information_schema.columns WHERE table_name='integers'
-- bwc_tag:end_query

SELECT ordinal_position, column_name, data_type FROM information_schema.columns WHERE table_name='integers'
-- bwc_tag:end_query

CREATE TEMPORARY TABLE reals (f FLOAT PRIMARY KEY, dec DECIMAL(16, 4), h HUGEINT, b BIGINT, t TINYINT, d DOUBLE NOT NULL)
-- bwc_tag:end_query

SELECT table_type FROM information_schema.tables WHERE table_catalog='temp' AND table_name='reals'
-- bwc_tag:end_query

SELECT numeric_precision, numeric_scale, is_nullable FROM information_schema.columns WHERE table_name='reals' ORDER BY ordinal_position
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW scheme.vintegers AS SELECT * FROM scheme.integers;
-- bwc_tag:end_query

SELECT table_type FROM information_schema.tables WHERE table_schema='scheme' AND table_name='vintegers'
-- bwc_tag:end_query

SELECT table_type FROM information_schema.tables WHERE table_schema='scheme' AND table_name='vintegers'
-- bwc_tag:end_query

SELECT ordinal_position, column_name, data_type FROM information_schema.columns WHERE table_schema='scheme' AND table_name='vintegers' AND table_catalog IS NOT NULL
-- bwc_tag:end_query

SELECT character_set_name, character_repertoire, form_of_use, default_collate_name FROM information_schema.character_sets
-- bwc_tag:end_query

SELECT * FROM information_schema.referential_constraints
-- bwc_tag:end_query

SELECT * FROM information_schema.key_column_usage
-- bwc_tag:end_query

SELECT * FROM information_schema.table_constraints
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE scheme.dept (dept_id INT PRIMARY KEY, dept_name VARCHAR(100) NOT NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE scheme.emp (emp_id INT PRIMARY KEY, first_name VARCHAR(100) NOT NULL, last_name VARCHAR(100) NOT NULL, ssn INT NOT NULL UNIQUE, salary DECIMAL(10, 2) NOT NULL CHECK (salary > 0), dept_id INT REFERENCES scheme.dept(dept_id))
-- bwc_tag:end_query

SELECT table_catalog, table_schema, table_name, column_name, constraint_catalog, constraint_schema, constraint_name FROM information_schema.constraint_column_usage WHERE table_schema = 'scheme' AND table_name = 'emp' ORDER BY column_name ASC
-- bwc_tag:end_query

SELECT table_catalog, table_schema, table_name, constraint_catalog, constraint_schema, constraint_name FROM information_schema.constraint_table_usage WHERE table_schema = 'scheme' AND table_name = 'emp' ORDER BY constraint_name ASC
-- bwc_tag:end_query

SELECT constraint_catalog, constraint_schema, constraint_name, check_clause FROM information_schema.check_constraints WHERE constraint_schema = 'scheme' AND check_clause LIKE 'CHECK%'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE VIEW scheme.emp_dept_view AS SELECT emp.*, dept.dept_name FROM scheme.emp JOIN scheme.dept ON emp.dept_id = dept.dept_id;
-- bwc_tag:end_query

SELECT table_catalog, table_schema, table_name, SUBSTR (view_definition, 1, 32) AS view_definition_substr, check_option, is_updatable, is_insertable_into, is_trigger_updatable, is_trigger_deletable, is_trigger_insertable_into FROM information_schema.views WHERE table_schema = 'scheme' AND table_name = 'emp_dept_view';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP SCHEMA scheme CASCADE;
-- bwc_tag:end_query

SELECT COUNT(*) FROM information_schema.schemata WHERE schema_name='scheme'
-- bwc_tag:end_query

SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='scheme'
-- bwc_tag:end_query

SELECT COUNT(*) FROM information_schema.columns WHERE table_schema='scheme'
-- bwc_tag:end_query

