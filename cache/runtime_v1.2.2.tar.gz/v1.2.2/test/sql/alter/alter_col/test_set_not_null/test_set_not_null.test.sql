-- bwc_tag:nb_steps=38
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t(i INTEGER, j INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t VALUES (1, 1), (2, 2)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE t ALTER COLUMN j SET NOT NULL
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO t VALUES (3, NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE t ALTER COLUMN j SET NOT NULL
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO t VALUES (3, NULL)
-- bwc_tag:end_query

SELECT * FROM t
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t SELECT 5,5 from range(65534)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE t ALTER COLUMN j SET NOT NULL
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO t VALUES (6, NULL)
-- bwc_tag:end_query

SELECT COUNT(*) FROM t WHERE j IS NULL
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE IF EXISTS t
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t(i INTEGER, j INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t VALUES (1, 1), (2, 2), (3, null)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t SELECT 4,4 FROM RANGE(65536)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE t ALTER COLUMN j SET NOT NULL
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t VALUES (5, null)
-- bwc_tag:end_query

SELECT * FROM t WHERE j IS NULL
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE IF EXISTS t
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t(i INTEGER, j INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t SELECT 1,1 FROM RANGE(65536)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE t ALTER COLUMN j SET NOT NULL
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO t VALUES (2, null)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE t ALTER COLUMN j DROP NOT NULL
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t VALUES (3, null)
-- bwc_tag:end_query

SELECT * FROM t WHERE j IS NULL
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t0(c0 AS (1), c1 INT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE t0 ALTER c1 SET NOT NULL;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE IF EXISTS t
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t(i AS (1), j INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t SELECT 1 FROM RANGE(65536)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE t ALTER COLUMN i SET NOT NULL
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE t ALTER COLUMN j SET NOT NULL
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO t VALUES (null)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE t ALTER COLUMN j DROP NOT NULL
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t VALUES (null)
-- bwc_tag:end_query

SELECT * FROM t WHERE j IS NULL
-- bwc_tag:end_query

