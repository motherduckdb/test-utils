-- bwc_tag:nb_steps=3
-- bwc_tag:execute_from_sql
CREATE TABLE lists_tbl AS SELECT i%20 as groups, i AS l FROM range(1000) tmp(i);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT COUNT(DISTINCT l) FROM lists_tbl group by groups order by l limit 10;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT DISTINCT ON(l) COUNT(DISTINCT l) FROM lists_tbl group by groups;
-- bwc_tag:end_query

