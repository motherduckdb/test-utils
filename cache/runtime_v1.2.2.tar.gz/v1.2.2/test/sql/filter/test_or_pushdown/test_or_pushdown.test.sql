-- bwc_tag:nb_steps=14
-- bwc_tag:execute_from_sql
PRAGMA explain_output = PHYSICAL_ONLY;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table t1 as select range a, 'foo' || (range%100)::VARCHAR b, 100000-range c from range(900000);
-- bwc_tag:end_query

select count(*) from t1 where a < 5 or b = 'foo8';
-- bwc_tag:end_query

explain select * from t1 where a<5 or b = 'foo8';
-- bwc_tag:end_query

explain select * from t1 where a<5 or c>8000;
-- bwc_tag:end_query

select a from t1 where a=5 or a=899999;
-- bwc_tag:end_query

explain select * from t1 where a<5 or a>10;
-- bwc_tag:end_query

explain select * from t1 where 5>a or 10<a;
-- bwc_tag:end_query

explain select * from t1 where 5>=a or 10<=a;
-- bwc_tag:end_query

explain select * from t1 where a in (1, 5, 10);
-- bwc_tag:end_query

explain select * from t1 where a = 1 or a = 5 or a = 10;
-- bwc_tag:end_query

explain select * from t1 where a in (1, 2, 3);
-- bwc_tag:end_query

explain select * from t1 where a in (1);
-- bwc_tag:end_query

explain select b from t1 where b = 'foo9' or b = 'foo10';
-- bwc_tag:end_query

