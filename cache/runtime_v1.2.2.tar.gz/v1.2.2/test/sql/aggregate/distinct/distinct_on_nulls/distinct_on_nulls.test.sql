-- bwc_tag:nb_steps=13
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER, j INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (2, 3), (4, 5), (2, NULL), (NULL, NULL);
-- bwc_tag:end_query

SELECT DISTINCT ON (i) i, j FROM integers ORDER BY j
-- bwc_tag:end_query

SELECT DISTINCT ON (i) i, j FROM integers ORDER BY i, j
-- bwc_tag:end_query

SELECT DISTINCT ON (i) i, j FROM integers ORDER BY i NULLS FIRST, j NULLS FIRST
-- bwc_tag:end_query

SELECT DISTINCT ON (i) i, j FROM integers ORDER BY i, j NULLS FIRST
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE distinct_on_test(key INTEGER, v1 VARCHAR, v2 INTEGER[], v3 INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO distinct_on_test VALUES
	(1, 'hello', ARRAY[1], 42), -- ASC
	(1, 'hello', ARRAY[1], 42),
	(1, 'hello', ARRAY[1], 43), -- DESC
	(2, NULL, NULL, 0),     -- ASC
	(2, NULL, NULL, 1),
	(2, NULL, NULL, NULL),  -- DESC
	(3, 'thisisalongstring', NULL, 0),     -- ASC
	(3, 'thisisalongstringbutlonger', NULL, 1),
	(3, 'thisisalongstringbutevenlonger', ARRAY[1, 2, 3, 4, 5, 6, 7, 8, 9], 2)  -- DESC
;
-- bwc_tag:end_query

SELECT DISTINCT ON (key) * FROM distinct_on_test ORDER BY key, v1, v2, v3
-- bwc_tag:end_query

SELECT DISTINCT ON (key) * FROM distinct_on_test  WHERE key <> 2 ORDER BY key, v1, v2, v3
-- bwc_tag:end_query

SELECT DISTINCT ON (key) * FROM distinct_on_test ORDER BY key, v1 DESC NULLS FIRST, v2 DESC NULLS FIRST, v3 DESC NULLS FIRST
-- bwc_tag:end_query

SELECT DISTINCT ON (key) * FROM distinct_on_test WHERE key <> 2 ORDER BY key, v1 DESC NULLS FIRST, v2 DESC NULLS FIRST, v3 DESC NULLS FIRST
-- bwc_tag:end_query

