-- bwc_tag:nb_steps=18
-- bwc_tag:expected_result=error

SELECT COVAR_POP()
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT COVAR_POP(1, 2, 3)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT COVAR_POP(COVAR_POP(1))
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT COVAR_SAMP()
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT COVAR_SAMP(1, 2, 3)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT COVAR_SAMP(COVAR_SAMP(1))
-- bwc_tag:end_query

SELECT COVAR_POP(3,3), COVAR_POP(NULL,3), COVAR_POP(3,NULL), COVAR_POP(NULL,NULL)
-- bwc_tag:end_query

SELECT COVAR_SAMP(3,3), COVAR_SAMP(NULL,3), COVAR_SAMP(3,NULL), COVAR_SAMP(NULL,NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE seqx;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE seqy;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT COVAR_POP(nextval('seqx'),nextval('seqy'))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT COVAR_POP(nextval('seqx'),nextval('seqy'))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(x INTEGER, y INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (10,NULL), (10,11), (20,22), (25,NULL), (30,35)
-- bwc_tag:end_query

SELECT COVAR_POP(x,y), COVAR_POP(x,1), COVAR_POP(1,y), COVAR_POP(x,NULL), COVAR_POP(NULL,y) FROM integers
-- bwc_tag:end_query

SELECT COVAR_SAMP(x,y), COVAR_SAMP(x,1), COVAR_SAMP(1,y), COVAR_SAMP(x,NULL), COVAR_SAMP(NULL,y) FROM integers
-- bwc_tag:end_query

SELECT COVAR_POP(x,y), COVAR_SAMP(x,y) FROM integers WHERE x > 100
-- bwc_tag:end_query

SELECT COVAR_POP(NULL, NULL), COVAR_SAMP(NULL, NULL) FROM integers
-- bwc_tag:end_query

