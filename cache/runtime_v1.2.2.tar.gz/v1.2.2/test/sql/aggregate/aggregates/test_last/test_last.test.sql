-- bwc_tag:nb_steps=45
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE five AS SELECT i::float AS i FROM range(1, 6, 1) t1(i)
-- bwc_tag:end_query

SELECT LAST(i) FROM five
-- bwc_tag:end_query

SELECT i % 3 AS g, LAST(i) FROM five GROUP BY 1 ORDER BY 1
-- bwc_tag:end_query

SELECT LAST(i ORDER BY 5-i) FROM five
-- bwc_tag:end_query

SELECT i % 3 AS g, LAST(i ORDER BY 5-i) FROM five GROUP BY 1 ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE five
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE five AS SELECT i::double AS i FROM range(1, 6, 1) t1(i)
-- bwc_tag:end_query

SELECT LAST(i) FROM five
-- bwc_tag:end_query

SELECT i % 3 AS g, LAST(i) FROM five GROUP BY 1 ORDER BY 1
-- bwc_tag:end_query

SELECT LAST(i ORDER BY 5-i) FROM five
-- bwc_tag:end_query

SELECT i % 3 AS g, LAST(i ORDER BY 5-i) FROM five GROUP BY 1 ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE five
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE five AS SELECT i::decimal(4,1) AS i FROM range(1, 6, 1) t1(i)
-- bwc_tag:end_query

SELECT LAST(i ORDER BY 5-i) FROM five
-- bwc_tag:end_query

SELECT i::INTEGER % 3 AS g, LAST(i ORDER BY 5-i) FROM five GROUP BY 1 ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE five
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE five AS SELECT i::decimal(8,1) AS i FROM range(1, 6, 1) t1(i)
-- bwc_tag:end_query

SELECT LAST(i ORDER BY 5-i) FROM five
-- bwc_tag:end_query

SELECT i::INTEGER % 3 AS g, LAST(i ORDER BY 5-i) FROM five GROUP BY 1 ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE five
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE five AS SELECT i::decimal(12,1) AS i FROM range(1, 6, 1) t1(i)
-- bwc_tag:end_query

SELECT LAST(i ORDER BY 5-i) FROM five
-- bwc_tag:end_query

SELECT i::INTEGER % 3 AS g, LAST(i ORDER BY 5-i) FROM five GROUP BY 1 ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE five
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE five AS SELECT i::decimal(18,1) AS i FROM range(1, 6, 1) t1(i)
-- bwc_tag:end_query

SELECT LAST(i ORDER BY 5-i) FROM five
-- bwc_tag:end_query

SELECT i::INTEGER % 3 AS g, LAST(i ORDER BY 5-i) FROM five GROUP BY 1 ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE five
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE five_dates AS
	SELECT
		i::integer AS i,
		'2021-08-20'::DATE + i::INTEGER AS d,
		'2021-08-20'::TIMESTAMP + INTERVAL (i) HOUR AS dt,
		'14:59:37'::TIME + INTERVAL (i) MINUTE AS t,
		INTERVAL (i) SECOND AS s
	FROM range(1, 6, 1) t1(i)
-- bwc_tag:end_query

SELECT LAST(d), LAST(dt), LAST(t), LAST(s) FROM five_dates
-- bwc_tag:end_query

SELECT i % 3 AS g, LAST(d), LAST(dt), LAST(t), LAST(s)
FROM five_dates
GROUP BY 1
ORDER BY 1
-- bwc_tag:end_query

SELECT LAST(d ORDER BY 5-i), LAST(dt ORDER BY 5-i), LAST(t ORDER BY 5-i), LAST(s ORDER BY 5-i) FROM five_dates
-- bwc_tag:end_query

SELECT i % 3 AS g, LAST(d ORDER BY 5-i), LAST(dt ORDER BY 5-i), LAST(t ORDER BY 5-i), LAST(s ORDER BY 5-i)
FROM five_dates
GROUP BY 1
ORDER BY 1
-- bwc_tag:end_query

SELECT LAST(dt::TIMESTAMPTZ), LAST(t::TIMETZ) FROM five_dates
-- bwc_tag:end_query

SELECT i % 3 AS g, LAST(dt::TIMESTAMPTZ), LAST(t::TIMETZ)
FROM five_dates
GROUP BY 1
ORDER BY 1
-- bwc_tag:end_query

SELECT LAST(dt::TIMESTAMPTZ ORDER BY 5-i), LAST(t::TIMETZ ORDER BY 5-i) FROM five_dates
-- bwc_tag:end_query

SELECT i % 3 AS g, LAST(dt::TIMESTAMPTZ ORDER BY 5-i), LAST(t::TIMETZ ORDER BY 5-i)
FROM five_dates
GROUP BY 1
ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE five_dates
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE five_complex AS
	SELECT
		i::integer AS i,
		i::VARCHAR AS s,
		[i] AS l,
		{'a': i} AS r
	FROM range(1, 6, 1) t1(i)
-- bwc_tag:end_query

SELECT LAST(s), LAST(l), LAST(r)
FROM five_complex
-- bwc_tag:end_query

SELECT i % 3 AS g, LAST(s), LAST(l), LAST(r)
FROM five_complex
GROUP BY 1
ORDER BY 1
-- bwc_tag:end_query

SELECT LAST(s ORDER BY 5-i), LAST(l ORDER BY 5-i), LAST(r ORDER BY 5-i)
FROM five_complex
-- bwc_tag:end_query

SELECT i % 3 AS g, LAST(s ORDER BY 5-i), LAST(l ORDER BY 5-i), LAST(r ORDER BY 5-i)
FROM five_complex
GROUP BY 1
ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE five_complex
-- bwc_tag:end_query

