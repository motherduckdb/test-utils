-- bwc_tag:nb_steps=7
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

ATTACH 'output/attach_row_group_size.db' AS db1 (STORAGE_VERSION 'v1.0.0', ROW_GROUP_SIZE 245760);
-- bwc_tag:end_query

ATTACH 'output/attach_row_group_size.db' AS db1 (STORAGE_VERSION 'v1.0.0');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE db1.tbl AS FROM range(10000) t(i)
-- bwc_tag:end_query

DETACH db1
-- bwc_tag:end_query

ATTACH 'output/attach_row_group_size.db' AS db1 (STORAGE_VERSION 'v1.2.0', ROW_GROUP_SIZE 245760);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO db1.tbl FROM range(10000)
-- bwc_tag:end_query

