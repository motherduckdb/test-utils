-- bwc_tag:nb_steps=20
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

ATTACH DATABASE 'output/view_search_path.db' AS view_search_path;
-- bwc_tag:end_query

USE view_search_path
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE my_tbl(i INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO my_tbl VALUES (42)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW my_view AS FROM my_tbl
-- bwc_tag:end_query

FROM my_view
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA my_schema
-- bwc_tag:end_query

USE my_schema
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE my_tbl(i INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO my_tbl VALUES (84)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW my_view AS FROM my_tbl
-- bwc_tag:end_query

FROM my_view
-- bwc_tag:end_query

USE memory
-- bwc_tag:end_query

FROM view_search_path.my_view
-- bwc_tag:end_query

FROM view_search_path.my_schema.my_view
-- bwc_tag:end_query

DETACH view_search_path
-- bwc_tag:end_query

ATTACH DATABASE 'output/view_search_path.db' AS view_search_path;
-- bwc_tag:end_query

FROM view_search_path.my_view
-- bwc_tag:end_query

FROM view_search_path.my_schema.my_view
-- bwc_tag:end_query

