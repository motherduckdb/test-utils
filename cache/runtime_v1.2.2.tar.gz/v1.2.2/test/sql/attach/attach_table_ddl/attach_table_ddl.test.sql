-- bwc_tag:nb_steps=45
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

ATTACH DATABASE ':memory:' AS new_database;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA new_database.s1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE new_database.s1.integers(i INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO new_database.s1.integers VALUES (42);
-- bwc_tag:end_query

SELECT * FROM new_database.s1.integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
UPDATE new_database.s1.integers SET i=i+1
-- bwc_tag:end_query

SELECT * FROM new_database.s1.integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DELETE FROM new_database.s1.integers WHERE i=43
-- bwc_tag:end_query

SELECT COUNT(*) FROM new_database.s1.integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE new_database.s1.integers ADD COLUMN j VARCHAR
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO new_database.s1.integers VALUES (1, 'T100');
-- bwc_tag:end_query

SELECT * FROM new_database.s1.integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE new_database.s1.integers ALTER j TYPE INT USING REPLACE(j, 'T', '')::INT
-- bwc_tag:end_query

SELECT * FROM new_database.s1.integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE new_database.s1.integers DROP COLUMN j
-- bwc_tag:end_query

SELECT * FROM new_database.s1.integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE new_database.s1.integers RENAME COLUMN i TO k
-- bwc_tag:end_query

SELECT k FROM new_database.s1.integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE new_database.s1.integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE new_database.s1.t1(i INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE new_database.s1.t1 RENAME TO t2
-- bwc_tag:end_query

SELECT * FROM new_database.s1.t2
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE new_database.s1.t2
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE new_database.integers(i INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO new_database.integers VALUES (42);
-- bwc_tag:end_query

SELECT * FROM new_database.integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
UPDATE new_database.integers SET i=i+1
-- bwc_tag:end_query

SELECT * FROM new_database.integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DELETE FROM new_database.integers WHERE i=43
-- bwc_tag:end_query

SELECT COUNT(*) FROM new_database.integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE new_database.integers ADD COLUMN j VARCHAR
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO new_database.integers VALUES (1, 'T100');
-- bwc_tag:end_query

SELECT * FROM new_database.integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE new_database.integers ALTER j TYPE INT USING REPLACE(j, 'T', '')::INT
-- bwc_tag:end_query

SELECT * FROM new_database.integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE new_database.integers DROP COLUMN j
-- bwc_tag:end_query

SELECT * FROM new_database.integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE new_database.integers RENAME COLUMN i TO k
-- bwc_tag:end_query

SELECT k FROM new_database.integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE new_database.integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE new_database.t1(i INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE new_database.t1 RENAME TO t2
-- bwc_tag:end_query

SELECT * FROM new_database.t2
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE new_database.t2
-- bwc_tag:end_query

