-- bwc_tag:nb_steps=15
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table a(i integer);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into a values (42), (44);
-- bwc_tag:end_query

SELECT rowid, * FROM a
-- bwc_tag:end_query

SELECT rowid+1 FROM a WHERE CASE WHEN i=42 THEN rowid=0 ELSE rowid=1 END;
-- bwc_tag:end_query

SELECT * FROM a
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

UPDATE a SET rowid=5
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO a (rowid, i)  VALUES (5, 6)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table b(rowid integer);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into b values (42), (22);
-- bwc_tag:end_query

SELECT * FROM b ORDER BY 1
-- bwc_tag:end_query

SELECT rowid FROM b ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
UPDATE b SET rowid=5
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO b (rowid) VALUES (5)
-- bwc_tag:end_query

SELECT * FROM b
-- bwc_tag:end_query

