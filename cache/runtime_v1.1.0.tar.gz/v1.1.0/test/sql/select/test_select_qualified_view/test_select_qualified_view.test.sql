-- bwc_tag:nb_steps=6
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA s;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table s.a as select 'hello' as col1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create view s.b as select * from s.a;
-- bwc_tag:end_query

select s.b.col1 from s.b;
-- bwc_tag:end_query

select b.col1 from s.b;
-- bwc_tag:end_query

