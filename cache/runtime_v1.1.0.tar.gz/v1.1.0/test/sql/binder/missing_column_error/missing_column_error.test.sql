-- bwc_tag:nb_steps=4
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table customers (name varchar, age integer, something_easy_to_type_wrong integer, city varchar);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table zipcodes (city varchar, zipcode varchar);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

with cte as (
  select *,
	  rank() over (order by something_easy_to_typo_wrong) as rk
  from customers
  where age <= 42
)
select *
from zipcodes
join cte
using (city);
-- bwc_tag:end_query

