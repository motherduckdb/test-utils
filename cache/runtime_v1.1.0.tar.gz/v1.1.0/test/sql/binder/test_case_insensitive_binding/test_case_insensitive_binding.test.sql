-- bwc_tag:nb_steps=39
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test ("HeLlO" INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (1)
-- bwc_tag:end_query

SELECT HeLlO FROM test
-- bwc_tag:end_query

SELECT hello FROM test
-- bwc_tag:end_query

SELECT "HeLlO" FROM test
-- bwc_tag:end_query

SELECT "HELLO" FROM test
-- bwc_tag:end_query

SELECT "HELLo" FROM test
-- bwc_tag:end_query

SELECT alias(HeLlO) FROM test
-- bwc_tag:end_query

SELECT alias(hello) FROM test
-- bwc_tag:end_query

SELECT alias(x) FROM (SELECT HeLlO as x FROM test) tbl;
-- bwc_tag:end_query

SELECT test.HeLlO FROM test
-- bwc_tag:end_query

SELECT test.hello FROM test
-- bwc_tag:end_query

SELECT test."HeLlO" FROM test
-- bwc_tag:end_query

SELECT test."HELLO" FROM test
-- bwc_tag:end_query

SELECT test."HELLo" FROM test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
UPDATE test SET hello=3
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
UPDATE test SET HeLlO=3
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE TABLE test("HeLlO" INTEGER, "HELLO" INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test1("HeLlO" INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test2("HELLO" INTEGER)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT HeLlO FROM test1, test2
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT hello FROM test1, test2
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT "HeLlO" FROM test1, test2
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT "HELLO" FROM test1, test2
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT "HELLo" FROM test1, test2
-- bwc_tag:end_query

SELECT test1.HeLlO FROM test1, test2
-- bwc_tag:end_query

SELECT test1.hello FROM test1, test2
-- bwc_tag:end_query

SELECT test1."HeLlO" FROM test1, test2
-- bwc_tag:end_query

SELECT test1."HELLO" FROM test1, test2
-- bwc_tag:end_query

SELECT test1."HELLo" FROM test1, test2
-- bwc_tag:end_query

SELECT test2.HeLlO FROM test1, test2
-- bwc_tag:end_query

SELECT test2.hello FROM test1, test2
-- bwc_tag:end_query

SELECT test2."HeLlO" FROM test1, test2
-- bwc_tag:end_query

SELECT test2."HELLO" FROM test1, test2
-- bwc_tag:end_query

SELECT test2."HELLo" FROM test1, test2
-- bwc_tag:end_query

SELECT * FROM test1 JOIN test2 USING (hello)
-- bwc_tag:end_query

SELECT hello FROM (SELECT 42) tbl("HeLlO")
-- bwc_tag:end_query

