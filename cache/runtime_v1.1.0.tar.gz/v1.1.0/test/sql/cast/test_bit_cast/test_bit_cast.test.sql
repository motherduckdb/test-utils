-- bwc_tag:nb_steps=78
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE bits (b bit);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO bits VALUES('00001111');
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT bitstring('1', 9)::BOOL;
-- bwc_tag:end_query

SELECT b::BOOLEAN FROM bits;
-- bwc_tag:end_query

SELECT '1'::BIT::BOOL;
-- bwc_tag:end_query

SELECT '0'::BIT::BOOL;
-- bwc_tag:end_query

SELECT b::TINYINT FROM bits;
-- bwc_tag:end_query

SELECT b::SMALLINT FROM bits;
-- bwc_tag:end_query

SELECT b::INTEGER FROM bits;
-- bwc_tag:end_query

SELECT b::BIGINT FROM bits;
-- bwc_tag:end_query

SELECT b::UTINYINT FROM bits;
-- bwc_tag:end_query

SELECT b::USMALLINT FROM bits;
-- bwc_tag:end_query

SELECT b::UINTEGER FROM bits;
-- bwc_tag:end_query

SELECT b::UBIGINT FROM bits;
-- bwc_tag:end_query

SELECT b::HUGEINT FROM bits;
-- bwc_tag:end_query

SELECT b::UHUGEINT FROM bits;
-- bwc_tag:end_query

SELECT b::FLOAT FROM bits;
-- bwc_tag:end_query

SELECT b::DOUBLE FROM bits;
-- bwc_tag:end_query

SELECT '100001111000011110000111100001111'::BIT::BIGINT;
-- bwc_tag:end_query

SELECT 15::BOOLEAN::BIT;
-- bwc_tag:end_query

SELECT 15::TINYINT::BIT;
-- bwc_tag:end_query

SELECT 15::SMALLINT::BIT;
-- bwc_tag:end_query

SELECT 15::BIT;
-- bwc_tag:end_query

SELECT 15::BIGINT::BIT;
-- bwc_tag:end_query

SELECT 15::HUGEINT::BIT;
-- bwc_tag:end_query

SELECT 15::UHUGEINT::BIT;
-- bwc_tag:end_query

SELECT 2.1e-44::FLOAT::BIT;
-- bwc_tag:end_query

SELECT 7.4e-323::BIT;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT bitstring('1', 9)::TINYINT;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT bitstring('1', 17)::SMALLINT;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT bitstring('1', 33)::INT;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT bitstring('1', 65)::BIGINT;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT bitstring('1', 33)::FLOAT;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT bitstring('1', 65)::DOUBLE;
-- bwc_tag:end_query

SELECT b::BLOB FROM bits;
-- bwc_tag:end_query

SELECT bitstring('1111', 32)::BLOB;
-- bwc_tag:end_query

SELECT '1111'::BIT::BLOB;
-- bwc_tag:end_query

SELECT bitstring('1111', 33)::BLOB;
-- bwc_tag:end_query

SELECT 'AAAA'::BLOB::BIT;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT ''::BLOB::BIT;
-- bwc_tag:end_query

SELECT (-15)::TINYINT::BIT;
-- bwc_tag:end_query

SELECT (-15)::HUGEINT::BIT;
-- bwc_tag:end_query

SELECT (127)::TINYINT::BIT;
-- bwc_tag:end_query

SELECT (-128)::TINYINT::BIT;
-- bwc_tag:end_query

SELECT (32767)::SMALLINT::BIT;
-- bwc_tag:end_query

SELECT (-32768)::SMALLINT::BIT;
-- bwc_tag:end_query

SELECT (2147483647)::INT::BIT;
-- bwc_tag:end_query

SELECT (-2147483648)::INT::BIT;
-- bwc_tag:end_query

SELECT (9223372036854775807)::BIGINT::BIT;
-- bwc_tag:end_query

SELECT (-9223372036854775808)::BIGINT::BIT;
-- bwc_tag:end_query

SELECT (170141183460469231731687303715884105727)::HUGEINT::BIT;
-- bwc_tag:end_query

SELECT (-170141183460469231731687303715884105728)::HUGEINT::BIT;
-- bwc_tag:end_query

SELECT '01111111'::BIT::TINYINT;
-- bwc_tag:end_query

SELECT '10000000'::BIT::TINYINT;
-- bwc_tag:end_query

SELECT '0111111111111111'::BIT::SMALLINT;
-- bwc_tag:end_query

SELECT '1000000000000000'::BIT::SMALLINT;
-- bwc_tag:end_query

SELECT '01111111111111111111111111111111'::BIT::INT;
-- bwc_tag:end_query

SELECT '10000000000000000000000000000000'::BIT::INT;
-- bwc_tag:end_query

SELECT '0111111111111111111111111111111111111111111111111111111111111111'::BIT::BIGINT;
-- bwc_tag:end_query

SELECT '1000000000000000000000000000000000000000000000000000000000000000'::BIT::BIGINT;
-- bwc_tag:end_query

SELECT '01111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111'::BIT::HUGEINT;
-- bwc_tag:end_query

SELECT '10000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000'::BIT::HUGEINT;
-- bwc_tag:end_query

SELECT (255)::UTINYINT::BIT;
-- bwc_tag:end_query

SELECT (65535)::USMALLINT::BIT;
-- bwc_tag:end_query

SELECT (4294967295)::UINTEGER::BIT;
-- bwc_tag:end_query

SELECT (18446744073709551615)::UBIGINT::BIT;
-- bwc_tag:end_query

SELECT '340282366920938463463374607431768211455'::UHUGEINT::BIT;
-- bwc_tag:end_query

SELECT '11111111'::BIT::UTINYINT;
-- bwc_tag:end_query

SELECT '1111111111111111'::BIT::USMALLINT;
-- bwc_tag:end_query

SELECT '11111111111111111111111111111111'::BIT::UINTEGER;
-- bwc_tag:end_query

SELECT '1111111111111111111111111111111111111111111111111111111111111111'::BIT::UBIGINT;
-- bwc_tag:end_query

SELECT (3.4028235e+38)::FLOAT::BIT;
-- bwc_tag:end_query

SELECT (1.7976931348623157e+308)::DOUBLE::BIT;
-- bwc_tag:end_query

SELECT '01111111011111111111111111111111'::BIT::FLOAT;
-- bwc_tag:end_query

SELECT '0111111111101111111111111111111111111111111111111111111111111111'::BIT::DOUBLE;
-- bwc_tag:end_query

SELECT NULL::BIT;
-- bwc_tag:end_query

SELECT NULL::BIT::INT;
-- bwc_tag:end_query

