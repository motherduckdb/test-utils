-- bwc_tag:nb_steps=65
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

select '0.000005'::tinyint;
-- bwc_tag:end_query

select '1.100004'::tinyint;
-- bwc_tag:end_query

select '0.5'::tinyint;
-- bwc_tag:end_query

select '1.50004'::tinyint;
-- bwc_tag:end_query

select '0.000005'::smallint;
-- bwc_tag:end_query

select '1.100004'::smallint;
-- bwc_tag:end_query

select '0.5'::smallint;
-- bwc_tag:end_query

select '1.50004'::smallint;
-- bwc_tag:end_query

select '0.000005'::integer;
-- bwc_tag:end_query

select '1.100004'::integer;
-- bwc_tag:end_query

select '0.5'::integer;
-- bwc_tag:end_query

select '1.50004'::integer;
-- bwc_tag:end_query

select '0.000005'::bigint;
-- bwc_tag:end_query

select '1.100004'::bigint;
-- bwc_tag:end_query

select '0.5'::bigint;
-- bwc_tag:end_query

select '1.50004'::bigint;
-- bwc_tag:end_query

select '0.000005'::hugeint;
-- bwc_tag:end_query

select '1.100004'::hugeint;
-- bwc_tag:end_query

select '0.5'::hugeint;
-- bwc_tag:end_query

select '1.50004'::hugeint;
-- bwc_tag:end_query

select '-0.000005'::tinyint;
-- bwc_tag:end_query

select '-1.100004'::tinyint;
-- bwc_tag:end_query

select '-0.5'::tinyint;
-- bwc_tag:end_query

select '-1.50004'::tinyint;
-- bwc_tag:end_query

select '-0.000005'::smallint;
-- bwc_tag:end_query

select '-1.100004'::smallint;
-- bwc_tag:end_query

select '-0.5'::smallint;
-- bwc_tag:end_query

select '-1.50004'::smallint;
-- bwc_tag:end_query

select '-0.000005'::integer;
-- bwc_tag:end_query

select '-1.100004'::integer;
-- bwc_tag:end_query

select '-0.5'::integer;
-- bwc_tag:end_query

select '-1.50004'::integer;
-- bwc_tag:end_query

select '-0.000005'::bigint;
-- bwc_tag:end_query

select '-1.100004'::bigint;
-- bwc_tag:end_query

select '-0.5'::bigint;
-- bwc_tag:end_query

select '-1.50004'::bigint;
-- bwc_tag:end_query

select '-0.000005'::hugeint;
-- bwc_tag:end_query

select '-1.100004'::hugeint;
-- bwc_tag:end_query

select '-0.5'::hugeint;
-- bwc_tag:end_query

select '-1.50004'::hugeint;
-- bwc_tag:end_query

select '127.1'::TINYINT, '-128.1'::TINYINT;
-- bwc_tag:end_query

select '32767.1'::SMALLINT, '-32768.1'::SMALLINT;
-- bwc_tag:end_query

select '2147483647.1'::INTEGER, '-2147483648.1'::INTEGER;
-- bwc_tag:end_query

select '9223372036854775807.1'::BIGINT, '-9223372036854775808.1'::BIGINT;
-- bwc_tag:end_query

select '170141183460469231731687303715884105727.1'::HUGEINT, '-170141183460469231731687303715884105728.1'::HUGEINT;
-- bwc_tag:end_query

select '255.1'::UTINYINT;
-- bwc_tag:end_query

select '65535.1'::USMALLINT;
-- bwc_tag:end_query

select '4294967295.1'::UINTEGER;
-- bwc_tag:end_query

select '18446744073709551615.1'::UBIGINT;
-- bwc_tag:end_query

select '340282366920938463463374607431768211455.1'::UHUGEINT;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select '127.5'::TINYINT;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select '32767.5'::SMALLINT;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select '2147483647.5'::INTEGER;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select '9223372036854775807.5'::BIGINT;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select '170141183460469231731687303715884105727.5'::HUGEINT;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select '-128.5'::TINYINT;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select '-32768.5'::SMALLINT;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select '-2147483648.5'::INTEGER;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select '-9223372036854775808.5'::BIGINT;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select '-170141183460469231731687303715884105728.5'::HUGEINT;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select '255.5'::UTINYINT;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select '65535.5'::USMALLINT;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select '4294967295.5'::UINTEGER;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select '18446744073709551615.5'::UBIGINT;
-- bwc_tag:end_query

