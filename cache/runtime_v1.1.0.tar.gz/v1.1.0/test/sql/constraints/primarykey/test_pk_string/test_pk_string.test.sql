-- bwc_tag:nb_steps=9
-- bwc_tag:execute_from_sql
CREATE TABLE numbers(i varchar PRIMARY KEY, j INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO numbers VALUES ('1', 4), ('1', 5)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO numbers VALUES ('1', 4), ('2', 5)
-- bwc_tag:end_query

SELECT * FROM numbers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO numbers VALUES ('6', 6), ('1', 4);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO numbers VALUES ('6', 6);
-- bwc_tag:end_query

SELECT * FROM numbers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO numbers VALUES (NULL, 4);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

UPDATE numbers SET i=NULL;
-- bwc_tag:end_query

