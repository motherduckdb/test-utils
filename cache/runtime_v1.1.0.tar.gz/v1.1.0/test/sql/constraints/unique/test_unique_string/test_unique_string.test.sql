-- bwc_tag:nb_steps=22
CREATE TEMPORARY TABLE integers(i INTEGER, j VARCHAR)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE UNIQUE INDEX "uidx" ON "integers" ("j")
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (3, '4'), (2, '5')
-- bwc_tag:end_query

SELECT * FROM integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO integers VALUES (6, '6'), (3, '4');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (6,NULL), (7,NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

UPDATE integers SET j='77' WHERE j IS NULL
-- bwc_tag:end_query

SELECT * FROM integers ORDER BY i, j
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
UPDATE integers SET j='7777777777777777777777777777' WHERE j IS NULL AND i=6
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (6,NULL), (7,NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (6,NULL), (7,NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (6,NULL), (7,NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (6,NULL), (7,NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (6,NULL), (7,NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (6,NULL), (7,NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (6,NULL), (7,NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (6,NULL), (7,NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (6,NULL), (7,NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (6,NULL), (7,NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO integers VALUES  (3, '4')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO integers VALUES  (3, '4')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE integers
-- bwc_tag:end_query

