-- bwc_tag:nb_steps=6
-- bwc_tag:skip_query
BEGIN TRANSACTION
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TYPE "group" AS ENUM ( 'one', 'two');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE table1(col1 "group");
-- bwc_tag:end_query

EXPORT DATABASE 'output/export_enum' (FORMAT CSV);
-- bwc_tag:end_query

-- bwc_tag:skip_query
ROLLBACK
-- bwc_tag:end_query

IMPORT DATABASE 'output/export_enum'
-- bwc_tag:end_query

