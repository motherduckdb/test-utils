-- bwc_tag:nb_steps=6
-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE TABLE collate_test(s VARCHAR COLLATE blabla)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE TABLE collate_test(s INTEGER COLLATE blabla)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE TABLE collate_test(s VARCHAR COLLATE NOACCENT.NOACCENT)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE TABLE collate_test(s VARCHAR COLLATE 1)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE TABLE collate_test(s VARCHAR COLLATE 'hello')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

PRAGMA default_collation='blabla'
-- bwc_tag:end_query

