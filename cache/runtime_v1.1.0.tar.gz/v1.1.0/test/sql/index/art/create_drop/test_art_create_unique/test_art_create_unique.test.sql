-- bwc_tag:nb_steps=11
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t0(c0 INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE UNIQUE INDEX i0 ON t0(c0);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t0(c0) VALUES (1);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO t0(c0) VALUES (1);
-- bwc_tag:end_query

SELECT * FROM t0 WHERE t0.c0 = 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE merge_violation (id INT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO merge_violation SELECT range FROM range(2048);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO merge_violation SELECT range + 10000 FROM range(2048);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO merge_violation VALUES (2047);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE UNIQUE INDEX idx ON merge_violation(id);
-- bwc_tag:end_query

