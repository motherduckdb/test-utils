-- bwc_tag:nb_steps=2
-- bwc_tag:execute_from_sql
CREATE TABlE t1 (foo INT)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE INDEX i3 ON t1 USING random_index_method (foo) WITH (my_option = 2, is_cool);
-- bwc_tag:end_query

