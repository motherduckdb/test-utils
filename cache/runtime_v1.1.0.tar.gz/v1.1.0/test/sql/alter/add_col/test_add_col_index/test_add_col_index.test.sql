-- bwc_tag:nb_steps=9
-- bwc_tag:execute_from_sql
CREATE TABLE test(i INTEGER, j INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (1, 1), (2, 2)
-- bwc_tag:end_query

-- bwc_tag:skip_query
BEGIN TRANSACTION
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test ADD COLUMN k INTEGER DEFAULT 2
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE INDEX i_index ON test(k)
-- bwc_tag:end_query

-- bwc_tag:skip_query
COMMIT
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (3, 3, 3)
-- bwc_tag:end_query

SELECT * FROM test WHERE k=2
-- bwc_tag:end_query

SELECT * FROM test WHERE k=3
-- bwc_tag:end_query

