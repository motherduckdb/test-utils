-- bwc_tag:nb_steps=11
-- bwc_tag:execute_from_sql
CREATE TABLE tbl(i INTEGER PRIMARY KEY, j INTEGER CHECK(j < 10))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO tbl VALUES (999, 4), (1000, 5)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO tbl VALUES (999, 4), (1000, 5)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO tbl VALUES (9999, 0), (10000, 1)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO tbl VALUES (777, 10), (888, 10)
-- bwc_tag:end_query

SELECT * FROM tbl
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE tbl RENAME TO new_tbl
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO new_tbl VALUES (999, 0), (1000, 1)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO new_tbl VALUES (9999, 0), (10000, 1)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO new_tbl VALUES (1, 10), (2, 999)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO new_tbl VALUES (66, 6), (55, 5)
-- bwc_tag:end_query

