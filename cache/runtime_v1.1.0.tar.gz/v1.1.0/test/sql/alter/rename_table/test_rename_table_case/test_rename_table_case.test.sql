-- bwc_tag:nb_steps=5
-- bwc_tag:execute_from_sql
create table MY_TABLE (i integer);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into MY_TABLE values(42);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
alter table MY_TABLE rename to my_table;
-- bwc_tag:end_query

select * from my_table;
-- bwc_tag:end_query

select * from MY_TABLE;
-- bwc_tag:end_query

