-- bwc_tag:nb_steps=5
-- bwc_tag:execute_from_sql
create table t(i int, j as (2), k int, m as (3), n int);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
alter table t drop column n;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
alter table t drop column m;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
alter table t drop column k;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
alter table t drop column j;
-- bwc_tag:end_query

