-- bwc_tag:nb_steps=18
-- bwc_tag:execute_from_sql
CREATE TABLE test(i INTEGER, j INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (1, 1), (2, 2)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test ALTER j SET DEFAULT 3
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test (i) VALUES (3)
-- bwc_tag:end_query

SELECT * FROM test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test ALTER COLUMN j DROP DEFAULT
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test (i) VALUES (4)
-- bwc_tag:end_query

SELECT * FROM test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE seq
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test ALTER j SET DEFAULT nextval('seq')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test (i) VALUES (5), (6)
-- bwc_tag:end_query

SELECT * FROM test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE constrainty(i INTEGER PRIMARY KEY, j INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE constrainty ALTER j SET DEFAULT 3
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO constrainty (i) VALUES (2)
-- bwc_tag:end_query

SELECT * FROM constrainty
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE test ALTER blabla SET DEFAULT 3
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE test ALTER blabla DROP DEFAULT
-- bwc_tag:end_query

