-- bwc_tag:nb_steps=4
SET autoload_known_extensions=false;
-- bwc_tag:end_query

SELECT * FROM duckdb_extensions();
-- bwc_tag:end_query

SELECT aliases FROM duckdb_extensions() WHERE extension_name='postgres_scanner';
-- bwc_tag:end_query

SELECT extension_name FROM duckdb_extensions() WHERE loaded AND extension_name='tpch';
-- bwc_tag:end_query

