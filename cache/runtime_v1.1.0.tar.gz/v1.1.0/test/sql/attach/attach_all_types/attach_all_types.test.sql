-- bwc_tag:nb_steps=7
ATTACH 'output/attach_all_types.db' AS db1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE db1.all_types AS SELECT * FROM test_all_types();
-- bwc_tag:end_query

SELECT * FROM test_all_types()
-- bwc_tag:end_query

SELECT * FROM db1.all_types
-- bwc_tag:end_query

DETACH db1
-- bwc_tag:end_query

ATTACH 'output/attach_all_types.db' AS db1
-- bwc_tag:end_query

SELECT * FROM db1.all_types
-- bwc_tag:end_query

