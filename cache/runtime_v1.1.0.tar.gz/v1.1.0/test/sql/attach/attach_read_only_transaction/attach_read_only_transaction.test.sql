-- bwc_tag:nb_steps=8
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

ATTACH ':memory:' AS db1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE db1.integers(i INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO db1.integers VALUES (42);
-- bwc_tag:end_query

-- bwc_tag:skip_query
BEGIN TRANSACTION READ ONLY
-- bwc_tag:end_query

FROM db1.integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO db1.integers VALUES (48)
-- bwc_tag:end_query

-- bwc_tag:skip_query
COMMIT
-- bwc_tag:end_query

