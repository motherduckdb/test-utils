-- bwc_tag:nb_steps=5
attach ':memory:' as test;
-- bwc_tag:end_query

use test;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

detach test;
-- bwc_tag:end_query

use memory
-- bwc_tag:end_query

detach test
-- bwc_tag:end_query

