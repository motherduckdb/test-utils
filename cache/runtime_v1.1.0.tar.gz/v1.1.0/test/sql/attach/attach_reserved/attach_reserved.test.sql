-- bwc_tag:nb_steps=10
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

ATTACH DATABASE 'output/temp.db';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE temp_db.integers(i INTEGER);
-- bwc_tag:end_query

DETACH temp_db;
-- bwc_tag:end_query

ATTACH DATABASE 'output/system.db';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE system_db.integers(i INTEGER);
-- bwc_tag:end_query

DETACH system_db;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

ATTACH DATABASE ':memory:' AS temp;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

ATTACH DATABASE ':memory:' AS main;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

ATTACH DATABASE ':memory:' AS system;
-- bwc_tag:end_query

