-- bwc_tag:nb_steps=9
-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (3), (4), (5)
-- bwc_tag:end_query

SELECT * FROM integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers SELECT i+3 FROM integers;
-- bwc_tag:end_query

SELECT * FROM integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers2 AS SELECT i, i+2 AS j FROM integers;
-- bwc_tag:end_query

SELECT * FROM integers2 ORDER BY i
-- bwc_tag:end_query

SELECT i FROM integers2 ORDER BY i
-- bwc_tag:end_query

SELECT j FROM integers2 ORDER BY i
-- bwc_tag:end_query

