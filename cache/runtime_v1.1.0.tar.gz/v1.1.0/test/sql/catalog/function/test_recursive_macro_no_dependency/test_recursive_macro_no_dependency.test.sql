-- bwc_tag:nb_steps=13
-- bwc_tag:execute_from_sql
CREATE MACRO "sum"(x) AS (CASE WHEN sum(x) IS NULL THEN 0 ELSE sum(x) END);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT sum(1);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT sum(1) WHERE 42=0
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP MACRO sum
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO "sum"(x) AS (CASE WHEN system.main.sum(x) IS NULL THEN 0 ELSE system.main.sum(x) END);
-- bwc_tag:end_query

SELECT sum(1);
-- bwc_tag:end_query

SELECT sum(1) WHERE 42=0
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create macro m1(a) as a+1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create macro m2(a) as m1(a)+1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create or replace macro m1(a) as m2(a)+1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create macro m3(a) as a+1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create macro m4(a) as table select m3(a);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create or replace macro m3(a) as (from m4(42));
-- bwc_tag:end_query

