-- bwc_tag:nb_steps=8
-- bwc_tag:skip_query
pragma enable_verification;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table tbl(a varchar primary key);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table tbl2(
	a varchar,
	foreign key (a) references tbl(a)
)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into tbl values('abc');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into tbl2 values ('abc');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
alter table tbl add column b integer default 5;
-- bwc_tag:end_query

select * from tbl;
-- bwc_tag:end_query

select * from tbl2;
-- bwc_tag:end_query

