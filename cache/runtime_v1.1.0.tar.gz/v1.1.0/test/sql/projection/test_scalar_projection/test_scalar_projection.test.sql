-- bwc_tag:nb_steps=12
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

SELECT 42
-- bwc_tag:end_query

SELECT 42 + 1
-- bwc_tag:end_query

SELECT 2 * (42 + 1), 35 - 2
-- bwc_tag:end_query

SELECT 'hello'
-- bwc_tag:end_query

SELECT cast('3' AS INTEGER)
-- bwc_tag:end_query

SELECT cast(3 AS VARCHAR)
-- bwc_tag:end_query

SELECT CASE WHEN 43 > 33 THEN 43 ELSE 33 END;
-- bwc_tag:end_query

SELECT 1 AS a, a * 2
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT FROM (SELECT 42) v1
-- bwc_tag:end_query

SELECT + CASE WHEN NOT + 84 NOT BETWEEN - 78 + 98 * 51 AND - ( ( - 28 ) ) * COUNT ( * ) + + - 65 THEN NULL ELSE 16 // + 34 + + - 98 END // + 70 - ( - - CASE - COALESCE ( + 73, + - 66 * - 89 * - 72 ) WHEN COUNT ( * ) // + 4 * CAST ( - - 18 AS INTEGER ) + + + COUNT ( * ) - - 88 THEN NULL WHEN 92 THEN NULL ELSE COUNT ( * ) END ) AS col0
-- bwc_tag:end_query

