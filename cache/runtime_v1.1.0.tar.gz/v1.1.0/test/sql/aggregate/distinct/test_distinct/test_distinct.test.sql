-- bwc_tag:nb_steps=12
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test (a INTEGER, b INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (11, 22), (13, 22), (11, 21), (11, 22)
-- bwc_tag:end_query

SELECT DISTINCT a, b FROM test ORDER BY a, b
-- bwc_tag:end_query

SELECT DISTINCT test.a, b FROM test ORDER BY a, b
-- bwc_tag:end_query

SELECT DISTINCT a FROM test ORDER BY a
-- bwc_tag:end_query

SELECT DISTINCT b FROM test ORDER BY b
-- bwc_tag:end_query

SELECT DISTINCT a, SUM(B) FROM test GROUP BY a ORDER BY a
-- bwc_tag:end_query

SELECT DISTINCT MAX(b) FROM test GROUP BY a
-- bwc_tag:end_query

SELECT DISTINCT CASE WHEN a > 11 THEN 11 ELSE a END FROM test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE issue3056 AS (SELECT * FROM (VALUES
	(['TGTA']),
	(['CGGT']),
	(['CCTC']),
	(['TCTA']),
	(['AGGG']),
	(NULL))
tbl(genes));
-- bwc_tag:end_query

SELECT DISTINCT genes FROM issue3056;
-- bwc_tag:end_query

