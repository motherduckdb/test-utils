-- bwc_tag:nb_steps=3
-- bwc_tag:skip_query
pragma enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
pragma verify_parallelism
-- bwc_tag:end_query

WITH evs AS (
  SELECT * FROM (VALUES
    ('1','123','7'),
    ('1','456','7')
  ) AS t("id", "type", "value" )
)
SELECT "id"
, COUNT(DISTINCT "value") FILTER (WHERE "type" = '456') AS type_456_count
FROM evs
GROUP BY "id"
-- bwc_tag:end_query

