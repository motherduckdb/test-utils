-- bwc_tag:nb_steps=16
SELECT AVG(3), AVG(NULL)
-- bwc_tag:end_query

SELECT AVG(3::SMALLINT), AVG(NULL::SMALLINT)
-- bwc_tag:end_query

SELECT AVG(3::DOUBLE), AVG(NULL::DOUBLE)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE seq;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT AVG(nextval('seq'))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT AVG(nextval('seq'))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (1), (2), (3)
-- bwc_tag:end_query

SELECT AVG(i), AVG(1), AVG(DISTINCT i), AVG(NULL) FROM integers
-- bwc_tag:end_query

SELECT AVG(i) FROM integers WHERE i > 100
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT AVG()
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT AVG(1, 2, 3)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT AVG(AVG(1))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE vals(i INTEGER, j DOUBLE, k HUGEINT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO vals VALUES (NULL, NULL, NULL)
-- bwc_tag:end_query

SELECT AVG(i), AVG(j), AVG(k) FROM vals;
-- bwc_tag:end_query

