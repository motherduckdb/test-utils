-- bwc_tag:nb_steps=41
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA verify_external
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select argmin()
-- bwc_tag:end_query

select argmin(NULL,NULL)
-- bwc_tag:end_query

select argmin(1,1)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select argmin(*)
-- bwc_tag:end_query

select argmin(i,i) from range (100) tbl(i);
-- bwc_tag:end_query

select argmin(i,i) from range (100) tbl(i) where 1 = 0;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select argmax()
-- bwc_tag:end_query

select argmax(NULL,NULL)
-- bwc_tag:end_query

select argmax(1,1)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select argmax(*)
-- bwc_tag:end_query

select argmax(i,i) from range (100) tbl(i);
-- bwc_tag:end_query

select argmax(i,i) from range (100) tbl(i) where 1 = 0;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table args (a integer, b integer)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into args values (1,1), (2,2), (8,8), (10,10)
-- bwc_tag:end_query

select argmin(a,b), argmax(a,b) from args;
-- bwc_tag:end_query

select argmin(a,b), argmax(a,b) from args group by a%2 ORDER BY argmin(a,b);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE hugeints (z HUGEINT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into hugeints values
	(-168123123123200005565479978461862821890), 
	(-168123123123200005565479978461862821889),
	(-168123123123200005565479978461862821888),
	(-168123123123200005565479978461862821893)
-- bwc_tag:end_query

SELECT min(z) - arg_min(z,z) FROM hugeints;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE blobs (b BYTEA, a BIGINT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO blobs VALUES('\xaa\xff\xaa',5), ('\xAA\xFF\xAA\xAA\xFF\xAA',30), ('\xAA\xFF\xAA\xAA\xFF\xAA\xAA\xFF\xAA',20)
-- bwc_tag:end_query

select argmin(b,a), argmax(b,a)  from blobs ;
-- bwc_tag:end_query

select argmin(a,b), argmax(a,b)  from blobs;
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
select argmin(a,b) over ( partition by a%2) from args;
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
select argmax(a,b) over ( partition by a%2) from args;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table names (name string, salary integer)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into names values ('Pedro',10), ('Hannes',20), ('Mark',15), ('Hubert-Blaine-Wolfeschlegelsteinhausenbergerdorff',30)
-- bwc_tag:end_query

select argmin(name,salary),argmax(name,salary)  from names;
-- bwc_tag:end_query

select argmin(salary,name),argmax(salary,name)  from names;
-- bwc_tag:end_query

select min_by(name,salary),max_by(name,salary)  from names;
-- bwc_tag:end_query

select arg_min(name,salary),arg_max(name,salary)  from names;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE employees(
	employee_id NUMERIC, 
	department_id NUMERIC, 
	salary NUMERIC);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO employees VALUES
  (1001, 10, 10000),
  (1020, 10, 9000),
  (1030, 10, 8000),
  (900, 20, 15000),
  (2000, 20, NULL),
  (2010, 20, 15000),
  (2020, 20, 8000);
-- bwc_tag:end_query

SET old_implicit_casting=true;
-- bwc_tag:end_query

SELECT MAX_BY(employee_id, salary) as employee_with_biggest_salary 
FROM employees;
-- bwc_tag:end_query

SELECT MIN_BY(employee_id, salary) as employee_with_least_salary 
FROM employees;
-- bwc_tag:end_query

SET old_implicit_casting=false;
-- bwc_tag:end_query

SELECT MAX_BY(employee_id, salary) as employee_with_biggest_salary 
FROM employees;
-- bwc_tag:end_query

SELECT MIN_BY(employee_id, salary) as employee_with_least_salary 
FROM employees;
-- bwc_tag:end_query

