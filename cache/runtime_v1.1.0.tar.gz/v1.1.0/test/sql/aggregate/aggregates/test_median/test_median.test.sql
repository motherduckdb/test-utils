-- bwc_tag:nb_steps=21
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA verify_external
-- bwc_tag:end_query

SELECT median(NULL), median(1)
-- bwc_tag:end_query

SELECT median(NULL), median(1) FROM range(2000)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table quantile as select range r, random() from range(10000) union all values (NULL, 0.1), (NULL, 0.5), (NULL, 0.9) order by 2;
-- bwc_tag:end_query

SELECT median(r) FROM quantile
-- bwc_tag:end_query

SELECT median(r) FROM quantile
-- bwc_tag:end_query

SELECT median(r::float) FROM quantile
-- bwc_tag:end_query

SELECT median(r::double) FROM quantile
-- bwc_tag:end_query

SELECT median(r::tinyint) FROM quantile where r < 100
-- bwc_tag:end_query

SELECT median(r::smallint) FROM quantile
-- bwc_tag:end_query

SELECT median(r::integer) FROM quantile
-- bwc_tag:end_query

SELECT median(r::bigint) FROM quantile
-- bwc_tag:end_query

SELECT median(r::hugeint) FROM quantile
-- bwc_tag:end_query

SELECT median(r::decimal(10,2)) FROM quantile
-- bwc_tag:end_query

SELECT median(case when r is null then null else [r] end) FROM quantile
-- bwc_tag:end_query

SELECT median(case when r is null then null else {'i': r} end) FROM quantile
-- bwc_tag:end_query

SELECT median(r::varchar) FROM quantile
-- bwc_tag:end_query

SELECT median(case when r is null then null else concat('thishasalongprefix_', r::varchar) end) FROM quantile
-- bwc_tag:end_query

SELECT median(NULL) FROM quantile
-- bwc_tag:end_query

SELECT median(42) FROM quantile
-- bwc_tag:end_query

