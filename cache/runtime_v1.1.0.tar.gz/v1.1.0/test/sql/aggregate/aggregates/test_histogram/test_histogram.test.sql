-- bwc_tag:nb_steps=29
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA verify_external
-- bwc_tag:end_query

select histogram(NULL)
-- bwc_tag:end_query

SELECT histogram(i) FROM range(100) tbl(i) WHERE 1=0;
-- bwc_tag:end_query

select histogram(1)
-- bwc_tag:end_query

SELECT histogram('、')
-- bwc_tag:end_query

SELECT histogram(2) FROM range(100);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE hist_data (g INTEGER, e INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO hist_data VALUES (1, 1), (1, 2), (2, 3), (2, 4), (2, 5), (3, 6), (5, NULL)
-- bwc_tag:end_query

SELECT histogram(g) from hist_data
-- bwc_tag:end_query

SELECT histogram(e) from hist_data
-- bwc_tag:end_query

select histogram(g)
    from hist_data
    group by g%2==0 ORDER BY g%2==0
-- bwc_tag:end_query

select histogram(g)
    from hist_data
    where g < 3
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table names (name string)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into names values ('pedro'), ('pedro'), ('pedro'),('hannes'),('hannes'),('mark'),(null),('Hubert Blaine Wolfeschlegelsteinhausenbergerdorff Sr.');
-- bwc_tag:end_query

select histogram(name) from names;
-- bwc_tag:end_query

SELECT histogram(CAST('2021-08-20' AS TIMESTAMP_S));
-- bwc_tag:end_query

SELECT histogram(CAST('2021-08-20' AS TIMESTAMP_MS));
-- bwc_tag:end_query

SELECT histogram(CAST('2021-08-20' AS TIMESTAMP_NS));
-- bwc_tag:end_query

SELECT histogram(CAST('15:05:42' AS TIME));
-- bwc_tag:end_query

SELECT histogram(CAST('15:05:42+00' AS TIME WITH TIME ZONE));
-- bwc_tag:end_query

SELECT histogram(CAST('2022-01-02' AS DATE));
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
select g,histogram(g) over (partition by g%2)
    from hist_data;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select histogram()
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select histogram(*)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TYPE mood AS ENUM ('sad', 'ok', 'happy')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE enums (e mood)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO enums VALUES ('happy'), ('ok')
-- bwc_tag:end_query

SELECT histogram(e) FROM enums
-- bwc_tag:end_query

