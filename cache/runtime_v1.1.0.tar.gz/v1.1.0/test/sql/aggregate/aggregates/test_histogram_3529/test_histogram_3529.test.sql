-- bwc_tag:nb_steps=4
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table tmp (c0 integer, c1 integer);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into tmp values
(0,	0),
(1,	1),
(2,	0),
(0,	1),
(1,	0),
(2,	1),
(0,	0),
(1,	1),
(2,	0),
(0,	1);
-- bwc_tag:end_query

SELECT c0, histogram(c1) FROM tmp GROUP BY c0 ORDER BY ALL
-- bwc_tag:end_query

