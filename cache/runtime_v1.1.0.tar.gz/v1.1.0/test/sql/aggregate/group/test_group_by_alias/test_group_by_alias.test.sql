-- bwc_tag:nb_steps=15
SET default_null_order='nulls_first';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (1), (2), (3), (NULL)
-- bwc_tag:end_query

SELECT i % 2 AS k, SUM(i) FROM integers WHERE i IS NOT NULL GROUP BY k HAVING k>0;
-- bwc_tag:end_query

SELECT i % 2 AS k, SUM(i) FROM integers WHERE i IS NOT NULL GROUP BY k HAVING i%2>0;
-- bwc_tag:end_query

SELECT i % 2 AS k, SUM(i) FROM integers WHERE i IS NOT NULL GROUP BY 1 HAVING i%2>0;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT i % 2 AS k, SUM(i) FROM integers WHERE i IS NOT NULL GROUP BY 42 HAVING i%2>0;
-- bwc_tag:end_query

SELECT i, i % 2 AS i, SUM(i) FROM integers GROUP BY i ORDER BY i, 3;
-- bwc_tag:end_query

SELECT i, i % 2 AS k, SUM(i) FROM integers GROUP BY i ORDER BY k, 3;
-- bwc_tag:end_query

SELECT i, i % 2 AS k, SUM(i) FROM integers GROUP BY i ORDER BY i;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT i % 2 AS k, SUM(k) FROM integers GROUP BY k
-- bwc_tag:end_query

SELECT i, SUM(i) FROM integers GROUP BY i ORDER BY i
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT (10-i) AS k, SUM(i) FROM integers GROUP BY k ORDER BY i;
-- bwc_tag:end_query

SELECT (10-i) AS k, SUM(i) FROM integers GROUP BY k ORDER BY FIRST(i);
-- bwc_tag:end_query

