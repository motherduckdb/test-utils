-- bwc_tag:nb_steps=20
SET default_null_order='nulls_first';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA verify_external
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(g integer, i integer);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers values (0, 1), (0, 2), (1, 3), (1, NULL);
-- bwc_tag:end_query

SELECT g, SUM(i) FROM integers GROUP BY ALL ORDER BY 1
-- bwc_tag:end_query

SELECT SUM(i), g FROM integers GROUP BY ALL ORDER BY 2
-- bwc_tag:end_query

SELECT g, SUM(i) FROM integers GROUP BY * ORDER BY 1
-- bwc_tag:end_query

SELECT g, SUM(i) FROM integers GROUP BY 1 ORDER BY ALL
-- bwc_tag:end_query

SELECT g, SUM(i) FROM integers GROUP BY 1 ORDER BY *
-- bwc_tag:end_query

SELECT g, SUM(i), COUNT(*), COUNT(i), SUM(g) FROM integers GROUP BY ALL ORDER BY 1
-- bwc_tag:end_query

SELECT i%2, SUM(i), SUM(g) FROM integers GROUP BY ALL ORDER BY 1
-- bwc_tag:end_query

SELECT i%2, SUM(i), SUM(g) FROM integers GROUP BY 1 ORDER BY 1
-- bwc_tag:end_query

SELECT i%2, SUM(i), SUM(g) FROM integers GROUP BY i ORDER BY 1 NULLS FIRST, 2
-- bwc_tag:end_query

SELECT (g+i)%2, SUM(i), SUM(g) FROM integers GROUP BY ALL ORDER BY 1 NULLS FIRST
-- bwc_tag:end_query

SELECT (g+i)%2, SUM(i), SUM(g) FROM integers GROUP BY 1 ORDER BY 1 NULLS FIRST
-- bwc_tag:end_query

SELECT (g+i)%2, SUM(i), SUM(g) FROM integers GROUP BY g, i ORDER BY 1 NULLS FIRST, 2
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT (g+i)%2 + SUM(i), SUM(i), SUM(g) FROM integers GROUP BY ALL ORDER BY 1
-- bwc_tag:end_query

SELECT g, i, g%2, SUM(i), SUM(g) FROM integers GROUP BY 1, 2, 3 ORDER BY 1, 2, 3, 4
-- bwc_tag:end_query

SELECT g, i, g%2, SUM(i), SUM(g) FROM integers GROUP BY ALL ORDER BY 1, 2 NULLS FIRST, 3, 4
-- bwc_tag:end_query

