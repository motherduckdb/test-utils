-- bwc_tag:nb_steps=36
SET default_null_order='nulls_first';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA verify_external
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test (a INTEGER, b INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (11, 22), (13, 22), (12, 21)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT SUM(SUM(41)), COUNT(*);
-- bwc_tag:end_query

SELECT SUM(a), COUNT(*), AVG(a) FROM test;
-- bwc_tag:end_query

SELECT COUNT(*) FROM test;
-- bwc_tag:end_query

SELECT SUM(a), COUNT(*) FROM test WHERE a = 11;
-- bwc_tag:end_query

SELECT SUM(a), SUM(b), SUM(a) + SUM (b) FROM test;
-- bwc_tag:end_query

SELECT SUM(a+2), SUM(a) + 2 * COUNT(*) FROM test;
-- bwc_tag:end_query

SELECT b, SUM(a), SUM(a+2), AVG(a) FROM test GROUP BY b ORDER BY b;
-- bwc_tag:end_query

SELECT b, SUM(a) FROM test GROUP BY b ORDER BY COUNT(a);
-- bwc_tag:end_query

SELECT b, SUM(a) FROM test GROUP BY b ORDER BY COUNT(a) DESC;
-- bwc_tag:end_query

SELECT b, SUM(a), COUNT(*), SUM(a+2) FROM test GROUP BY b ORDER BY b;
-- bwc_tag:end_query

SELECT b % 2 AS f, SUM(a) FROM test GROUP BY f ORDER BY f;
-- bwc_tag:end_query

SELECT b, SUM(a), COUNT(*), SUM(a+2) FROM test WHERE a <= 12 GROUP BY b ORDER BY b;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT b % 2 AS f, COUNT(SUM(a)) FROM test GROUP BY f;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (12, 21), (12, 21), (12, 21)
-- bwc_tag:end_query

SELECT b, SUM(a), COUNT(*), SUM(a+2) FROM test WHERE a <= 12 GROUP BY b ORDER BY b;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER, j INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (3, 4), (3, 4), (2, 4);
-- bwc_tag:end_query

SELECT i, i + 10 FROM integers GROUP BY i ORDER BY i
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT i, SUM(j), j FROM integers GROUP BY i ORDER BY i
-- bwc_tag:end_query

SELECT i, SUM(j), FIRST(j) FROM integers GROUP BY i ORDER BY i
-- bwc_tag:end_query

SELECT i, SUM(j), LAST(j) FROM integers GROUP BY i ORDER BY i
-- bwc_tag:end_query

SELECT 1 AS k, SUM(i) FROM integers GROUP BY k ORDER BY 2;
-- bwc_tag:end_query

SELECT 1 AS i, SUM(i) FROM integers GROUP BY i ORDER BY 2;
-- bwc_tag:end_query

SELECT i % 2 AS k, SUM(i) FROM integers GROUP BY k, k ORDER BY 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE integers;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (1), (2), (3), (NULL);
-- bwc_tag:end_query

SELECT i, SUM(i) FROM integers GROUP BY i ORDER BY 1;
-- bwc_tag:end_query

SELECT i, i % 2 AS i, SUM(i) FROM integers GROUP BY i ORDER BY 1;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT 1 AS k, SUM(i) FROM integers GROUP BY k+1 ORDER BY 2;
-- bwc_tag:end_query

SELECT test.b, SUM(a) FROM test GROUP BY b ORDER BY COUNT(a) DESC;
-- bwc_tag:end_query

