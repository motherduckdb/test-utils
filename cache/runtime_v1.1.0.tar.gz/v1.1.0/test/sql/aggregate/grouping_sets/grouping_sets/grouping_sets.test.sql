-- bwc_tag:nb_steps=24
SET default_null_order='nulls_first';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table students (course VARCHAR, type VARCHAR);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into students
		(course, type)
	values
		('CS', 'Bachelor'),
		('CS', 'Bachelor'),
		('CS', 'PhD'),
		('Math', 'Masters'),
		('CS', NULL),
		('CS', NULL),
		('Math', NULL);
-- bwc_tag:end_query

select 1 from students group by ();
-- bwc_tag:end_query

select count(*) from students group by ();
-- bwc_tag:end_query

select course, type, count(*) from students group by course, type order by 1, 2, 3;
-- bwc_tag:end_query

select course, type, count(*) from students group by (course, type) order by 1, 2, 3;
-- bwc_tag:end_query

select course, count(*) from students group by (), course, () ORDER BY 1;
-- bwc_tag:end_query

select count(*), course, type
	from students
	group by grouping sets ((course), (type))
	order by 1, 2, 3;
-- bwc_tag:end_query

select count(*), course, type
	from students
	group by grouping sets (course), grouping sets(type)
	order by 1, 2, 3;
-- bwc_tag:end_query

select count(*), course, type
	from students
	group by course, grouping sets(type)
	order by 1, 2, 3;
-- bwc_tag:end_query

select count(*), course, type
	from students
	group by course, grouping sets(type, ())
	order by 1, 2, 3;
-- bwc_tag:end_query

select count(*), course, type
	from students
	group by grouping sets((course, type), (course))
	order by 1, 2, 3;
-- bwc_tag:end_query

select count(*), course, type
	from students
	group by grouping sets (grouping sets(course), grouping sets(type))
	order by 1, 2, 3;
-- bwc_tag:end_query

select count(*), course, type
        from students
        group by grouping sets (grouping sets(course, ()), grouping sets(type))
        order by 1, 2, 3;
-- bwc_tag:end_query

select count(*), course, type
        from students
        group by grouping sets ((course), (), (type))
        order by 1, 2, 3;
-- bwc_tag:end_query

select count(*), course, type
        from students
        group by grouping sets(course, ()), grouping sets(type)
        order by 1, 2, 3;
-- bwc_tag:end_query

select count(*), course, type
        from students
        group by grouping sets(course, ()), type
        order by 1, 2, 3;
-- bwc_tag:end_query

select count(*), course, type
        from students
        group by grouping sets((course, type), (type))
        order by 1, 2, 3;
-- bwc_tag:end_query

select count(*), course, type
        from students
        group by grouping sets((2, 3), (3))
        order by 1, 2, 3;
-- bwc_tag:end_query

select count(*), course AS crs, type AS tp
        from students
        group by grouping sets((crs, tp), (tp))
        order by 1, 2, 3;
-- bwc_tag:end_query

select count(*), course, type
        from students
        group by grouping sets (grouping sets(course, ()), grouping sets(type, ()))
        order by 1, 2, 3;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select course from students group by ();
-- bwc_tag:end_query

