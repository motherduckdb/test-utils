-- bwc_tag:nb_steps=7
copy (select 42 as x) to 'output/foo';
-- bwc_tag:end_query

copy (select 42 as x) to 'output/foo';
-- bwc_tag:end_query

COPY (SELECT 36) TO 'output/.a.b';
-- bwc_tag:end_query

COPY (SELECT 37 as x) TO 'output/.a.b';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('output/.a.b');
-- bwc_tag:end_query

COPY (SELECT 50) TO 'output/.a.b.c.d.e..';
-- bwc_tag:end_query

COPY (SELECT 51) TO 'output/.a.b.c.d.e..';
-- bwc_tag:end_query

