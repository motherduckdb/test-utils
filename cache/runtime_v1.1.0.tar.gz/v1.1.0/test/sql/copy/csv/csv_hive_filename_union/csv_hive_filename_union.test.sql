-- bwc_tag:nb_steps=12
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

select filename.replace('\', '/').split('/')[-2] from read_csv_auto('data/csv/hive-partitioning/simple/*/*/test.csv', HIVE_PARTITIONING=1,  FILENAME=1)  order by 1
-- bwc_tag:end_query

select part, filename.replace('\', '/').split('/')[-2], value from read_csv_auto('data/csv/hive-partitioning/simple/*/*/test.csv', HIVE_PARTITIONING=1,  FILENAME=1)  order by 1
-- bwc_tag:end_query

select part, filename.replace('\', '/').split('/')[-2], value from read_csv_auto('data/csv/hive-partitioning/simple/*/*/test.csv', HIVE_PARTITIONING=1,  FILENAME=1, UNION_BY_NAME=1)  order by 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

select * exclude(filename) from read_csv_auto('data/csv/hive-partitioning/mismatching_types/*/*.csv', HIVE_PARTITIONING=1, FILENAME=1)  order by 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select * from read_csv_auto('data/csv/hive-partitioning/mismatching_types/*/*.csv', HIVE_PARTITIONING=1,  UNION_BY_NAME=1)  order by 1
-- bwc_tag:end_query

select * exclude(filename), filename.replace('\', '/').split('/')[-2] from read_csv_auto('data/csv/hive-partitioning/mismatching_types/*/*.csv', HIVE_PARTITIONING=1, FILENAME=1, UNION_BY_NAME=1)  order by 1
-- bwc_tag:end_query

select part, filename.replace('\', '/').split('/')[-2], a, b from read_csv_auto('data/csv/hive-partitioning/mismatching_types/*/*.csv', HIVE_PARTITIONING=1, FILENAME=1, UNION_BY_NAME=1)  order by 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select * exclude (filename) from read_csv_auto('data/csv/hive-partitioning/mismatching_types/*/*.csv', HIVE_PARTITIONING=0,  FILENAME=1, UNION_BY_NAME=1)  order by 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

select * from read_csv_auto(['data/csv/hive-partitioning/mismatching_contents/part=1/test.csv', 'data/csv/hive-partitioning/mismatching_contents/part=2/test.csv'])  order by 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select a, b, c from read_csv_auto('data/csv/hive-partitioning/mismatching_contents/*/*.csv', UNION_BY_NAME=1)  order by 2 NULLS LAST
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select a, b, part, c from read_csv_auto('data/csv/hive-partitioning/mismatching_contents/*/*.csv',  UNION_BY_NAME=1, HIVE_PARTITIONING=1)  order by 2 NULLS LAST
-- bwc_tag:end_query

