-- bwc_tag:nb_steps=15
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE ubn1(a BIGINT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE ubn2(a INTEGER, b INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE ubn3(a INTEGER, c INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO ubn1 VALUES (1), (2), (9223372036854775807);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO ubn2 VALUES (3,4), (5, 6);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO ubn3 VALUES (100,101), (102, 103);
-- bwc_tag:end_query

COPY ubn1 TO 'output/ubn1.csv' WITH (DELIMITER ',');
-- bwc_tag:end_query

COPY ubn2 TO 'output/ubn2.csv' WITH ( DELIMITER ',');
-- bwc_tag:end_query

COPY ubn3 TO 'output/ubn3.csv' WITH (DELIMITER ',');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT typeof(a), typeof(b), typeof(c)
FROM  read_csv_auto('output/ubn*.csv', UNION_BY_NAME=TRUE, dtypes={'c': TINYINT})
LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT typeof(a), typeof(b), typeof(c)
FROM  read_csv_auto('output/ubn*.csv', UNION_BY_NAME=TRUE, dtypes={'c': TINYINT, 'A': DOUBLE})
LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT typeof(a), typeof(b), typeof(c)
FROM  read_csv_auto('output/ubn*.csv', UNION_BY_NAME=TRUE, dtypes={'xxx': TINYINT})
LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT typeof(a), typeof(b), typeof(c)
FROM  read_csv_auto('output/ubn*.csv', UNION_BY_NAME=TRUE, dtypes={'c': TINYINT, 'A': DOUBLE, 'C': FLOAT})
LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT typeof(a), typeof(b), typeof(c)
FROM  read_csv_auto('output/ubn*.csv', UNION_BY_NAME=TRUE, dtypes={'c': TINYINT, 'A': DOUBLE, 'xZX': FLOAT})
LIMIT 1;
-- bwc_tag:end_query

