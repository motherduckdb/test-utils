-- bwc_tag:nb_steps=2
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select count(*) from read_csv_auto('data/csv/small_file.csv', buffer_size = 7)
-- bwc_tag:end_query

