-- bwc_tag:nb_steps=4
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT count(*) from read_csv_auto('data/csv/header_left_space.csv')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table t as select * from read_csv_auto('data/csv/header_normalize.csv', normalize_names=1)
-- bwc_tag:end_query

describe t
-- bwc_tag:end_query

