-- bwc_tag:nb_steps=11
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

SET autoload_known_extensions=false;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS VALUES ('a', 'foo', 1), ('a', 'foo', 2), ('a', 'bar', 1), ('b', 'bar', 1);
-- bwc_tag:end_query

COPY (FROM test) TO 'output/data.csv.d' (FORMAT 'csv', COMPRESSION 'gzip', PARTITION_BY ('col0', 'col1'));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

FROM read_csv_auto('output/data.csv.d/*/*/*.csv')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv_auto('output/data.csv.d/*/*/*.csv.gz');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv_auto('output/data.csv.d/*/*/*.csv.*');
-- bwc_tag:end_query

COPY (FROM test) TO 'output/data.csv.d2' (FORMAT 'csv', COMPRESSION 'zstd', PARTITION_BY ('col0', 'col1'));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

FROM read_csv_auto('output/data.csv.d2/*/*/*.csv')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv_auto('output/data.csv.d2/*/*/*.csv.zst');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv_auto('output/data.csv.d2/*/*/*.csv.*');
-- bwc_tag:end_query

