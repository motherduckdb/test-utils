-- bwc_tag:nb_steps=6
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table r AS SELECT * FROM read_csv('data/csv/test/date.csv', columns=STRUCT_PACK(d := 'DATE'), header=0, auto_detect=0);
-- bwc_tag:end_query

WITH RECURSIVE t(i) AS
(
	SELECT 1, NULL::DATE
	UNION ALL
	(
		SELECT i+1, d
		FROM t, r
		WHERE i<5
	)
)
SELECT * FROM t ORDER BY i;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
WITH RECURSIVE t(i) AS
(
	SELECT 1, NULL::DATE
	UNION ALL
	(
		SELECT i+1, d
		FROM t, read_csv('data/csv/test/date.csv', columns=STRUCT_PACK(d := 'DATE'), header=0, auto_detect=0)
		WHERE i<5
	)
)
SELECT * FROM t ORDER BY i;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv_auto('data/csv/test/date.csv')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
WITH RECURSIVE t(i) AS
(
	SELECT 1, NULL::DATE
	UNION ALL
	(
		SELECT i+1, d
		FROM t, read_csv('data/csv/test/date.csv', header=0, auto_detect=1) r(d)
		WHERE i<5
	)
)
SELECT * FROM t ORDER BY i;
-- bwc_tag:end_query

