-- bwc_tag:nb_steps=9
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM 'data/csv/bad_date.csv'
-- bwc_tag:end_query

SELECT columns FROM sniff_csv('data/csv/bad_date.csv')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM 'data/csv/bad_date_2.csv'
-- bwc_tag:end_query

SELECT columns[1].type FROM sniff_csv('data/csv/bad_date_2.csv')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM 'data/csv/conflict_timestamp.csv'
-- bwc_tag:end_query

SELECT columns[1].type, columns[2].type FROM sniff_csv('data/csv/conflict_timestamp.csv')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM 'data/csv/bad_date_timestamp_mix.csv'
-- bwc_tag:end_query

SELECT columns FROM sniff_csv('data/csv/bad_date_timestamp_mix.csv')
-- bwc_tag:end_query

