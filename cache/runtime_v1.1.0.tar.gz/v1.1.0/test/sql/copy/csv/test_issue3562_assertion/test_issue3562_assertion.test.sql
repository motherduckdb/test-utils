-- bwc_tag:nb_steps=3
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table test as SELECT * FROM read_csv('data/csv/test/issue3562_assertion.csv.gz',  columns={'OBJECTID': 'DECIMAL(18,3)', 'URL': 'TEXT', 'NAME': 'TEXT', 'the_geom':'TEXT', 'LINE': 'TEXT'});
-- bwc_tag:end_query

select objectid, name from test ORDER BY objectid limit 10
-- bwc_tag:end_query

