-- bwc_tag:nb_steps=6
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select * from 'data/csv/nullbyte.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select * from read_csv('data/csv/nullbyte.csv', columns={'col1': 'VARCHAR', 'col2': 'VARCHAR', 'col3': 'VARCHAR'}, delim='|');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select * from 'data/csv/nullbyte_header.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select * from read_csv('data/csv/nullbyte_header.csv', columns={'col1': 'VARCHAR', 'col2': 'VARCHAR'}, delim='|', header=False);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select * from read_csv('data/csv/nullbyte_header.csv', columns={'col1': 'VARCHAR', 'col2': 'VARCHAR'}, delim='|', header=True);
-- bwc_tag:end_query

