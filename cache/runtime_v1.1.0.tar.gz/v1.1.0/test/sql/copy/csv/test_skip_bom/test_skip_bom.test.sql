-- bwc_tag:nb_steps=5
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE people AS SELECT * FROM read_csv('data/csv/people.csv', columns=STRUCT_PACK(a := 'VARCHAR', b := 'VARCHAR'), sep=',', auto_detect='false');
-- bwc_tag:end_query

SELECT * FROM people
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE people2 AS SELECT * FROM read_csv_auto('data/csv/people.csv');
-- bwc_tag:end_query

SELECT * FROM people2
-- bwc_tag:end_query

