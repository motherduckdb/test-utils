-- bwc_tag:nb_steps=27
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

SET default_null_order='nulls_first';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE ubn1(a BIGINT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE ubn2(a INTEGER, b INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE ubn3(a INTEGER, c INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO ubn1 VALUES (1), (2), (9223372036854775807);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO ubn2 VALUES (3,4), (5, 6);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO ubn3 VALUES (100,101), (102, 103);
-- bwc_tag:end_query

COPY ubn1 TO 'output/ubn1.csv' WITH ( DELIMITER ',');
-- bwc_tag:end_query

COPY ubn2 TO 'output/ubn2.csv' WITH (DELIMITER ',');
-- bwc_tag:end_query

COPY ubn3 TO 'output/ubn3.csv' WITH (DELIMITER ',');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv_auto(['output/ubn1.csv', 'output/ubn2.csv', 'output/ubn3.csv']);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT a, b, c
FROM  read_csv_auto(['output/ubn1.csv', 'output/ubn2.csv', 'output/ubn3.csv'], UNION_BY_NAME=TRUE)
ORDER BY a;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT typeof(a), typeof(b), typeof(c)
FROM read_csv_auto(['output/ubn1.csv', 'output/ubn2.csv', 'output/ubn3.csv'], UNION_BY_NAME=TRUE)
LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT * FROM read_csv_auto(['data/csv/union-by-name/ubn1.csv', 'data/csv/union-by-name/ubn2.csv', 'data/csv/union-by-name/ubn3.csv', 'data/csv/union-by-name/ubn4.csv'])
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT  a, b, c, ts, k
FROM read_csv_auto('data/csv/union-by-name/ubn*.csv',UNION_BY_NAME=TRUE)
ORDER BY a, c, ts
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT  typeof(a), typeof(b), typeof(c), typeof(ts), typeof(k)
FROM read_csv_auto('data/csv/union-by-name/ubn*.csv',UNION_BY_NAME=TRUE)
LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT  c, k
FROM read_csv_auto('data/csv/union-by-name/ubn*.csv',UNION_BY_NAME=TRUE)
ORDER BY c NULLS LAST, k NULLS LAST
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT  ts
FROM read_csv_auto('data/csv/union-by-name/ubn*.csv',UNION_BY_NAME=TRUE)
ORDER BY ts NULLS LAST
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT typeof(a), typeof(b), typeof(ts) FROM read_csv_auto('data/csv/union-by-name/ubn2.csv') LIMIT 1;
-- bwc_tag:end_query

SELECT a, b, c, ts, replace(filename, '\', '/')
FROM read_csv_auto('data/csv/union-by-name/ubn[12].csv',FILENAME=TRUE ,UNION_BY_NAME=TRUE)
ORDER BY a, c, ts
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT typeof(a), typeof(b), typeof(c), typeof(ts)
FROM read_csv_auto('data/csv/union-by-name/ubn[12].csv',UNION_BY_NAME=TRUE)
LIMIT 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT typeof(ts)
FROM read_csv_auto('data/csv/union-by-name/ubn[23].csv',UNION_BY_NAME=TRUE)
LIMIT 1
-- bwc_tag:end_query

SELECT k, c, ts, replace(filename, '\', '/')
FROM read_csv_auto('data/csv/union-by-name/ubn[!1-2].csv',FILENAME=TRUE ,UNION_BY_NAME=TRUE)
ORDER BY c
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT * FROM read_csv_auto('data/csv/union-by-name/part=[ab]/*',HIVE_PARTITIONING=TRUE, null_padding=0)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT id, value, a, part
FROM read_csv_auto('data/csv/union-by-name/part=[ab]/*',HIVE_PARTITIONING=TRUE ,UNION_BY_NAME=TRUE)
ORDER BY id
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT * FROM read_csv_auto('data/csv/union-by-name/*[!a]/*',HIVE_PARTITIONING=TRUE ,UNION_BY_NAME=TRUE)
-- bwc_tag:end_query

