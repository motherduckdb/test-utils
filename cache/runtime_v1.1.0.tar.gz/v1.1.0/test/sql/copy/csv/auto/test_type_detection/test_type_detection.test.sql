-- bwc_tag:nb_steps=43
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/large_mixed_data.csv', SAMPLE_SIZE=-1);
-- bwc_tag:end_query

SELECT linenr, mixed_string, mixed_double FROM test LIMIT 3;
-- bwc_tag:end_query

SELECT typeof(linenr), typeof(mixed_string), typeof(mixed_double) FROM test LIMIT 1;
-- bwc_tag:end_query

SELECT linenr, mixed_string, mixed_double FROM test WHERE linenr > 27000 LIMIT 3;
-- bwc_tag:end_query

SELECT count(*) FROM test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/time_date_timestamp.csv');
-- bwc_tag:end_query

SELECT a, b, t, d, ts FROM test ORDER BY a;
-- bwc_tag:end_query

SELECT typeof(a), typeof(b), typeof(t), typeof(d), typeof(ts) FROM test LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/time_date_timestamp_trailing.csv');
-- bwc_tag:end_query

SELECT a, b, t, tf, d, df FROM test ORDER BY a;
-- bwc_tag:end_query

SELECT typeof(a), typeof(b), typeof(t), typeof(tf), typeof(d), typeof(df) FROM test LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/time_date_timestamp_mm-dd-yyyy.csv');
-- bwc_tag:end_query

SELECT a, b, t, d, ts FROM test ORDER BY a;
-- bwc_tag:end_query

SELECT typeof(a), typeof(b), typeof(t), typeof(d), typeof(ts) FROM test LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/time_date_timestamp_mm-dd-yy.csv');
-- bwc_tag:end_query

SELECT a, b, t, d, ts FROM test ORDER BY a;
-- bwc_tag:end_query

SELECT typeof(a), typeof(b), typeof(t), typeof(d), typeof(ts) FROM test LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/time_date_timestamp_dd-mm-yyyy.csv');
-- bwc_tag:end_query

SELECT a, b, t, d, ts FROM test ORDER BY a;
-- bwc_tag:end_query

SELECT typeof(a), typeof(b), typeof(t), typeof(d), typeof(ts) FROM test LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/time_date_timestamp_dd-mm-yy.csv');
-- bwc_tag:end_query

SELECT a, b, t, d, ts FROM test ORDER BY a;
-- bwc_tag:end_query

SELECT typeof(a), typeof(b), typeof(t), typeof(d), typeof(ts) FROM test LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/time_date_timestamp_yyyy.mm.dd.csv');
-- bwc_tag:end_query

SELECT a, b, t, d, ts FROM test ORDER BY a;
-- bwc_tag:end_query

SELECT typeof(a), typeof(b), typeof(t), typeof(d), typeof(ts) FROM test LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/time_date_timestamp_yy.mm.dd.csv');
-- bwc_tag:end_query

SELECT a, b, t, d, ts FROM test ORDER BY a;
-- bwc_tag:end_query

SELECT typeof(a), typeof(b), typeof(t), typeof(d), typeof(ts) FROM test LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/int_bol.csv');
-- bwc_tag:end_query

SELECT i FROM test ORDER BY i;
-- bwc_tag:end_query

SELECT typeof(i), typeof(b) FROM test LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

