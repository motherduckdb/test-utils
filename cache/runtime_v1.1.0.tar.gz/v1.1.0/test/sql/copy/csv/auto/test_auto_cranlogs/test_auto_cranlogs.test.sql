-- bwc_tag:nb_steps=7
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE cranlogs AS SELECT * FROM read_csv_auto ('data/csv/real/tmp2013-06-15.csv.gz');
-- bwc_tag:end_query

SELECT COUNT(*) FROM cranlogs;
-- bwc_tag:end_query

SELECT * FROM cranlogs LIMIT 5;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA verify_parallelism
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE cranlogs2 AS SELECT * FROM read_csv_auto ('data/csv/real/tmp2013-06-15.csv.gz');
-- bwc_tag:end_query

(SELECT * FROM cranlogs EXCEPT SELECT * FROM cranlogs2)
UNION ALL
(SELECT * FROM cranlogs2 EXCEPT SELECT * FROM cranlogs)
-- bwc_tag:end_query

