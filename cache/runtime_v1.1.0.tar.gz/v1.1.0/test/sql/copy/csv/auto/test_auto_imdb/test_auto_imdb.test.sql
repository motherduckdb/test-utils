-- bwc_tag:nb_steps=5
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE movie_info AS SELECT * FROM read_csv_auto ('data/csv/real/imdb_movie_info_escaped.csv');
-- bwc_tag:end_query

SELECT COUNT(*) FROM movie_info;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE movie_info2 AS SELECT * FROM read_csv_auto ('data/csv/real/imdb_movie_info_escaped.csv');
-- bwc_tag:end_query

(FROM movie_info EXCEPT FROM movie_info2)
UNION ALL
(FROM movie_info2 EXCEPT FROM movie_info)
-- bwc_tag:end_query

