-- bwc_tag:nb_steps=11
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

SET home_directory='output'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers AS SELECT * FROM range(10)
-- bwc_tag:end_query

COPY integers TO 'output/integers.csv' (FORMAT CSV);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM '~/integers.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers_load(i INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY integers_load FROM '~/integers.csv'
-- bwc_tag:end_query

SELECT * FROM integers_load
-- bwc_tag:end_query

COPY integers TO 'output/homedir_integers1.csv'
-- bwc_tag:end_query

COPY integers TO 'output/homedir_integers2.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT COUNT(*) FROM '~/homedir_integers*.csv'
-- bwc_tag:end_query

