-- bwc_tag:nb_steps=32
-- bwc_tag:execute_from_sql
SELECT * FROM read_csv(
    'data/csv/rejects/maximum_line/max_10.csv',
    columns = {'a': 'VARCHAR', 'b': 'INTEGER'},
    store_rejects=true, auto_detect=false, header = 1, max_line_size=10);
-- bwc_tag:end_query

SELECT * EXCLUDE (scan_id) FROM reject_errors order by all;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv(
    'data/csv/rejects/maximum_line/max_10.csv',
    columns = {'a': 'VARCHAR', 'b': 'INTEGER'},
    store_rejects = true, auto_detect=false, header = 1, max_line_size=10, buffer_size=22);
-- bwc_tag:end_query

SELECT * EXCLUDE (scan_id) FROM reject_errors order by all;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv(
    'data/csv/rejects/maximum_line/max_10.csv',
    columns = {'a': 'VARCHAR', 'b': 'INTEGER'},
    store_rejects = true, auto_detect=false, header = 1, max_line_size=10, buffer_size=23);
-- bwc_tag:end_query

SELECT * EXCLUDE (scan_id) FROM reject_errors order by all;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv(
    'data/csv/rejects/maximum_line/max_10.csv',
    columns = {'a': 'VARCHAR', 'b': 'INTEGER'},
    store_rejects = true, auto_detect=false, header = 1, max_line_size=10, buffer_size=24);
-- bwc_tag:end_query

SELECT * EXCLUDE (scan_id) FROM reject_errors order by all;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv(
    'data/csv/rejects/maximum_line/max_10.csv',
    columns = {'a': 'VARCHAR', 'b': 'INTEGER'},
    store_rejects = true, auto_detect=false, header = 1, max_line_size=10, buffer_size=25);
-- bwc_tag:end_query

SELECT * EXCLUDE (scan_id) FROM reject_errors order by all;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv(
    'data/csv/rejects/maximum_line/max_10.csv',
    columns = {'a': 'VARCHAR', 'b': 'INTEGER'},
    store_rejects = true, auto_detect=false, header = 1, max_line_size=10, buffer_size=26);
-- bwc_tag:end_query

SELECT * EXCLUDE (scan_id) FROM reject_errors order by all;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv(
    'data/csv/rejects/maximum_line/over_vector.csv',
    columns = {'a': 'VARCHAR', 'b': 'INTEGER'},
    store_rejects = true, auto_detect=false, header = 1, max_line_size=20);
-- bwc_tag:end_query

SELECT * EXCLUDE (scan_id) FROM reject_errors order by all;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv(
    'data/csv/rejects/maximum_line/*.csv',
    columns = {'a': 'VARCHAR', 'b': 'INTEGER'},
     store_rejects = true, auto_detect=false, header = 1, max_line_size=10);
-- bwc_tag:end_query

SELECT * EXCLUDE (scan_id) FROM reject_errors order by all;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

