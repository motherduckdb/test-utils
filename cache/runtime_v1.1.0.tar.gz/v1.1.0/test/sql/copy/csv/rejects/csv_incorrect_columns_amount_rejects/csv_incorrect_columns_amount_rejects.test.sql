-- bwc_tag:nb_steps=34
-- bwc_tag:execute_from_sql
SELECT * FROM read_csv(
    'data/csv/rejects/incorrect_columns/few_columns.csv',
    columns = {'a': 'INTEGER', 'b': 'INTEGER', 'c': 'INTEGER', 'd': 'INTEGER'},
    store_rejects=true, auto_detect=false, header = 1);
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
SELECT * EXCLUDE (scan_id) FROM reject_errors order by all;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv(
    'data/csv/rejects/incorrect_columns/many_columns.csv',
    columns = {'a': 'INTEGER', 'b': 'INTEGER', 'c': 'INTEGER', 'd': 'INTEGER'},
    store_rejects=true, auto_detect=false, header = 1);
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
SELECT * EXCLUDE (scan_id) FROM reject_errors order by all;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv(
    'data/csv/rejects/incorrect_columns/mix_columns.csv',
    columns = {'a': 'INTEGER', 'b': 'INTEGER', 'c': 'INTEGER', 'd': 'INTEGER'},
    store_rejects=true, auto_detect=false, header = 1);
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
SELECT * EXCLUDE (scan_id) FROM reject_errors order by all;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv(
    'data/csv/rejects/incorrect_columns/small_mix.csv',
    columns = {'a': 'INTEGER', 'b': 'INTEGER', 'c': 'INTEGER', 'd': 'INTEGER'},
    store_rejects=true, auto_detect=false, header = 1);
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
SELECT * EXCLUDE (scan_id) FROM reject_errors order by all
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv(
    'data/csv/rejects/incorrect_columns/small_mix.csv',
    columns = {'a': 'INTEGER', 'b': 'INTEGER', 'c': 'INTEGER', 'd': 'INTEGER'},
    store_rejects=true, auto_detect=false, header = 1);
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
SELECT * EXCLUDE (scan_id) FROM reject_errors order by all
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv(
    'data/csv/rejects/incorrect_columns/small_mix.csv',
    columns = {'a': 'INTEGER', 'b': 'INTEGER', 'c': 'INTEGER', 'd': 'INTEGER'},
    store_rejects=true, auto_detect=false, header = 1);
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
SELECT * EXCLUDE (scan_id) FROM reject_errors order by all
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv(
    'data/csv/rejects/incorrect_columns/small_mix.csv',
    columns = {'a': 'INTEGER', 'b': 'INTEGER', 'c': 'INTEGER', 'd': 'INTEGER'},
    store_rejects=true, auto_detect=false, header = 1);
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
SELECT * EXCLUDE (scan_id) FROM reject_errors order by all
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv(
    'data/csv/rejects/incorrect_columns/small_mix.csv',
    columns = {'a': 'INTEGER', 'b': 'INTEGER', 'c': 'INTEGER', 'd': 'INTEGER'},
    store_rejects=true, auto_detect=false, header = 1);
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
SELECT * EXCLUDE (scan_id) FROM reject_errors order by all
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv(
    'data/csv/rejects/incorrect_columns/*.csv',
    columns = {'a': 'INTEGER', 'b': 'INTEGER', 'c': 'INTEGER', 'd': 'INTEGER'},
   store_rejects=true, auto_detect=false, header = 1);
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
SELECT * EXCLUDE (scan_id) FROM reject_errors order by all
-- bwc_tag:end_query

