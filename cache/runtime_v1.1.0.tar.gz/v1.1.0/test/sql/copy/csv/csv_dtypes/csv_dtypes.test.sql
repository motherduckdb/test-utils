-- bwc_tag:nb_steps=10
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select typeof(Year), typeof(Quarter) from 'data/csv/real/ontime_sample.csv' LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select typeof(Year), typeof(Quarter) from read_csv_auto('data/csv/real/ontime_sample.csv', dtypes={'Quarter': 'TINYINT'}) LIMIT 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select typeof(Year), typeof(Quarter) from read_csv_auto('data/csv/real/ontime_sample.csv', dtypes={'quArTeR': 'TINYINT'}) LIMIT 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select typeof(Year), typeof(Quarter) from read_csv_auto('data/csv/real/ontime_sample.csv', dtypes=['INT', 'TINYINT']) LIMIT 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

select * from read_csv_auto('data/csv/real/ontime_sample.csv', dtypes=['INT'], column_types={'Quarter': 'TINYINT'}) LIMIT 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

select * from read_csv_auto('data/csv/real/ontime_sample.csv', dtypes=[42]) LIMIT 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

select * from read_csv_auto('data/csv/real/ontime_sample.csv', dtypes=['unknown_type']) LIMIT 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

select * from read_csv_auto('data/csv/real/ontime_sample.csv', dtypes={'Quarter': 42}) LIMIT 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

select * from read_csv_auto('data/csv/auto/int_bol.csv', dtypes=['varchar', 'varchar', 'varchar']) LIMIT 1
-- bwc_tag:end_query

