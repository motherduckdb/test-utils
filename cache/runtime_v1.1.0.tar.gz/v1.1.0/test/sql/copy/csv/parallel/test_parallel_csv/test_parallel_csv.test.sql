-- bwc_tag:needed_extensions=httpfs
-- bwc_tag:nb_steps=8
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select * from read_csv_auto('data/csv/dirty_line.csv',  skip = 1)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select * from read_csv_auto('data/csv/null_string.csv',  nullstr="null")
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select * from read_csv_auto('data/csv/null_string.csv', header = false)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select * from read_csv_auto('data/csv/aws_locations.csv')
-- bwc_tag:end_query

LOAD 'httpfs';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select * from read_csv_auto("https://duckdb-public-gzip-test.s3.us-east-2.amazonaws.com/test.csv", header = 0);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
from read_csv_auto("https://duckdb-public-gzip-test.s3.us-east-2.amazonaws.com/test.csv.gz", header = 0);
-- bwc_tag:end_query

