-- bwc_tag:nb_steps=15
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:skip_query
pragma threads=4
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA enable_profiling
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA profiling_output='output/test.json'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA profiling_mode = detailed
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (3)
-- bwc_tag:end_query

SELECT min (i + i) FROM integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE exprtest (a INTEGER, b INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO exprtest VALUES (42, 10), (43, 100), (NULL, 1), (45, -1)
-- bwc_tag:end_query

SELECT min (a + a ) FROM exprtest
-- bwc_tag:end_query

SELECT a FROM exprtest WHERE a BETWEEN 43 AND 44
-- bwc_tag:end_query

SELECT CASE a WHEN 42 THEN 100 WHEN 43 THEN 200 ELSE 300 END FROM exprtest
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA profiling_output='output/test_2.json'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT COUNT(*) > 0
FROM read_csv('output/test.json', columns={'c': 'VARCHAR'}, delim=NULL, header=0, quote=NULL, escape=NULL, auto_detect = false)
WHERE contains(c, 'Optimizer');
-- bwc_tag:end_query

