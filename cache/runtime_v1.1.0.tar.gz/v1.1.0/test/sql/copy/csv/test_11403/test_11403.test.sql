-- bwc_tag:nb_steps=3
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT COUNT(*) FROM 'data/csv/quoted_newline.csv'
-- bwc_tag:end_query

SELECT quote FROM sniff_csv('data/csv/quoted_newline.csv')
-- bwc_tag:end_query

