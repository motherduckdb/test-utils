-- bwc_tag:needed_extensions=tpch
-- bwc_tag:nb_steps=14
LOAD 'tpch';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
call dbgen(sf=0.1);
-- bwc_tag:end_query

copy (select l_orderkey,l_partkey,l_suppkey,l_linenumber,l_quantity,l_extendedprice,l_discount,l_tax,l_returnflag,l_linestatus,l_shipdate,l_commitdate,l_receiptdate,l_shipinstruct,l_shipmode,l_comment from lineitem limit 10000 offset 0)
  to 'output/lineitem_part1.csv';
-- bwc_tag:end_query

copy (select l_orderkey,l_partkey,l_suppkey,l_linenumber,l_quantity,l_extendedprice,l_tax,l_discount,l_returnflag,l_linestatus,l_shipdate,l_commitdate,l_receiptdate,l_shipinstruct,l_shipmode,l_comment from lineitem limit 10000 offset 10000)
  to 'output/lineitem_part2.csv';
-- bwc_tag:end_query

copy (select l_comment,l_orderkey,l_partkey,l_suppkey,l_linenumber,l_quantity,l_extendedprice,l_tax,l_discount,l_returnflag,l_linestatus,l_shipdate,l_commitdate,l_receiptdate,l_shipinstruct,l_shipmode from lineitem limit 10000 offset 20000)
  to 'output/lineitem_part3.csv';
-- bwc_tag:end_query

copy (select l_comment,l_orderkey,l_returnflag,l_linestatus,l_shipdate,l_commitdate,l_receiptdate,l_shipinstruct,l_partkey,l_suppkey,l_linenumber,l_quantity,l_extendedprice,l_tax,l_discount,l_shipmode from lineitem limit 10000 offset 30000)
  to 'output/lineitem_part4.csv';
-- bwc_tag:end_query

copy (select l_comment,l_orderkey,l_returnflag,l_linestatus,l_shipdate,l_commitdate,l_receiptdate,l_shipinstruct,l_partkey,l_suppkey,l_linenumber,l_quantity,l_extendedprice,l_tax,l_discount,l_shipmode,l_shipmode as shipmode2 from lineitem limit 10000 offset 40000)
  to 'output/lineitem_part5.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table t as from read_csv(['output/lineitem_part1.csv', 'output/lineitem_part3.csv']);
-- bwc_tag:end_query

select count(*) from t;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop table t;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table t as from read_csv(['output/lineitem_part*.csv']);
-- bwc_tag:end_query

select count(*) from t;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop table t;
-- bwc_tag:end_query

