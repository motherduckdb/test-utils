-- bwc_tag:nb_steps=11
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM 'data/csv/decimal.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select typeof (col_a) FROM 'data/csv/decimal.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv(
    'data/csv/decimal.csv',
    columns = {'col_a': 'DECIMAL'});
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT typeof(col_a) FROM read_csv(
    'data/csv/decimal.csv',
    columns = {'col_a': 'DECIMAL'});
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv(
    'data/csv/decimal.csv',
    columns = {'col_a': 'DECIMAL(18,15)'});
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT typeof(col_a) FROM read_csv(
    'data/csv/decimal.csv',
    columns = {'col_a': 'DECIMAL(18,15)'});
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT typeof(col_a) FROM read_csv(
    'data/csv/decimal.csv',
     auto_type_candidates=['NULL', 'DECIMAL', 'VARCHAR']);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT typeof(col_a) FROM read_csv(
    'data/csv/decimal.csv',
     auto_type_candidates=['NULL', 'DECIMAL(18,3)','DECIMAL(18,15)', 'VARCHAR']);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT typeof(col_a) FROM read_csv(
    'data/csv/decimal.csv',
     auto_type_candidates=['NULL','DECIMAL(18,15)', 'DECIMAL(18,3)', 'VARCHAR']);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT typeof(col_a) FROM read_csv(
    'data/csv/decimal.csv',
     auto_type_candidates=['NULL', 'DECIMAL(18,15)', 'VARCHAR']);
-- bwc_tag:end_query

