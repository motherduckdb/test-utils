-- bwc_tag:needed_extensions=parquet;httpfs
-- bwc_tag:nb_steps=11
LOAD 'httpfs';
-- bwc_tag:end_query

LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM PARQUET_SCAN('https://this-host-does-not-exist-for-sure/test.parquet');
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM PARQUET_SCAN('https://duckdb.org/test.parquet');
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM PARQUET_SCAN('https://duckdb.org');
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM PARQUET_SCAN('https://duckdb.org/');
-- bwc_tag:end_query

SELECT id, first_name, last_name, email FROM PARQUET_SCAN('https://raw.githubusercontent.com/duckdb/duckdb/main/data/parquet-testing/userdata1.parquet') LIMIT 10;
-- bwc_tag:end_query

SELECT id, first_name, last_name, email FROM PARQUET_SCAN('https://github.com/duckdb/duckdb/blob/main/data/parquet-testing/userdata1.parquet?raw=true') LIMIT 10;
-- bwc_tag:end_query

SELECT id, first_name, last_name, email FROM PARQUET_SCAN('https://github.com:443/duckdb/duckdb/blob/main/data/parquet-testing/userdata1.parquet?raw=true') LIMIT 10;
-- bwc_tag:end_query

SELECT id, first_name, last_name, email FROM PARQUET_SCAN('https://github.com/duckdb/duckdb-data/releases/download/v1.0/us+er+da+ta.parquet') LIMIT 1;
-- bwc_tag:end_query

SELECT id, first_name, last_name, email FROM PARQUET_SCAN('https://github.com/duckdb/duckdb-data/releases/download/v1.0/us%2Ber%2Bda%2Bta.parquet') LIMIT 1;
-- bwc_tag:end_query

