-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=50
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE values_UTINYINT AS SELECT d::UTINYINT d FROM (VALUES
    (0), (42), (NULL), (255)) tbl (d);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE values_USMALLINT AS SELECT d::USMALLINT d FROM (VALUES
    (0), (42), (NULL), (65535)) tbl (d);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE values_UINTEGER AS SELECT d::UINTEGER d FROM (VALUES
    (0), (42), (NULL), (4294967295)) tbl (d);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE values_UBIGINT AS SELECT d::UBIGINT d FROM (VALUES
    (0), (42), (NULL), (18446744073709551615)) tbl (d);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE unsigned(d UTINYINT)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO unsigned SELECT * FROM values_UTINYINT
-- bwc_tag:end_query

COPY unsigned TO 'output/unsigned.parquet' (FORMAT 'parquet');
-- bwc_tag:end_query

SELECT * FROM 'output/unsigned.parquet' EXCEPT SELECT * FROM unsigned
-- bwc_tag:end_query

SELECT * FROM unsigned EXCEPT SELECT * FROM 'output/unsigned.parquet'
-- bwc_tag:end_query

SELECT * FROM 'output/unsigned.parquet' WHERE d=42
-- bwc_tag:end_query

SELECT COUNT(*) FROM 'output/unsigned.parquet' WHERE d>42
-- bwc_tag:end_query

SELECT COUNT(*) FROM 'output/unsigned.parquet' WHERE d>=42
-- bwc_tag:end_query

SELECT COUNT(*) FROM 'output/unsigned.parquet' WHERE d<42
-- bwc_tag:end_query

SELECT COUNT(*) FROM 'output/unsigned.parquet' WHERE d<=42
-- bwc_tag:end_query

SELECT typeof(d)='UTINYINT' FROM 'output/unsigned.parquet' LIMIT 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE unsigned(d USMALLINT)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO unsigned SELECT * FROM values_USMALLINT
-- bwc_tag:end_query

COPY unsigned TO 'output/unsigned.parquet' (FORMAT 'parquet');
-- bwc_tag:end_query

SELECT * FROM 'output/unsigned.parquet' EXCEPT SELECT * FROM unsigned
-- bwc_tag:end_query

SELECT * FROM unsigned EXCEPT SELECT * FROM 'output/unsigned.parquet'
-- bwc_tag:end_query

SELECT * FROM 'output/unsigned.parquet' WHERE d=42
-- bwc_tag:end_query

SELECT COUNT(*) FROM 'output/unsigned.parquet' WHERE d>42
-- bwc_tag:end_query

SELECT COUNT(*) FROM 'output/unsigned.parquet' WHERE d>=42
-- bwc_tag:end_query

SELECT COUNT(*) FROM 'output/unsigned.parquet' WHERE d<42
-- bwc_tag:end_query

SELECT COUNT(*) FROM 'output/unsigned.parquet' WHERE d<=42
-- bwc_tag:end_query

SELECT typeof(d)='USMALLINT' FROM 'output/unsigned.parquet' LIMIT 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE unsigned(d UINTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO unsigned SELECT * FROM values_UINTEGER
-- bwc_tag:end_query

COPY unsigned TO 'output/unsigned.parquet' (FORMAT 'parquet');
-- bwc_tag:end_query

SELECT * FROM 'output/unsigned.parquet' EXCEPT SELECT * FROM unsigned
-- bwc_tag:end_query

SELECT * FROM unsigned EXCEPT SELECT * FROM 'output/unsigned.parquet'
-- bwc_tag:end_query

SELECT * FROM 'output/unsigned.parquet' WHERE d=42
-- bwc_tag:end_query

SELECT COUNT(*) FROM 'output/unsigned.parquet' WHERE d>42
-- bwc_tag:end_query

SELECT COUNT(*) FROM 'output/unsigned.parquet' WHERE d>=42
-- bwc_tag:end_query

SELECT COUNT(*) FROM 'output/unsigned.parquet' WHERE d<42
-- bwc_tag:end_query

SELECT COUNT(*) FROM 'output/unsigned.parquet' WHERE d<=42
-- bwc_tag:end_query

SELECT typeof(d)='UINTEGER' FROM 'output/unsigned.parquet' LIMIT 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE unsigned(d UBIGINT)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO unsigned SELECT * FROM values_UBIGINT
-- bwc_tag:end_query

COPY unsigned TO 'output/unsigned.parquet' (FORMAT 'parquet');
-- bwc_tag:end_query

SELECT * FROM 'output/unsigned.parquet' EXCEPT SELECT * FROM unsigned
-- bwc_tag:end_query

SELECT * FROM unsigned EXCEPT SELECT * FROM 'output/unsigned.parquet'
-- bwc_tag:end_query

SELECT * FROM 'output/unsigned.parquet' WHERE d=42
-- bwc_tag:end_query

SELECT COUNT(*) FROM 'output/unsigned.parquet' WHERE d>42
-- bwc_tag:end_query

SELECT COUNT(*) FROM 'output/unsigned.parquet' WHERE d>=42
-- bwc_tag:end_query

SELECT COUNT(*) FROM 'output/unsigned.parquet' WHERE d<42
-- bwc_tag:end_query

SELECT COUNT(*) FROM 'output/unsigned.parquet' WHERE d<=42
-- bwc_tag:end_query

SELECT typeof(d)='UBIGINT' FROM 'output/unsigned.parquet' LIMIT 1
-- bwc_tag:end_query

