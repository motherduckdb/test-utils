-- bwc_tag:needed_extensions=icu;parquet
-- bwc_tag:nb_steps=6
LOAD 'parquet';
-- bwc_tag:end_query

LOAD 'icu';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

select typeof(TimeRecStart) from 'data/parquet-testing/tz.parquet' limit 1;
-- bwc_tag:end_query

SET timezone='UTC'
-- bwc_tag:end_query

select TimeRecStart from 'data/parquet-testing/tz.parquet';
-- bwc_tag:end_query

