-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=28
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:skip_query
pragma enable_verification
-- bwc_tag:end_query

SELECT COUNT(*) FROM parquet_scan('data/parquet-testing/userdata1.parquet') where id > 500
-- bwc_tag:end_query

SELECT COUNT(*) FROM parquet_scan('data/parquet-testing/userdata1.parquet') where id < 500
-- bwc_tag:end_query

SELECT COUNT(*) FROM parquet_scan('data/parquet-testing/userdata1.parquet') where id > 100 and id < 900
-- bwc_tag:end_query

SELECT COUNT(*) FROM parquet_scan('data/parquet-testing/userdata1.parquet') where id between 100 and 900
-- bwc_tag:end_query

SELECT registration_dttm, id, first_name, birthdate, salary FROM parquet_scan('data/parquet-testing/userdata1.parquet') where id = 42
-- bwc_tag:end_query

SELECT COUNT(*) FROM parquet_scan('data/parquet-testing/userdata1.parquet') where id = 42
-- bwc_tag:end_query

SELECT COUNT(*) FROM parquet_scan('data/parquet-testing/userdata1.parquet') where salary < 1000
-- bwc_tag:end_query

SELECT COUNT(*) FROM parquet_scan('data/parquet-testing/userdata1.parquet') where salary < 1000
-- bwc_tag:end_query

SELECT first_name, gender FROM parquet_scan('data/parquet-testing/userdata1.parquet') where first_name = 'Mark' and gender <> ''
-- bwc_tag:end_query

SELECT gender, first_name FROM parquet_scan('data/parquet-testing/userdata1.parquet') where first_name = 'Mark' and gender <> ''
-- bwc_tag:end_query

SELECT COUNT(*) FROM parquet_scan('data/parquet-testing/userdata1.parquet') where gender = 'Male' and first_name = 'Mark'
-- bwc_tag:end_query

SELECT last_name FROM parquet_scan('data/parquet-testing/userdata1.parquet') where first_name > 'Mark' and country > 'Germany' and salary > 0 order by last_name limit 10
-- bwc_tag:end_query

SELECT length(l_comment) FROM parquet_scan('data/parquet-testing/lineitem-top10000.gzip.parquet') where l_orderkey = 1 order by l_comment
-- bwc_tag:end_query

SELECT * FROM parquet_scan('data/parquet-testing/date.parquet') where d < cast('1978-01-01' as date)
-- bwc_tag:end_query

SELECT * FROM parquet_scan('data/parquet-testing/date.parquet') where d > cast('1982-01-01' as date) and d < cast('1986-01-01' as date)
-- bwc_tag:end_query

SELECT * FROM parquet_scan('data/parquet-testing/date.parquet') where d >= cast('1990-01-01' as date)
-- bwc_tag:end_query

SELECT COUNT(*) FROM parquet_scan('data/parquet-testing/date.parquet') where d == cast('1970-01-01' as date)
-- bwc_tag:end_query

SELECT COUNT(*) FROM parquet_scan('data/parquet-testing/date.parquet') where d > cast('1970-01-01' as date)
-- bwc_tag:end_query

SELECT COUNT(*) FROM parquet_scan('data/parquet-testing/date.parquet') where d >= cast('1982-01-01' as date) and d < cast('1985-01-01' as date)
-- bwc_tag:end_query

SELECT COUNT(*) FROM parquet_scan('data/parquet-testing/date.parquet') where d < cast('1970-01-01' as date)
-- bwc_tag:end_query

SELECT COUNT(*) FROM parquet_scan('data/parquet-testing/date.parquet') where d between cast('1975-01-01' as date) and cast('1976-01-01' as date)
-- bwc_tag:end_query

SELECT COUNT(*) FROM parquet_scan('data/parquet-testing/date.parquet') where d >= cast('1975-01-01' as date) and d < cast('1976-01-01' as date)
-- bwc_tag:end_query

SELECT COUNT(*) FROM parquet_scan('data/parquet-testing/date.parquet') where d < cast('1975-01-01' as date) and d > cast('1976-01-01' as date)
-- bwc_tag:end_query

SELECT COUNT(*) FROM parquet_scan('data/parquet-testing/date.parquet') where d < cast('1975-01-01' as date) or d > cast('1976-01-01' as date)
-- bwc_tag:end_query

SELECT COUNT(*) FROM parquet_scan('data/parquet-testing/date.parquet') where d < cast('1975-01-01' as date) or d >= cast('1976-01-01' as date)
-- bwc_tag:end_query

SELECT COUNT(*) FROM parquet_scan('data/parquet-testing/date.parquet') where d is null
-- bwc_tag:end_query

