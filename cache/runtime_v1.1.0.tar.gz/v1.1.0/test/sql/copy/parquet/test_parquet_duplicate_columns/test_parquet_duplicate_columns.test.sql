-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=7
LOAD 'parquet';
-- bwc_tag:end_query

COPY (SELECT 1 as a, 2 as a, 3 as a) TO 'output/dupe_cols.parquet';
-- bwc_tag:end_query

SELECT a, "a_1", "a_2" FROM 'output/dupe_cols.parquet';
-- bwc_tag:end_query

COPY (SELECT 1 as a, 2 as a, 3 as "a_1") TO 'output/dupe_cols.parquet';
-- bwc_tag:end_query

SELECT a, "a_1", "a_1_1" FROM 'output/dupe_cols.parquet';
-- bwc_tag:end_query

COPY (SELECT 1 as a, 3 as "a_1", 2 as a) TO 'output/dupe_cols.parquet';
-- bwc_tag:end_query

SELECT a, "a_1", "a_2" FROM 'output/dupe_cols.parquet';
-- bwc_tag:end_query

