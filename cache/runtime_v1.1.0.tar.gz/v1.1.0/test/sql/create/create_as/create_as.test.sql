-- bwc_tag:nb_steps=16
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tbl1 AS SELECT 1;
-- bwc_tag:end_query

SELECT * FROM tbl1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tbl2 AS SELECT 2 AS f;
-- bwc_tag:end_query

SELECT * FROM tbl2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE tbl3 AS SELECT 3;
-- bwc_tag:end_query

SELECT * FROM tbl3;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE TABLE tbl1 AS SELECT 3;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE tbl1 AS SELECT 4;
-- bwc_tag:end_query

SELECT * FROM tbl1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE tbl1 AS SELECT 'hello' UNION ALL SELECT 'world';
-- bwc_tag:end_query

SELECT * FROM tbl1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE tbl1 AS SELECT 5 WHERE false;
-- bwc_tag:end_query

SELECT * FROM tbl1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE TABLE tbl4 IF NOT EXISTS AS SELECT 4;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE OR REPLACE TABLE tbl4 IF NOT EXISTS AS SELECT 4;
-- bwc_tag:end_query

