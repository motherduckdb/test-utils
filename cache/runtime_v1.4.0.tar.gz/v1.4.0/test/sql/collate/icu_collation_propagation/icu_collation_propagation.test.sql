-- bwc_tag:needed_extensions=icu
-- bwc_tag:nb_steps=17
-- bwc_tag:execute_from_sql
create table tbl (a varchar, b varchar);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into tbl values ('ö', '>>>>>ö<<<<<'), ('o', '>>>>>o<<<<<'), ('p', '>>>>>p<<<<<');
-- bwc_tag:end_query

LOAD 'icu';
-- bwc_tag:end_query

select concat(a collate de, a) from tbl order by all;
-- bwc_tag:end_query

select lower(a collate de) from tbl order by all;
-- bwc_tag:end_query

select upper(a collate de) from tbl order by all;
-- bwc_tag:end_query

select trim(b collate de, '<>') from tbl order by all
-- bwc_tag:end_query

select ltrim(b collate de, '<>') from tbl order by all
-- bwc_tag:end_query

select rtrim(b collate de, '<>') from tbl order by all
-- bwc_tag:end_query

select repeat(a collate de, 10) from tbl order by all;
-- bwc_tag:end_query

select left(b collate de, 6) from tbl order by all;
-- bwc_tag:end_query

select right(b collate de, 6) from tbl order by all;
-- bwc_tag:end_query

select right(left(b collate de, 6), 1) from tbl order by all;
-- bwc_tag:end_query

select reverse(a collate de) from tbl order by all;
-- bwc_tag:end_query

select a from tbl where contains(b collate de, 'o') order by all
-- bwc_tag:end_query

select a from tbl where starts_with(b collate de, '>>>>>o') order by all
-- bwc_tag:end_query

select a from tbl where b collate de like '%>o<%' order by all
-- bwc_tag:end_query

