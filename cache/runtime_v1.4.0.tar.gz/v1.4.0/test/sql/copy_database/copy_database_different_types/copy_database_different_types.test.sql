-- bwc_tag:nb_steps=22
ATTACH 'output/copy_database_different_types.db' AS db1
-- bwc_tag:end_query

USE db1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test(a INTEGER, b INTEGER, c VARCHAR(10));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (42, 88, 'hello');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW v1 AS FROM test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TYPE mood AS ENUM('ok', 'sad', 'happy');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE enums(i mood)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO enums VALUES ('ok'), ('sad'), (NULL)
-- bwc_tag:end_query

select * from db1.enums
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE seq;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('seq')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE FUNCTION my_add(a, b) AS a + b
-- bwc_tag:end_query

ATTACH 'output/other_copy_database_different_types.db' AS db2;
-- bwc_tag:end_query

COPY FROM DATABASE db1 TO db2
-- bwc_tag:end_query

USE db2
-- bwc_tag:end_query

SELECT * FROM test;
-- bwc_tag:end_query

SELECT * FROM enums;
-- bwc_tag:end_query

SELECT * FROM v1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (43, 88, 'hello');
-- bwc_tag:end_query

SELECT * FROM v1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('seq')
-- bwc_tag:end_query

SELECT my_add(1, 2)
-- bwc_tag:end_query

