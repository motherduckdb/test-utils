-- bwc_tag:nb_steps=12
-- bwc_tag:execute_from_sql
PRAGMA verify_serializer
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE sequence1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE sequence2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tbl1 (
    colname integer
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tbl2 (
	colname integer
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER SEQUENCE sequence1 OWNED BY tbl1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER SEQUENCE sequence2 OWNED BY sequence1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER SEQUENCE sequence1 OWNED BY tbl2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create sequence sequence3;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

alter sequence sequence3 owned by sequence1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE tbl1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT nextval('sequence1');
-- bwc_tag:end_query

