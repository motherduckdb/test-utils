-- bwc_tag:nb_steps=32
-- bwc_tag:execute_from_sql
create or replace macro m(a := 'a', b := 'b') as a || b
-- bwc_tag:end_query

select m()
-- bwc_tag:end_query

select m(b := 'a', a := 'b')
-- bwc_tag:end_query

select m(a := 'b', b := 'a')
-- bwc_tag:end_query

select m('c')
-- bwc_tag:end_query

select m('c', 'd')
-- bwc_tag:end_query

select m('c', b := 'd')
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select m('c', a:= 'd')
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select m('c', 'd', b := 'e')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create or replace macro m(a, b) as a || b
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select m()
-- bwc_tag:end_query

select m(b := 'a', a := 'b')
-- bwc_tag:end_query

select m(a := 'b', b := 'a')
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select m('c')
-- bwc_tag:end_query

select m('c', 'd')
-- bwc_tag:end_query

select m('c', b := 'd')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create or replace macro m(a := 'a', b := 'b') as table (select a || b)
-- bwc_tag:end_query

select * from m()
-- bwc_tag:end_query

select * from m(b := 'a', a := 'b')
-- bwc_tag:end_query

select * from m(a := 'b', b := 'a')
-- bwc_tag:end_query

select * from m('c')
-- bwc_tag:end_query

select * from m('c', 'd')
-- bwc_tag:end_query

select * from m('c', b := 'd')
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select * from m('c', a:= 'd')
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select * from m('c', 'd', b := 'e')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create or replace macro m(a, b) as table (select a || b)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select * from m()
-- bwc_tag:end_query

select * from m(b := 'a', a := 'b')
-- bwc_tag:end_query

select * from m(a := 'b', b := 'a')
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select * from m('c')
-- bwc_tag:end_query

select * from m('c', 'd')
-- bwc_tag:end_query

select * from m('c', b := 'd')
-- bwc_tag:end_query

