-- bwc_tag:nb_steps=13
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO multi_add
	() AS 0,
	(a) AS a,
	(a, b) AS a + b,
	(a, b, c) AS  a + b + c,
	(a, b, c, d) AS  a + b + c + d,
	(a, b, c, d, e) AS  a + b + c + d + e
-- bwc_tag:end_query

SELECT multi_add(),
       multi_add(42),
       multi_add(42, 1),
       multi_add(42, 1, 1),
       multi_add(42, 1, 1, 1),
       multi_add(42, 1, 1, 1, 1)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT multi_add(1, 1, 1, 1, 1, 1, 1, 1, 1, 1);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO arithmetic
	(a, b, mult := 1) AS (a + b) * mult,
	(a, b, c, division := 1) AS  (a + b + c) / division
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select arithmetic(100, 200, 300)
-- bwc_tag:end_query

SELECT arithmetic(42, 84), arithmetic(42, 84, mult := 10), arithmetic(100, 200, c := 300), arithmetic(100, 200, 300, division := 10)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO generate_numbers
	(a, b) AS TABLE (SELECT * FROM range(a + b) t(i)),
	(a, b, c, mult := 1) AS TABLE (SELECT * FROM range((a + b + c) * mult) t(i))
-- bwc_tag:end_query

SELECT COUNT(*) FROM generate_numbers(20, 10);
-- bwc_tag:end_query

SELECT COUNT(*) FROM generate_numbers(1, 2, 2, mult := 5);
-- bwc_tag:end_query

SELECT function_name, parameters FROM duckdb_functions() WHERE function_name IN ('arithmetic', 'multi_add', 'generate_numbers') ORDER BY function_name, len(parameters)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE MACRO ambiguous_macro
	(a) AS a,
	(a) AS a + 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE MACRO error_in_definition
	(a) AS a,
	(a, b) AS a + y
-- bwc_tag:end_query

