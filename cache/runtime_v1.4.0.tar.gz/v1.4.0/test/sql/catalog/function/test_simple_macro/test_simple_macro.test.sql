-- bwc_tag:nb_steps=80
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers (a INT)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (1)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO one() AS (SELECT 1);
-- bwc_tag:end_query

SELECT one()
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT one(1)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT one(NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP MACRO one;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO having_macro(x) AS (SELECT * FROM integers GROUP BY a HAVING a = x)
-- bwc_tag:end_query

SELECT having_macro(1)
-- bwc_tag:end_query

SELECT having_macro(6)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO union_macro(x, y, z) AS (SELECT x IN (SELECT y UNION ALL SELECT z))
-- bwc_tag:end_query

SELECT union_macro(1, 2, 3)
-- bwc_tag:end_query

SELECT union_macro(1, 2, 1)
-- bwc_tag:end_query

SELECT union_macro(1, 1, 2)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO in_expression_list(x, y, z) AS (SELECT x IN (VALUES (y), (z)))
-- bwc_tag:end_query

SELECT in_expression_list(1, 2, 3)
-- bwc_tag:end_query

SELECT in_expression_list(1, 2, 1)
-- bwc_tag:end_query

SELECT in_expression_list(1, 1, 2)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE FUNCTION two() AS (SELECT 2);
-- bwc_tag:end_query

SELECT two()
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP FUNCTION two;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE MACRO add_macro(a) AS a + b
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO add_macro(a, b) AS a + b
-- bwc_tag:end_query

SELECT add_macro(a,a) FROM integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE floats (b FLOAT)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO floats VALUES (0.5)
-- bwc_tag:end_query

SELECT add_macro(a,2) + add_macro(3,b) FROM integers, floats
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO string_split(a,b) AS a + b
-- bwc_tag:end_query

SELECT string_split(1, 2)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO IFELSE(a,b,c) AS CASE WHEN a THEN b ELSE c END
-- bwc_tag:end_query

SELECT IFELSE(1,'true','false')
-- bwc_tag:end_query

SELECT ifelse(1,'true','false')
-- bwc_tag:end_query

SELECT IFELSE(0,'true','false')
-- bwc_tag:end_query

SELECT IFELSE(a = 1, 'true', 'false') FROM integers
-- bwc_tag:end_query

SELECT IFELSE(a = 0, 'true', 'false') FROM integers
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT IFELSE();
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT IFELSE(1);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT IFELSE(1, 2);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT IFELSE(1, 2, 3, 4);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE MACRO IFELSE(a,b) AS a+b
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE MACRO ifelse(a,b) AS a+b
-- bwc_tag:end_query

SELECT IFELSE('1', 'random', RANDOM()::VARCHAR)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA macros
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO macros.add_macro(a, b) AS a + b
-- bwc_tag:end_query

SELECT macros.add_macro(40,2)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE MACRO conflict(i, i) AS i + 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO myavg(x) AS SUM(x) / COUNT(x)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (21), (41);
-- bwc_tag:end_query

SELECT myavg(a) FROM integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO weird_avg(x) AS (MIN(x) + MAX(x)) / COUNT(x)
-- bwc_tag:end_query

SELECT weird_avg(a) FROM integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE MACRO star() AS *
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE MACRO conflict(a, a := 1) AS a + a
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO add_default5(a, b := 5) AS a + b
-- bwc_tag:end_query

SELECT add_default5(3, 6)
-- bwc_tag:end_query

SELECT add_default5(3)
-- bwc_tag:end_query

SELECT add_default5(3, b := 6)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT add_default5(b := 6, 3)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE MACRO wrong_order(a, b := 3, c)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE MACRO wrong_order(a := 3, b)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE MACRO select_plus_floats(a, f := b) AS (SELECT a + f FROM floats)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE MACRO wrong_type(s='not a float') AS (SELECT b + s FROM floats)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE MACRO two_default_params(a := 4, a := 2) AS a + a
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO two_default_params(a := 4, b := 2) AS a + b
-- bwc_tag:end_query

SELECT two_default_params()
-- bwc_tag:end_query

SELECT two_default_params(a := 5)
-- bwc_tag:end_query

SELECT two_default_params(b := 3)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT two_default_params(a := 5, a := 3)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT two_default_params(b := 5, b := 3)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE MACRO macros.add_macro(a, b) AS a + b
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE MACRO my_macro(a.b) AS 42;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE MACRO my_macro(a.b.c) AS 42;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO my_macro(a) AS 42;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT my_macro(x := 42);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT my_macro(a := 42, a := 42);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create macro zz1(x) as (select 10+x);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create macro zz2(x) as 20+x;
-- bwc_tag:end_query

select zz1(1),zz2(2);
-- bwc_tag:end_query

select function_name, parameters, macro_definition
from duckdb_functions()
where function_name like 'zz%'
and macro_definition like '%macro_parameters%';
-- bwc_tag:end_query

