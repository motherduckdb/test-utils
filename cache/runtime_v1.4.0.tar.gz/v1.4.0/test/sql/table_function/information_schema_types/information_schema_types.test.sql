-- bwc_tag:nb_steps=2
-- bwc_tag:skip_query
pragma enable_verification
-- bwc_tag:end_query

select table_name, column_name
from duckdb_columns()
where database_name = 'system'
and schema_name = 'information_schema'
and data_type = 'NULL'
-- bwc_tag:end_query

