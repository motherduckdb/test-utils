-- bwc_tag:nb_steps=9
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

DESCRIBE select 42 AS a
-- bwc_tag:end_query

with cte as (select 42 AS a) FROM (DESCRIBE TABLE cte)
-- bwc_tag:end_query

with cte as (select 42 AS a) FROM (DESCRIBE TABLE cte)
-- bwc_tag:end_query

SUMMARIZE select 42 AS a
-- bwc_tag:end_query

with cte as (select 42 AS a) FROM (SUMMARIZE TABLE cte)
-- bwc_tag:end_query

with cte as (select 42 AS a) FROM (SUMMARIZE TABLE cte)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

with cte as (select 42 AS a) (DESCRIBE TABLE cte)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

(DESCRIBE TABLE cte) ORDER BY 1
-- bwc_tag:end_query

