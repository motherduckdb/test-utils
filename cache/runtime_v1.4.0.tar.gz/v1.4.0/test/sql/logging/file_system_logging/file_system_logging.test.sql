-- bwc_tag:needed_extensions=httpfs;parquet
-- bwc_tag:nb_steps=11
LOAD 'parquet';
-- bwc_tag:end_query

set enable_logging = true;
-- bwc_tag:end_query

set logging_level='trace';
-- bwc_tag:end_query

COPY (SELECT 1 as a) TO 'output/test.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM 'output/test.csv'
-- bwc_tag:end_query

-- bwc_tag:skip_query
pragma threads=1
-- bwc_tag:end_query

SELECT scope, type, log_level, regexp_replace(message, '\"path\":.*test.csv"', '"test.csv"')
FROM duckdb_logs
WHERE type = 'FileSystem'
ORDER BY timestamp
-- bwc_tag:end_query

CALL truncate_duckdb_logs();
-- bwc_tag:end_query

LOAD 'httpfs';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM 'https://github.com/duckdb/duckdb/raw/main/data/csv/customer.csv'
-- bwc_tag:end_query

SELECT scope, type, log_level, regexp_replace(message, '\"path\":.*test.csv"', '"test.csv"')
FROM duckdb_logs
WHERE type = 'FileSystem' AND message NOT LIKE '%duckdb_extension%'
ORDER BY timestamp
-- bwc_tag:end_query

