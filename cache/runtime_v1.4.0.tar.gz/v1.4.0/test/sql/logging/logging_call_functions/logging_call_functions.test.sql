-- bwc_tag:nb_steps=28
-- bwc_tag:execute_from_sql
CREATE VIEW log_settings AS select name, value from duckdb_settings() where name in ['logging_level', 'logging_mode', 'logging_storage', 'enable_logging', 'enabled_log_types', 'disabled_log_types'] ORDER BY name
-- bwc_tag:end_query

CALL enable_logging();
-- bwc_tag:end_query

FROM log_settings;
-- bwc_tag:end_query

CALL disable_logging()
-- bwc_tag:end_query

FROM log_settings;
-- bwc_tag:end_query

CALL enable_logging(level='DEBUG');
-- bwc_tag:end_query

FROM log_settings;
-- bwc_tag:end_query

CALL disable_logging()
-- bwc_tag:end_query

FROM log_settings;
-- bwc_tag:end_query

CALL enable_logging('QueryLog');
-- bwc_tag:end_query

FROM log_settings;
-- bwc_tag:end_query

CALL enable_logging(['QueryLog', 'FileSystem']);
-- bwc_tag:end_query

SELECT name, list_sort(split(value, ',')) FROM log_settings;
-- bwc_tag:end_query

CALL enable_logging('FileSystem', storage='file', storage_config={'path': 'output/logging_call_functions_test_log'});
-- bwc_tag:end_query

FROM log_settings;
-- bwc_tag:end_query

CALL enable_logging(storage='file', storage_path='output/logging_call_functions');
-- bwc_tag:end_query

CALL disable_logging()
-- bwc_tag:end_query

CALL enable_logging(storage_path='output/logging_call_functions');
-- bwc_tag:end_query

FROM log_settings;
-- bwc_tag:end_query

CALL enable_logging()
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

CALL enable_logging(hocus_pocus='this is bogus');
-- bwc_tag:end_query

FROM log_settings;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

CALL enable_logging(storage='file', level='DEBUG', storage_config={'hocus_pocus': 'this is bogus', 'path': 'output/hi.csv'});
-- bwc_tag:end_query

FROM log_settings;
-- bwc_tag:end_query

CALL disable_logging();
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

CALL enable_logging(storage='memory', storage_config={'path': 'bla'});
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

CALL enable_logging(storage_config='hi')
-- bwc_tag:end_query

FROM log_settings;
-- bwc_tag:end_query

