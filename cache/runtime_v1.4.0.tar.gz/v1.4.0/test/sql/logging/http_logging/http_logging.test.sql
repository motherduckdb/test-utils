-- bwc_tag:needed_extensions=httpfs;parquet
-- bwc_tag:nb_steps=10
LOAD 'parquet';
-- bwc_tag:end_query

LOAD 'httpfs';
-- bwc_tag:end_query

CALL enable_logging('HTTP');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM 'https://github.com/duckdb/duckdb/raw/main/data/csv/customer.csv'
-- bwc_tag:end_query

SELECT
	request.type,
	request.url,
	response.status,
	response.reason,
FROM duckdb_logs_parsed('HTTP') WHERE response.status != 'ServiceUnavailable_503'
-- bwc_tag:end_query

SELECT request.headers['Range'], response.headers['Content-Range']
FROM duckdb_logs_parsed('HTTP')
WHERE request.type='GET'
-- bwc_tag:end_query

CALL truncate_duckdb_logs()
-- bwc_tag:end_query

set enable_http_logging=false;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM 'https://github.com/duckdb/duckdb/raw/main/data/csv/customer.csv'
-- bwc_tag:end_query

select count(*) FROM duckdb_logs_parsed('HTTP');
-- bwc_tag:end_query

