-- bwc_tag:nb_steps=36
CALL enable_logging(['FileSystem'], storage='file', storage_config={'path': 'output/logging_csv_log.csv', 'normalize': false});
-- bwc_tag:end_query

FROM "data/csv/big_number.csv"
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DESCRIBE FROM 'output/logging_csv_log.csv';
-- bwc_tag:end_query

SELECT 
	scope, 
	path: parse_duckdb_log_message('FileSystem', message)['path'],
	op: parse_duckdb_log_message('FileSystem', message)['op'],
FROM "output/logging_csv_log.csv"
WHERE path = 'data/csv/big_number.csv';
-- bwc_tag:end_query

CALL disable_logging()
-- bwc_tag:end_query

CALL truncate_duckdb_logs();
-- bwc_tag:end_query

select count(*) FROM "output/logging_csv_log.csv";
-- bwc_tag:end_query

CALL enable_logging(['FileSystem'], storage='file', storage_config={'path': 'output/logging_csv_logs_normalized', 'normalize': true});
-- bwc_tag:end_query

FROM "data/csv/big_number.csv"
-- bwc_tag:end_query

SELECT 
	context_id is not null, 
	path: parse_duckdb_log_message('FileSystem', message)['path'],
	op: parse_duckdb_log_message('FileSystem', message)['op'],
FROM "output/logging_csv_logs_normalized/duckdb_log_entries.csv"
WHERE path = 'data/csv/big_number.csv';
-- bwc_tag:end_query

SELECT scope
FROM "output/logging_csv_logs_normalized/duckdb_log_contexts.csv";
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DESCRIBE FROM 'output/logging_csv_logs_normalized/duckdb_log_entries.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DESCRIBE FROM 'output/logging_csv_logs_normalized/duckdb_log_contexts.csv';
-- bwc_tag:end_query

CALL disable_logging();
-- bwc_tag:end_query

CALL truncate_duckdb_logs();
-- bwc_tag:end_query

select count(*) FROM "output/logging_csv_logs_normalized/duckdb_log_contexts.csv";
-- bwc_tag:end_query

select count(*) FROM "output/logging_csv_logs_normalized/duckdb_log_entries.csv";
-- bwc_tag:end_query

CALL enable_logging(['FileSystem'], storage='stdout');
-- bwc_tag:end_query

CALL truncate_duckdb_logs();
-- bwc_tag:end_query

CALL disable_logging();
-- bwc_tag:end_query

CALL enable_logging(['FileSystem'], storage='stdout', storage_config={'buffer_size': 1000000}); 
-- bwc_tag:end_query

CALL disable_logging();
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

CALL enable_logging(['FileSystem'], storage='stdout', storage_config={'bla': 'bla'});
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

CALL enable_logging(['FileSystem'], storage='stdout', storage_config={'path': './file.csv'});
-- bwc_tag:end_query

CALL truncate_duckdb_logs()
-- bwc_tag:end_query

CALL enable_logging(['QueryLog'], storage='file', storage_config={'path': 'output/logging_csv_log.csv'});
-- bwc_tag:end_query

SELECT 1;
-- bwc_tag:end_query

CALL truncate_duckdb_logs()
-- bwc_tag:end_query

explain FROM duckdb_logs
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

CALL enable_logging(['QueryLog'], storage='file', storage_config={'path': 'output/logging_csv_log.csv', 'normalize': true});
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

CALL enable_logging(['QueryLog'], storage='file', storage_config={'path': 'output/logging_csv_log.csv', 'normalize': true});
-- bwc_tag:end_query

CALL truncate_duckdb_logs();
-- bwc_tag:end_query

CALL disable_logging();
-- bwc_tag:end_query

CALL enable_logging(['QueryLog'], storage='file', storage_config={'path': 'output/logging_csv_log_delim.csv', 'delim': ';'});
-- bwc_tag:end_query

SELECT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT message FROM read_csv('output/logging_csv_log_delim.csv', delim=';');
-- bwc_tag:end_query

