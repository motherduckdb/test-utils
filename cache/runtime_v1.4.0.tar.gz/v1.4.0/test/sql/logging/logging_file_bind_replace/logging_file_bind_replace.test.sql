-- bwc_tag:nb_steps=25
CALL enable_logging(['QueryLog'], storage_path='output/logging_file_bind_replace_log.csv');
-- bwc_tag:end_query

SELECT 1 as a
-- bwc_tag:end_query

FROM duckdb_logs_parsed('FileSystem');
-- bwc_tag:end_query

CALL disable_logging();
-- bwc_tag:end_query

DESCRIBE FROM duckdb_logs;
-- bwc_tag:end_query

SELECT message FROM duckdb_logs_parsed('QueryLog') WHERE starts_with(message, 'SELECT 1');
-- bwc_tag:end_query

CALL truncate_duckdb_logs();
-- bwc_tag:end_query

CALL enable_logging(['QueryLog'], storage='file', storage_config={'path': 'output/logging_file_bind_replace_normalized/', 'normalize': true});
-- bwc_tag:end_query

SELECT 1 as b
-- bwc_tag:end_query

FROM duckdb_logs
-- bwc_tag:end_query

CALL disable_logging();
-- bwc_tag:end_query

DESCRIBE FROM duckdb_logs
-- bwc_tag:end_query

SELECT message FROM duckdb_logs_parsed('QueryLog') WHERE starts_with(message, 'SELECT 1');
-- bwc_tag:end_query

CALL truncate_duckdb_logs();
-- bwc_tag:end_query

CALL enable_logging(['QueryLog'], storage='memory');
-- bwc_tag:end_query

SELECT 1 as c
-- bwc_tag:end_query

CALL disable_logging();
-- bwc_tag:end_query

DESCRIBE FROM duckdb_logs
-- bwc_tag:end_query

SELECT message FROM duckdb_logs_parsed('QueryLog') WHERE starts_with(message, 'SELECT 1');
-- bwc_tag:end_query

CALL truncate_duckdb_logs();
-- bwc_tag:end_query

CALL enable_logging(level='trace', storage='memory');
-- bwc_tag:end_query

SELECT 1 as d
-- bwc_tag:end_query

CALL disable_logging();
-- bwc_tag:end_query

DESCRIBE FROM duckdb_logs
-- bwc_tag:end_query

SELECT message FROM duckdb_logs_parsed('QueryLog') WHERE starts_with(message, 'SELECT 1');
-- bwc_tag:end_query

