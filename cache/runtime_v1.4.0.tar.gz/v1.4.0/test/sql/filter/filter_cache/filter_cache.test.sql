-- bwc_tag:nb_steps=5
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers AS SELECT a FROM generate_series(0, 9999, 1) tbl(a), generate_series(0, 9, 1) tbl2(b);
-- bwc_tag:end_query

SELECT COUNT(*) FROM integers WHERE a<5;
-- bwc_tag:end_query

SELECT COUNT(*) FROM (SELECT * FROM integers WHERE (a>1 AND a<10) OR a>9995) tbl(a) WHERE a<5;
-- bwc_tag:end_query

SELECT COUNT(*) FROM (SELECT * FROM (SELECT * FROM integers WHERE (a <> 3 AND a<50) OR (a > 9995)) WHERE a>1 AND a<20) tbl(a) WHERE a<5;
-- bwc_tag:end_query

