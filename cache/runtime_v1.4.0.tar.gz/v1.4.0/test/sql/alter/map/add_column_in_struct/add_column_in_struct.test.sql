-- bwc_tag:nb_steps=16
WITH cte as (
	select a::MAP(STRUCT(n INTEGER, m INTEGER), STRUCT(i INTEGER, j INTEGER)) a from
	VALUES
		(MAP {ROW(3,3): ROW(1, 1)}),
		(MAP {ROW(4,4): ROW(2, 2)})
	t(a)
)
SELECT remap_struct(
	a,
	NULL::MAP(STRUCT(n INTEGER, m INTEGER), STRUCT(i INTEGER, j INTEGER, k INTEGER)),
	{
		'key': 'key',
		'value': (
			'value', {
				'i': 'i',
				'j': 'j'
			}
		)
	},
	{
		'value': {
			'k': NULL::INTEGER
		}
	}
) from cte;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test(
	s MAP(
		STRUCT(
			n INTEGER,
			m INTEGER
		),
		STRUCT(
			i INTEGER,
			j INTEGER
		)
	)
)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES
	(MAP {ROW(3,3): ROW(1, 1)}),
	(MAP {ROW(4,4): ROW(2, 2)})
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test ADD COLUMN s.key.k INTEGER
-- bwc_tag:end_query

select * from test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test ADD COLUMN s.value.b VARCHAR
-- bwc_tag:end_query

select * from test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop table test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test(
	s STRUCT(
		a MAP(
			STRUCT(
				n INTEGER,
				m INTEGER
			),
			STRUCT(
				i INTEGER,
				j INTEGER
			)
		)
	)
)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES
	(ROW(MAP {ROW(3,3): ROW(1, 1)})),
	(ROW(MAP {ROW(4,4): ROW(2, 2)}))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test ADD COLUMN s.a.key.k INTEGER
-- bwc_tag:end_query

select * from test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test ADD COLUMN s.a.value.b VARCHAR
-- bwc_tag:end_query

select * from test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE test ADD COLUMN s.a.not_key INTEGER
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE test ADD COLUMN s.a.key INTEGER
-- bwc_tag:end_query

