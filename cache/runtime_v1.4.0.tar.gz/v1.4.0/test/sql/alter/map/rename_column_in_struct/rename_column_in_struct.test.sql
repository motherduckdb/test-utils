-- bwc_tag:nb_steps=15
-- bwc_tag:execute_from_sql
CREATE TABLE test(
	s MAP(
		STRUCT(
			n INTEGER,
			m INTEGER
		),
		STRUCT(
			i INTEGER,
			j INTEGER
		)
	)
)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES
	(MAP {ROW(3,3): ROW(1, 1)}),
	(MAP {ROW(4,4): ROW(2, 2)})
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE test RENAME COLUMN s.key to anything
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE test RENAME COLUMN s.value to anything
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test RENAME COLUMN s.value.j TO abc
-- bwc_tag:end_query

select * from test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test RENAME COLUMN s.key.n TO def
-- bwc_tag:end_query

select * from test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop table test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test(
	s STRUCT(
		a MAP(
			STRUCT(
				n INTEGER,
				m INTEGER
			),
			STRUCT(
				i INTEGER,
				j INTEGER
			)
		)
	)
)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES
	(ROW(MAP {ROW(3,3): ROW(1, 1)})),
	(ROW(MAP {ROW(4,4): ROW(2, 2)}))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test RENAME COLUMN s.a.key.m TO abc
-- bwc_tag:end_query

select * from test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test RENAME COLUMN s.a.value.j TO def
-- bwc_tag:end_query

select * from test;
-- bwc_tag:end_query

