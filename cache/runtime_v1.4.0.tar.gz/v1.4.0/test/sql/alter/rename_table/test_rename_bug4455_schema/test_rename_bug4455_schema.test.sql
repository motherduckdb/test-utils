-- bwc_tag:nb_steps=8
-- bwc_tag:execute_from_sql
create schema public;
-- bwc_tag:end_query

set schema=public;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table a1 (c int);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
alter table public.a1 rename to a2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
alter table a2 rename to a3;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create view v1 as select 42;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
alter view public.v1 rename to v2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
alter view v2 rename to v3;
-- bwc_tag:end_query

