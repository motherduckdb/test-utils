-- bwc_tag:nb_steps=7
-- bwc_tag:execute_from_sql
CREATE TABLE test(i INTEGER, j INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test SELECT i, i FROM range(100) tbl(i);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test DROP COLUMN i
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DELETE FROM test WHERE j%2=0
-- bwc_tag:end_query

SELECT COUNT(j), SUM(j) FROM test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
UPDATE test SET j=j+100
-- bwc_tag:end_query

SELECT COUNT(j), SUM(j) FROM test
-- bwc_tag:end_query

