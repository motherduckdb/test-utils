-- bwc_tag:nb_steps=6
-- bwc_tag:execute_from_sql
CREATE TABLE test(i INTEGER, j INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (1, 1), (2, 2)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE test DROP COLUMN blabla
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test DROP COLUMN IF EXISTS blabla
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test DROP COLUMN i
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE test DROP COLUMN j
-- bwc_tag:end_query

