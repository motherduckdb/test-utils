-- bwc_tag:nb_steps=1
-- bwc_tag:expected_result=error

SELECT (SELECT 42, 84)
-- bwc_tag:end_query

