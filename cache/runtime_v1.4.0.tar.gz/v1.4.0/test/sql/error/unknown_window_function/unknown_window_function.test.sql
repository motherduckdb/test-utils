-- bwc_tag:nb_steps=1
-- bwc_tag:expected_result=error

SELECT substr('hello', 3, 2) OVER ();
-- bwc_tag:end_query

