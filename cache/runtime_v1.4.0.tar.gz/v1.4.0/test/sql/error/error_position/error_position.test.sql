-- bwc_tag:nb_steps=3
-- bwc_tag:execute_from_sql
create macro checksum(x) as table SELECT bit_xor(md5_number(CAST(COLUMNS(*) AS VARCHAR))) FROM query_table(table_name);
-- bwc_tag:end_query

set errors_as_json=true;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select * from checksum('tbl');
-- bwc_tag:end_query

