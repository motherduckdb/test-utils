-- bwc_tag:nb_steps=21
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

SELECT typeof(100::UTINYINT + 1) == 'UTINYINT';
-- bwc_tag:end_query

SELECT typeof(100 + 1::UTINYINT) == 'UTINYINT';
-- bwc_tag:end_query

SELECT typeof(100::USMALLINT + 1) == 'USMALLINT';
-- bwc_tag:end_query

SELECT typeof(100 + 1::USMALLINT) == 'USMALLINT';
-- bwc_tag:end_query

SELECT typeof(100::UINTEGER + 1) == 'UINTEGER';
-- bwc_tag:end_query

SELECT typeof(100 + 1::UINTEGER) == 'UINTEGER';
-- bwc_tag:end_query

SELECT typeof(100::UBIGINT + 1) == 'UBIGINT';
-- bwc_tag:end_query

SELECT typeof(100 + 1::UBIGINT) == 'UBIGINT';
-- bwc_tag:end_query

SELECT typeof(100::TINYINT + 1) == 'TINYINT';
-- bwc_tag:end_query

SELECT typeof(100 + 1::TINYINT) == 'TINYINT';
-- bwc_tag:end_query

SELECT typeof(100::SMALLINT + 1) == 'SMALLINT';
-- bwc_tag:end_query

SELECT typeof(100 + 1::SMALLINT) == 'SMALLINT';
-- bwc_tag:end_query

SELECT typeof(100::INTEGER + 1) == 'INTEGER';
-- bwc_tag:end_query

SELECT typeof(100 + 1::INTEGER) == 'INTEGER';
-- bwc_tag:end_query

SELECT typeof(100::BIGINT + 1) == 'BIGINT';
-- bwc_tag:end_query

SELECT typeof(100 + 1::BIGINT) == 'BIGINT';
-- bwc_tag:end_query

SELECT typeof(1::TINYINT + 100);
-- bwc_tag:end_query

SELECT typeof(1::TINYINT + 10000);
-- bwc_tag:end_query

SELECT typeof(1.05 + 1)
-- bwc_tag:end_query

SELECT typeof(1 + 1);
-- bwc_tag:end_query

