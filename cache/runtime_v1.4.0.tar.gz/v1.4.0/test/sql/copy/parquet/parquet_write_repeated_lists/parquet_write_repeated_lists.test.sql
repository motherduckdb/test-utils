-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=4
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

COPY (
    SELECT *
            FROM (values(['asdf', 'fdsa']))
            JOIN (values(1),(2)) ON TRUE
) to 'output/lists.parquet';
-- bwc_tag:end_query

SELECT * FROM read_parquet('output/lists.parquet');
-- bwc_tag:end_query

