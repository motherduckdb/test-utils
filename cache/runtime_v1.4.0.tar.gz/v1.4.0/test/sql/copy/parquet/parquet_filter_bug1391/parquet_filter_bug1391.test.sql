-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=6
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW tbl AS SELECT * FROM PARQUET_SCAN('data/parquet-testing/filter_bug1391.parquet');
-- bwc_tag:end_query

SELECT ORGUNITID FROM tbl LIMIT 10
-- bwc_tag:end_query

SELECT COUNT(*) FROM tbl;
-- bwc_tag:end_query

SELECT COUNT(*) FROM tbl
WHERE Namevalidfrom <= '2017-03-01'
AND Namevalidto >= '2017-03-01'
AND Parentnamevalidfrom <= '2017-03-01'
AND Parentnamevalidto >= '2017-03-01'
AND CustomerCode = 'CODE';
-- bwc_tag:end_query

