-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=6
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

SELECT * FROM parquet_scan('data/parquet-testing/decimal/fixed_length_decimal.parquet')
-- bwc_tag:end_query

SELECT * FROM parquet_scan('data/parquet-testing/decimal/fixed_length_decimal_legacy.parquet')
-- bwc_tag:end_query

SELECT * FROM parquet_scan('data/parquet-testing/decimal/decimal_dc.parquet') limit 10
-- bwc_tag:end_query

SELECT * FROM parquet_scan('data/parquet-testing/decimal/pandas_decimal.parquet') limit 10
-- bwc_tag:end_query

