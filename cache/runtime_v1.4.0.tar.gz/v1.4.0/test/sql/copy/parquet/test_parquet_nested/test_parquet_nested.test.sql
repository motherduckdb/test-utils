-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=10
LOAD 'parquet';
-- bwc_tag:end_query

select * FROM parquet_scan('data/parquet-testing/map.parquet') sq limit 3;
-- bwc_tag:end_query

SELECT * FROM parquet_scan('data/parquet-testing/arrow/nested_lists.snappy.parquet')
-- bwc_tag:end_query

SELECT unnest(a) FROM parquet_scan('data/parquet-testing/arrow/nested_lists.snappy.parquet')
-- bwc_tag:end_query

SELECT * FROM parquet_scan('data/parquet-testing/arrow/list_columns.parquet')
-- bwc_tag:end_query

SELECT id, url FROM parquet_scan('data/parquet-testing/apkwan.parquet') limit 10
-- bwc_tag:end_query

select * from (SELECT id, unnest(url) u FROM parquet_scan('data/parquet-testing/apkwan.parquet')) sq where u is not null limit 10
-- bwc_tag:end_query

SELECT id, authors FROM parquet_scan('data/parquet-testing/apkwan.parquet') limit 10
-- bwc_tag:end_query

SELECT id, unnest(authors) FROM parquet_scan('data/parquet-testing/apkwan.parquet') limit 20
-- bwc_tag:end_query

SELECT id, struct_extract(unnest(authors), 'name'), struct_extract(unnest(authors), 'id') FROM parquet_scan('data/parquet-testing/apkwan.parquet') limit 20
-- bwc_tag:end_query

