-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=22
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE struct AS SELECT * FROM (VALUES
	({'a': 42, 'b': 84}),
	({'a': 33, 'b': 32}),
	({'a': 42, 'b': 27})
) tbl(i);
-- bwc_tag:end_query

COPY struct TO 'output/test_struct.parquet' (FORMAT 'parquet');
-- bwc_tag:end_query

SELECT * FROM parquet_scan('output/test_struct.parquet');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE struct_nulls AS SELECT * FROM (VALUES
	({'a': 42, 'b': 84}),
	({'a': NULL, 'b': 32}),
	(NULL),
	({'a': 42, 'b': NULL})
) tbl(i);
-- bwc_tag:end_query

COPY struct_nulls TO 'output/test_struct_nulls.parquet' (FORMAT 'parquet');
-- bwc_tag:end_query

SELECT * FROM parquet_scan('output/test_struct_nulls.parquet');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE struct_nested AS SELECT * FROM (VALUES
	({'a': {'x': 3, 'x1': 22}, 'b': {'y': 27, 'y1': 44}}),
	({'a': {'x': 9, 'x1': 26}, 'b': {'y': 1, 'y1': 999}}),
	({'a': {'x': 17, 'x1': 23}, 'b': {'y': 3, 'y1': 9999}})
) tbl(i);
-- bwc_tag:end_query

COPY struct_nested TO 'output/struct_nested.parquet' (FORMAT 'parquet');
-- bwc_tag:end_query

SELECT * FROM parquet_scan('output/struct_nested.parquet');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE struct_nested_null AS SELECT * FROM (VALUES
	({'a': {'x': 3, 'x1': 22}, 'b': {'y': NULL, 'y1': 44}}),
	({'a': {'x': NULL, 'x1': 26}, 'b': {'y': 1, 'y1': NULL}}),
	({'a': {'x': 17, 'x1': NULL}, 'b': {'y': 3, 'y1': 9999}}),
	(NULL),
	({'a': NULL, 'b': NULL})
) tbl(i);
-- bwc_tag:end_query

COPY struct_nested_null TO 'output/struct_nested_null.parquet' (FORMAT 'parquet');
-- bwc_tag:end_query

SELECT * FROM parquet_scan('output/struct_nested_null.parquet');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE single_struct AS SELECT * FROM (VALUES
	({'a': 42}),
	({'a': 33}),
	({'a': 42})
) tbl(i);
-- bwc_tag:end_query

COPY single_struct TO 'output/single_struct.parquet' (FORMAT 'parquet');
-- bwc_tag:end_query

SELECT * FROM parquet_scan('output/single_struct.parquet');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE single_struct_null AS SELECT * FROM (VALUES
	({'a': 42}),
	({'a': NULL}),
	(NULL)
) tbl(i);
-- bwc_tag:end_query

COPY single_struct_null TO 'output/single_struct_null.parquet' (FORMAT 'parquet');
-- bwc_tag:end_query

SELECT * FROM parquet_scan('output/single_struct_null.parquet');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE nested_single_struct AS SELECT * FROM (VALUES
	({'a': {'b': 42}}),
	({'a': {'b': NULL}}),
	({'a': NULL}),
	(NULL)
) tbl(i);
-- bwc_tag:end_query

COPY nested_single_struct TO 'output/nested_single_struct.parquet' (FORMAT 'parquet');
-- bwc_tag:end_query

SELECT * FROM parquet_scan('output/nested_single_struct.parquet');
-- bwc_tag:end_query

