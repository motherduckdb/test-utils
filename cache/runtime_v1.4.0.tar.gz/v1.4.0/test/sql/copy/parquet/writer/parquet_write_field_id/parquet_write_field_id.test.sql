-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=73
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

copy (select range as i from range(10)) to 'output/my.parquet' (FIELD_IDS)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

copy (select range as i from range(10)) to 'output/my.parquet' (FIELD_IDS {j:42})
-- bwc_tag:end_query

copy (select range as i from range(10)) to 'output/my.parquet' (FIELD_IDS {i:42})
-- bwc_tag:end_query

select field_id from parquet_schema('output/my.parquet') where name = 'i'
-- bwc_tag:end_query

copy (select range as i from range(10)) to 'output/my.parquet' (FIELD_IDS {i:'42'})
-- bwc_tag:end_query

select field_id from parquet_schema('output/my.parquet') where name = 'i'
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

copy (select range as i from range(10)) to 'output/my.parquet' (FIELD_IDS {i:'abc'})
-- bwc_tag:end_query

copy (select range as i from range(10)) to 'output/my.parquet' (FIELD_IDS {i:42::hugeint})
-- bwc_tag:end_query

select field_id from parquet_schema('output/my.parquet') where name = 'i'
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

copy (select range as i from range(10)) to 'output/my.parquet' (FIELD_IDS {i:1024::utinyint})
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

copy (select range as i from range(10)) to 'output/my.parquet' (FIELD_IDS {i:i})
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

copy (select range as i from range(10)) to 'output/my.parquet' (FIELD_IDS 'oops')
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

copy (select range as i, range as j from range(10)) to 'output/my.parquet' (FIELD_IDS {i:42,i:43})
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

copy (select range as i, range as j from range(10)) to 'output/my.parquet' (FIELD_IDS {i:42,j:41+1})
-- bwc_tag:end_query

copy (select range as i, range as j from range(10)) to 'output/my.parquet' (FIELD_IDS {i:42})
-- bwc_tag:end_query

select field_id from parquet_schema('output/my.parquet') where name = 'i'
-- bwc_tag:end_query

select field_id from parquet_schema('output/my.parquet') where name = 'j'
-- bwc_tag:end_query

copy (select range as i, range as j from range(10)) to 'output/my.parquet' (FIELD_IDS {i:42,j:43})
-- bwc_tag:end_query

select field_id from parquet_schema('output/my.parquet') where name = 'i'
-- bwc_tag:end_query

select field_id from parquet_schema('output/my.parquet') where name = 'j'
-- bwc_tag:end_query

copy (select range as i, range as j from range(10)) to 'output/my.parquet' (FIELD_IDS {i:{__duckdb_field_id:42},j:{__duckdb_field_id:43}})
-- bwc_tag:end_query

select field_id from parquet_schema('output/my.parquet') where name = 'i'
-- bwc_tag:end_query

select field_id from parquet_schema('output/my.parquet') where name = 'j'
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

copy (select range as i, range as j from range(10)) to 'output/my.parquet' (FIELD_IDS {i:{__duckdb_field_id:42,j:43}})
-- bwc_tag:end_query

copy (select range(range, range + 3) as i from range(10)) to 'output/my.parquet' (FIELD_IDS {i:{__duckdb_field_id:42,element:43}})
-- bwc_tag:end_query

select field_id from parquet_schema('output/my.parquet') where name = 'i'
-- bwc_tag:end_query

select field_id from parquet_schema('output/my.parquet') where name = 'element'
-- bwc_tag:end_query

copy (select range(range, range + 3) as i from range(10)) to 'output/my.parquet' (FIELD_IDS {i:{element:43}})
-- bwc_tag:end_query

select field_id from parquet_schema('output/my.parquet') where name = 'i'
-- bwc_tag:end_query

select field_id from parquet_schema('output/my.parquet') where name = 'element'
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

copy (select range(range, range + 3) as i from range(10)) to 'output/my.parquet' (FIELD_IDS {i:{__duckdb_field_id:42,elem:43}})
-- bwc_tag:end_query

copy (select {f : range} as i from range(10)) to 'output/my.parquet' (FIELD_IDS {i:{__duckdb_field_id:42,f:43}})
-- bwc_tag:end_query

select field_id from parquet_schema('output/my.parquet') where name = 'i' and num_children > 0
-- bwc_tag:end_query

select field_id from parquet_schema('output/my.parquet') where name = 'f'
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

copy (select {f : range} as i from range(10)) to 'output/my.parquet' (FIELD_IDS {i:{__duckdb_field_id:42,g:43}})
-- bwc_tag:end_query

copy (select map {range : 10 - range} as i from range(10)) to 'output/my.parquet' (FIELD_IDS {i:{__duckdb_field_id:42,key:43,value:44}})
-- bwc_tag:end_query

select field_id from parquet_schema('output/my.parquet') where name = 'i' and num_children > 0
-- bwc_tag:end_query

select field_id from parquet_schema('output/my.parquet') where name = 'key'
-- bwc_tag:end_query

select field_id from parquet_schema('output/my.parquet') where name = 'value'
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

copy (select map {range : 10 - range} as i from range(10)) to 'output/my.parquet' (FIELD_IDS {i:{__duckdb_field_id:42,k:43,v:44}})
-- bwc_tag:end_query

copy (select range as i, range as j from range(10)) to 'output/my.parquet' (FIELD_IDS 'auto')
-- bwc_tag:end_query

select field_id from parquet_schema('output/my.parquet') where name = 'i'
-- bwc_tag:end_query

select field_id from parquet_schema('output/my.parquet') where name = 'j'
-- bwc_tag:end_query

set variable field_id_values={i:{__duckdb_field_id:42,key:43,value:{__duckdb_field_id:44,element:{__duckdb_field_id:45,j:46}}}}
-- bwc_tag:end_query

copy (select map {'my_key' : [{j : 42}]} as i) to 'output/my.parquet' (FIELD_IDS getvariable('field_id_values'))
-- bwc_tag:end_query

select name, field_id from parquet_schema('output/my.parquet') where name in ('i', 'key', 'value', 'element', 'j') order by field_id
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

copy (select {f : range} as i from range(10)) to 'output/my.parquet' (FIELD_IDS {i:{__duckdb_field_id:42}, f:43})
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

copy (select {f : range} as i from range(10)) to 'output/my.parquet' (FIELD_IDS {i:{field_id:42, f:43}})
-- bwc_tag:end_query

copy (select range(range, range + 3) as i from range(10)) to 'output/my.parquet' (FIELD_IDS 'auto')
-- bwc_tag:end_query

select field_id from parquet_schema('output/my.parquet') where name = 'i'
-- bwc_tag:end_query

select field_id from parquet_schema('output/my.parquet') where name = 'element'
-- bwc_tag:end_query

copy (select {f : range} as i from range(10)) to 'output/my.parquet' (FIELD_IDS 'auto')
-- bwc_tag:end_query

select field_id from parquet_schema('output/my.parquet') where name = 'i' and num_children > 0
-- bwc_tag:end_query

select field_id from parquet_schema('output/my.parquet') where name = 'f'
-- bwc_tag:end_query

copy (select map {range : 10 - range} as i from range(10)) to 'output/my.parquet' (FIELD_IDS 'auto')
-- bwc_tag:end_query

select field_id from parquet_schema('output/my.parquet') where name = 'i' and num_children > 0
-- bwc_tag:end_query

select field_id from parquet_schema('output/my.parquet') where name = 'key'
-- bwc_tag:end_query

select field_id from parquet_schema('output/my.parquet') where name = 'value'
-- bwc_tag:end_query

copy (select map {'my_key' : [{j : 42}]} as i) to 'output/my.parquet' (FIELD_IDS 'auto')
-- bwc_tag:end_query

select name, field_id from parquet_schema('output/my.parquet') where name in ('i', 'key', 'value', 'element', 'j') order by field_id
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

copy (select range as __duckdb_field_id from range(10)) to 'output/my.parquet' (FIELD_IDS {__duckdb_field_id : 42})
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

copy (select {__duckdb_field_id : range} as __duckdb_field_id from range(10)) to 'output/my.parquet' (FIELD_IDS {__duckdb_field_id : {__duckdb_field_id : 42}})
-- bwc_tag:end_query

copy (select range as i from range(10)) to 'output/my.parquet' (FIELD_IDS {"I" : 42})
-- bwc_tag:end_query

select field_id from parquet_schema('output/my.parquet') where name = 'i'
-- bwc_tag:end_query

copy (select range as "I" from range(10)) to 'output/my.parquet' (FIELD_IDS {i : 42})
-- bwc_tag:end_query

select field_id from parquet_schema('output/my.parquet') where name = 'I'
-- bwc_tag:end_query

copy (select {f : range} as i from range(10)) to 'output/my.parquet' (FIELD_IDS {"I" : {__duckdb_field_id: 42, "F": 43}})
-- bwc_tag:end_query

select field_id from parquet_schema('output/my.parquet') where name = 'i' and num_children > 0
-- bwc_tag:end_query

select field_id from parquet_schema('output/my.parquet') where name = 'f'
-- bwc_tag:end_query

copy (select {"F" : range} as "I" from range(10)) to 'output/my.parquet' (FIELD_IDS {i : {__duckdb_field_id: 42, f: 43}})
-- bwc_tag:end_query

select field_id from parquet_schema('output/my.parquet') where name = 'I' and num_children > 0
-- bwc_tag:end_query

select field_id from parquet_schema('output/my.parquet') where name = 'F'
-- bwc_tag:end_query

