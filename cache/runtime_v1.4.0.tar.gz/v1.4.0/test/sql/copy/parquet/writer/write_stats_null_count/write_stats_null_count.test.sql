-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=21
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA explain_output = OPTIMIZED_ONLY;
-- bwc_tag:end_query

COPY (SELECT 42 i) TO 'output/stats.parquet' (FORMAT PARQUET);
-- bwc_tag:end_query

SELECT stats_null_count FROM parquet_metadata('output/stats.parquet')
-- bwc_tag:end_query

EXPLAIN SELECT COUNT(*) FROM 'output/stats.parquet' WHERE i IS NULL
-- bwc_tag:end_query

SELECT COUNT(*) FROM 'output/stats.parquet' WHERE i IS NULL
-- bwc_tag:end_query

COPY (SELECT NULL i) TO 'output/stats.parquet' (FORMAT PARQUET);
-- bwc_tag:end_query

SELECT stats_null_count FROM parquet_metadata('output/stats.parquet')
-- bwc_tag:end_query

EXPLAIN SELECT COUNT(*) FROM 'output/stats.parquet' WHERE i IS NULL
-- bwc_tag:end_query

SELECT COUNT(*) FROM 'output/stats.parquet' WHERE i IS NULL
-- bwc_tag:end_query

COPY (SELECT * FROM VALUES (42), (NULL) tbl(i)) TO 'output/stats.parquet' (FORMAT PARQUET);
-- bwc_tag:end_query

EXPLAIN SELECT COUNT(*) FROM 'output/stats.parquet' WHERE i IS NULL
-- bwc_tag:end_query

SELECT COUNT(*) FROM 'output/stats.parquet' WHERE i IS NULL
-- bwc_tag:end_query

COPY (SELECT [42, NULL, 43] i) TO 'output/stats.parquet' (FORMAT PARQUET);
-- bwc_tag:end_query

SELECT stats_null_count FROM parquet_metadata('output/stats.parquet')
-- bwc_tag:end_query

COPY (SELECT {'a': NULL, 'b': 42} i) TO 'output/stats.parquet' (FORMAT PARQUET);
-- bwc_tag:end_query

SELECT stats_null_count FROM parquet_metadata('output/stats.parquet')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE structs AS SELECT {'a': NULL, 'b': 'hello'} i UNION ALL SELECT NULL UNION ALL SELECT {'a': 84, 'b': 'world'};
-- bwc_tag:end_query

COPY structs TO 'output/stats.parquet' (FORMAT PARQUET);
-- bwc_tag:end_query

SELECT stats_null_count FROM parquet_metadata('output/stats.parquet')
-- bwc_tag:end_query

