-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=8
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table t (ts TIMESTAMP_S);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into t select make_timestamp((1706961600 + (360 * i))::BIGINT * 1000000) from range(10000) range(i);
-- bwc_tag:end_query

select * from t limit 3;
-- bwc_tag:end_query

copy (select * from t) to 'output/t.parquet' (format parquet);
-- bwc_tag:end_query

select * from 'output/t.parquet' limit 3;
-- bwc_tag:end_query

copy (select * from t) to 'output/t.parquet' (format parquet);
-- bwc_tag:end_query

select * from 'output/t.parquet' limit 3;
-- bwc_tag:end_query

