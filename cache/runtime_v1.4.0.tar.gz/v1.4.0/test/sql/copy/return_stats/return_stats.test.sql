-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=66
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers AS SELECT range i FROM range(200000);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE multi_column_test AS SELECT range i, range%10 j, case when range%2=0 then null else range end k FROM range(2500);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE floating_point_test AS SELECT case when i%10=0 then null else i/10.0 end as fp FROM range(2500) t(i)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE floating_point_nan AS SELECT case when i%10=0 then 'nan'::double when i%4=0 then null else i/10.0 end as fp FROM range(2500) t(i)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE fp_nan_only AS SELECT 'nan'::float as float_val
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE string_test AS SELECT concat('thisisalongstring_', range) s FROM range(2500);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE date_test AS
SELECT (TIMESTAMP '2000-01-01' + interval (range) day)::DATE dt,
       TIMESTAMP '2000-01-01 12:12:12.123456' + interval (range) day ts,
       (TIMESTAMP '2000-01-01 12:12:12' + interval (range) day)::TIMESTAMP_S ts_s,
       (TIMESTAMP '2000-01-01 12:12:12.123' + interval (range) day)::TIMESTAMP_MS ts_ms,
       concat((TIMESTAMP '2000-01-01 12:12:12.123456' + interval (range) day)::VARCHAR, '789')::TIMESTAMP_NS ts_ns,
       TIME '00:00:00' + interval (10 * range) second t
FROM range(2500);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE empty_test AS FROM range(2500) LIMIT 0;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE blob_test AS SELECT ''::BLOB AS bl UNION ALL SELECT '\x80\x00\x80'::BLOB
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE decimal_test AS
SELECT 25.3::DECIMAL(4,1) AS dec_i16,
       123456.789::DECIMAL(9,3) AS dec_i32,
       123456789123.456::DECIMAL(18,3) AS dec_i64
UNION ALL
SELECT 1.1::DECIMAL(4,1),
       2.123::DECIMAL(9,3),
       3.456::DECIMAL(18,3)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE struct_test AS SELECT case when i%10=0 then null else {'x': i, 'y': case when i%2=0 then 100 + i else null end} end struct_val FROM range(2500) t(i)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE list_test AS SELECT [i] l1, case when i%10=0 then null else [case when i%2=0 then 100 + i else null end] end l2 FROM range(2500) t(i)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE nested_struct_test AS SELECT {'s1': {'x': i}, 's2': {'s3': {'y': i}, 'l': [i]}} n FROM range(2500) t(i)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE funky_names AS SELECT {'quoted ''"field name"': 42} """quoted col name"""
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE map_test AS SELECT MAP {'key'||i: i} AS map_val FROM range(2500) t(i)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE array_test AS SELECT [i, i + 1, i + 2]::INT[3] AS array_val FROM range(2500) t(i)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE partitioned_test AS SELECT range%2 as partition_key, range val FROM range(2500)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE multi_partitioned_test AS SELECT range%2 as partition_key, range % 3 as partition_key2, range val FROM range(2500)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE large_string AS SELECT repeat('A', 254) || '🦆' AS val UNION ALL SELECT repeat('Z', 254) || '🦆'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE large_blob AS SELECT repeat('\x81', 4000)::BLOB AS val UNION ALL SELECT repeat('\x80', 4000)::BLOB
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE uuids AS SELECT uuid '47183823-2574-4bfd-b411-99ed177d3e43' uuid_val union all select uuid '00112233-4455-6677-8899-aabbccddeeff';
-- bwc_tag:end_query

SET preserve_insertion_order=true;
-- bwc_tag:end_query

COPY integers TO 'output/test_copy_to_file.parquet' (RETURN_STATS);
-- bwc_tag:end_query

COPY multi_column_test TO 'output/multi_column_copy.parquet' (RETURN_STATS);
-- bwc_tag:end_query

COPY string_test TO 'output/string_test.parquet' (RETURN_STATS);
-- bwc_tag:end_query

COPY date_test TO 'output/date_test.parquet' (RETURN_STATS);
-- bwc_tag:end_query

COPY empty_test TO 'output/empty_test.parquet' (RETURN_STATS);
-- bwc_tag:end_query

COPY blob_test TO 'output/blob_test.parquet' (RETURN_STATS);
-- bwc_tag:end_query

COPY decimal_test TO 'output/decimal_test.parquet' (RETURN_STATS);
-- bwc_tag:end_query

COPY floating_point_test TO 'output/fp.parquet' (RETURN_STATS);
-- bwc_tag:end_query

COPY floating_point_nan TO 'output/fp_nan.parquet' (RETURN_STATS);
-- bwc_tag:end_query

COPY fp_nan_only TO 'output/fp_nan_only.parquet' (RETURN_STATS);
-- bwc_tag:end_query

COPY large_string TO 'output/test_large_string.parquet' (RETURN_STATS);
-- bwc_tag:end_query

COPY large_blob TO 'output/test_large_blob.parquet' (RETURN_STATS);
-- bwc_tag:end_query

COPY uuids TO 'output/test_uuids.parquet' (RETURN_STATS);
-- bwc_tag:end_query

COPY struct_test TO 'output/struct_test.parquet' (RETURN_STATS);
-- bwc_tag:end_query

COPY list_test TO 'output/list_test.parquet' (RETURN_STATS);
-- bwc_tag:end_query

COPY nested_struct_test TO 'output/nested_struct_test.parquet' (RETURN_STATS);
-- bwc_tag:end_query

COPY funky_names TO 'output/funky_names.parquet' (RETURN_STATS);
-- bwc_tag:end_query

COPY map_test TO 'output/map_test.parquet' (RETURN_STATS);
-- bwc_tag:end_query

COPY array_test TO 'output/array_test.parquet' (RETURN_STATS);
-- bwc_tag:end_query

SET preserve_insertion_order=false;
-- bwc_tag:end_query

COPY integers TO 'output/test_copy_to_file.parquet' (RETURN_STATS);
-- bwc_tag:end_query

COPY multi_column_test TO 'output/multi_column_copy.parquet' (RETURN_STATS);
-- bwc_tag:end_query

COPY string_test TO 'output/string_test.parquet' (RETURN_STATS);
-- bwc_tag:end_query

COPY date_test TO 'output/date_test.parquet' (RETURN_STATS);
-- bwc_tag:end_query

COPY empty_test TO 'output/empty_test.parquet' (RETURN_STATS);
-- bwc_tag:end_query

COPY blob_test TO 'output/blob_test.parquet' (RETURN_STATS);
-- bwc_tag:end_query

COPY decimal_test TO 'output/decimal_test.parquet' (RETURN_STATS);
-- bwc_tag:end_query

COPY floating_point_test TO 'output/fp.parquet' (RETURN_STATS);
-- bwc_tag:end_query

COPY floating_point_nan TO 'output/fp_nan.parquet' (RETURN_STATS);
-- bwc_tag:end_query

COPY fp_nan_only TO 'output/fp_nan_only.parquet' (RETURN_STATS);
-- bwc_tag:end_query

COPY large_string TO 'output/test_large_string.parquet' (RETURN_STATS);
-- bwc_tag:end_query

COPY large_blob TO 'output/test_large_blob.parquet' (RETURN_STATS);
-- bwc_tag:end_query

COPY uuids TO 'output/test_uuids.parquet' (RETURN_STATS);
-- bwc_tag:end_query

COPY struct_test TO 'output/struct_test.parquet' (RETURN_STATS);
-- bwc_tag:end_query

COPY list_test TO 'output/list_test.parquet' (RETURN_STATS);
-- bwc_tag:end_query

COPY nested_struct_test TO 'output/nested_struct_test.parquet' (RETURN_STATS);
-- bwc_tag:end_query

COPY funky_names TO 'output/funky_names.parquet' (RETURN_STATS);
-- bwc_tag:end_query

COPY map_test TO 'output/map_test.parquet' (RETURN_STATS);
-- bwc_tag:end_query

COPY array_test TO 'output/array_test.parquet' (RETURN_STATS);
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
COPY partitioned_test TO 'output/partitioned_test' (FORMAT PARQUET, PARTITION_BY (partition_key), RETURN_STATS, OVERWRITE);
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
COPY multi_partitioned_test TO 'output/multi_partitioned_test' (FORMAT PARQUET, PARTITION_BY (partition_key, partition_key2), RETURN_STATS, OVERWRITE);
-- bwc_tag:end_query

COPY (FROM test_all_types()) TO 'output/test_all_types.parquet' (RETURN_STATS);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

COPY integers TO 'output/test_copy_to_file.csv' (RETURN_STATS);
-- bwc_tag:end_query

