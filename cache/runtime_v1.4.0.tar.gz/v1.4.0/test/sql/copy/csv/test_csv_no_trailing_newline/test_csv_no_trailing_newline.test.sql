-- bwc_tag:nb_steps=4
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE no_newline (a INTEGER, b INTEGER, c VARCHAR(10));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY no_newline FROM 'data/csv/test/no_newline.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/test/no_newline_unicode.csv', delim= '🦆') limit 5;
-- bwc_tag:end_query

