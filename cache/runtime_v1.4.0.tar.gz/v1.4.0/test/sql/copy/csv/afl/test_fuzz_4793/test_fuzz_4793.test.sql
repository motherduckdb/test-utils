-- bwc_tag:needed_extensions=json
-- bwc_tag:nb_steps=4
LOAD 'json';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/4793/crashes/case_0.csv', auto_detect=false, columns={'a':'varchar'}, delim='', encoding='latin-1', header=false, quote='');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/4793/crashes/case_1.csv', auto_detect=false, buffer_size=42, columns={'a':'INTEGER','b':'INTEGER', 'c':'VARCHAR'}, delim=';', escape='"', quote='"');
-- bwc_tag:end_query

