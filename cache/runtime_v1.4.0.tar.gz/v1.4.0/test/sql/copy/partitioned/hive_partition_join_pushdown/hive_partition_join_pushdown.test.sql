-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=13
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tbl AS SELECT i//1000 AS partition, i FROM range(10000) t(i)
-- bwc_tag:end_query

COPY tbl TO 'output/partition_join_pushdown' (FORMAT parquet, PARTITION_BY (partition))
-- bwc_tag:end_query

EXPLAIN ANALYZE SELECT COUNT(*), MIN(partition), MAX(partition), SUM(i)
FROM 'output/partition_join_pushdown/**/*.parquet'
-- bwc_tag:end_query

SELECT COUNT(*), MIN(partition), MAX(partition), SUM(i)
FROM 'output/partition_join_pushdown/**/*.parquet'
WHERE partition=(SELECT MAX(partition) FROM tbl)
-- bwc_tag:end_query

EXPLAIN ANALYZE SELECT COUNT(*), MIN(partition), MAX(partition), SUM(i)
FROM 'output/partition_join_pushdown/**/*.parquet'
WHERE partition=(SELECT MAX(partition) FROM tbl)
-- bwc_tag:end_query

SELECT COUNT(*), MIN(partition), MAX(partition), SUM(i)
FROM 'output/partition_join_pushdown/**/*.parquet'
WHERE i>=9980 AND partition=(SELECT MAX(partition) FROM tbl)
-- bwc_tag:end_query

SELECT COUNT(*), MIN(partition), MAX(partition), SUM(i)
FROM 'output/partition_join_pushdown/**/*.parquet'
WHERE partition>5 AND partition=(SELECT MAX(partition) FROM tbl)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tbl2 AS SELECT (date '2000-01-01' + interval (i//2000) years)::DATE AS part1, i%2 AS part2, i FROM range(10000) t(i)
-- bwc_tag:end_query

COPY tbl2 TO 'output/partition_join_pushdown_multi' (FORMAT parquet, PARTITION_BY (part1, part2))
-- bwc_tag:end_query

SELECT COUNT(*), MIN(part1), MAX(part1), MIN(part2), MAX(part2), SUM(i)
FROM 'output/partition_join_pushdown_multi/**/*.parquet'
WHERE part1=(SELECT MAX(part1) FROM tbl2) AND part2=(SELECT MAX(part2) FROM tbl2)
-- bwc_tag:end_query

SELECT COUNT(*), MIN(part2), MAX(part2), MIN(part1), MAX(part1), SUM(i)
FROM 'output/partition_join_pushdown_multi/**/*.parquet'
WHERE part2=(SELECT MAX(part2) FROM tbl2) AND part1=date '2004-01-01'
-- bwc_tag:end_query

SELECT COUNT(*)
FROM 'output/partition_join_pushdown_multi/**/*.parquet'
WHERE part2=(SELECT MAX(part2) FROM tbl2)
-- bwc_tag:end_query

