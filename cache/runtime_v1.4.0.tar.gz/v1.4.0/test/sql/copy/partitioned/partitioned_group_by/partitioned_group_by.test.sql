-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=21
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE partitioned_tbl AS SELECT i%2 AS partition, i col1, i // 7 col2, (i%3)::VARCHAR col3 FROM range(10000) t(i)
-- bwc_tag:end_query

COPY partitioned_tbl TO 'output/partition_group_by' (FORMAT parquet, PARTITION_BY (partition))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE partitioned_tbl
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW partitioned_tbl AS FROM 'output/partition_group_by/**/*.parquet'
-- bwc_tag:end_query

SELECT partition, SUM(col1)
FROM partitioned_tbl
GROUP BY partition
ORDER BY ALL
-- bwc_tag:end_query

EXPLAIN SELECT partition, SUM(col1)
FROM partitioned_tbl
GROUP BY partition
ORDER BY ALL
-- bwc_tag:end_query

SELECT partition, COUNT(DISTINCT col2)
FROM partitioned_tbl
GROUP BY partition
ORDER BY ALL
-- bwc_tag:end_query

SELECT partition, SUM(col1)
FROM partitioned_tbl
GROUP BY GROUPING SETS ((), (partition))
ORDER BY ALL
-- bwc_tag:end_query

SELECT partition, SUM(col1) FILTER (col2%7>2)
FROM partitioned_tbl
GROUP BY partition
ORDER BY ALL
-- bwc_tag:end_query

SELECT SUM(col1), partition
FROM partitioned_tbl
GROUP BY partition
ORDER BY ALL
-- bwc_tag:end_query

SELECT partition, SUM(col1)
FROM partitioned_tbl
WHERE col2 > 100
GROUP BY partition
ORDER BY ALL
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE partitioned_tbl2 AS SELECT i%2 AS partition1, i%3 AS partition2, i col1, i + 1 col2 FROM range(10000) t(i)
-- bwc_tag:end_query

COPY partitioned_tbl2 TO 'output/partition_group_by_multiple' (FORMAT parquet, PARTITION_BY (partition1, partition2))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE partitioned_tbl2
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW partitioned_tbl2 AS FROM 'output/partition_group_by_multiple/**/*.parquet'
-- bwc_tag:end_query

SELECT partition1, partition2, SUM(col1)
FROM partitioned_tbl2
GROUP BY partition1, partition2
ORDER BY ALL
-- bwc_tag:end_query

SELECT partition1, SUM(col1)
FROM partitioned_tbl2
GROUP BY partition1
ORDER BY ALL
-- bwc_tag:end_query

SELECT partition2, SUM(col1)
FROM partitioned_tbl2
GROUP BY partition2
ORDER BY ALL
-- bwc_tag:end_query

SELECT partition1, SUM(col1)
FROM partitioned_tbl2
WHERE partition2=0
GROUP BY partition1
ORDER BY ALL
-- bwc_tag:end_query

SELECT partition1, partition2, SUM(col1)
FROM partitioned_tbl2
GROUP BY GROUPING SETS ((partition1), (partition2))
ORDER BY ALL
-- bwc_tag:end_query

