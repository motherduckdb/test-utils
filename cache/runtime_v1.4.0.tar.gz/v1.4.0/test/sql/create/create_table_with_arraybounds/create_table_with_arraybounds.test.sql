-- bwc_tag:nb_steps=9
-- bwc_tag:execute_from_sql
create table T (
	vis enum ('hide', 'visible')[]
);
-- bwc_tag:end_query

select column_type from (describe T);
-- bwc_tag:end_query

attach ':memory:' as db2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create schema schema2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create schema db2.schema3;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create type schema2.foo as VARCHAR;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create type db2.schema3.bar as BOOL;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

create table B (
	vis schema2.foo[]
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

create table B (
	vis db2.schema3.bar[]
);
-- bwc_tag:end_query

