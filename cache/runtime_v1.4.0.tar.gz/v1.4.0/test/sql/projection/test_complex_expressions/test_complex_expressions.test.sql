-- bwc_tag:nb_steps=38
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE exprtest (a INTEGER, b INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO exprtest VALUES (42, 10), (43, 100), (NULL, 1), (45, -1)
-- bwc_tag:end_query

SELECT * FROM exprtest
-- bwc_tag:end_query

SELECT a FROM exprtest WHERE a BETWEEN 43 AND 44
-- bwc_tag:end_query

SELECT a FROM exprtest WHERE a NOT BETWEEN 43 AND 44
-- bwc_tag:end_query

SELECT a FROM exprtest WHERE a BETWEEN b AND 44
-- bwc_tag:end_query

SELECT CASE a WHEN 42 THEN 100 WHEN 43 THEN 200 ELSE 300 END FROM exprtest
-- bwc_tag:end_query

SELECT CASE WHEN a = 42 THEN 100 WHEN a = 43 THEN 200 ELSE 300 END FROM exprtest
-- bwc_tag:end_query

SELECT CASE WHEN a = 42 THEN 100 WHEN a = 43 THEN 200 END FROM exprtest
-- bwc_tag:end_query

SELECT ABS(1), ABS(-1), ABS(NULL)
-- bwc_tag:end_query

SELECT ABS(b) FROM exprtest
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE intest (a INTEGER, b INTEGER, c INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO intest VALUES (42, 42, 42), (43, 42, 42), (44, 41, 44);
-- bwc_tag:end_query

SELECT * FROM intest WHERE a IN (42, 43)
-- bwc_tag:end_query

SELECT a IN (42, 43) FROM intest
-- bwc_tag:end_query

SELECT * FROM intest WHERE a IN (86, 103, 162)
-- bwc_tag:end_query

SELECT * FROM intest WHERE a IN (NULL, NULL, NULL, NULL)
-- bwc_tag:end_query

SELECT * FROM intest WHERE a IN (b)
-- bwc_tag:end_query

SELECT * FROM intest WHERE a IN (b, c)
-- bwc_tag:end_query

SELECT * FROM intest WHERE a IN (43, b) ORDER BY 1
-- bwc_tag:end_query

SELECT * FROM intest WHERE a NOT IN (42, 43)
-- bwc_tag:end_query

SELECT * FROM intest WHERE a NOT IN (86, 103, 162) ORDER BY 1
-- bwc_tag:end_query

SELECT * FROM intest WHERE a NOT IN (NULL, NULL)
-- bwc_tag:end_query

SELECT * FROM intest WHERE a NOT IN (b) ORDER BY 1
-- bwc_tag:end_query

SELECT * FROM intest WHERE a NOT IN (b, c)
-- bwc_tag:end_query

SELECT * FROM intest WHERE a NOT IN (43, b)
-- bwc_tag:end_query

SELECT * FROM intest WHERE NULL IN ('a', 'b')
-- bwc_tag:end_query

SELECT * FROM intest WHERE NULL NOT IN ('a', 'b')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE strtest (a INTEGER, b VARCHAR)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO strtest VALUES (1, 'a'), (2, 'h'), (3, 'd')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO strtest VALUES (4, NULL)
-- bwc_tag:end_query

SELECT a FROM strtest WHERE b = 'a'
-- bwc_tag:end_query

SELECT a FROM strtest WHERE b <> 'a'
-- bwc_tag:end_query

SELECT a FROM strtest WHERE b < 'h'
-- bwc_tag:end_query

SELECT a FROM strtest WHERE b <= 'h'
-- bwc_tag:end_query

SELECT a FROM strtest WHERE b > 'h'
-- bwc_tag:end_query

SELECT a FROM strtest WHERE b >= 'h'
-- bwc_tag:end_query

