-- bwc_tag:nb_steps=19
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(col1 INTEGER, col2 INTEGER, k INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (1, 2, 3)
-- bwc_tag:end_query

SELECT COLUMNS(lambda x: x LIKE 'col%') FROM integers
-- bwc_tag:end_query

SELECT * LIKE 'col%' FROM integers
-- bwc_tag:end_query

SELECT * NOT LIKE 'col%' FROM integers
-- bwc_tag:end_query

SELECT * ILIKE 'COL%' FROM integers
-- bwc_tag:end_query

SELECT * SIMILAR TO '.*col.*' FROM integers
-- bwc_tag:end_query

SELECT * EXCLUDE (col1) SIMILAR TO '.*col.*' FROM integers
-- bwc_tag:end_query

SELECT c2, c1 FROM (
SELECT * SIMILAR TO 'number(\d+)' AS 'c\1' FROM (SELECT 1 AS number1, 2 AS number2, 3 AS end)
)
-- bwc_tag:end_query

SELECT val FROM (
SELECT * NOT LIKE '%number%' AS val FROM (SELECT 1 AS number1, 2 AS number2, 3 AS end)
)
-- bwc_tag:end_query

SELECT * LIKE '\_%' ESCAPE '\' AS val FROM (SELECT 1 AS number1, 2 AS _number2)
-- bwc_tag:end_query

SELECT * NOT LIKE '\_%' ESCAPE '\' AS val FROM (SELECT 1 AS number1, 2 AS _number2)
-- bwc_tag:end_query

SELECT * ILIKE '\_NUM%' ESCAPE '\' AS val FROM (SELECT 1 AS number1, 2 AS _number2)
-- bwc_tag:end_query

SELECT * NOT ILIKE '\_NUM%' ESCAPE '\' AS val FROM (SELECT 1 AS number1, 2 AS _number2)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * SIMILAR TO pattern FROM integers, (SELECT '.*col.*') t(pattern)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * + 42 FROM integers
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * REPLACE (col1 + 42 AS col1) SIMILAR TO '.*col.*' FROM integers
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * RENAME (col1 AS other_) SIMILAR TO '.*col.*' FROM integers
-- bwc_tag:end_query

