-- bwc_tag:nb_steps=19
-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers SELECT * FROM range(0, 1000, 1);
-- bwc_tag:end_query

SELECT SUM(i) FROM integers;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers SELECT * FROM range(0, -1000, -1);
-- bwc_tag:end_query

SELECT SUM(i) FROM integers;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers SELECT * FROM range(0, -1000, -1);
-- bwc_tag:end_query

SELECT SUM(i) FROM integers;
-- bwc_tag:end_query

SELECT SUM(1) FROM integers;
-- bwc_tag:end_query

SELECT SUM(-1) FROM integers;
-- bwc_tag:end_query

SELECT SUM(-1) FROM integers WHERE i=-1;
-- bwc_tag:end_query

SELECT SUM(-1) FROM integers WHERE i>10000;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE bigints(b BIGINT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO bigints SELECT * FROM range(4611686018427387904, 4611686018427388904, 1);
-- bwc_tag:end_query

SELECT SUM(b) FROM bigints
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT SUM(b)::BIGINT FROM bigints
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE doubles(n DOUBLE);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO doubles (n) VALUES ('9007199254740992'::DOUBLE), (1::DOUBLE), (1::DOUBLE), (0::DOUBLE);
-- bwc_tag:end_query

SELECT sum(n ORDER BY ABS(n))::BIGINT FROM doubles;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT (sum(n) WITHIN GROUP(ORDER BY ABS(n)))::BIGINT FROM doubles;
-- bwc_tag:end_query

