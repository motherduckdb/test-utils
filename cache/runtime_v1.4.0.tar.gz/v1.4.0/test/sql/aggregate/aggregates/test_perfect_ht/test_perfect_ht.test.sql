-- bwc_tag:nb_steps=52
SET default_null_order='nulls_first';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA perfect_ht_threshold=20;
-- bwc_tag:end_query

SET disabled_optimizers to 'compressed_materialization'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE timeseries(year INTEGER, val INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO timeseries VALUES (1996, 10), (1997, 12), (1996, 20), (2001, 30), (NULL, 1), (1996, NULL);
-- bwc_tag:end_query

SELECT year, SUM(val), COUNT(val), COUNT(*) FROM timeseries GROUP BY year ORDER BY year;
-- bwc_tag:end_query

SELECT year, LIST(val), STRING_AGG(val::VARCHAR, ',') FROM timeseries GROUP BY year ORDER BY year;
-- bwc_tag:end_query

SET disabled_optimizers to ''
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE timeseries(year INTEGER, val INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO timeseries VALUES (1996, 10), (1997, 12), (1996, 20), (2001, 30), (NULL, 1), (1996, NULL);
-- bwc_tag:end_query

SELECT year, SUM(val), COUNT(val), COUNT(*) FROM timeseries GROUP BY year ORDER BY year;
-- bwc_tag:end_query

SELECT year, LIST(val), STRING_AGG(val::VARCHAR, ',') FROM timeseries GROUP BY year ORDER BY year;
-- bwc_tag:end_query

SET disabled_optimizers to 'compressed_materialization'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE timeseries(year UINTEGER, val UINTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO timeseries VALUES (1996, 10), (1997, 12), (1996, 20), (2001, 30), (NULL, 1), (1996, NULL);
-- bwc_tag:end_query

SELECT year, SUM(val), COUNT(val), COUNT(*) FROM timeseries GROUP BY year ORDER BY year;
-- bwc_tag:end_query

SELECT year, LIST(val), STRING_AGG(val::VARCHAR, ',') FROM timeseries GROUP BY year ORDER BY year;
-- bwc_tag:end_query

SET disabled_optimizers to ''
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE timeseries(year UINTEGER, val UINTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO timeseries VALUES (1996, 10), (1997, 12), (1996, 20), (2001, 30), (NULL, 1), (1996, NULL);
-- bwc_tag:end_query

SELECT year, SUM(val), COUNT(val), COUNT(*) FROM timeseries GROUP BY year ORDER BY year;
-- bwc_tag:end_query

SELECT year, LIST(val), STRING_AGG(val::VARCHAR, ',') FROM timeseries GROUP BY year ORDER BY year;
-- bwc_tag:end_query

SET disabled_optimizers to 'compressed_materialization'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE timeseries(year BIGINT, val BIGINT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO timeseries VALUES (1996, 10), (1997, 12), (1996, 20), (2001, 30), (NULL, 1), (1996, NULL);
-- bwc_tag:end_query

SELECT year, SUM(val), COUNT(val), COUNT(*) FROM timeseries GROUP BY year ORDER BY year;
-- bwc_tag:end_query

SELECT year, LIST(val), STRING_AGG(val::VARCHAR, ',') FROM timeseries GROUP BY year ORDER BY year;
-- bwc_tag:end_query

SET disabled_optimizers to ''
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE timeseries(year BIGINT, val BIGINT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO timeseries VALUES (1996, 10), (1997, 12), (1996, 20), (2001, 30), (NULL, 1), (1996, NULL);
-- bwc_tag:end_query

SELECT year, SUM(val), COUNT(val), COUNT(*) FROM timeseries GROUP BY year ORDER BY year;
-- bwc_tag:end_query

SELECT year, LIST(val), STRING_AGG(val::VARCHAR, ',') FROM timeseries GROUP BY year ORDER BY year;
-- bwc_tag:end_query

SET disabled_optimizers to 'compressed_materialization'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE timeseries(year UBIGINT, val UBIGINT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO timeseries VALUES (1996, 10), (1997, 12), (1996, 20), (2001, 30), (NULL, 1), (1996, NULL);
-- bwc_tag:end_query

SELECT year, SUM(val), COUNT(val), COUNT(*) FROM timeseries GROUP BY year ORDER BY year;
-- bwc_tag:end_query

SELECT year, LIST(val), STRING_AGG(val::VARCHAR, ',') FROM timeseries GROUP BY year ORDER BY year;
-- bwc_tag:end_query

SET disabled_optimizers to ''
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE timeseries(year UBIGINT, val UBIGINT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO timeseries VALUES (1996, 10), (1997, 12), (1996, 20), (2001, 30), (NULL, 1), (1996, NULL);
-- bwc_tag:end_query

SELECT year, SUM(val), COUNT(val), COUNT(*) FROM timeseries GROUP BY year ORDER BY year;
-- bwc_tag:end_query

SELECT year, LIST(val), STRING_AGG(val::VARCHAR, ',') FROM timeseries GROUP BY year ORDER BY year;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table manycolumns as select i a, i b, i c, i d, i e from range(0,2) tbl(i);
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
select a, b, c, d, e FROM manycolumns GROUP BY 1, 2, 3, 4, 5
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tinyints AS SELECT i::TINYINT::VARCHAR AS t FROM range(-127, 128) tbl(i);
-- bwc_tag:end_query

SELECT COUNT(DISTINCT i), MIN(i), MAX(i), SUM(i) / COUNT(i) FROM (SELECT t::TINYINT t1 FROM tinyints GROUP BY t1) tbl(i)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE smallints AS SELECT i::SMALLINT::VARCHAR AS t FROM range(-32767, 32768) tbl(i);
-- bwc_tag:end_query

SELECT COUNT(DISTINCT i), MIN(i), MAX(i), SUM(i) / COUNT(i) FROM (SELECT t::SMALLINT t1 FROM smallints GROUP BY t1) tbl(i)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA disable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table dates as select date '1992-01-01' + concat(i, ' months')::interval as d from range(100) tbl(i);
-- bwc_tag:end_query

select extract(year from d), extract(month from d) from dates group by 1, 2 ORDER BY ALL;
-- bwc_tag:end_query

