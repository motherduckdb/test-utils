-- bwc_tag:nb_steps=28
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA verify_external
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select approx_count_distinct(*)
-- bwc_tag:end_query

select approx_count_distinct(1)
-- bwc_tag:end_query

select approx_count_distinct(NULL)
-- bwc_tag:end_query

select approx_count_distinct('hello')
-- bwc_tag:end_query

select approx_count_distinct(10), approx_count_distinct('hello') from range(100);
-- bwc_tag:end_query

select approx_count_distinct(i) from range (100) tbl(i) WHERE 1 == 0;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE IF NOT EXISTS dates (t date);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO dates VALUES ('2008-01-01'), (NULL), ('2007-01-01'), ('2008-02-01'), ('2008-01-02'), ('2008-01-01'), ('2008-01-01'), ('2008-01-01')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE IF NOT EXISTS timestamp (t TIMESTAMP);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO timestamp VALUES ('2008-01-01 00:00:01'), (NULL), ('2007-01-01 00:00:01'), ('2008-02-01 00:00:01'), ('2008-01-02 00:00:01'), ('2008-01-01 10:00:00'), ('2008-01-01 00:10:00'), ('2008-01-01 00:00:10')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE IF NOT EXISTS names (t string);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO names VALUES ('Pedro'), (NULL), ('Pedro'), ('Pedro'), ('Mark'), ('Mark'),('Mark'),('Hannes-Muehleisen'),('Hannes-Muehleisen')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create  table t as select range a, mod(range,10) b from range(2000);
-- bwc_tag:end_query

SELECT COUNT( a),approx_count_distinct(a),approx_count_distinct(b) from t
-- bwc_tag:end_query

SELECT approx_count_distinct(a) from t group by a %2 order by all;
-- bwc_tag:end_query

SELECT count(*) from t where a < 10;
-- bwc_tag:end_query

SELECT approx_count_distinct(a) over (partition by a%2) from t where a < 10;
-- bwc_tag:end_query

SELECT COUNT( t),approx_count_distinct(t) from timestamp
-- bwc_tag:end_query

SELECT COUNT( t),approx_count_distinct(t) from dates
-- bwc_tag:end_query

SELECT COUNT(t),approx_count_distinct(t) from names
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table customers (cname varchar)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into customers values ('Customer#000000001'), ('Customer#000000002'), ('Customer#000000003'), ('Customer#000000004')
-- bwc_tag:end_query

select approx_count_distinct(cname) from customers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table issue5259(c0 int);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into issue5259 values (1),(2),(3);
-- bwc_tag:end_query

SELECT approx_count_distinct(c0 ORDER BY (c0, 1)) FROM issue5259;
-- bwc_tag:end_query

