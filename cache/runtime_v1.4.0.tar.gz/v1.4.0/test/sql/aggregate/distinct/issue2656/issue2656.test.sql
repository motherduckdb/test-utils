-- bwc_tag:nb_steps=7
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE T (t1 int, t2 int);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t VALUES (1, 1), (1, 2);
-- bwc_tag:end_query

SELECT DISTINCT t1
FROM T
ORDER BY t1, t2;
-- bwc_tag:end_query

SELECT DISTINCT ON (1) t1, t2
FROM T
ORDER BY t1, t2;
-- bwc_tag:end_query

SELECT DISTINCT t1 FROM T
UNION
SELECT DISTINCT t1 FROM T
ORDER BY t1;
-- bwc_tag:end_query

SELECT DISTINCT t1 FROM T
UNION ALL
SELECT DISTINCT t1 FROM T
ORDER BY t1;
-- bwc_tag:end_query

