-- bwc_tag:nb_steps=23
SET default_null_order='nulls_first';
-- bwc_tag:end_query

CREATE TEMPORARY TABLE integers(i INTEGER, j INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE UNIQUE INDEX uidx ON integers (i,j)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (3, 4), (2, 5)
-- bwc_tag:end_query

SELECT * FROM integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO integers VALUES (6, 6), (3, 4);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (NULL, 6), (NULL, 6), (NULL, 7)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

UPDATE integers SET i=77 WHERE i IS NULL
-- bwc_tag:end_query

SELECT * FROM integers ORDER BY i, j
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
UPDATE integers SET i=77 WHERE i IS NULL AND j=7
-- bwc_tag:end_query

SELECT * FROM integers ORDER BY i, j
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (NULL, 6), (NULL, 7)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (NULL, 6), (NULL, 7)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (NULL, 6), (NULL, 7)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (NULL, 6), (NULL, 7)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (NULL, 6), (NULL, 7)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (NULL, 6), (NULL, 7)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (NULL, 6), (NULL, 7)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (NULL, 6), (NULL, 7)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (NULL, 6), (NULL, 7)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (NULL, 6), (NULL, 7)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO integers VALUES  (3, 4)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE integers
-- bwc_tag:end_query

