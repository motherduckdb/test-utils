-- bwc_tag:nb_steps=6
-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER, j VARCHAR, PRIMARY KEY(i, j))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (3, 'hello'), (3, 'world')
-- bwc_tag:end_query

SELECT * FROM integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO integers VALUES (6, 'bla'), (3, 'hello');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (6, 'bla');
-- bwc_tag:end_query

SELECT * FROM integers
-- bwc_tag:end_query

