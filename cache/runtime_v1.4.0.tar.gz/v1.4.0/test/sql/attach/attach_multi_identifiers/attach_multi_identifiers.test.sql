-- bwc_tag:nb_steps=27
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

ATTACH ':memory:' AS db1;
-- bwc_tag:end_query

ATTACH ':memory:' AS db2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA db1.s1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA db2.s1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE db1.s1.t(c INT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE db2.s1.t(c INT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO db1.s1.t VALUES (42);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO db2.s1.t SELECT c * 2 FROM db1.s1.t
-- bwc_tag:end_query

SELECT * FROM db1.s1.t, db2.s1.t
-- bwc_tag:end_query

SELECT db1.t.c, db2.t.c FROM db1.s1.t, db2.s1.t
-- bwc_tag:end_query

SELECT db1.s1.t.c, db2.s1.t.c FROM db1.s1.t, db2.s1.t
-- bwc_tag:end_query

SELECT * EXCLUDE (db1.s1.t.c) FROM db1.s1.t, db2.s1.t
-- bwc_tag:end_query

SELECT * EXCLUDE (DB1.S1.T.C) FROM db1.s1.t, db2.s1.t
-- bwc_tag:end_query

SELECT * EXCLUDE (s1.t.c) FROM db1.s1.t, (SELECT 42) t
-- bwc_tag:end_query

SELECT * EXCLUDE (new_col) FROM (SELECT * RENAME (db1.s1.t.c AS new_col) FROM db1.s1.t, db2.s1.t)
-- bwc_tag:end_query

SELECT * EXCLUDE (new_col) FROM (SELECT * RENAME (DB1.S1.T.C AS new_col) FROM db1.s1.t, db2.s1.t)
-- bwc_tag:end_query

SELECT * EXCLUDE (new_col) FROM (SELECT * RENAME (s1.t.c AS new_col) FROM db1.s1.t, (SELECT 42) t)
-- bwc_tag:end_query

SELECT db1.s1.t, db2.s1.t FROM db1.s1.t, db2.s1.t
-- bwc_tag:end_query

SELECT db1.t, db2.t FROM db1.s1.t, db2.s1.t
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT c FROM db1.s1.t, db2.s1.t
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT t.c FROM db1.s1.t, db2.s1.t
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT s1.t.c FROM db1.s1.t, db2.s1.t
-- bwc_tag:end_query

SELECT db1.s1.t.c FROM db1.s1.t, db2.s1.t
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE db1.s1.t (
	c INT,
	c_squared AS (c * c),
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO db1.s1.t VALUES (42);
-- bwc_tag:end_query

SELECT * FROM db1.s1.t, db2.s1.t
-- bwc_tag:end_query

