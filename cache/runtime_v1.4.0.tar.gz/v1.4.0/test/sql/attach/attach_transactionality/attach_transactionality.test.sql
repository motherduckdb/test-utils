-- bwc_tag:nb_steps=31
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:skip_query
BEGIN TRANSACTION
-- bwc_tag:end_query

ATTACH 'output/attach_transaction.db'
-- bwc_tag:end_query

-- bwc_tag:skip_query
ROLLBACK
-- bwc_tag:end_query

-- bwc_tag:skip_query
BEGIN TRANSACTION
-- bwc_tag:end_query

ATTACH 'output/attach_transaction.db'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE attach_transaction.integers(i INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO attach_transaction.integers VALUES (42)
-- bwc_tag:end_query

-- bwc_tag:skip_query
ROLLBACK
-- bwc_tag:end_query

-- bwc_tag:skip_query
BEGIN TRANSACTION
-- bwc_tag:end_query

ATTACH 'output/attach_transaction.db'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE attach_transaction.integers(i INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO attach_transaction.integers VALUES (42)
-- bwc_tag:end_query

-- bwc_tag:skip_query
COMMIT
-- bwc_tag:end_query

-- bwc_tag:skip_query
BEGIN TRANSACTION
-- bwc_tag:end_query

DETACH attach_transaction
-- bwc_tag:end_query

-- bwc_tag:skip_query
ROLLBACK
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

DETACH attach_transaction
-- bwc_tag:end_query

-- bwc_tag:skip_query
BEGIN TRANSACTION
-- bwc_tag:end_query

ATTACH 'output/attach_transaction.db'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO attach_transaction.integers VALUES (84)
-- bwc_tag:end_query

DETACH attach_transaction
-- bwc_tag:end_query

-- bwc_tag:skip_query
ROLLBACK
-- bwc_tag:end_query

-- bwc_tag:skip_query
BEGIN TRANSACTION
-- bwc_tag:end_query

ATTACH 'output/attach_transaction.db'
-- bwc_tag:end_query

SELECT * FROM attach_transaction.integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO attach_transaction.integers VALUES (84)
-- bwc_tag:end_query

DETACH attach_transaction
-- bwc_tag:end_query

-- bwc_tag:skip_query
COMMIT
-- bwc_tag:end_query

ATTACH 'output/attach_transaction.db'
-- bwc_tag:end_query

SELECT * FROM attach_transaction.integers ORDER BY 1
-- bwc_tag:end_query

