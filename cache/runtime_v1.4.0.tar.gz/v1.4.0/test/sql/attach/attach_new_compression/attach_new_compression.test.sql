-- bwc_tag:nb_steps=18
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

ATTACH 'output/test_new_compression.db' AS db1 (STORAGE_VERSION 'v1.0.0');
-- bwc_tag:end_query

SET force_compression='roaring'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE db1.tbl AS SELECT CASE WHEN i%2=0 THEN NULL ELSE i END i FROM range(10000) t(i);
-- bwc_tag:end_query

SET force_compression='zstd';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE db1.str_tbl AS SELECT STRING_AGG('long_string_' || i, '-') FROM range(1000) t(i);
-- bwc_tag:end_query

SELECT COUNT(*)>0 FROM pragma_storage_info('db1.tbl') WHERE compression='Roaring'
-- bwc_tag:end_query

SELECT COUNT(*)>0 FROM pragma_storage_info('db1.str_tbl') WHERE compression='ZSTD'
-- bwc_tag:end_query

DETACH db1
-- bwc_tag:end_query

ATTACH 'output/test_new_compression.db' AS db1 (STORAGE_VERSION 'v1.2.0');
-- bwc_tag:end_query

SET force_compression='roaring'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE db1.tbl2 AS FROM db1.tbl
-- bwc_tag:end_query

CHECKPOINT db1
-- bwc_tag:end_query

SET force_compression='zstd';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE db1.str_tbl2 AS FROM db1.str_tbl
-- bwc_tag:end_query

CHECKPOINT db1
-- bwc_tag:end_query

SELECT COUNT(*)>0 FROM pragma_storage_info('db1.tbl2') WHERE compression='Roaring'
-- bwc_tag:end_query

SELECT COUNT(*)>0 FROM pragma_storage_info('db1.str_tbl2') WHERE compression='ZSTD'
-- bwc_tag:end_query

