-- bwc_tag:nb_steps=28
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

ATTACH DATABASE ':memory:' AS new_database;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t1 AS SELECT 42 i
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA new_database.s1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW new_database.s1.v1 AS SELECT * FROM t1
-- bwc_tag:end_query

SELECT * FROM new_database.s1.v1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE new_database.s1.t1 AS SELECT 84 i
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE VIEW new_database.s1.v1 AS SELECT * FROM new_database.s1.t1
-- bwc_tag:end_query

SELECT * FROM new_database.s1.t1
-- bwc_tag:end_query

SELECT * FROM new_database.s1.v1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE VIEW new_database.s1.v1 AS SELECT * FROM new_database.s1.t1 UNION ALL FROM memory.t1 ORDER BY ALL
-- bwc_tag:end_query

SELECT * FROM new_database.s1.v1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER VIEW new_database.s1.v1 RENAME TO v2
-- bwc_tag:end_query

SELECT * FROM new_database.s1.v2
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP VIEW new_database.s1.v2
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE new_database.s1.t1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW new_database.v1 AS SELECT * FROM t1
-- bwc_tag:end_query

SELECT * FROM new_database.v1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE new_database.t1 AS SELECT 84 i
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE VIEW new_database.v1 AS SELECT * FROM new_database.t1
-- bwc_tag:end_query

SELECT * FROM new_database.t1
-- bwc_tag:end_query

SELECT * FROM new_database.v1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE VIEW new_database.v1 AS SELECT * FROM new_database.t1 UNION ALL FROM memory.t1 ORDER BY ALL
-- bwc_tag:end_query

SELECT * FROM new_database.v1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER VIEW new_database.v1 RENAME TO v2
-- bwc_tag:end_query

SELECT * FROM new_database.v2
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP VIEW new_database.v2
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE new_database.t1
-- bwc_tag:end_query

