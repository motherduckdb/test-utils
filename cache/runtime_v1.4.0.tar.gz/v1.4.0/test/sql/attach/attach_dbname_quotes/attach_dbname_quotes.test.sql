-- bwc_tag:nb_steps=14
ATTACH ':memory:' as "my""db";
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE "my""db".tbl(i int);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO "my""db".tbl VALUES (42)
-- bwc_tag:end_query

USE "my""db";
-- bwc_tag:end_query

SELECT * FROM tbl
-- bwc_tag:end_query

ATTACH 'output/attach_quoated_base.db'
-- bwc_tag:end_query

USE attach_quoated_base
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA "my""db"."my""schema"
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE "my""db"."my""schema".tbl(i int);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO "my""db"."my""schema".tbl VALUES (84)
-- bwc_tag:end_query

USE "my""db"."my""schema"
-- bwc_tag:end_query

SELECT * FROM tbl
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA """"
-- bwc_tag:end_query

USE """"
-- bwc_tag:end_query

