-- bwc_tag:nb_steps=9
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

SELECT #1 FROM range(1)
-- bwc_tag:end_query

SELECT #1+#2 FROM range(1) tbl, range(1) tbl2
-- bwc_tag:end_query

SELECT #1 FROM (SELECT * FROM range(1)) tbl
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select (select #1) from range(1);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT #2 FROM range(1)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT #1
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT #0 FROM range(1)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT #-1 FROM range(1)
-- bwc_tag:end_query

