-- bwc_tag:nb_steps=2
-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER)
-- bwc_tag:end_query

SELECT * FROM integers
-- bwc_tag:end_query

