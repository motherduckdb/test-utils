-- bwc_tag:nb_steps=11
-- bwc_tag:execute_from_sql
CREATE TABLE test(i INTEGER, j INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (1, 1), (2, 2)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PREPARE v1 AS SELECT * FROM test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
EXECUTE v1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test ALTER i TYPE VARCHAR USING i::VARCHAR
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
EXECUTE v1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test ALTER i TYPE INTEGER USING i::INTEGER
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PREPARE v2 AS SELECT i+$1 FROM test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
EXECUTE v2(1)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test ALTER i TYPE VARCHAR USING i::VARCHAR
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

EXECUTE v2
-- bwc_tag:end_query

