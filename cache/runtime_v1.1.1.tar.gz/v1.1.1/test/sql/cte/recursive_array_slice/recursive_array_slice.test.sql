-- bwc_tag:nb_steps=7
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE p(loc int8);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO p VALUES (1);
-- bwc_tag:end_query

WITH RECURSIVE t(y, arr) AS
(
  SELECT 1, array[1,2,3,4,5,6]
    UNION ALL
  SELECT y+1, arr[:loc]
  FROM   t, p
  WHERE y < 10
) SELECT * FROM t;
-- bwc_tag:end_query

WITH RECURSIVE t(y, arr) AS
(
  SELECT 1, array[1,2,3,4,5,6]
    UNION ALL
  SELECT y+1, arr
  FROM   t, p
  WHERE y < 10
    AND y = loc
) SELECT * FROM t;
-- bwc_tag:end_query

WITH RECURSIVE t(y, arr) AS
(
  SELECT 1, array[1,2,3,4,5,6]
    UNION ALL
  SELECT y+1, arr[:loc]
  FROM   t, p
  WHERE y < 10
    AND y = loc
) SELECT * FROM t;
-- bwc_tag:end_query

WITH RECURSIVE t(arr) AS
(
  SELECT array[1,2,3,4,5,6]
    UNION ALL
  SELECT  arr[arr[1]+1:6]
  FROM   t
  WHERE arr[1] < 6
) SELECT * FROM t;
-- bwc_tag:end_query

