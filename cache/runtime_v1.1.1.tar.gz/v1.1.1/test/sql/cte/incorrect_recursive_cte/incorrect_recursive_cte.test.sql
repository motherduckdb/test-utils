-- bwc_tag:nb_steps=3
WITH RECURSIVE cte AS (SELECT 42) SELECT * FROM cte;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

with recursive t as (select 1 as x intersect select x+1 from t where x < 3) select * from t order by x
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

with recursive t as (select 1 as x except select x+1 from t where x < 3) select * from t order by x
-- bwc_tag:end_query

