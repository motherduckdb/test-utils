-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=5
LOAD 'parquet';
-- bwc_tag:end_query

SELECT setseed(0.72)
-- bwc_tag:end_query

COPY (SELECT uuid()::VARCHAR as varchar, uuid() AS uuid FROM range(10000000) t(i)) TO 'output/random_uuids.parquet'
-- bwc_tag:end_query

SET memory_limit='750MB'
-- bwc_tag:end_query

COPY 'output/random_uuids.parquet' TO 'output/random_uuids_copy.parquet';
-- bwc_tag:end_query

