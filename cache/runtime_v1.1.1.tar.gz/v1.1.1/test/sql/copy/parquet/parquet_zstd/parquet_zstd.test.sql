-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=3
SET default_null_order='nulls_first';
-- bwc_tag:end_query

LOAD 'parquet';
-- bwc_tag:end_query

select * from parquet_scan('data/parquet-testing/zstd.parquet') order by 1
-- bwc_tag:end_query

