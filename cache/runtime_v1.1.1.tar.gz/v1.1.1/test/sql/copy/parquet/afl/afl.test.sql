-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=9
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select * from parquet_scan('data/parquet-testing/afl/1.parquet')
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select * from parquet_scan('data/parquet-testing/afl/2.parquet')
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select * from parquet_scan('data/parquet-testing/afl/6.parquet')
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select * from parquet_scan('data/parquet-testing/afl/3.parquet')
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select * from parquet_scan('data/parquet-testing/afl/3.parquet')
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select * from parquet_scan('data/parquet-testing/afl/3.parquet')
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select * from parquet_scan('data/parquet-testing/afl/3.parquet')
-- bwc_tag:end_query

