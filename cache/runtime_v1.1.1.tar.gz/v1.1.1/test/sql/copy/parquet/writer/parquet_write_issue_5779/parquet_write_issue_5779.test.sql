-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=13
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE empty_lists(i INTEGER[]);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO empty_lists SELECT [] FROM range(10) UNION ALL SELECT [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
-- bwc_tag:end_query

COPY (SELECT * FROM empty_lists LIMIT 10) TO 'output/emptylist_int.parquet';
-- bwc_tag:end_query

SELECT * FROM 'output/emptylist_int.parquet'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE empty_lists_varchar(i VARCHAR[]);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO empty_lists_varchar SELECT [] FROM range(10) UNION ALL SELECT ['hello', 'world', 'this', 'is', 'a', 'varchar', 'list']
-- bwc_tag:end_query

COPY (SELECT * FROM empty_lists_varchar LIMIT 10) TO 'output/emptylist_varchar.parquet';
-- bwc_tag:end_query

SELECT * FROM 'output/emptylist_varchar.parquet'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE empty_list_nested(i INT[][]);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO empty_list_nested SELECT [] FROM range(10) UNION ALL SELECT [[1, 2, 3], [4, 5], [6, 7, 8]]
-- bwc_tag:end_query

COPY (SELECT * FROM empty_list_nested LIMIT 10) TO 'output/empty_list_nested.parquet';
-- bwc_tag:end_query

SELECT * FROM 'output/empty_list_nested.parquet'
-- bwc_tag:end_query

