-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=3
LOAD 'parquet';
-- bwc_tag:end_query

SELECT * FROM parquet_scan('data/parquet-testing/bug2267.parquet')
-- bwc_tag:end_query

SELECT assignedLicenses[1] FROM parquet_scan('data/parquet-testing/bug2267.parquet')
-- bwc_tag:end_query

