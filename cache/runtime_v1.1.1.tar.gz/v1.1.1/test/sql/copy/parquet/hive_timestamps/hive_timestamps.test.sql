-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=9
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

SELECT SETSEED(0.8675309);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE raw_data (
  ts TIMESTAMP_S NOT NULL,
  hits INTEGER NOT NULL
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO raw_data
SELECT *, (random() * 500)::INTEGER
FROM RANGE(TIMESTAMP '2023-11-01', TIMESTAMP '2023-11-06', INTERVAL 1 MINUTE);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE timeseries AS (
  SELECT DATE_TRUNC('hour', ts) AS bucket, SUM(hits)::BIGINT AS total
  FROM raw_data
  GROUP BY bucket
);
-- bwc_tag:end_query

SELECT * 
FROM timeseries
ORDER BY ALL
LIMIT 5
-- bwc_tag:end_query

COPY (
  SELECT * FROM timeseries
) TO 'output/hive' (
  FORMAT 'PARQUET', COMPRESSION 'SNAPPY', PARTITION_BY (bucket), OVERWRITE_OR_IGNORE
);
-- bwc_tag:end_query

SELECT bucket, total 
FROM read_parquet('output/hive/*/*.parquet') 
ORDER BY ALL
LIMIT 5
-- bwc_tag:end_query

