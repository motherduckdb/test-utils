-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=75
LOAD 'parquet';
-- bwc_tag:end_query

select stats_min, stats_max, stats_min_value, stats_max_value from parquet_metadata('data/parquet-testing/boolean_stats.parquet');
-- bwc_tag:end_query

select stats_min, stats_max, stats_min_value, stats_max_value from parquet_metadata('data/parquet-testing/signed_stats.parquet');
-- bwc_tag:end_query

select * from 'data/parquet-testing/signed_stats.parquet';
-- bwc_tag:end_query

select stats_min, stats_max, stats_min_value, stats_max_value from parquet_metadata('data/parquet-testing/unsigned_stats.parquet');
-- bwc_tag:end_query

select * from 'data/parquet-testing/unsigned_stats.parquet';
-- bwc_tag:end_query

select stats_min, stats_max, stats_min_value, stats_max_value from parquet_metadata('data/parquet-testing/date_stats.parquet');
-- bwc_tag:end_query

select * from 'data/parquet-testing/date_stats.parquet';
-- bwc_tag:end_query

select stats_min, stats_max, stats_min_value, stats_max_value from parquet_metadata('data/parquet-testing/varchar_stats.parquet');
-- bwc_tag:end_query

select * from 'data/parquet-testing/varchar_stats.parquet';
-- bwc_tag:end_query

select stats_min, stats_max, stats_min_value, stats_max_value from parquet_metadata('data/parquet-testing/decimal_stats.parquet');
-- bwc_tag:end_query

select * from 'data/parquet-testing/decimal_stats.parquet';
-- bwc_tag:end_query

select stats_min, stats_max, stats_min_value, stats_max_value from parquet_metadata('data/parquet-testing/arrow/int32_decimal.parquet');
-- bwc_tag:end_query

SELECT * FROM 'data/parquet-testing/arrow/int32_decimal.parquet'
-- bwc_tag:end_query

select stats_min, stats_max, stats_min_value, stats_max_value from parquet_metadata('data/parquet-testing/arrow/int64_decimal.parquet');
-- bwc_tag:end_query

SELECT * FROM 'data/parquet-testing/arrow/int64_decimal.parquet'
-- bwc_tag:end_query

SELECT stats_min, stats_max, stats_min_value, stats_max_value FROM parquet_metadata('data/parquet-testing/data-types.parquet')
-- bwc_tag:end_query

SELECT * FROM 'data/parquet-testing/data-types.parquet'
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/manyrowgroups.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/map.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/arrow/int32_decimal.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/arrow/nonnullable.impala.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/bug687_nulls.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/bug1554.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/apkwan.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/arrow/nested_lists.snappy.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/arrow/nulls.snappy.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/nan-float.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/manyrowgroups2.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/struct.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/arrow/list_columns.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/timestamp-ms.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/arrow/alltypes_dictionary.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/arrow/binary.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/arrow/nation.dict-malformed.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/lineitem-top10000.gzip.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/arrow/nested_maps.snappy.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/arrow/dict-page-offset-zero.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/silly-names.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/zstd.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/bug1618_struct_strings.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/arrow/single_nan.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/arrow/int64_decimal.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/filter_bug1391.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/arrow/fixed_length_decimal_legacy.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/timestamp.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/arrow/fixed_length_decimal.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/leftdate3_192_loop_1.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/blob.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/bug1588.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/bug1589.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/arrow/alltypes_plain.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/arrow/repeated_no_annotation.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/data-types.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/unsigned.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/pandas-date.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/date.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/arrow/nullable.impala.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/fixed.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/arrow/alltypes_plain.snappy.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/decimal/int32_decimal.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/decimal/pandas_decimal.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/decimal/decimal_dc.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/decimal/int64_decimal.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/decimal/fixed_length_decimal_legacy.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/decimal/fixed_length_decimal.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/glob2/t1.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/cache/cache1.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/cache/cache2.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/glob/t2.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/glob/t1.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/bug2557.parquet');
-- bwc_tag:end_query

copy (select '' i) to 'output/test.parquet';
-- bwc_tag:end_query

select i is null c0 from 'output/test.parquet';
-- bwc_tag:end_query

select stats_min_value is null c0, stats_max_value is null c1 from parquet_metadata('output/test.parquet');
-- bwc_tag:end_query

