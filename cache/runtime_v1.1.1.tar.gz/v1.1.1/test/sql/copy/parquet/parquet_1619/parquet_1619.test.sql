-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=4
LOAD 'parquet';
-- bwc_tag:end_query

select struct_extract("inner", 'f64_field') from parquet_scan('data/parquet-testing/struct.parquet');
-- bwc_tag:end_query

select ("inner")."f64_field" from parquet_scan('data/parquet-testing/struct.parquet');
-- bwc_tag:end_query

select "inner"['f64_field'] from parquet_scan('data/parquet-testing/struct.parquet');
-- bwc_tag:end_query

