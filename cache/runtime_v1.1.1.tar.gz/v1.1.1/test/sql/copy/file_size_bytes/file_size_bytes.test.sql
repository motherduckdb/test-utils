-- bwc_tag:needed_extensions=json;parquet
-- bwc_tag:nb_steps=33
-- bwc_tag:execute_from_sql
CREATE TABLE bigdata AS SELECT i AS col_a, i AS col_b FROM range(0,10000) tbl(i);
-- bwc_tag:end_query

-- bwc_tag:skip_query
set threads=1
-- bwc_tag:end_query

COPY (FROM bigdata) TO 'output/file_size_bytes_csv1' (FORMAT CSV, FILE_SIZE_BYTES 1000);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT COUNT(*) FROM read_csv_auto('output/file_size_bytes_csv1/*.csv')
-- bwc_tag:end_query

SELECT count(*) FROM glob('output/file_size_bytes_csv1/*.csv')
-- bwc_tag:end_query

COPY (FROM bigdata) TO 'output/file_size_bytes_csv2' (FORMAT CSV, FILE_SIZE_BYTES '1kb');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT COUNT(*) FROM read_csv_auto('output/file_size_bytes_csv2/*.csv')
-- bwc_tag:end_query

SELECT count(*) FROM glob('output/file_size_bytes_csv2/*.csv')
-- bwc_tag:end_query

LOAD 'json';
-- bwc_tag:end_query

COPY (FROM bigdata) TO 'output/file_size_bytes_json' (FORMAT JSON, FILE_SIZE_BYTES '1kb');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT COUNT(*) FROM read_json_auto('output/file_size_bytes_json/*.json')
-- bwc_tag:end_query

SELECT count(*) FROM glob('output/file_size_bytes_json/*.json')
-- bwc_tag:end_query

LOAD 'parquet';
-- bwc_tag:end_query

COPY (FROM bigdata) TO 'output/file_size_bytes_parquet' (FORMAT PARQUET, ROW_GROUP_SIZE 2000, FILE_SIZE_BYTES '1kb');
-- bwc_tag:end_query

SELECT COUNT(*) FROM read_parquet('output/file_size_bytes_parquet/*.parquet')
-- bwc_tag:end_query

SELECT count(*) FROM glob('output/file_size_bytes_parquet/*.parquet')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO bigdata SELECT bigdata.* FROM bigdata, range(9)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA verify_parallelism;
-- bwc_tag:end_query

-- bwc_tag:skip_query
pragma threads=4;
-- bwc_tag:end_query

COPY (FROM bigdata) TO 'output/file_size_bytes_csv3' (FORMAT CSV, FILE_SIZE_BYTES '500kb');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT COUNT(*) FROM read_csv_auto('output/file_size_bytes_csv3/*.csv')
-- bwc_tag:end_query

SELECT count(*) FROM glob('output/file_size_bytes_csv3/*.csv')
-- bwc_tag:end_query

COPY (FROM bigdata) TO 'output/file_size_bytes_csv4' (FORMAT CSV, FILE_SIZE_BYTES '200kb');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT COUNT(*) FROM read_csv_auto('output/file_size_bytes_csv4/*.csv')
-- bwc_tag:end_query

SELECT count(*) BETWEEN 3 AND 5 FROM glob('output/file_size_bytes_csv4/*.csv')
-- bwc_tag:end_query

COPY (FROM bigdata) TO 'output/file_size_bytes_csv5' (FORMAT CSV, FILE_SIZE_BYTES '700kb', PER_THREAD_OUTPUT TRUE);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT COUNT(*) FROM read_csv_auto('output/file_size_bytes_csv5/*.csv')
-- bwc_tag:end_query

SELECT count(*) > 1 FROM glob('output/file_size_bytes_csv5/*.csv')
-- bwc_tag:end_query

COPY (FROM bigdata) TO 'output/file_size_bytes_csv6' (FORMAT CSV, FILE_SIZE_BYTES '190kb', PER_THREAD_OUTPUT TRUE);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT COUNT(*) FROM read_csv_auto('output/file_size_bytes_csv6/*.csv')
-- bwc_tag:end_query

SELECT count(*) BETWEEN 6 AND 10 FROM glob('output/file_size_bytes_csv6/*.csv')
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

COPY (FROM bigdata) TO 'output/file_size_bytes_csv7' (FORMAT CSV, FILE_SIZE_BYTES '190kb', USE_TMP_FILE TRUE);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

COPY (FROM bigdata) TO 'output/file_size_bytes_csv7' (FORMAT CSV, FILE_SIZE_BYTES '190kb', PARTITION_BY col_a);
-- bwc_tag:end_query

