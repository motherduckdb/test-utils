-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=5
LOAD 'parquet';
-- bwc_tag:end_query

copy (select NULL as i, NULL as j from range(100000)) to 'output/issue6304_null' (format parquet, partition_by(i), overwrite_or_ignore);
-- bwc_tag:end_query

copy (select 1 as i, 2 as j from range(100000)) to 'output/issue6304_constant' (format parquet, partition_by(i), overwrite_or_ignore);
-- bwc_tag:end_query

copy (select NULL as i from range(100000)) to 'output/issue6304_null' (format parquet, partition_by(i), overwrite_or_ignore, write_partition_columns);
-- bwc_tag:end_query

copy (select 1 as i from range(100000)) to 'output/issue6304_constant' (format parquet, partition_by(i), overwrite_or_ignore, write_partition_columns);
-- bwc_tag:end_query

