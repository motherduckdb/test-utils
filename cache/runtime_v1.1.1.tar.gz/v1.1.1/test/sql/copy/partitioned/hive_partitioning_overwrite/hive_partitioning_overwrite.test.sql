-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=10
LOAD 'parquet';
-- bwc_tag:end_query

COPY (SELECT 42 AS part_col, 43 AS value_col) TO 'output/overwrite_test' (FORMAT PARQUET, PARTITION_BY (part_col));
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

COPY (SELECT 84 AS part_col, 85 AS value_col) TO 'output/overwrite_test' (FORMAT PARQUET, PARTITION_BY (part_col));
-- bwc_tag:end_query

COPY (SELECT 84 AS part_col, 85 AS value_col) TO 'output/overwrite_test' (FORMAT PARQUET, PARTITION_BY (part_col), OVERWRITE 1);
-- bwc_tag:end_query

SELECT * FROM 'output/overwrite_test/**/*.parquet'
-- bwc_tag:end_query

COPY (SELECT 42 AS part_col) TO 'output/overwrite_test2' (FORMAT PARQUET);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

COPY (SELECT 84 AS part_col, 85 AS value_col) TO 'output/overwrite_test2' (FORMAT PARQUET, PARTITION_BY (part_col));
-- bwc_tag:end_query

COPY (SELECT 84 AS part_col, 85 AS value_col) TO 'output/overwrite_test2' (FORMAT PARQUET, PARTITION_BY (part_col), OVERWRITE 1);
-- bwc_tag:end_query

SELECT * FROM 'output/overwrite_test2/**/*.parquet'
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

COPY (SELECT 84 AS part_col) TO 'output/overwrite_test' (FORMAT PARQUET, PARTITION_BY (part_col), OVERWRITE 1, OVERWRITE_OR_IGNORE 1);
-- bwc_tag:end_query

