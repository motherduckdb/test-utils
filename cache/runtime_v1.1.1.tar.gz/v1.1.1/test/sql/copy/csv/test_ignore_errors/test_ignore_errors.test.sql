-- bwc_tag:nb_steps=27
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER, j INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY integers FROM 'data/csv/test/error_too_little.csv' (HEADER, IGNORE_ERRORS, NULL_PADDING FALSE)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY integers FROM 'data/csv/test/error_too_little.csv' (HEADER, NULL_PADDING FALSE)
-- bwc_tag:end_query

SELECT * FROM integers AS too_little_columns
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DELETE FROM integers;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers SELECT * FROM read_csv('data/csv/test/error_too_little.csv', columns={'i': 'INTEGER', 'j': 'INTEGER'},  ignore_errors=1, null_padding=0)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO integers SELECT * FROM read_csv('data/csv/test/error_too_little.csv', columns={'i': 'INTEGER'}, null_padding=0)
-- bwc_tag:end_query

SELECT * FROM integers AS too_little_columns
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DELETE FROM integers;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY integers FROM 'data/csv/test/error_too_little_single.csv' (HEADER, IGNORE_ERRORS, NULL_PADDING 0)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY integers FROM 'data/csv/test/error_too_little_single.csv' (HEADER, NULL_PADDING 0)
-- bwc_tag:end_query

SELECT * FROM integers AS too_little_columns
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DELETE FROM integers;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY integers FROM 'data/csv/test/error_too_many.csv' (HEADER, IGNORE_ERRORS, SAMPLE_SIZE -1)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY integers FROM 'data/csv/test/error_too_many.csv' (HEADER)
-- bwc_tag:end_query

SELECT * FROM integers AS too_many_columns
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DELETE FROM integers;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY integers FROM 'data/csv/test/error_invalid_type.csv' (HEADER, IGNORE_ERRORS)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY integers FROM 'data/csv/test/error_invalid_type.csv' (HEADER)
-- bwc_tag:end_query

SELECT * FROM integers AS too_many_columns
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE nullable_type (col_a INTEGER, col_b VARCHAR(10), col_c VARCHAR(10), col_d VARCHAR(10));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY nullable_type FROM 'data/csv/test/test_incompatible_type_with_nullable.csv'
-- bwc_tag:end_query

SELECT * FROM nullable_type
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/titanic.csv', ignore_errors=1) limit 10
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv('data/csv/test_ignore_errors.csv', columns = {'Order ref ID': 'VARCHAR'}, ignore_errors=true);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv('data/csv/test_ignore_errors.csv', types = {'Order ref ID': 'VARCHAR'}, ignore_errors=true);
-- bwc_tag:end_query

