-- bwc_tag:nb_steps=8
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table t1 as select 1 as a,1 as b from range(3);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table t2 (b integer, a integer);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into t2 select NULL as b,NULL as a from range(30000);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into t2 values (3,4);
-- bwc_tag:end_query

copy t1 to 'output/null_glob_reorder_1.csv';
-- bwc_tag:end_query

copy t2  to 'output/null_glob_reorder_2.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select * from read_csv(['output/null_glob_reorder_*.csv']) where b is not null;
-- bwc_tag:end_query

