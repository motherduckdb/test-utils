-- bwc_tag:nb_steps=15
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test (a INTEGER, b VARCHAR(10));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (1, 'hello'), (2, 'world '), (3, ' xx');
-- bwc_tag:end_query

SELECT * FROM test ORDER BY 1;
-- bwc_tag:end_query

COPY test TO 'output/overwrite.csv';
-- bwc_tag:end_query

COPY (SELECT * FROM test LIMIT 2) TO 'output/overwrite.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DELETE FROM test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY test FROM 'output/overwrite.csv';
-- bwc_tag:end_query

SELECT * FROM test ORDER BY 1;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

COPY (SELECT i FROM range(1) tbl(i) UNION ALL SELECT concat('hello', i)::INT i FROM range(1) tbl(i)) to 'output/overwrite.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DELETE FROM test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY test FROM 'output/overwrite.csv';
-- bwc_tag:end_query

SELECT * FROM test ORDER BY 1;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

COPY (SELECT i FROM range(1) tbl(i) UNION ALL SELECT concat('hello', i)::INT i FROM range(1) tbl(i)) to 'output/overwrite.csv' (USE_TMP_FILE FALSE);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM 'output/overwrite.csv';
-- bwc_tag:end_query

