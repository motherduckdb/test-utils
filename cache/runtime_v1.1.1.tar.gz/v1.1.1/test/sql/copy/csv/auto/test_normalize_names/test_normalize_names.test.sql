-- bwc_tag:nb_steps=24
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/normalize_names_1.csv', normalize_names=TRUE);
-- bwc_tag:end_query

SELECT a, b, c FROM test ORDER BY a;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/normalize_names_1.csv');
-- bwc_tag:end_query

SELECT A, B, C FROM test ORDER BY a;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

select columns from sniff_csv('data/csv/auto/normalize_names_2.csv', normalize_names = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/normalize_names_2.csv', normalize_names=TRUE);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT _select, insert, _join FROM test ORDER BY _select;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/normalize_names_3.csv', normalize_names=TRUE);
-- bwc_tag:end_query

SELECT _0_a, _1_b, _9_c FROM test ORDER BY _0_a;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/normalize_names_4.csv', normalize_names=TRUE);
-- bwc_tag:end_query

SELECT allo, teost, _ FROM test ORDER BY allo;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/normalize_names_5.csv', normalize_names=TRUE);
-- bwc_tag:end_query

SELECT a, b, c FROM test ORDER BY a;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/normalize_names_6.csv', normalize_names=TRUE);
-- bwc_tag:end_query

SELECT aax, hello_world, qty_m2 FROM test ORDER BY aax;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

select columns from sniff_csv('data/csv/normalize.csv', normalize_names = true)
-- bwc_tag:end_query

