-- bwc_tag:nb_steps=25
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/missing_header_col.csv');
-- bwc_tag:end_query

SELECT a, column1, c FROM test ORDER BY a;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/duplicate_header_col.csv');
-- bwc_tag:end_query

SELECT a, b, a_1 FROM test ORDER BY a;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/duplicate_header_collision.csv');
-- bwc_tag:end_query

SELECT a, b, a_1, a_1_1 FROM test ORDER BY a;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/empty_header.csv');
-- bwc_tag:end_query

SELECT column0, column1, column2 FROM test ORDER BY column0;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/missing_many_col.csv');
-- bwc_tag:end_query

SELECT a, column01, column12 FROM test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/duplicate_header_columns.csv');
-- bwc_tag:end_query

SELECT a, a_8, a_9, column12 FROM test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/test_header_mix.csv');
-- bwc_tag:end_query

SELECT a, a_8, a_9, column12, column11, column12_1 FROM test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/unnamed_columns.csv');
-- bwc_tag:end_query

SELECT column00, column01, column02, column03, column04, column05, column06, column07, column08, column09, column10, column11, column12 FROM test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

