-- bwc_tag:nb_steps=5
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t1 AS select i, (i+1) as j from range(0,3000) tbl(i)
-- bwc_tag:end_query

COPY t1 TO 'output/t1.csv' (FORMAT CSV, DELIMITER '|', HEADER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select count(*) from 'output/t1.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select count(*) from read_csv('data/csv/empty.csv', columns=STRUCT_PACK(d := 'BIGINT'), header=0, auto_detect = false)
-- bwc_tag:end_query

