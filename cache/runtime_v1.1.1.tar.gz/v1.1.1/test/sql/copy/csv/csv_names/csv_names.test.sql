-- bwc_tag:nb_steps=11
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select column00, column01, column02, column03 from 'data/csv/real/lineitem_sample.csv' LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select l_orderkey, l_partkey, column02, column03 from read_csv_auto('data/csv/real/lineitem_sample.csv', names=['l_orderkey', 'l_partkey']) LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select column00, column01, column02, column03 from read_csv_auto('data/csv/real/lineitem_sample.csv', names=[]) LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select l_orderkey, l_partkey, l_commitdate, l_comment from read_csv_auto('data/csv/real/lineitem_sample.csv', column_names=['l_orderkey', 'l_partkey', 'l_suppkey', 'l_linenumber', 'l_quantity', 'l_extendedprice', 'l_discount', 'l_tax', 'l_returnflag', 'l_linestatus', 'l_shipdate', 'l_commitdate', 'l_receiptdate', 'l_shipinstruct', 'l_shipmode', 'l_comment']) LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select l_orderkey, l_partkey, l_commitdate, l_comment from read_csv_auto('data/csv/real/lineitem_sample.csv', names=['l_orderkey', 'l_partkey', 'l_suppkey', 'l_linenumber', 'l_quantity', 'l_extendedprice', 'l_discount', 'l_tax', 'l_returnflag', 'l_linestatus', 'l_shipdate', 'l_commitdate', 'l_receiptdate', 'l_shipinstruct', 'l_shipmode', 'l_comment', 'xx']) LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select yr, Quarter from read_csv_auto('data/csv/real/ontime_sample.csv', names=['yr']) LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

select column00, column01, column02, column03 from read_csv_auto('data/csv/real/lineitem_sample.csv', names=NULL) LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

select l_orderkey, l_partkey, column02, column03 from read_csv_auto('data/csv/real/lineitem_sample.csv', names=['l_orderkey', 'l_partkey'], column_names=['l_orderkey']) LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

select l_orderkey, l_partkey, column02, column03 from read_csv_auto('data/csv/real/lineitem_sample.csv', names=42) LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

select l_orderkey, l_partkey, column02, column03 from read_csv_auto('data/csv/real/lineitem_sample.csv', names=['l_orderkey', 'l_orderkey']) LIMIT 1;
-- bwc_tag:end_query

