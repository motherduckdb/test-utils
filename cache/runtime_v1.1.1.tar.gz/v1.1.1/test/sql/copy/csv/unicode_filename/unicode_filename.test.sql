-- bwc_tag:nb_steps=5
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM 'data/csv/issue2628_中文.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM 'data/csv/*中文.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM 'data/csv/中文/*.csv' ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM 'data/csv/中*/*.csv' ORDER BY 1
-- bwc_tag:end_query

