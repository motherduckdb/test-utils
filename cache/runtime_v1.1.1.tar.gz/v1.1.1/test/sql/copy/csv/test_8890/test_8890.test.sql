-- bwc_tag:nb_steps=2
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select
    field1,
    field2,
    min(datum) as firstseen,
    max(datum) as lastseen
from read_csv('data/csv/hebere.csv.gz',
        delim='\t',
        header=0,
        columns={field1: varchar, field2: varchar, datum: varchar},
        compression='gzip',
        ignore_errors=0,
        auto_detect = false)
group by field1, field2
order by all
limit 10;
-- bwc_tag:end_query

