-- bwc_tag:needed_extensions=json
-- bwc_tag:nb_steps=7
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

LOAD 'json';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

FROM read_csv('data/csv/error/json.csv', columns={'a':'JSON'})
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/error/json.csv', columns={'a':'JSON'}, ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table t (a json);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into t  FROM read_csv('data/csv/error/json.csv', columns={'a':'JSON'}, ignore_errors = true)
-- bwc_tag:end_query

FROM t
-- bwc_tag:end_query

