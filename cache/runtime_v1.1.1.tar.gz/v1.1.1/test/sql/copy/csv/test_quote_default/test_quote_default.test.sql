-- bwc_tag:nb_steps=3
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

select quote,escape,delimiter from sniff_csv('data/csv/test_default_option.csv')
-- bwc_tag:end_query

select quote,escape,delimiter from sniff_csv('data/csv/test_default_option_2.csv')
-- bwc_tag:end_query

