-- bwc_tag:nb_steps=11
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/inconsistencies/inconsistent_columns_3.csv')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/inconsistencies/inconsistent_columns_3.csv', null_padding = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/inconsistencies/inconsistent_columns_3.csv', null_padding = true, ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/inconsistencies/inconsistent_columns_6.csv')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/inconsistencies/inconsistent_columns_6.csv', null_padding = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/inconsistencies/inconsistent_columns_6.csv', null_padding = true, ignore_errors = true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/inconsistencies/inconsistent_columns_6.csv', null_padding = true, ignore_errors = true, header = false)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/inconsistencies/line_with_spaces.csv')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/inconsistencies/line_with_spaces.csv', null_padding = true, header = false)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/inconsistencies/line_with_spaces.csv', null_padding = true, ignore_errors = true)
-- bwc_tag:end_query

