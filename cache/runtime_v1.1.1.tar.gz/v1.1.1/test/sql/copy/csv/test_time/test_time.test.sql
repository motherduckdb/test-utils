-- bwc_tag:nb_steps=5
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
from read_csv('data/csv/auto/invalid_time.csv', header = 0)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
from 'data/csv/auto/time.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
from 'data/csv/auto/various_time_formats.csv'
-- bwc_tag:end_query

select columns from sniff_csv('data/csv/auto/various_time_formats.csv')
-- bwc_tag:end_query

