-- bwc_tag:nb_steps=25
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

FROM  read_csv('data/csv/comments/mixed_options.csv', delim = ',', comment = ',', auto_detect = false, columns= {'a':'integer'})
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

FROM  read_csv('data/csv/comments/mixed_options.csv', quote = ',', comment = ',', escape = '', delim = ';', auto_detect = false, columns= {'a':'integer'})
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM 'data/csv/comments/simple.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM 'data/csv/comments/simple_comma.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/comments/simple_comma.csv', comment = ',');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM 'data/csv/comments/big.csv' limit 5;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM 'data/csv/comments/big.csv' where  a = 20
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT count(*) FROM 'data/csv/comments/big.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM 'data/csv/comments/empty_space.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/comments/simple.csv', buffer_size = 30) limit 5;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/comments/simple.csv', buffer_size = 31) limit 5;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/comments/simple.csv', buffer_size = 32) limit 5;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/comments/simple.csv', buffer_size = 33) limit 5;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/comments/simple.csv', buffer_size = 34) limit 5;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/comments/simple.csv', skip = 2);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM 'data/csv/comments/invalid_rows.csv';
-- bwc_tag:end_query

select SkipRows, Comment FROM sniff_csv('data/csv/comments/invalid_rows.csv');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

select count(*) FROM 'data/csv/comments/error.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select count(*) FROM read_csv('data/csv/comments/error.csv', ignore_errors = true);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select count(*) FROM read_csv('data/csv/comments/error.csv', ignore_errors = true, comment = '#');
-- bwc_tag:end_query

select comment, columns from sniff_csv('data/csv/comments/error.csv', ignore_errors = true);
-- bwc_tag:end_query

select comment, columns from sniff_csv('data/csv/comments/error.csv', ignore_errors = true);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/comments/simple.csv',skip=0);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/comments/simple.csv',skip=1);
-- bwc_tag:end_query

