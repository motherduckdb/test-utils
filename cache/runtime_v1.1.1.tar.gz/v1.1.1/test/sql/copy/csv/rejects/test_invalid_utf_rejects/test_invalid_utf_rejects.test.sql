-- bwc_tag:nb_steps=2
-- bwc_tag:execute_from_sql
from read_csv('data/csv/test/invalid_utf_big.csv',columns = {'col1': 'VARCHAR','col2': 'VARCHAR','col3': 'VARCHAR'},
 auto_detect=false, header = 0, delim = ',', store_rejects=true)
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
SELECT * EXCLUDE (scan_id) FROM reject_errors ORDER BY ALL;
-- bwc_tag:end_query

