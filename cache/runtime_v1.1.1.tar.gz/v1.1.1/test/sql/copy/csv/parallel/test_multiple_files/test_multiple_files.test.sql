-- bwc_tag:nb_steps=6
-- bwc_tag:execute_from_sql
PRAGMA verify_parallelism
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:sort=row_sort
select * from read_csv_auto('data/csv/auto/glob/[0-9].csv');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:sort=row_sort
select * from read_csv_auto('data/csv/auto/glob/[0-9].csv', buffer_size=100)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:sort=row_sort
select * from read_csv('data/csv/auto/glob/[0-9].csv', AUTO_DETECT=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:sort=row_sort
select * from read_csv('data/csv/auto/glob/[0-9].csv', sample_size=-1,  new_line = '\r\n', columns={'row_id':'BIGINT','integer':'INTEGER','float':'DOUBLE', 'text':'VARCHAR'})
-- bwc_tag:end_query

