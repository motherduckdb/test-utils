-- bwc_tag:nb_steps=12
-- bwc_tag:execute_from_sql
PRAGMA verify_parallelism
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT sum(a), sum(b), sum(c) FROM read_csv('data/csv/test/multi_column_integer.csv',  COLUMNS=STRUCT_PACK(a := 'INTEGER', b := 'INTEGER', c := 'INTEGER'), auto_detect='true', delim = '|', buffer_size=30)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT sum(a) FROM read_csv('data/csv/test/multi_column_integer.csv',  COLUMNS=STRUCT_PACK(a := 'INTEGER', b := 'INTEGER', c := 'INTEGER'), auto_detect='true', delim = '|', buffer_size=30)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT sum(a) FROM read_csv('data/csv/test/multi_column_integer_rn.csv',  COLUMNS=STRUCT_PACK(a := 'INTEGER', b := 'INTEGER', c := 'INTEGER'), auto_detect='true', delim = '|', buffer_size=30)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select * from read_csv('data/csv/test/multi_column_string.csv',  COLUMNS=STRUCT_PACK(a := 'INTEGER', b := 'INTEGER', c := 'INTEGER', d := 'VARCHAR'), auto_detect='true', delim = '|', buffer_size=25)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select * from read_csv('data/csv/test/multi_column_string_rn.csv',  COLUMNS=STRUCT_PACK(a := 'INTEGER', b := 'INTEGER', c := 'INTEGER', d := 'VARCHAR'), auto_detect='true', delim = '|', buffer_size=25)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT sum(a) FROM read_csv('data/csv/test/new_line_string_rn.csv',  COLUMNS=STRUCT_PACK(a := 'INTEGER', b := 'INTEGER', c := 'INTEGER', d := 'VARCHAR'), auto_detect='true', delim = '|')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT sum(a) FROM read_csv('data/csv/test/new_line_string_rn.csv',  COLUMNS=STRUCT_PACK(a := 'INTEGER', b := 'INTEGER', c := 'INTEGER', d := 'VARCHAR'), auto_detect='true', delim = '|', buffer_size=80)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT sum(a) FROM read_csv('data/csv/test/new_line_string_rn_exc.csv',  COLUMNS=STRUCT_PACK(a := 'INTEGER', b := 'INTEGER', c := 'INTEGER', d := 'VARCHAR'), auto_detect='true', delim = '|')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT sum(a) FROM read_csv('data/csv/test/new_line_string_rn_exc.csv',  COLUMNS=STRUCT_PACK(a := 'INTEGER', b := 'INTEGER', c := 'INTEGER', d := 'VARCHAR'), auto_detect='true', delim = '|', buffer_size=60)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT sum(a) FROM read_csv('data/csv/test/new_line_string.csv',  COLUMNS=STRUCT_PACK(a := 'INTEGER', b := 'INTEGER', c := 'INTEGER', d := 'VARCHAR'), auto_detect='true', delim = '|')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT sum(a) FROM read_csv('data/csv/test/new_line_string.csv',  COLUMNS=STRUCT_PACK(a := 'INTEGER', b := 'INTEGER', c := 'INTEGER', d := 'VARCHAR'), auto_detect='true', delim = '|', buffer_size=60)
-- bwc_tag:end_query

