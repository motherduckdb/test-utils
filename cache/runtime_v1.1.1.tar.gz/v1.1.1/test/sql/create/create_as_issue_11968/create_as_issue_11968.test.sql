-- bwc_tag:nb_steps=5
-- bwc_tag:load_db=temp_create_as

ATTACH 'output/temp_create_as.db' AS temp_create_as;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test (x INTEGER[]);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test SELECT CASE WHEN x <= 520 THEN [0, 0] ELSE [0] END FROM generate_series(1, 2048) s(x);
-- bwc_tag:end_query

CHECKPOINT;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test2 AS SELECT x FROM test;
-- bwc_tag:end_query

