-- bwc_tag:nb_steps=6
-- bwc_tag:execute_from_sql
CREATE SCHEMA db0;
-- bwc_tag:end_query

USE db0;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t0 (a BIGINT PRIMARY KEY, b INT, c INT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE INDEX t0_idx ON t0 (b);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE UNIQUE INDEX t0_uidx ON t0 (c);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE UNIQUE INDEX t0_uidx2 ON db0.t0 (c);
-- bwc_tag:end_query

