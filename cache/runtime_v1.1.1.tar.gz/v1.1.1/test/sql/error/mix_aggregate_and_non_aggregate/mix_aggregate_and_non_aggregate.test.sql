-- bwc_tag:nb_steps=3
-- bwc_tag:execute_from_sql
CREATE TABLE tbl(name VARCHAR, style VARCHAR, brewery_id INTEGER, abv DOUBLE, ibu INTEGER);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT FIRST(name), FIRST(abv)
FROM tbl
GROUP BY style
ORDER BY abv DESC;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT FIRST(name)||abv
FROM tbl
-- bwc_tag:end_query

