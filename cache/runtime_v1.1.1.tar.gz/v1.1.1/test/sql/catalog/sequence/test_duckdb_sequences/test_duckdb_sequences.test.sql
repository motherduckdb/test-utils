-- bwc_tag:nb_steps=3
-- bwc_tag:execute_from_sql
create sequence my_seq;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select nextval('my_seq');
-- bwc_tag:end_query

select last_value from duckdb_sequences();
-- bwc_tag:end_query

