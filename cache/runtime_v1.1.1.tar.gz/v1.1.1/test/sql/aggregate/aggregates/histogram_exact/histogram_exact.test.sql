-- bwc_tag:nb_steps=15
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE obs(n BIGINT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO obs VALUES (0), (5), (7), (12), (20), (23), (24), (25), (26), (28), (31), (34), (36), (41), (47)
-- bwc_tag:end_query

SELECT histogram_exact(n, [10, 20, 30, 40, 50]) FROM obs
-- bwc_tag:end_query

SELECT histogram_exact(n::double, [10, 20, 30, 40, 50]) FROM obs
-- bwc_tag:end_query

SELECT histogram_exact((date '2000-01-01' + interval (n) days)::date, [date '2000-01-01' + interval (x) days for x in [10, 20, 30, 40, 50]]) FROM obs
-- bwc_tag:end_query

SELECT histogram_exact(n::varchar, [10, 20, 30, 40, 50]) FROM obs
-- bwc_tag:end_query

SELECT histogram_exact([n], [[x] for x in [10, 20, 30, 40, 50]]) FROM obs
-- bwc_tag:end_query

SELECT case when is_histogram_other_bin(bin) then '(other values)' else bin::varchar end as bin,
       count
FROM (
	SELECT UNNEST(map_keys(hist)) AS bin, UNNEST(map_values(hist)) AS count
	FROM (SELECT histogram_exact(n, [10, 20, 30, 40, 50]) AS hist FROM obs)
)
-- bwc_tag:end_query

SELECT case when is_histogram_other_bin(bin) then '(other values)' else bin::varchar end as bin,
       count
FROM (
	SELECT UNNEST(map_keys(hist)) AS bin, UNNEST(map_values(hist)) AS count
	FROM (SELECT histogram(n, [10, 20, 30, 40]) AS hist FROM obs)
)
-- bwc_tag:end_query

SELECT histogram_exact(r, [0, 1, 2, 3]) FROM range(4) t(r);
-- bwc_tag:end_query

SELECT is_histogram_other_bin(NULL)
-- bwc_tag:end_query

SELECT is_histogram_other_bin([[1]])
-- bwc_tag:end_query

SELECT is_histogram_other_bin([]::INT[][][])
-- bwc_tag:end_query

SELECT is_histogram_other_bin({'i': NULL::INT[][]})
-- bwc_tag:end_query

