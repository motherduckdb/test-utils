-- bwc_tag:nb_steps=54
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

SELECT mad(NULL), mad(1)
-- bwc_tag:end_query

SELECT mad(NULL), mad(1) FROM range(2000)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table tinys as
	select range r, random()
	from range(100)
	union all values (NULL, 0.1), (NULL, 0.5), (NULL, 0.9)
	order by 2;
-- bwc_tag:end_query

SELECT mad(r::tinyint) FROM tinys
-- bwc_tag:end_query

SELECT mad(NULL::tinyint) FROM tinys
-- bwc_tag:end_query

SELECT mad(42::tinyint) FROM tinys
-- bwc_tag:end_query

SELECT mad(r::decimal(4,1)) FROM tinys
-- bwc_tag:end_query

SELECT mad(NULL::decimal(4,1)) FROM tinys
-- bwc_tag:end_query

SELECT mad(42::decimal(4,1)) FROM tinys
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table numerics as
	select range r, random()
	from range(10000)
	union all values (NULL, 0.1), (NULL, 0.5), (NULL, 0.9)
	order by 2;
-- bwc_tag:end_query

SELECT mad(r::smallint) FROM numerics
-- bwc_tag:end_query

SELECT mad(NULL::smallint) FROM numerics
-- bwc_tag:end_query

SELECT mad(42::smallint) FROM numerics
-- bwc_tag:end_query

SELECT mad(r::integer) FROM numerics
-- bwc_tag:end_query

SELECT mad(NULL::integer) FROM numerics
-- bwc_tag:end_query

SELECT mad(42::integer) FROM numerics
-- bwc_tag:end_query

SELECT mad(r::bigint) FROM numerics
-- bwc_tag:end_query

SELECT mad(NULL::bigint) FROM numerics
-- bwc_tag:end_query

SELECT mad(42::bigint) FROM numerics
-- bwc_tag:end_query

SELECT mad(r::hugeint) FROM numerics
-- bwc_tag:end_query

SELECT mad(NULL::hugeint) FROM numerics
-- bwc_tag:end_query

SELECT mad(42::hugeint) FROM numerics
-- bwc_tag:end_query

SELECT mad(r::uhugeint) FROM numerics
-- bwc_tag:end_query

SELECT mad(NULL::uhugeint) FROM numerics
-- bwc_tag:end_query

SELECT mad(42::uhugeint) FROM numerics
-- bwc_tag:end_query

SELECT mad(r::float) FROM numerics
-- bwc_tag:end_query

SELECT mad(NULL::float) FROM numerics
-- bwc_tag:end_query

SELECT mad(42::float) FROM numerics
-- bwc_tag:end_query

SELECT mad(r::double) FROM numerics
-- bwc_tag:end_query

SELECT mad(NULL::double) FROM numerics
-- bwc_tag:end_query

SELECT mad(42::double) FROM numerics
-- bwc_tag:end_query

SELECT mad(r::decimal(8,1)) FROM numerics
-- bwc_tag:end_query

SELECT mad(NULL::decimal(8,1)) FROM numerics
-- bwc_tag:end_query

SELECT mad(42::decimal(8,1)) FROM numerics
-- bwc_tag:end_query

SELECT mad(r::decimal(12,1)) FROM numerics
-- bwc_tag:end_query

SELECT mad(NULL::decimal(12,1)) FROM numerics
-- bwc_tag:end_query

SELECT mad(42::decimal(12,1)) FROM numerics
-- bwc_tag:end_query

SELECT mad(r::decimal(18,1)) FROM numerics
-- bwc_tag:end_query

SELECT mad(NULL::decimal(18,1)) FROM numerics
-- bwc_tag:end_query

SELECT mad(42::decimal(18,1)) FROM numerics
-- bwc_tag:end_query

SELECT mad(r::decimal(24,1)) FROM numerics
-- bwc_tag:end_query

SELECT mad(NULL::decimal(24,1)) FROM numerics
-- bwc_tag:end_query

SELECT mad(42::decimal(24,1)) FROM numerics
-- bwc_tag:end_query

SELECT mad(('2018-01-01'::DATE + INTERVAL (r) DAY)::DATE) FROM numerics
-- bwc_tag:end_query

SELECT mad('2018-01-01'::TIMESTAMP + INTERVAL (r) HOUR) FROM numerics
-- bwc_tag:end_query

SELECT mad('00:00:00'::TIME + INTERVAL (r) SECOND) FROM numerics
-- bwc_tag:end_query

select mad(x) from (values ('127'::DECIMAL(3,0)), ('-128'::DECIMAL(3,0))) tbl(x);
-- bwc_tag:end_query

select mad(x) from (values ('32767'::DECIMAL(5,0)), ('-32768'::DECIMAL(5,0))) tbl(x);
-- bwc_tag:end_query

select mad(x) from (values ('2147483647'::DECIMAL(10,0)), ('-2147483648'::DECIMAL(10,0))) tbl(x);
-- bwc_tag:end_query

select mad(x) from (values (-1e308), (1e308)) tbl(x);
-- bwc_tag:end_query

select mad(x) from (values ('294247-01-10'::date), ('290309-12-22 (BC)'::date)) tbl(x);
-- bwc_tag:end_query

select mad(x) from (values
	('294247-01-10 04:00:54.775806'::timestamp),
	('290309-12-22 (BC) 00:00:00'::timestamp)
	) tbl(x);
-- bwc_tag:end_query

select mad(x) from (values ('23:59:59.999999'::time), ('00:00:00'::time)) tbl(x);
-- bwc_tag:end_query

