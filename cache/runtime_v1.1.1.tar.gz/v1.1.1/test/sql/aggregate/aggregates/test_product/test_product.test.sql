-- bwc_tag:nb_steps=12
-- bwc_tag:expected_result=error

select product()
-- bwc_tag:end_query

select product(NULL)
-- bwc_tag:end_query

select product(1)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select product(*)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (1), (2),(4), (NULL)
-- bwc_tag:end_query

SELECT product(i)  FROM integers
-- bwc_tag:end_query

SELECT PRODUCT(2) FROM range(100);
-- bwc_tag:end_query

SELECT PRODUCT(2) FROM range(100) tbl(i) WHERE i % 2 != 0;
-- bwc_tag:end_query

select product(i) from integers group by i%2 order by all
-- bwc_tag:end_query

SELECT PRODUCT(i) FROM range(100) tbl(i) WHERE 1=0;
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
select product(i) over (partition by i%2)
    from integers;
-- bwc_tag:end_query

