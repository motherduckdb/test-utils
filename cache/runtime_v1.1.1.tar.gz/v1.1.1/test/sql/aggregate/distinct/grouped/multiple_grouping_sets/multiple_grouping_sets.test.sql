-- bwc_tag:nb_steps=24
SET default_null_order='nulls_first';
-- bwc_tag:end_query

-- bwc_tag:skip_query
pragma enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
pragma verify_parallelism
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table students (
	course VARCHAR,
	type VARCHAR,
	value BIGINT
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into students
		(course, type, value)
	values
		('CS', 'Bachelor', 20),
		('CS', 'Bachelor', 10),
		('CS', 'PhD', -20),
		('Math', 'Masters', 10),
		('CS', NULL, -15),
		('CS', NULL, 10),
		('Math', NULL, 15);
-- bwc_tag:end_query

select course, type, count(*), sum(distinct value) from students group by course, type order by all;
-- bwc_tag:end_query

select course, type, count(*), sum(distinct value) from students group by (course, type) order by all;
-- bwc_tag:end_query

select course, count(*), sum(distinct value) from students group by (), course, () order by all;
-- bwc_tag:end_query

select count(*), course, type, sum(distinct value)
	from students
	group by grouping sets ((course), (type))
	order by all;
-- bwc_tag:end_query

select sum(distinct value), count(*), course, avg(distinct value), type
	from students
	group by grouping sets (course), grouping sets(type)
	order by all;
-- bwc_tag:end_query

select sum(distinct value), count(*), count(distinct value), course, type
	from students
	group by course, grouping sets(type)
	order by all;
-- bwc_tag:end_query

select count(*), ARG_MIN(distinct value%5, value), course, sum(distinct value), type
	from students
	group by course, grouping sets(type, ())
	order by all;
-- bwc_tag:end_query

select sum(distinct value), count(*), course, type
	from students
	group by grouping sets((course, type), (course))
	order by all;
-- bwc_tag:end_query

select count(*), count(distinct value), count(value), course, sum(distinct value), type
	from students
	group by grouping sets (grouping sets(course), grouping sets(type))
	order by all;
-- bwc_tag:end_query

select count(*), avg(distinct value) FILTER (where value < 5), avg(distinct value), course, avg(value), type
        from students
        group by grouping sets (grouping sets(course, ()), grouping sets(type))
        order by all;
-- bwc_tag:end_query

select count(*), sum(distinct value), course, type
        from students
        group by grouping sets ((course), (), (type))
        order by all;
-- bwc_tag:end_query

select count(*), count(distinct value), sum(distinct value), course, type
        from students
        group by grouping sets(course, ()), grouping sets(type)
        order by all;
-- bwc_tag:end_query

select sum(distinct value), count(*), course, type, sum(distinct value)
        from students
        group by grouping sets(course, ()), type
        order by all;
-- bwc_tag:end_query

select sum(distinct value) FILTER (where value % 10 != 0), count(*), course, type, sum(distinct value)
        from students
        group by grouping sets((course, type), (type))
        order by all;
-- bwc_tag:end_query

select count(*), sum(distinct value), course, type
        from students
        group by grouping sets((3, 4), (4))
        order by all;
-- bwc_tag:end_query

select count(*), course AS crs, sum(distinct value), type AS tp
        from students
        group by grouping sets((crs, tp), (tp))
        order by all;
-- bwc_tag:end_query

select sum(distinct value), count(*), course, type
        from students
        group by grouping sets (grouping sets(course, ()), grouping sets(type, ()))
        order by all;
-- bwc_tag:end_query

-- bwc_tag:skip_query
set threads=1
-- bwc_tag:end_query

select course, type, count(*), sum(distinct value) from students group by course, type order by all;
-- bwc_tag:end_query

