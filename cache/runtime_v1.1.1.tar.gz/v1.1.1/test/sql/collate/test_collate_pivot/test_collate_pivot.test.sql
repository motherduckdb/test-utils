-- bwc_tag:nb_steps=18
-- bwc_tag:execute_from_sql
PRAGMA default_collation=NOACCENT;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE Cities (
    Country VARCHAR, Name VARCHAR, Year INTEGER, Population INTEGER
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO Cities VALUES ('NL', 'Amsterdam', 2010, 1005);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO Cities VALUES ('NL', 'Amsterdam', 2011, 1065);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO Cities VALUES ('NL', 'Amsterdam', 2012, 1158);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO Cities VALUES ('US', 'Seattle', 2013, 564);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO Cities VALUES ('US', 'Seattle', 2014, 608);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO Cities VALUES ('US', 'Seattle', 2015, 738);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO Cities VALUES ('US', 'New York City', 2016, 8015);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO Cities VALUES ('US', 'New York City', 2017, 8175);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO Cities VALUES ('US', 'New York City', 2018, 8772);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO Cities VALUES ('US', 'New York City', 2019, 8772);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO Cities VALUES ('US', 'New York City', 2020, 8772);
-- bwc_tag:end_query

SET pivot_filter_threshold=99
-- bwc_tag:end_query

PIVOT Cities ON Year USING sum(Population);
-- bwc_tag:end_query

SET pivot_filter_threshold=0
-- bwc_tag:end_query

PIVOT Cities ON Year USING sum(Population);
-- bwc_tag:end_query

SET pivot_filter_threshold=0
-- bwc_tag:end_query

