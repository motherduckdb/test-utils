-- bwc_tag:nb_steps=101
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

SELECT '[12,13,14]'::INT[];
-- bwc_tag:end_query

SELECT '["hello", "world", "!"]'::VARCHAR[];
-- bwc_tag:end_query

SELECT CAST('[Hello World!]' AS VARCHAR[]);
-- bwc_tag:end_query

SELECT CAST('[[Hello World!], hello, universe]' AS VARCHAR[]);
-- bwc_tag:end_query

SELECT '[Cast like this]':: VARCHAR[];
-- bwc_tag:end_query

select UNNEST('[NULL, , NULL]'::varchar[]);
-- bwc_tag:end_query

select UNNEST('[NULL,, NULL]'::varchar[]);
-- bwc_tag:end_query

select UNNEST('[NULL,   , NULL]'::varchar[]);
-- bwc_tag:end_query

SELECT UNNEST('[NULL, NULL , ]'::varchar[]);
-- bwc_tag:end_query

SELECT UNNEST('[NULL, NULL ,]'::varchar[]);
-- bwc_tag:end_query

SELECT UNNEST('[NULL, NULL,]'::varchar[]);
-- bwc_tag:end_query

SELECT CAST('[ [12,13,14], [8, 9], [4], [2, 1, 0] ]' AS INT[][]);
-- bwc_tag:end_query

SELECT CAST('[ [[12,13,14], [8, 9]], [[4]], [[2, 1, 0], [99]] ]' AS INT[][][]);
-- bwc_tag:end_query

SELECT CAST('[ [12,13,14], [8, 9], [4], [2,  1,  0] ]' AS VARCHAR[]);
-- bwc_tag:end_query

SELECT CAST('[[ [🦆, 🦆, 🦆]], [[duck, db, 🦆], [🦆]], [[🦆, duck, db]]]' AS VARCHAR[][][]);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE stringList (col1 VARCHAR)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO stringList VALUES ('["hello","world","!"]'), ('["Amazing","text"]'), ('[Hello World!]');
-- bwc_tag:end_query

SELECT col1::VARCHAR[] FROM stringList;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE nestedStrings (col1 VARCHAR)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO nestedStrings VALUES ('[["hello"], ["world"],["!"]]'), ('[["Amazing"],["text"]]'), ('[[Hello World!]]');
-- bwc_tag:end_query

SELECT col1::VARCHAR[][] FROM nestedStrings;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE superNestedStrings (col1 VARCHAR)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO superNestedStrings VALUES ('[[[[["hello"]]], [[["world"],["!"]]]]]'), ('[[[[["Amazing"]],[["text"]]]]]'), ('[[[[[Hello World!]]]]]');
-- bwc_tag:end_query

SELECT col1::VARCHAR[][][][][] FROM superNestedStrings;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tbl (col1 VARCHAR);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO tbl VALUES ('[1,2,2]'), ('[345,67865,44,4]'), ('[5,6,7]');
-- bwc_tag:end_query

SELECT col1::INT[] FROM tbl;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE doubleNested (col1 VARCHAR);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO doubleNested VALUES ('[[1,2],[2]]'), ('[[345],[67865,44,4]]'), ('[[5],[6,7]]');
-- bwc_tag:end_query

SELECT col1::INT[][] FROM doubleNested;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tripleNested (col1 VARCHAR)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO tripleNested VALUES ('[[[1,2],[3]]]'), ('[[[4]]]');
-- bwc_tag:end_query

SELECT col1::INT[][][] FROM tripleNested;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE crazyNested (col1 VARCHAR)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO crazyNested VALUES ('[[[[[[1]],[[3,4,9]]],[[[0,1]]]]]]'), ('[[[[[[4]]]]]]');
-- bwc_tag:end_query

SELECT col1::INT[][][][][][] FROM crazyNested;
-- bwc_tag:end_query

SELECT CAST('[''hello'',''world'', ''!'']' AS VARCHAR[]);
-- bwc_tag:end_query

SELECT CAST('[''''hello'''',''''world'''', ''''!'''']' AS VARCHAR[]);
-- bwc_tag:end_query

SELECT CAST('[[ [''🦆, 🦆, 🦆'']], [[duck, db, ''🦆''] ]]' AS VARCHAR[][][]);
-- bwc_tag:end_query

SELECT CAST('["can''t", "you''re", "i''m"]' AS VARCHAR[]);
-- bwc_tag:end_query

SELECT CAST('[can''t, you''re, i''m]' AS VARCHAR[]);
-- bwc_tag:end_query

SELECT CAST('["]", "hello", "world"]' AS VARCHAR[]);
-- bwc_tag:end_query

SELECT CAST('['']'', "hello", "world"]' AS VARCHAR[]);
-- bwc_tag:end_query

SELECT CAST('[ [12,     13,14], [8, 9         ], [ 4    ], [    2, 1,     0] ]  ' AS INT[][]);
-- bwc_tag:end_query

SELECT CAST('[          [ [12,     13,14], [8, 9         ]  ],[[ 4    ]   ],        [[    2, 1,     0 ]         ] ]  ' AS INT[][][]);
-- bwc_tag:end_query

SELECT CAST('["   hello","          ''  world", "!         "]' AS VARCHAR[]);
-- bwc_tag:end_query

SELECT CAST('[   hello     ,   world      , !         ]' AS VARCHAR[]);     
-- bwc_tag:end_query

SELECT CAST('[    [ "   hello"]  ,["            world"        ],[ "!        "           ]      ]' AS VARCHAR[][]);
-- bwc_tag:end_query

SELECT '[]'::VARCHAR[];
-- bwc_tag:end_query

SELECT '[]'::INT[];
-- bwc_tag:end_query

SELECT '[]'::INT[][][][];
-- bwc_tag:end_query

SELECT '[[1, 2, 3], [], [	], [  ]]'::INT[][];
-- bwc_tag:end_query

SELECT '[[1, 2, 3], [], NULL, [NULL], [4, NULL]]'::INT[][];
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE null_tbl(col1 VARCHAR);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO null_tbl VALUES(NULL), (NULL), ('[NULL]');
-- bwc_tag:end_query

SELECT col1::INT[] FROM null_tbl;
-- bwc_tag:end_query

SELECT CAST(NULL AS INT[]);
-- bwc_tag:end_query

SELECT CAST('[NULL]' AS INT[]);
-- bwc_tag:end_query

SELECT CAST('[NULL]' AS INT[][]);
-- bwc_tag:end_query

SELECT CAST('[[12,13,14], [8, 9], NULL, [2, 1]]' AS INT[][]);
-- bwc_tag:end_query

SELECT CAST('[[12,13,14], [8, 9], [2, NULL, 1]]' AS INT[][]);
-- bwc_tag:end_query

SELECT CAST('[ [[12,13,14], NULL], [[4]], NULL, [[2, NULL, 1, 0], [99]] ]' AS INT[][][]);
-- bwc_tag:end_query

SELECT TRY_CAST('Hello World' AS INT[]);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE try_cast_tbl (col1 VARCHAR);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO try_cast_tbl VALUES ('[1,2,X,2]'), ('[hello DuckDB]'), ('[345,oops,44,4.0]'), ('[12345678901]'), ('[5,6,7]'), ('[3 0, 1]');
-- bwc_tag:end_query

SELECT TRY_CAST(col1 AS INT[]) FROM try_cast_tbl;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT CAST('{[3]}' AS INT[]);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT CAST('Hello World' AS INT[]);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT CAST('[3]]' AS INT[]);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT CAST('[3],[[]' AS INT[][]);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT CAST('[3], [[1]]' AS INT[][]);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT CAST('[[3 1]]' AS INT[][]);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT CAST('[[3,, 1]]' AS INT[][]);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT CAST('[[3], [[5], [4]]' AS INT[][]);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT CAST('][3]' AS INT[]);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT CAST('[[[[[]][3][[]][][[[][]]]]]' AS INT[][][][]);
-- bwc_tag:end_query

SELECT * FROM tbl WHERE cast(col1 as int[]) = [1, 2, 2];
-- bwc_tag:end_query

SELECT col1 FROM tbl WHERE LEN(cast(col1 as int[])) < 4;
-- bwc_tag:end_query

SELECT cast(col1 as int[]) FROM tbl WHERE LEN(cast(col1 as int[])) < 4;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE struct_tbl1(col VARCHAR);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO struct_tbl1 VALUES('[{a: "hii"}, {a: "hellooo"}]');
-- bwc_tag:end_query

SELECT col::STRUCT(a VARCHAR)[] FROM struct_tbl1;
-- bwc_tag:end_query

SELECT CAST('[ [{a:[12,13,14], b:"🦆"}], [{a:[12,13,14], b:"🦆", c:100}] ]' AS STRUCT(a INT[], b VARCHAR, c FLOAT)[][]);
-- bwc_tag:end_query

SELECT CAST('[{a:[12,13,14], b:"🦆", c:{a:[[a], [b, c]], b:[123]}}]' AS STRUCT(a INT[], b VARCHAR, c STRUCT(a VARCHAR[][], b INT[]))[]);
-- bwc_tag:end_query

SELECT '[{a: hii}, {a: "{" }]'::STRUCT(a VARCHAR)[] FROM struct_tbl1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE struct_tbl2(col VARCHAR);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO struct_tbl2 VALUES('[{a: 7, b:"Duck"}, {a: 7000, b: "🦆🦆🦆🦆🦆🦆"}]');
-- bwc_tag:end_query

SELECT col::STRUCT(a INT, b VARCHAR)[] FROM struct_tbl2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE int_list(col INT[]);
-- bwc_tag:end_query

COPY (SELECT [1,2,3]) TO 'output/int_list.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY int_list FROM 'output/int_list.csv';
-- bwc_tag:end_query

SELECT col FROM int_list;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE assorted_lists(col1 INT[], col2 VARCHAR[], col3 DATE[]);
-- bwc_tag:end_query

COPY (SELECT [8,7,6], '[hello, Duck''DB]', '[2022-12-2, 1929-01-25]') TO 'output/assorted_lists.csv' (Header 0);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY assorted_lists FROM 'output/assorted_lists.csv';
-- bwc_tag:end_query

SELECT * FROM assorted_lists;
-- bwc_tag:end_query

select '[{"bar":"\""}]'::VARCHAR[];
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select '[{"bar":"\\""}]'::VARCHAR[];
-- bwc_tag:end_query

select '[{"bar":"\\\""}]'::VARCHAR[];
-- bwc_tag:end_query

select '[{"bar":"\"\"\\\"\"\"\\"}]'::VARCHAR[];
-- bwc_tag:end_query

