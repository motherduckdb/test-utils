-- bwc_tag:nb_steps=8
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

ATTACH ':memory:' AS db1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE db1.tbl AS SELECT 42 AS x, 3 AS y;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO db1.two_x_plus_y(x, y) AS 2 * x + y;
-- bwc_tag:end_query

SELECT db1.two_x_plus_y(x, y) FROM db1.tbl;
-- bwc_tag:end_query

SELECT db1.main.two_x_plus_y(x, y) FROM db1.tbl;
-- bwc_tag:end_query

USE db1
-- bwc_tag:end_query

SELECT two_x_plus_y(x, y) FROM db1.tbl;
-- bwc_tag:end_query

