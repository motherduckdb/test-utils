-- bwc_tag:nb_steps=11
ATTACH 'output/attach_index_db.db'
-- bwc_tag:end_query

USE attach_index_db
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tbl_a (a_id INTEGER PRIMARY KEY, value VARCHAR NOT NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE INDEX idx_tbl_a ON tbl_a (value)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO tbl_a VALUES (1, 'x')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO tbl_a VALUES (2, 'y')
-- bwc_tag:end_query

SELECT * FROM tbl_a WHERE a_id = 2
-- bwc_tag:end_query

USE memory
-- bwc_tag:end_query

DETACH attach_index_db
-- bwc_tag:end_query

ATTACH 'output/attach_index_db.db'
-- bwc_tag:end_query

SELECT * FROM attach_index_db.tbl_a WHERE a_id = 2
-- bwc_tag:end_query

