-- bwc_tag:nb_steps=10
ATTACH DATABASE ':memory:' AS db1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE album(artistid INTEGER, albumname TEXT, albumcover TEXT, UNIQUE (artistid, albumname));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE TABLE db1.song(songid INTEGER, songartist INTEGER, songalbum TEXT, songname TEXT, FOREIGN KEY(songartist, songalbum) REFERENCES album(artistid, albumname));
-- bwc_tag:end_query

USE db1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE album(artistid INTEGER, albumname TEXT, albumcover TEXT, UNIQUE (artistid, albumname));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO album VALUES (1, 'A', 'A_cover'), (2, 'B', 'B_cover'), (3, 'C', 'C_cover'), (4, 'D', 'D_cover');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE song(songid INTEGER, songartist INTEGER, songalbum TEXT, songname TEXT, FOREIGN KEY(songartist, songalbum) REFERENCES album(artistid, albumname));
-- bwc_tag:end_query

ATTACH DATABASE ':memory:' AS db2;
-- bwc_tag:end_query

USE db2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO db1.song VALUES (11, 1, 'A', 'A_song'), (12, 2, 'B', 'B_song'), (13, 3, 'C', 'C_song');
-- bwc_tag:end_query

