-- bwc_tag:nb_steps=16
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

ATTACH DATABASE ':memory:' AS database;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA database.schema;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE database.schema.table(col ROW(field INTEGER));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO database.schema.table VALUES ({'field': 42});
-- bwc_tag:end_query

SELECT database.schema.table.col.field FROM database.schema.table
-- bwc_tag:end_query

SELECT database.schema.table.col FROM database.schema.table
-- bwc_tag:end_query

SELECT database.schema.table FROM database.schema.table
-- bwc_tag:end_query

USE database
-- bwc_tag:end_query

SELECT schema.table FROM database.schema.table
-- bwc_tag:end_query

SELECT "table" FROM database.schema.table
-- bwc_tag:end_query

USE database.schema
-- bwc_tag:end_query

SELECT "table" FROM "table"
-- bwc_tag:end_query

SELECT schema.table FROM "table"
-- bwc_tag:end_query

SELECT database.table FROM "table"
-- bwc_tag:end_query

SELECT database.schema.table FROM "table"
-- bwc_tag:end_query

