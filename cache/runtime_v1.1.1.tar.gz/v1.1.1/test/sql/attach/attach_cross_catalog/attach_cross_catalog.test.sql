-- bwc_tag:nb_steps=10
ATTACH DATABASE ':memory:' AS db1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test(a INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE INDEX index ON test(a)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE INDEX db1.index ON test(a)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TYPE db1.mood AS ENUM('ok', 'sad', 'happy');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE db1.integers(i mood)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE TABLE integers(i mood)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT 'happy'::mood
-- bwc_tag:end_query

USE db1
-- bwc_tag:end_query

SELECT 'happy'::mood
-- bwc_tag:end_query

