-- bwc_tag:nb_steps=14
set memory_limit='20mb';
-- bwc_tag:end_query

set max_temp_directory_size='150MiB';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop table if exists tmp1;
-- bwc_tag:end_query

create or replace temp table tmp1 as select * from range(15_000_000);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop table if exists tmp1;
-- bwc_tag:end_query

create or replace temp table tmp1 as select * from range(15_000_000);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop table if exists tmp1;
-- bwc_tag:end_query

create or replace temp table tmp1 as select * from range(15_000_000);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop table if exists tmp1;
-- bwc_tag:end_query

create or replace temp table tmp1 as select * from range(15_000_000);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop table if exists tmp1;
-- bwc_tag:end_query

create or replace temp table tmp1 as select * from range(15_000_000);
-- bwc_tag:end_query

select temporary_storage_bytes < 150_000_000 from duckdb_memory() where tag = 'IN_MEMORY_TABLE';
-- bwc_tag:end_query

select size < 150_000_000 FROM duckdb_temporary_files();
-- bwc_tag:end_query

