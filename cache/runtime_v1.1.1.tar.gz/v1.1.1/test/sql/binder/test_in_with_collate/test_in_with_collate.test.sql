-- bwc_tag:nb_steps=12
-- bwc_tag:execute_from_sql
create table tbl (str varchar);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into tbl values ('ABCDE'), ('aBcDe');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into tbl values ('àbcdë');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into tbl values ('ÀbCdÈ');
-- bwc_tag:end_query

select * from tbl where str in ('AbCdE');
-- bwc_tag:end_query

select * from tbl where str collate nocase in ('abcde');
-- bwc_tag:end_query

select * from tbl where str collate noaccent in ('abcde');
-- bwc_tag:end_query

select * from tbl where str collate nocase.noaccent in ('abcde');
-- bwc_tag:end_query

select * from tbl where str not in ('abcde');
-- bwc_tag:end_query

select * from tbl where str collate nocase not in ('abcde');
-- bwc_tag:end_query

select * from tbl where str collate noaccent not in ('abcde');
-- bwc_tag:end_query

select * from tbl where str collate nocase.noaccent not in ('abcde');
-- bwc_tag:end_query

