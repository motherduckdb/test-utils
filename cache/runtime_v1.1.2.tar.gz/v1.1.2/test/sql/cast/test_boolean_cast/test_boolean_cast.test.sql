-- bwc_tag:nb_steps=46
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

SELECT CAST(1=1 AS VARCHAR)
-- bwc_tag:end_query

SELECT CAST(1=0 AS VARCHAR)
-- bwc_tag:end_query

SELECT CAST(12345 AS BOOLEAN)
-- bwc_tag:end_query

SELECT CAST('true' AS BOOLEAN)
-- bwc_tag:end_query

SELECT CAST('t' AS BOOLEAN)
-- bwc_tag:end_query

SELECT CAST('TRUE' AS BOOLEAN)
-- bwc_tag:end_query

SELECT CAST('yes' AS BOOLEAN)
-- bwc_tag:end_query

SELECT CAST('YeS' AS BOOLEAN)
-- bwc_tag:end_query

SELECT CAST('y' AS BOOLEAN)
-- bwc_tag:end_query

SELECT CAST('false' AS BOOLEAN)
-- bwc_tag:end_query

SELECT CAST('f' AS BOOLEAN)
-- bwc_tag:end_query

SELECT CAST('FALSE' AS BOOLEAN)
-- bwc_tag:end_query

SELECT CAST('no' AS BOOLEAN)
-- bwc_tag:end_query

SELECT CAST('nO' AS BOOLEAN)
-- bwc_tag:end_query

SELECT CAST('n' AS BOOLEAN)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT CAST('12345' AS BOOLEAN)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tbl AS SELECT 0 AS yes
-- bwc_tag:end_query

SELECT CAST(yes AS BOOLEAN) FROM tbl
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT CAST(yes AS BOOLEAN)
-- bwc_tag:end_query

SELECT CAST(CAST('12345' AS INTEGER) AS BOOLEAN)
-- bwc_tag:end_query

SELECT CAST(CAST('0' AS INTEGER) AS BOOLEAN)
-- bwc_tag:end_query

SELECT CAST(CAST('1' AS tinyint) AS BOOLEAN)
-- bwc_tag:end_query

SELECT CAST(CAST('0' AS tinyint) AS BOOLEAN)
-- bwc_tag:end_query

SELECT CAST(CAST('1' AS smallint) AS BOOLEAN)
-- bwc_tag:end_query

SELECT CAST(CAST('0' AS smallint) AS BOOLEAN)
-- bwc_tag:end_query

SELECT CAST(CAST('1' AS integer) AS BOOLEAN)
-- bwc_tag:end_query

SELECT CAST(CAST('0' AS integer) AS BOOLEAN)
-- bwc_tag:end_query

SELECT CAST(CAST('1' AS bigint) AS BOOLEAN)
-- bwc_tag:end_query

SELECT CAST(CAST('0' AS bigint) AS BOOLEAN)
-- bwc_tag:end_query

SELECT CAST(CAST('1' AS decimal) AS BOOLEAN)
-- bwc_tag:end_query

SELECT CAST(CAST('0' AS decimal) AS BOOLEAN)
-- bwc_tag:end_query

SELECT CAST(CAST('1' AS decimal(1,0)) AS BOOLEAN)
-- bwc_tag:end_query

SELECT CAST(CAST('0' AS decimal(1,0)) AS BOOLEAN)
-- bwc_tag:end_query

SELECT CAST(CAST('1' AS decimal(9,0)) AS BOOLEAN)
-- bwc_tag:end_query

SELECT CAST(CAST('0' AS decimal(9,0)) AS BOOLEAN)
-- bwc_tag:end_query

SELECT CAST(CAST('1' AS decimal(38,0)) AS BOOLEAN)
-- bwc_tag:end_query

SELECT CAST(CAST('0' AS decimal(38,0)) AS BOOLEAN)
-- bwc_tag:end_query

SELECT CAST(CAST('1' AS float) AS BOOLEAN)
-- bwc_tag:end_query

SELECT CAST(CAST('0' AS float) AS BOOLEAN)
-- bwc_tag:end_query

SELECT CAST(CAST('1' AS double) AS BOOLEAN)
-- bwc_tag:end_query

SELECT CAST(CAST('0' AS double) AS BOOLEAN)
-- bwc_tag:end_query

SELECT CAST(CAST('1' AS HUGEINT) AS BOOLEAN)
-- bwc_tag:end_query

SELECT CAST(CAST('0' AS HUGEINT) AS BOOLEAN)
-- bwc_tag:end_query

SELECT CAST(CAST('1' AS UHUGEINT) AS BOOLEAN)
-- bwc_tag:end_query

SELECT CAST(CAST('0' AS UHUGEINT) AS BOOLEAN)
-- bwc_tag:end_query

