-- bwc_tag:nb_steps=9
-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT {'t': 42} t
-- bwc_tag:end_query

SELECT * FROM test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test ALTER t TYPE ROW(t VARCHAR) USING {'t': concat('hello', (test.t.t + 42)::varchar)}
-- bwc_tag:end_query

SELECT * FROM test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT {'t': 42} t
-- bwc_tag:end_query

SELECT * FROM test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test ALTER t TYPE ROW(t VARCHAR) USING {'t': concat('hello', (t.t + 42)::varchar)}
-- bwc_tag:end_query

SELECT * FROM test
-- bwc_tag:end_query

