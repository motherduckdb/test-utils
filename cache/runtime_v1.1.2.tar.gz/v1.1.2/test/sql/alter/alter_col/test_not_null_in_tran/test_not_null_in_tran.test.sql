-- bwc_tag:nb_steps=64
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t(i INTEGER, j INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t SELECT i, i FROM RANGE(2048) tbl(i)
-- bwc_tag:end_query

-- bwc_tag:skip_query
BEGIN TRANSACTION
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t VALUES(9999, NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE t ALTER COLUMN j SET NOT NULL
-- bwc_tag:end_query

-- bwc_tag:skip_query
ROLLBACK
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t VALUES(9999, NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE t ALTER COLUMN j SET NOT NULL
-- bwc_tag:end_query

SELECT i FROM t WHERE j IS NULL
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE IF EXISTS t
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t(i INTEGER, j INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t SELECT i, i FROM RANGE(2048) tbl(i)
-- bwc_tag:end_query

-- bwc_tag:skip_query
BEGIN TRANSACTION
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t values(8888, 8888)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE t ALTER COLUMN j SET NOT NULL
-- bwc_tag:end_query

-- bwc_tag:skip_query
COMMIT
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO t VALUES(9999, NULL)
-- bwc_tag:end_query

SELECT * FROM t WHERE j = 8888
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE IF EXISTS t
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t(i int, j int)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO T SELECT 1,1 FROM RANGE(2048)
-- bwc_tag:end_query

-- bwc_tag:skip_query
BEGIN TRANSACTION
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE t ALTER COLUMN j SET NOT NULL
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t VALUES(2, 2)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE t ALTER COLUMN j DROP NOT NULL
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t values(3, NULL)
-- bwc_tag:end_query

-- bwc_tag:skip_query
COMMIT
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t VALUES(4, NULL)
-- bwc_tag:end_query

SELECT * FROM t WHERE j IS NULL
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE IF EXISTS t
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t(i int, j int)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO T SELECT 1,1 FROM RANGE(2048)
-- bwc_tag:end_query

-- bwc_tag:skip_query
BEGIN TRANSACTION
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE t ALTER COLUMN j SET NOT NULL
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO T VALUES(8888, 8888)
-- bwc_tag:end_query

-- bwc_tag:skip_query
ROLLBACK
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t VALUES(9999, NULL)
-- bwc_tag:end_query

SELECT i FROM t WHERE j IS NULL
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE IF EXISTS t
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t(i int, j int)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE t ALTER COLUMN j SET NOT NULL
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO T SELECT 1,1 FROM RANGE(2048)
-- bwc_tag:end_query

-- bwc_tag:skip_query
BEGIN TRANSACTION
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE t ALTER COLUMN j DROP NOT NULL
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO T VALUES(7777, NULL)
-- bwc_tag:end_query

-- bwc_tag:skip_query
ROLLBACK
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO t VALUES(8888, NULL)
-- bwc_tag:end_query

SELECT COUNT(*) FROM t WHERE j IS NULL
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE IF EXISTS t
-- bwc_tag:end_query

-- bwc_tag:skip_query
BEGIN TRANSACTION
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t(i INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE t ALTER COLUMN i SET NOT NULL
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t SELECT 1 FROM RANGE(1024)
-- bwc_tag:end_query

-- bwc_tag:skip_query
COMMIT
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO t VALUES(NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE IF EXISTS t
-- bwc_tag:end_query

-- bwc_tag:skip_query
BEGIN TRANSACTION
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t(i INTEGER NOT NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t SELECT 1 FROM RANGE(1024)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE t ALTER COLUMN i DROP NOT NULL
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t VALUES(NULL)
-- bwc_tag:end_query

-- bwc_tag:skip_query
COMMIT
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t VALUES(NULL)
-- bwc_tag:end_query

