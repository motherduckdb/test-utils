-- bwc_tag:fixtures=huggingface_index.db
-- bwc_tag:nb_steps=1
ATTACH 'output/huggingface_index.db'
-- bwc_tag:end_query

