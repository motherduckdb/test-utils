-- bwc_tag:nb_steps=17
-- bwc_tag:execute_from_sql
CREATE TABLE pk_integers(i INTEGER PRIMARY KEY)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO pk_integers VALUES (1);
-- bwc_tag:end_query

-- bwc_tag:skip_query
BEGIN TRANSACTION
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE fk_integers(j INTEGER, FOREIGN KEY (j) REFERENCES pk_integers(i))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DROP TABLE pk_integers
-- bwc_tag:end_query

-- bwc_tag:skip_query
ROLLBACK
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE pk_integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE pk_integers(i INTEGER PRIMARY KEY)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO pk_integers VALUES (1), (2);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE fk_integers(j INTEGER, FOREIGN KEY (j) REFERENCES pk_integers(i))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO fk_integers VALUES (2);
-- bwc_tag:end_query

-- bwc_tag:skip_query
BEGIN TRANSACTION
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE fk_integers
-- bwc_tag:end_query

-- bwc_tag:skip_query
ROLLBACK
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DELETE FROM pk_integers WHERE i=2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO fk_integers VALUES (3);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DROP TABLE pk_integers
-- bwc_tag:end_query

