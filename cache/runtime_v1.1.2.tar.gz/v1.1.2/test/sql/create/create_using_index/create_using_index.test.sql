-- bwc_tag:nb_steps=1
-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE TABLE t0 (i INT, CONSTRAINT any_constraint UNIQUE USING INDEX any_non_existed_index);
-- bwc_tag:end_query

