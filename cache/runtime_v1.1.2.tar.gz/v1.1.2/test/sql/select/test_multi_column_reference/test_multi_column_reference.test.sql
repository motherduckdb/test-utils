-- bwc_tag:nb_steps=34
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test.tbl(col INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test.tbl VALUES (1), (2), (3);
-- bwc_tag:end_query

SELECT test.tbl.col FROM test.tbl;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT test.t.col FROM test.tbl t;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT test.tbl.col FROM test.tbl t;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA t
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t.t(t ROW(t INTEGER));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t.t VALUES ({'t': 42});
-- bwc_tag:end_query

SELECT t FROM t.t;
-- bwc_tag:end_query

SELECT t.t FROM t.t;
-- bwc_tag:end_query

SELECT t.t.t FROM t.t;
-- bwc_tag:end_query

SELECT t.t.t.t FROM t.t;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP SCHEMA t CASCADE;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA t
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t.t AS SELECT {'t': {'t': {'t': {'t': {'t': 42}}}}} t
-- bwc_tag:end_query

SELECT t.t.t.t.t.t.t.t FROM t.t;
-- bwc_tag:end_query

SELECT t.t.t.t.t.t.t FROM t.t;
-- bwc_tag:end_query

SELECT t.t.t.t.t.t FROM t.t;
-- bwc_tag:end_query

SELECT t.t.t.t.t FROM t.t;
-- bwc_tag:end_query

SELECT t.t.t.t FROM t.t;
-- bwc_tag:end_query

SELECT t.t.t FROM t.t;
-- bwc_tag:end_query

SELECT t.t FROM t.t;
-- bwc_tag:end_query

SELECT t FROM t.t;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP SCHEMA t CASCADE
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA s1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA s2
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE s1.t1 AS SELECT 42 t
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE s2.t1 AS SELECT 84 t
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT s1.t1.t FROM s1.t1, s2.t1
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT testX.tbl.col FROM test.tbl;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT test.tblX.col FROM test.tbl;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT test.tbl.colX FROM test.tbl;
-- bwc_tag:end_query

