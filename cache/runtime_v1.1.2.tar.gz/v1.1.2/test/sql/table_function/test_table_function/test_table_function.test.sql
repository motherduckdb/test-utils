-- bwc_tag:nb_steps=9
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER, j INTEGER);
-- bwc_tag:end_query

SELECT * FROM pragma_table_info('integers');
-- bwc_tag:end_query

SELECT name FROM pragma_table_info('integers');
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT blablabla FROM pragma_table_info('integers');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE join_table(name VARCHAR, value INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO join_table VALUES ('i', 33), ('j', 44)
-- bwc_tag:end_query

SELECT a.name, cid, value FROM pragma_table_info('integers') AS a INNER JOIN join_table ON a.name=join_table.name ORDER BY a.name;
-- bwc_tag:end_query

SELECT cid, name FROM (SELECT * FROM pragma_table_info('integers')) AS a
-- bwc_tag:end_query

