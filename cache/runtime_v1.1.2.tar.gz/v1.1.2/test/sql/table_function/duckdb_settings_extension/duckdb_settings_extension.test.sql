-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=6
SET default_null_order='nulls_first';
-- bwc_tag:end_query

LOAD 'parquet';
-- bwc_tag:end_query

SELECT * FROM duckdb_settings();
-- bwc_tag:end_query

SELECT name, value FROM duckdb_settings() WHERE name='default_null_order';
-- bwc_tag:end_query

SET default_null_order='nulls_last'
-- bwc_tag:end_query

SELECT name, value FROM duckdb_settings() WHERE name='default_null_order';
-- bwc_tag:end_query

