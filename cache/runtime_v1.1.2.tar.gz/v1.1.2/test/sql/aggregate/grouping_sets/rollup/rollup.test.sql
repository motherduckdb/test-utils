-- bwc_tag:nb_steps=15
SET default_null_order='nulls_first';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table students (course VARCHAR, type VARCHAR);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into students
		(course, type)
	values
		('CS', 'Bachelor'),
		('CS', 'Bachelor'),
		('CS', 'PhD'),
		('Math', 'Masters'),
		('CS', NULL),
		('CS', NULL),
		('Math', NULL);
-- bwc_tag:end_query

select course, count(*) from students group by rollup (course) order by 1, 2;
-- bwc_tag:end_query

select course, type, count(*) from students group by rollup (course, type) order by 1, 2, 3;
-- bwc_tag:end_query

select course, type, count(*) from students group by rollup ((course, type)) order by 1, 2, 3;
-- bwc_tag:end_query

select course, type, count(*) from students group by rollup (course, type, course) order by 1, 2, 3;
-- bwc_tag:end_query

select course, type, count(*) from students group by grouping sets ((course, type), (course), ()) order by 1, 2, 3;
-- bwc_tag:end_query

select course, type, count(*) from students group by rollup (course), rollup (type) order by 1, 2, 3;
-- bwc_tag:end_query

select course as crs, type, count(*) from students group by rollup (crs), (), type order by 1, 2, 3;
-- bwc_tag:end_query

select course as crs, type as tp, count(*) from students group by grouping sets (rollup (crs)), (), tp order by 1, 2, 3;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select course, count(*) from students group by rollup () order by 1, 2;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select course, count(*) from students group by rollup (rollup (course)) order by 1, 2;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select course, count(*) from students group by rollup (grouping_sets (course)) order by 1, 2;
-- bwc_tag:end_query

