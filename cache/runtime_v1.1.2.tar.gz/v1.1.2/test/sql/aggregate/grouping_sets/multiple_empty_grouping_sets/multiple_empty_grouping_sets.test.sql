-- bwc_tag:nb_steps=2
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

select count(*)
group by grouping sets ((), ())
-- bwc_tag:end_query

