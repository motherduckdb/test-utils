-- bwc_tag:nb_steps=16
SELECT 42 HAVING 42 > 20
-- bwc_tag:end_query

SELECT 42 HAVING 42 > 80
-- bwc_tag:end_query

SELECT SUM(42) HAVING AVG(42) > MIN(20)
-- bwc_tag:end_query

SELECT SUM(42) HAVING SUM(42) > SUM(80)
-- bwc_tag:end_query

SELECT SUM(42)+COUNT(*)+COUNT(1), 3 HAVING SUM(42)+MAX(20)+AVG(30) > SUM(120)-MIN(100)
-- bwc_tag:end_query

SELECT SUM(42) HAVING (SELECT SUM(42)) > SUM(80)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test (a INTEGER, b INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (11, 22), (13, 22), (12, 21)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT a FROM test WHERE a=13 HAVING a > 11
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT a FROM test WHERE a=13 HAVING SUM(a) > 11
-- bwc_tag:end_query

SELECT SUM(a) FROM test WHERE a=13 HAVING SUM(a) > 11
-- bwc_tag:end_query

SELECT SUM(a) FROM test WHERE a=13 HAVING SUM(a) > 20
-- bwc_tag:end_query

SELECT SUM(a) FROM test HAVING SUM(a)>10;
-- bwc_tag:end_query

SELECT SUM(a) FROM test HAVING SUM(a)<10;
-- bwc_tag:end_query

SELECT SUM(a) FROM test HAVING COUNT(*)>1;
-- bwc_tag:end_query

SELECT SUM(a) FROM test HAVING COUNT(*)>10;
-- bwc_tag:end_query

