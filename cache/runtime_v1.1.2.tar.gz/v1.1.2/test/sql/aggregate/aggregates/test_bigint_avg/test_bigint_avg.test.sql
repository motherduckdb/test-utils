-- bwc_tag:nb_steps=3
-- bwc_tag:execute_from_sql
CREATE TABLE bigints(n HUGEINT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO bigints (n) VALUES ('9007199254740992'::HUGEINT), (1::HUGEINT), (0::HUGEINT);
-- bwc_tag:end_query

SELECT AVG(n)::DOUBLE - '3002399751580331'::DOUBLE FROM bigints;
-- bwc_tag:end_query

