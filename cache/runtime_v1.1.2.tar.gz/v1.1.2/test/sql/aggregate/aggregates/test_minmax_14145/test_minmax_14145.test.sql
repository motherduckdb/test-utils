-- bwc_tag:needed_extensions=json
-- bwc_tag:nb_steps=3
LOAD 'json';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

DESCRIBE SELECT max(l) from (select unnest( [{'a':1}::JSON, [2]::JSON ]) as l);
-- bwc_tag:end_query

