-- bwc_tag:nb_steps=19
SET default_null_order='nulls_first';
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select bool_or(0)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select bool_and(0)
-- bwc_tag:end_query

select bool_or(NULL)
-- bwc_tag:end_query

select bool_and(NULL)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select bool_or()
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select bool_and()
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select bool_or(*)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select bool_and(*)
-- bwc_tag:end_query

SELECT bool_or(True) FROM range(100);
-- bwc_tag:end_query

SELECT bool_and(True) FROM range(100);
-- bwc_tag:end_query

SELECT bool_or(True) FROM range(100) tbl(i) WHERE 1=0;
-- bwc_tag:end_query

SELECT bool_and(True) FROM range(100) tbl(i) WHERE 1=0;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table t (d date)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into t values (DATE'2021-02-09'-1),(DATE'2021-02-09'+1),(NULL)
-- bwc_tag:end_query

select bool_or(d > '2021-02-09') AS or_result,
       bool_and(d > '2021-02-09') AS and_result
from t;
-- bwc_tag:end_query

select d,bool_or(d > '2021-02-09') AS or_result,
       bool_and(d > '2021-02-09') AS and_result
from t
group by d
order by d;
-- bwc_tag:end_query

select bool_or(d > '2021-02-09') over (partition by d)
    from t order by d;
-- bwc_tag:end_query

select bool_and(d > '2021-02-09') over (partition by d)
    from t order by d;
-- bwc_tag:end_query

