-- bwc_tag:nb_steps=11
-- bwc_tag:execute_from_sql
CREATE TABLE integer(i INTEGER, j INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integer VALUES (3, 4), (3, 5), (3, 7);
-- bwc_tag:end_query

SELECT j * 2 FROM integer GROUP BY j * 2 ORDER BY j * 2;
-- bwc_tag:end_query

SELECT integer.j * 2 FROM integer GROUP BY j * 2 ORDER BY j * 2;
-- bwc_tag:end_query

SELECT j * 2 FROM integer GROUP BY integer.j * 2 ORDER BY j * 2;
-- bwc_tag:end_query

SELECT j * 2 FROM integer GROUP BY j * 2 ORDER BY integer.j * 2;
-- bwc_tag:end_query

SELECT integer.j * 2 FROM integer GROUP BY j * 2 ORDER BY integer.j * 2;
-- bwc_tag:end_query

SELECT j * 2 FROM integer GROUP BY integer.j * 2 ORDER BY integer.j * 2;
-- bwc_tag:end_query

SELECT integer.j * 2 FROM integer GROUP BY integer.j * 2 ORDER BY j * 2;
-- bwc_tag:end_query

SELECT integer.j * 2 FROM integer GROUP BY integer.j * 2 ORDER BY integer.j * 2;
-- bwc_tag:end_query

SELECT j * 2 AS i FROM integer GROUP BY j * 2 ORDER BY i;
-- bwc_tag:end_query

