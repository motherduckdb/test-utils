-- bwc_tag:nb_steps=9
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (1), (2), (3)
-- bwc_tag:end_query

SELECT DISTINCT i%2 FROM integers ORDER BY 1
-- bwc_tag:end_query

SELECT DISTINCT i % 2 FROM integers WHERE i<3 ORDER BY i
-- bwc_tag:end_query

SELECT DISTINCT ON (1) i % 2, i FROM integers WHERE i<3 ORDER BY i
-- bwc_tag:end_query

SELECT DISTINCT integers.i FROM integers ORDER BY i DESC
-- bwc_tag:end_query

SELECT DISTINCT i FROM integers ORDER BY integers.i DESC
-- bwc_tag:end_query

SELECT DISTINCT integers.i FROM integers ORDER BY integers.i DESC
-- bwc_tag:end_query

