-- bwc_tag:nb_steps=28
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER, j INTEGER, k INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (2, 3, 5), (4, 5, 6), (2, 7, 6)
-- bwc_tag:end_query

SELECT DISTINCT ON (i) i, j FROM integers WHERE i <> 2
-- bwc_tag:end_query

SELECT DISTINCT ON (j) i, j FROM integers WHERE i <> 2
-- bwc_tag:end_query

SELECT DISTINCT ON (j, i) i, j FROM integers WHERE i <> 2
-- bwc_tag:end_query

SELECT DISTINCT ON (j + 1, i * 3) i, j FROM integers WHERE i <> 2
-- bwc_tag:end_query

SELECT DISTINCT ON (1) i, j FROM integers ORDER BY i
-- bwc_tag:end_query

SELECT DISTINCT ON (1) i, j FROM integers ORDER BY i LIMIT 1
-- bwc_tag:end_query

SELECT DISTINCT ON (1) i, j FROM integers ORDER BY i LIMIT 1 OFFSET 1
-- bwc_tag:end_query

SELECT DISTINCT ON (2) i, j FROM integers ORDER BY 2
-- bwc_tag:end_query

SELECT DISTINCT ON (2) j, k FROM integers ORDER BY 2
-- bwc_tag:end_query

SELECT DISTINCT ON (3) i, j, k FROM integers ORDER BY 2
-- bwc_tag:end_query

SELECT DISTINCT ON (3) i, j, k FROM integers ORDER BY 3
-- bwc_tag:end_query

SELECT DISTINCT ON (2) j, (SELECT i FROM integers WHERE i=2 LIMIT 1) FROM integers ORDER BY 2
-- bwc_tag:end_query

SELECT DISTINCT ON (2) j, (SELECT DISTINCT ON (i) i FROM integers ORDER BY 1 LIMIT 1) FROM integers ORDER BY 2
-- bwc_tag:end_query

SELECT DISTINCT ON (i) i, j FROM integers ORDER BY j
-- bwc_tag:end_query

SELECT * FROM (SELECT DISTINCT ON (i) i, j FROM integers) tbl1 WHERE i <> 2
-- bwc_tag:end_query

SELECT DISTINCT ON (i) i, j FROM integers ORDER BY k
-- bwc_tag:end_query

SELECT DISTINCT ON (i) i, j, k FROM integers ORDER BY k
-- bwc_tag:end_query

SELECT DISTINCT ON (integers.i) i, j FROM integers ORDER BY 1, 2
-- bwc_tag:end_query

SELECT DISTINCT ON (i) integers.i, integers.j FROM integers ORDER BY 1, 2
-- bwc_tag:end_query

SELECT DISTINCT ON (integers.i) integers.i, integers.j FROM integers ORDER BY i, j
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT DISTINCT ON (2) i FROM integers
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT DISTINCT ON(i, 'literal') i FROM integers
-- bwc_tag:end_query

SET order_by_non_integer_literal=true
-- bwc_tag:end_query

SELECT DISTINCT ON(i, 'literal') i FROM integers ORDER BY ALL
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

PREPARE v1 AS select distinct on (?) 42;
-- bwc_tag:end_query

