-- bwc_tag:nb_steps=1
EXPORT DATABASE 'output/empty_export' (FORMAT CSV)
-- bwc_tag:end_query

