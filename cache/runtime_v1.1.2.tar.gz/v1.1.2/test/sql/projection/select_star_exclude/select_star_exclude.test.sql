-- bwc_tag:nb_steps=21
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER, j INTEGER, k INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (1, 2, 3)
-- bwc_tag:end_query

SELECT * EXCLUDE i FROM integers
-- bwc_tag:end_query

SELECT * EXCLUDE (i, j) FROM integers
-- bwc_tag:end_query

SELECT * EXCLUDE (j) FROM integers
-- bwc_tag:end_query

SELECT * EXCLUDE (j) FROM integers
-- bwc_tag:end_query

SELECT * EXCLUDE ("J") FROM integers
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * EXCLUDE (i, j, k) FROM integers
-- bwc_tag:end_query

SELECT integers.* EXCLUDE (i) FROM integers
-- bwc_tag:end_query

SELECT integers.* EXCLUDE (i, j) FROM integers
-- bwc_tag:end_query

SELECT integers.* EXCLUDE (j) FROM integers
-- bwc_tag:end_query

SELECT integers.* EXCLUDE (i, j), * EXCLUDE (i, j), * EXCLUDE (i, k) FROM integers
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT integers.* EXCLUDE (i, j, k) FROM integers
-- bwc_tag:end_query

SELECT * EXCLUDE (i, j) FROM integers i1, integers i2
-- bwc_tag:end_query

SELECT i1.* EXCLUDE (i, j), i2.* EXCLUDE (i, j, k) FROM integers i1, integers i2
-- bwc_tag:end_query

SELECT i1.* EXCLUDE (i, j), i2.* EXCLUDE (k) FROM integers i1, integers i2
-- bwc_tag:end_query

SELECT * EXCLUDE (i) FROM integers i1 JOIN integers i2 USING (i)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * EXCLUDE (i, i) FROM integers
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * EXCLUDE (blabla) FROM integers
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT integers.* EXCLUDE (blabla) FROM integers
-- bwc_tag:end_query

