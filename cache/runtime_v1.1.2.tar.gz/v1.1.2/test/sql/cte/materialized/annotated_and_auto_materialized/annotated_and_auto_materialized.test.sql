-- bwc_tag:nb_steps=3
-- bwc_tag:execute_from_sql
create table batch (
    entity text,
    start_ts timestamp,
    duration interval
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table active_events (
    entity text,
    start_ts timestamp,
    end_ts timestamp
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
explain create table new_active_events as
with
  new_events as materialized (  -- Does not make much sense in this example, but my original query was a union of a bunch of things
      select * from batch
  ), combined_deduplicated_events as (
      select
          entity,
          min(start_ts) as start_ts,
          max(end_ts) as end_ts
      from
          active_events
      group by
          entity
  ), all_events as (
      select  * from combined_deduplicated_events
  )
select
  *
from
  new_events;
-- bwc_tag:end_query

