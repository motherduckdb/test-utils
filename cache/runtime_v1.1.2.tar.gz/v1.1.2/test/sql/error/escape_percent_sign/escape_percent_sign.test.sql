-- bwc_tag:nb_steps=2
-- bwc_tag:execute_from_sql
CREATE VIEW list_int AS
SELECT case when i%2 <> 0 then [1] else NULL end FROM range(10000) tbl(i);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select count(*) from list_int where l is distinct from NULL;
-- bwc_tag:end_query

