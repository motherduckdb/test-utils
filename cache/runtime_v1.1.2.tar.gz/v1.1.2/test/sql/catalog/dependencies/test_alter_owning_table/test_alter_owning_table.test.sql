-- bwc_tag:nb_steps=10
-- bwc_tag:execute_from_sql
create sequence seq;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create sequence other_seq;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table tbl (
	a integer default nextval('other_seq')
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
alter sequence seq owned by tbl;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
alter table tbl rename to tbl2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

drop sequence seq;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

drop sequence other_seq;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop table tbl2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

drop sequence seq;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop sequence other_seq;
-- bwc_tag:end_query

