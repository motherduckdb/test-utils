-- bwc_tag:nb_steps=4
-- bwc_tag:skip_query
pragma enable_verification;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table tbl(a varchar, b integer);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create index idx on tbl(a);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

alter table tbl drop column a;
-- bwc_tag:end_query

