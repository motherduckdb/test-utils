-- bwc_tag:nb_steps=8
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t1 (c1 CHAR(5));
-- bwc_tag:end_query

-- bwc_tag:skip_query
BEGIN TRANSACTION;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE IF EXISTS t1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE T1 (C2 CHAR(5));
-- bwc_tag:end_query

SELECT C2 FROM T1;
-- bwc_tag:end_query

-- bwc_tag:skip_query
ROLLBACK;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT C2 FROM T1;
-- bwc_tag:end_query

