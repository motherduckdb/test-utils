-- bwc_tag:nb_steps=6
-- bwc_tag:execute_from_sql
CREATE TABLE integers("42" INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (33)
-- bwc_tag:end_query

SELECT "42" FROM integers;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE "table ""." ( "col ""." TEXT)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO "table ""." ("col "".") VALUES ('quote_escaped_quote_''')
-- bwc_tag:end_query

SELECT "table ""."."col "".", "col ""." FROM "table "".";
-- bwc_tag:end_query

