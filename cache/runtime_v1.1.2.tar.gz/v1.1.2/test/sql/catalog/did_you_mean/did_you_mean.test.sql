-- bwc_tag:nb_steps=5
-- bwc_tag:execute_from_sql
CREATE TABLE hello(i INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test.bye(i INTEGER);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM helloo;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM bye;
-- bwc_tag:end_query

