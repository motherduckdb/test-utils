-- bwc_tag:nb_steps=52
SET default_null_order='nulls_first';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE INTEGERS(I INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers (i) VALUES (1), (2), (3), (NULL);
-- bwc_tag:end_query

SELECT integers.i FROM integers ORDER BY i;
-- bwc_tag:end_query

SELECT integers.i AS i FROM integers GROUP BY I ORDER BY "integers"."I";
-- bwc_tag:end_query

SELECT integers.i AS "ZZZ" FROM integers GROUP BY "zzz" ORDER BY "INTEGERS"."i";
-- bwc_tag:end_query

WITH "CTE"("ZZZ") AS (
	SELECT integers.i AS "ZZZ" FROM integers GROUP BY "zzz"
)
SELECT * FROM cte ORDER BY zZz;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

WITH "CTE"("ZZZ") AS (
	SELECT integers.i AS "ZZZ" FROM integers GROUP BY "zzz"
),
	"cte" AS (SELECT 42)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
UPDATE integers SET i=integers.i+1
-- bwc_tag:end_query

SELECT i FROM integers ORDER BY integers.i;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DELETE FROM integers WHERE i IS NULL;
-- bwc_tag:end_query

SELECT i FROM integers ORDER BY integers.i;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE integers ADD COLUMN J INTEGER;
-- bwc_tag:end_query

SELECT i, j FROM integers ORDER BY integers.i;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
UPDATE integers SET j=integers.i;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE integers DROP COLUMN i;
-- bwc_tag:end_query

SELECT j FROM integers ORDER BY integers.j;
-- bwc_tag:end_query

SELECT tbl.k FROM (SELECT j FROM integers) TBL(K) ORDER BY K;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE integers;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE STRUCTS(S ROW(I ROW(K INTEGER)));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO structs VALUES ({'i': {'k': 42}});
-- bwc_tag:end_query

SELECT structs.S.i.K, "STRUCTS"."S"."I"."K", "structs"."s"."i"."k" FROM structs
-- bwc_tag:end_query

SELECT "STRUCTS"."S"."I"."K" FROM structs GROUP BY "STRUCTS"."S"."I"."K"
-- bwc_tag:end_query

SELECT structs.S.i.K FROM structs GROUP BY structs.S.i.K
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE structs;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA preserve_identifier_case=false;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE INTEGERS(I INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers (i) VALUES (1), (2), (3), (NULL);
-- bwc_tag:end_query

SELECT integers.i FROM integers ORDER BY i;
-- bwc_tag:end_query

SELECT integers.i AS i FROM integers GROUP BY I ORDER BY "integers"."I";
-- bwc_tag:end_query

SELECT integers.i AS "ZZZ" FROM integers GROUP BY "zzz" ORDER BY "INTEGERS"."i";
-- bwc_tag:end_query

WITH "CTE"("ZZZ") AS (
	SELECT integers.i AS "ZZZ" FROM integers GROUP BY "zzz"
)
SELECT * FROM cte ORDER BY zZz;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

WITH "CTE"("ZZZ") AS (
	SELECT integers.i AS "ZZZ" FROM integers GROUP BY "zzz"
),
	"cte" AS (SELECT 42)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
UPDATE integers SET i=integers.i+1
-- bwc_tag:end_query

SELECT i FROM integers ORDER BY integers.i;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DELETE FROM integers WHERE i IS NULL;
-- bwc_tag:end_query

SELECT i FROM integers ORDER BY integers.i;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE integers ADD COLUMN J INTEGER;
-- bwc_tag:end_query

SELECT i, j FROM integers ORDER BY integers.i;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
UPDATE integers SET j=integers.i;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE integers DROP COLUMN i;
-- bwc_tag:end_query

SELECT j FROM integers ORDER BY integers.j;
-- bwc_tag:end_query

SELECT tbl.k FROM (SELECT j FROM integers) TBL(K) ORDER BY K;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE integers;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE STRUCTS(S ROW(I ROW(K INTEGER)));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO structs VALUES ({'i': {'k': 42}});
-- bwc_tag:end_query

SELECT structs.S.i.K, "STRUCTS"."S"."I"."K", "structs"."s"."i"."k" FROM structs
-- bwc_tag:end_query

SELECT "STRUCTS"."S"."I"."K" FROM structs GROUP BY "STRUCTS"."S"."I"."K"
-- bwc_tag:end_query

SELECT structs.S.i.K FROM structs GROUP BY structs.S.i.K
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE structs;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA preserve_identifier_case=false;
-- bwc_tag:end_query

