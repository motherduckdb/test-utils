-- bwc_tag:needed_extensions=parquet;httpfs
-- bwc_tag:nb_steps=9
LOAD 'parquet';
-- bwc_tag:end_query

LOAD 'httpfs';
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

FROM parquet_scan('hf://')
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

FROM 'hf://file.parquet'
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

FROM 'hf://yepthisdoesntwork/file.parquet'
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

FROM 'hf://stil/not/file.parquet'
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

FROM 'hf://datasets/file.parquet'
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

FROM 'hf://datasets/myname/file.parquet'
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

FROM 'hf://datasets/**/file.parquet'
-- bwc_tag:end_query

