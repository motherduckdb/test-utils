-- bwc_tag:needed_extensions=parquet;tpch
-- bwc_tag:nb_steps=9
LOAD 'tpch';
-- bwc_tag:end_query

LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE lineitem AS SELECT * FROM 'data/parquet-testing/arrow/lineitem-arrow.parquet'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA tpch(1)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA tpch(6)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE lineitem
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW lineitem AS SELECT * FROM 'data/parquet-testing/arrow/lineitem-arrow.parquet'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA tpch(1)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA tpch(6)
-- bwc_tag:end_query

