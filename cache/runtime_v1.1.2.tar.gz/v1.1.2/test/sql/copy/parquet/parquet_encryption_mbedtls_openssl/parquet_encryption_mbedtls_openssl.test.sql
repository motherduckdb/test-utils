-- bwc_tag:needed_extensions=parquet;httpfs
-- bwc_tag:nb_steps=21
LOAD 'parquet';
-- bwc_tag:end_query

LOAD 'httpfs';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA add_parquet_key('key128', '0123456789112345')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA add_parquet_key('key192', '012345678911234501234567')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA add_parquet_key('key256', '01234567891123450123456789112345')
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

COPY (SELECT 42 i) to 'output/encrypted128_openssl.parquet' (ENCRYPTION_CONFIG {footer_key: 'key128'}, DEBUG_USE_OPENSSL randomval)
-- bwc_tag:end_query

COPY (SELECT 42 i) to 'output/encrypted128_openssl.parquet' (ENCRYPTION_CONFIG {footer_key: 'key128'}, DEBUG_USE_OPENSSL true)
-- bwc_tag:end_query

SELECT * FROM read_parquet('output/encrypted128_openssl.parquet', encryption_config={footer_key: 'key128'}, debug_use_openssl=false)
-- bwc_tag:end_query

COPY (SELECT 42 i) to 'output/encrypted128_mbedtls.parquet' (ENCRYPTION_CONFIG {footer_key: 'key128'}, DEBUG_USE_OPENSSL false)
-- bwc_tag:end_query

SELECT * FROM read_parquet('output/encrypted128_mbedtls.parquet', encryption_config={footer_key: 'key128'}, debug_use_openssl=true)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

COPY (SELECT 42 i) to 'output/encrypted192_openssl.parquet' (ENCRYPTION_CONFIG {footer_key: 'key192'}, DEBUG_USE_OPENSSL randomval)
-- bwc_tag:end_query

COPY (SELECT 42 i) to 'output/encrypted192_openssl.parquet' (ENCRYPTION_CONFIG {footer_key: 'key192'}, DEBUG_USE_OPENSSL true)
-- bwc_tag:end_query

SELECT * FROM read_parquet('output/encrypted192_openssl.parquet', encryption_config={footer_key: 'key192'}, debug_use_openssl=false)
-- bwc_tag:end_query

COPY (SELECT 42 i) to 'output/encrypted192_mbedtls.parquet' (ENCRYPTION_CONFIG {footer_key: 'key192'}, DEBUG_USE_OPENSSL false)
-- bwc_tag:end_query

SELECT * FROM read_parquet('output/encrypted192_mbedtls.parquet', encryption_config={footer_key: 'key192'}, debug_use_openssl=true)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

COPY (SELECT 42 i) to 'output/encrypted256_openssl.parquet' (ENCRYPTION_CONFIG {footer_key: 'key256'}, DEBUG_USE_OPENSSL randomval)
-- bwc_tag:end_query

COPY (SELECT 42 i) to 'output/encrypted256_openssl.parquet' (ENCRYPTION_CONFIG {footer_key: 'key256'}, DEBUG_USE_OPENSSL true)
-- bwc_tag:end_query

SELECT * FROM read_parquet('output/encrypted256_openssl.parquet', encryption_config={footer_key: 'key256'}, debug_use_openssl=false)
-- bwc_tag:end_query

COPY (SELECT 42 i) to 'output/encrypted256_mbedtls.parquet' (ENCRYPTION_CONFIG {footer_key: 'key256'}, DEBUG_USE_OPENSSL false)
-- bwc_tag:end_query

SELECT * FROM read_parquet('output/encrypted256_mbedtls.parquet', encryption_config={footer_key: 'key256'}, debug_use_openssl=true)
-- bwc_tag:end_query

