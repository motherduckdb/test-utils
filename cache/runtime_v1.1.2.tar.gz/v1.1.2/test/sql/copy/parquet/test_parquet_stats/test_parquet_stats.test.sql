-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=22
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA explain_output = PHYSICAL_ONLY
-- bwc_tag:end_query

explain select * from parquet_scan('data/parquet-testing/userdata1.parquet') where false;
-- bwc_tag:end_query

explain select * from parquet_scan('data/parquet-testing/userdata1.parquet') where id is null;
-- bwc_tag:end_query

explain select * from parquet_scan('data/parquet-testing/userdata1.parquet') where id < 1;
-- bwc_tag:end_query

explain select * from parquet_scan('data/parquet-testing/userdata1.parquet') where id > 1000;
-- bwc_tag:end_query

explain select * from parquet_scan('data/parquet-testing/userdata1.parquet') where salary < 12380;
-- bwc_tag:end_query

explain select * from parquet_scan('data/parquet-testing/userdata1.parquet') where salary > 286593;
-- bwc_tag:end_query

explain select * from parquet_scan('data/parquet-testing/timestamp.parquet') where time < '2020-10-04';
-- bwc_tag:end_query

explain select * from parquet_scan('data/parquet-testing/timestamp.parquet') where time > '2020-10-06';
-- bwc_tag:end_query

explain select * from parquet_scan('data/parquet-testing/timestamp-ms.parquet') where time < '2020-10-04';
-- bwc_tag:end_query

explain select * from parquet_scan('data/parquet-testing/timestamp-ms.parquet') where time > '2020-10-06';
-- bwc_tag:end_query

explain select * from parquet_scan('data/parquet-testing/data-types.parquet') where timestampval < '2019-11-25';
-- bwc_tag:end_query

explain select * from parquet_scan('data/parquet-testing/data-types.parquet') where timestampval > '2019-11-27';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
pragma disable_object_cache
-- bwc_tag:end_query

explain select time from parquet_scan('data/parquet-testing/timestamp*.parquet') where time > '2020-10-06'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
pragma enable_object_cache
-- bwc_tag:end_query

explain select time from parquet_scan('data/parquet-testing/timestamp*.parquet') where time > '2020-10-06'
-- bwc_tag:end_query

select time from parquet_scan('data/parquet-testing/timestamp*.parquet') where time > '2020-10-06'
-- bwc_tag:end_query

explain select time from parquet_scan('data/parquet-testing/timestamp*.parquet') where time > '2020-10-06'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
pragma disable_object_cache
-- bwc_tag:end_query

explain select time from parquet_scan('data/parquet-testing/timestamp*.parquet') where time > '2020-10-06'
-- bwc_tag:end_query

