-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=7
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table test as select i%5 as a, i%2 as b from range(0,10) tbl(i);
-- bwc_tag:end_query

copy (FROM test UNION ALL select 'NULL' as a, 'NULL' as b) to 'output/null-parquet' (PARTITION_BY (a,b), FORMAT 'parquet', WRITE_PARTITION_COLUMNS);
-- bwc_tag:end_query

select * 
from parquet_scan('output/null-parquet/**/*.parquet', hive_partitioning=1, hive_types={'a': INT})
ORDER BY ALL
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table test2 as select i%5 as a, i%2 as b, i as c from range(0,10) tbl(i);
-- bwc_tag:end_query

copy (FROM test2 UNION ALL select 'NULL' as a, 'NULL' as b, 'NULL' as c) to 'output/null-parquet' (PARTITION_BY (a,b), FORMAT 'parquet', OVERWRITE);
-- bwc_tag:end_query

select * 
from parquet_scan('output/null-parquet/**/*.parquet', hive_partitioning=1, hive_types={'a': INT})
ORDER BY ALL
-- bwc_tag:end_query

