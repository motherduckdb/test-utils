-- bwc_tag:needed_extensions=parquet;httpfs
-- bwc_tag:nb_steps=3
LOAD 'parquet';
-- bwc_tag:end_query

LOAD 'httpfs';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE snowflake_lineitem AS FROM 'https://github.com/duckdb/duckdb-data/releases/download/v1.0/snowflake_lineitem_export.parquet'
-- bwc_tag:end_query

