-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=19
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE struct_of_lists AS SELECT * FROM (VALUES
	({'a': [1, 2, 3], 'b': ['hello', 'world']}),
	({'a': [4, NULL, 5], 'b': ['duckduck', 'goose']}),
	({'a': NULL, 'b': ['longlonglonglonglonglong', NULL, NULL]}),
	(NULL),
    ({'a': [], 'b': []}),
    ({'a': [1, 2, 3], 'b': NULL})
) tbl(i);
-- bwc_tag:end_query

COPY struct_of_lists TO 'output/complex_list.parquet' (FORMAT 'parquet');
-- bwc_tag:end_query

SELECT i FROM parquet_scan('output/complex_list.parquet');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE list_of_structs AS SELECT * FROM (VALUES
	([{'a': 1, 'b': 100}, NULL, {'a': 2, 'b': 101}]),
	(NULL),
	([]),
	([{'a': NULL, 'b': 102}, {'a': 3, 'b': NULL}, NULL])
) tbl(i);
-- bwc_tag:end_query

COPY list_of_structs TO 'output/complex_list.parquet' (FORMAT 'parquet');
-- bwc_tag:end_query

SELECT i FROM parquet_scan('output/complex_list.parquet');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE list_of_struct_of_structs AS SELECT * FROM (VALUES
	([{'a': {'x': 33}, 'b': {'y': 42, 'z': 99}}, NULL, {'a': {'x': NULL}, 'b': {'y': 43, 'z': 100}}]),
	(NULL),
	([]),
	([{'a': NULL, 'b': {'y': NULL, 'z': 101}}, {'a': {'x': 34}, 'b': {'y': 43, 'z': NULL}}]),
	([{'a': NULL, 'b': NULL}])
) tbl(i);
-- bwc_tag:end_query

COPY list_of_struct_of_structs TO 'output/complex_list.parquet' (FORMAT 'parquet');
-- bwc_tag:end_query

SELECT i FROM parquet_scan('output/complex_list.parquet');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE list_of_lists_simple AS SELECT * FROM (VALUES
	([[1, 2, 3], [4, 5]]),
	([[6, 7]]),
	([[8, 9, 10], [11, 12]])
) tbl(i);
-- bwc_tag:end_query

COPY list_of_lists_simple TO 'output/complex_list.parquet' (FORMAT 'parquet');
-- bwc_tag:end_query

SELECT i FROM parquet_scan('output/complex_list.parquet');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE list_of_lists AS SELECT * FROM (VALUES
	([[1, 2, 3], [4, 5], [], [6, 7]]),
	([[8, NULL, 10], NULL, []]),
	([]),
	(NULL),
	([[11, 12, 13, 14], [], NULL, [], [], [15], [NULL, NULL, NULL]])
) tbl(i);
-- bwc_tag:end_query

COPY list_of_lists TO 'output/complex_list.parquet' (FORMAT 'parquet');
-- bwc_tag:end_query

SELECT i FROM parquet_scan('output/complex_list.parquet');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE list_of_lists_of_lists_of_lists AS
   SELECT [LIST(i)] i FROM list_of_lists
   UNION ALL
   SELECT NULL
   UNION ALL
   SELECT [NULL]
   UNION ALL
   SELECT [[], NULL, [], []]
   UNION ALL
   SELECT [[[NULL, NULL, [NULL]], NULL, [[], [7, 8, 9], [NULL], NULL, []]], [], [NULL]]
-- bwc_tag:end_query

COPY list_of_lists_of_lists_of_lists TO 'output/complex_list.parquet' (FORMAT 'parquet');
-- bwc_tag:end_query

SELECT i FROM parquet_scan('output/complex_list.parquet');
-- bwc_tag:end_query

