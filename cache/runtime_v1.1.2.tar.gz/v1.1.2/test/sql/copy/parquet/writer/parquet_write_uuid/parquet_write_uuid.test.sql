-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=7
SET default_null_order='nulls_first';
-- bwc_tag:end_query

LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE IF NOT EXISTS uuid (u uuid);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO uuid VALUES
       ('A0EEBC99-9C0B-4EF8-BB6D-6BB9BD380A11'),
       (NULL),
       ('47183823-2574-4bfd-b411-99ed177d3e43'),
       ('{10203040506070800102030405060708}'),
       ('A0EEBC99-9C0B-4EF8-BB6D-6BB9BD380A11'),
       (NULL),
       ('00112233-4455-6677-8899-aabbccddeeff'),
       ('47183823-2574-4bfd-b411-99ed177d3e43'),
       ('{10203040506070800102030405060708}'),
       ('00000000-0000-0000-0000-000000000000'),
       ('00000000-0000-0000-0000-000000000001'),
       ('00000000-0000-0000-8000-000000000001'),
       ('80000000-0000-0000-0000-000000000000'),
       ('80000000-0000-0000-8000-000000000000'),
       ('80000000-0000-0000-8fff-ffffffffffff'),
       ('80000000-0000-0000-ffff-ffffffffffff'),
       ('8fffffff-ffff-ffff-0000-000000000000'),
       ('8fffffff-ffff-ffff-8000-000000000000'),
       ('8fffffff-ffff-ffff-8fff-ffffffffffff'),
       ('8fffffff-ffff-ffff-ffff-ffffffffffff'),
       ('ffffffff-ffff-ffff-ffff-ffffffffffff');
-- bwc_tag:end_query

COPY uuid TO 'output/uuid.parquet'
-- bwc_tag:end_query

SELECT * FROM 'output/uuid.parquet' ORDER BY 1
-- bwc_tag:end_query

