-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=50
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE values_TINYINT AS SELECT d::TINYINT d FROM (VALUES
    (-128), (42), (NULL), (127)) tbl (d);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE values_SMALLINT AS SELECT d::SMALLINT d FROM (VALUES
    (-32768), (42), (NULL), (32767)) tbl (d);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE values_INTEGER AS SELECT d::INTEGER d FROM (VALUES
    (-2147483648), (42), (NULL), (2147483647)) tbl (d);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE values_BIGINT AS SELECT d::BIGINT d FROM (VALUES
    (-9223372036854775808), (42), (NULL), (9223372036854775807)) tbl (d);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE signed(d TINYINT)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO signed SELECT * FROM values_TINYINT
-- bwc_tag:end_query

COPY signed TO 'output/signed.parquet' (FORMAT 'parquet');
-- bwc_tag:end_query

SELECT * FROM 'output/signed.parquet' EXCEPT SELECT * FROM signed
-- bwc_tag:end_query

SELECT * FROM signed EXCEPT SELECT * FROM 'output/signed.parquet'
-- bwc_tag:end_query

SELECT * FROM 'output/signed.parquet' WHERE d=42
-- bwc_tag:end_query

SELECT COUNT(*) FROM 'output/signed.parquet' WHERE d>42
-- bwc_tag:end_query

SELECT COUNT(*) FROM 'output/signed.parquet' WHERE d>=42
-- bwc_tag:end_query

SELECT COUNT(*) FROM 'output/signed.parquet' WHERE d<42
-- bwc_tag:end_query

SELECT COUNT(*) FROM 'output/signed.parquet' WHERE d<=42
-- bwc_tag:end_query

SELECT typeof(d)='TINYINT' FROM 'output/signed.parquet' LIMIT 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE signed(d SMALLINT)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO signed SELECT * FROM values_SMALLINT
-- bwc_tag:end_query

COPY signed TO 'output/signed.parquet' (FORMAT 'parquet');
-- bwc_tag:end_query

SELECT * FROM 'output/signed.parquet' EXCEPT SELECT * FROM signed
-- bwc_tag:end_query

SELECT * FROM signed EXCEPT SELECT * FROM 'output/signed.parquet'
-- bwc_tag:end_query

SELECT * FROM 'output/signed.parquet' WHERE d=42
-- bwc_tag:end_query

SELECT COUNT(*) FROM 'output/signed.parquet' WHERE d>42
-- bwc_tag:end_query

SELECT COUNT(*) FROM 'output/signed.parquet' WHERE d>=42
-- bwc_tag:end_query

SELECT COUNT(*) FROM 'output/signed.parquet' WHERE d<42
-- bwc_tag:end_query

SELECT COUNT(*) FROM 'output/signed.parquet' WHERE d<=42
-- bwc_tag:end_query

SELECT typeof(d)='SMALLINT' FROM 'output/signed.parquet' LIMIT 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE signed(d INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO signed SELECT * FROM values_INTEGER
-- bwc_tag:end_query

COPY signed TO 'output/signed.parquet' (FORMAT 'parquet');
-- bwc_tag:end_query

SELECT * FROM 'output/signed.parquet' EXCEPT SELECT * FROM signed
-- bwc_tag:end_query

SELECT * FROM signed EXCEPT SELECT * FROM 'output/signed.parquet'
-- bwc_tag:end_query

SELECT * FROM 'output/signed.parquet' WHERE d=42
-- bwc_tag:end_query

SELECT COUNT(*) FROM 'output/signed.parquet' WHERE d>42
-- bwc_tag:end_query

SELECT COUNT(*) FROM 'output/signed.parquet' WHERE d>=42
-- bwc_tag:end_query

SELECT COUNT(*) FROM 'output/signed.parquet' WHERE d<42
-- bwc_tag:end_query

SELECT COUNT(*) FROM 'output/signed.parquet' WHERE d<=42
-- bwc_tag:end_query

SELECT typeof(d)='INTEGER' FROM 'output/signed.parquet' LIMIT 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE signed(d BIGINT)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO signed SELECT * FROM values_BIGINT
-- bwc_tag:end_query

COPY signed TO 'output/signed.parquet' (FORMAT 'parquet');
-- bwc_tag:end_query

SELECT * FROM 'output/signed.parquet' EXCEPT SELECT * FROM signed
-- bwc_tag:end_query

SELECT * FROM signed EXCEPT SELECT * FROM 'output/signed.parquet'
-- bwc_tag:end_query

SELECT * FROM 'output/signed.parquet' WHERE d=42
-- bwc_tag:end_query

SELECT COUNT(*) FROM 'output/signed.parquet' WHERE d>42
-- bwc_tag:end_query

SELECT COUNT(*) FROM 'output/signed.parquet' WHERE d>=42
-- bwc_tag:end_query

SELECT COUNT(*) FROM 'output/signed.parquet' WHERE d<42
-- bwc_tag:end_query

SELECT COUNT(*) FROM 'output/signed.parquet' WHERE d<=42
-- bwc_tag:end_query

SELECT typeof(d)='BIGINT' FROM 'output/signed.parquet' LIMIT 1
-- bwc_tag:end_query

