-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=8
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE bools(b BOOL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO bools SELECT CASE WHEN i%2=0 THEN NULL ELSE i%7=0 OR i%3=0 END b FROM range(10000) tbl(i);
-- bwc_tag:end_query

SELECT COUNT(*), COUNT(b), BOOL_AND(b), BOOL_OR(b), SUM(CASE WHEN b THEN 1 ELSE 0 END) true_count, SUM(CASE WHEN b THEN 0 ELSE 1 END) false_count
FROM bools
-- bwc_tag:end_query

COPY bools TO 'output/bools.parquet' (FORMAT 'parquet');
-- bwc_tag:end_query

SELECT COUNT(*), COUNT(b), BOOL_AND(b), BOOL_OR(b), SUM(CASE WHEN b THEN 1 ELSE 0 END) true_count, SUM(CASE WHEN b THEN 0 ELSE 1 END) false_count
FROM 'output/bools.parquet'
-- bwc_tag:end_query

SELECT typeof(b) FROM 'output/bools.parquet' LIMIT 1
-- bwc_tag:end_query

