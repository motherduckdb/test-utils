-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=8
SET default_null_order='nulls_first';
-- bwc_tag:end_query

LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE IF NOT EXISTS intervals (i interval);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO intervals VALUES
       (interval '1' day),
       (interval '00:00:01'),
       (NULL),
       (interval '0' month),
       (interval '1' month)
-- bwc_tag:end_query

COPY intervals TO 'output/intervals.parquet'
-- bwc_tag:end_query

SELECT * FROM 'output/intervals.parquet' ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

COPY (SELECT -interval '1 day') TO 'output/intervals.parquet'
-- bwc_tag:end_query

