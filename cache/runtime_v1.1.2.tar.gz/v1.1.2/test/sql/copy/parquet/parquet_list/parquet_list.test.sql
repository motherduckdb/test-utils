-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=10
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

select count(*) from parquet_scan(['data/parquet-testing/glob/t1.parquet', 'data/parquet-testing/glob/t2.parquet']);
-- bwc_tag:end_query

select count(*) from parquet_scan(['data/parquet-testing/glob/*.parquet', 'data/parquet-testing/glob/t2.parquet']);
-- bwc_tag:end_query

select count(*) from parquet_scan(['data/parquet-testing/glob/t1.parquet', 'data/parquet-testing/glob/t1.parquet', 'data/parquet-testing/glob/t1.parquet', 'data/parquet-testing/glob/t1.parquet', 'data/parquet-testing/glob/t1.parquet']);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select count(*) from parquet_scan(['data/parquet-testing/glob/t1.parquet', 'data/parquet-testing/glob/t2.parquet', 'this/file/doesnot/exist/hopefully.parquet']);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select count(*) from parquet_scan([]::varchar[]);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select count(*) from parquet_scan([NULL]);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select count(*) from parquet_scan(NULL::VARCHAR[]);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select count(*) from parquet_scan(NULL::VARCHAR);
-- bwc_tag:end_query

