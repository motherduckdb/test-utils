-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=19
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers AS SELECT i, i // 5 AS j FROM range(1000000) t(i) ;
-- bwc_tag:end_query

COPY integers TO 'output/batched_integers.parquet';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers_copied AS FROM 'output/batched_integers.parquet'
-- bwc_tag:end_query

SELECT SUM(i), SUM(j), COUNT(*), COUNT(i), COUNT(j) FROM integers_copied
-- bwc_tag:end_query

SELECT * FROM integers_copied ORDER BY i LIMIT 5
-- bwc_tag:end_query

SELECT * FROM integers_copied ORDER BY i LIMIT 5 OFFSET 99997
-- bwc_tag:end_query

SELECT * FROM integers_copied QUALIFY i<=lag(i) over ()
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW v1 AS SELECT * FROM integers WHERE (i%2=0 AND i<300000) OR (i BETWEEN 500000 AND 700000)
-- bwc_tag:end_query

COPY v1 TO 'output/batched_integers_filters.parquet';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers_filtered AS FROM 'output/batched_integers_filters.parquet'
-- bwc_tag:end_query

SELECT SUM(i), SUM(j), COUNT(*), COUNT(i), COUNT(j) FROM v1
-- bwc_tag:end_query

SELECT * FROM v1 ORDER BY i LIMIT 5
-- bwc_tag:end_query

SELECT * FROM v1 ORDER BY i LIMIT 5 OFFSET 99997
-- bwc_tag:end_query

SELECT * FROM v1 ORDER BY i LIMIT 5 OFFSET 300000
-- bwc_tag:end_query

SELECT SUM(i), SUM(j), COUNT(*), COUNT(i), COUNT(j) FROM integers_filtered
-- bwc_tag:end_query

SELECT * FROM integers_filtered ORDER BY i LIMIT 5
-- bwc_tag:end_query

SELECT * FROM integers_filtered ORDER BY i LIMIT 5 OFFSET 99997
-- bwc_tag:end_query

SELECT * FROM integers_filtered ORDER BY i LIMIT 5 OFFSET 300000
-- bwc_tag:end_query

