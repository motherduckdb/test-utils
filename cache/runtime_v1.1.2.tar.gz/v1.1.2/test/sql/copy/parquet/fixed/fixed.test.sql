-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=2
LOAD 'parquet';
-- bwc_tag:end_query

SELECT data FROM parquet_scan('data/parquet-testing/fixed.parquet')
-- bwc_tag:end_query

