-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=17
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

SELECT typeof(#1) FROM parquet_scan('data/parquet-testing/binary_string.parquet',binary_as_string=False) limit 1
-- bwc_tag:end_query

SELECT * FROM parquet_scan('data/parquet-testing/binary_string.parquet',binary_as_string=False)
-- bwc_tag:end_query

SELECT typeof(#1) FROM parquet_scan('data/parquet-testing/binary_string.parquet',binary_as_string=True) limit 1
-- bwc_tag:end_query

SELECT * FROM parquet_scan('data/parquet-testing/binary_string.parquet',binary_as_string=True)
-- bwc_tag:end_query

SELECT converted_type FROM parquet_schema('data/parquet-testing/binary_string.parquet')
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SET binary_as_sting=true
-- bwc_tag:end_query

SET binary_as_string=true
-- bwc_tag:end_query

SELECT typeof(#1) FROM parquet_scan('data/parquet-testing/binary_string.parquet') limit 1
-- bwc_tag:end_query

SELECT * FROM parquet_scan('data/parquet-testing/binary_string.parquet')
-- bwc_tag:end_query

SET binary_as_string=false
-- bwc_tag:end_query

SELECT typeof(#1) FROM parquet_scan('data/parquet-testing/binary_string.parquet') limit 1
-- bwc_tag:end_query

SELECT * FROM parquet_scan('data/parquet-testing/binary_string.parquet')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA binary_as_string=1
-- bwc_tag:end_query

SELECT typeof(#1) FROM parquet_scan('data/parquet-testing/binary_string.parquet' ,binary_as_string=False) limit 1
-- bwc_tag:end_query

SELECT * FROM parquet_scan('data/parquet-testing/binary_string.parquet')
-- bwc_tag:end_query

