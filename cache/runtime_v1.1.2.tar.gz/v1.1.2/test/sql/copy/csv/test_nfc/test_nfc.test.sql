-- bwc_tag:nb_steps=4
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE nfcstrings (s STRING);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY nfcstrings FROM 'data/csv/test/nfc.csv' (HEADER 0);
-- bwc_tag:end_query

SELECT COUNT(*) FROM nfcstrings WHERE s COLLATE NFC = 'ü'
-- bwc_tag:end_query

