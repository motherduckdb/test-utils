-- bwc_tag:nb_steps=6
-- bwc_tag:execute_from_sql
PRAGMA verify_parallelism
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select * from read_csv_auto('data/csv/auto/test_single_column.csv')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select * from read_csv_auto('data/csv/auto/test_single_column_rn.csv')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select foo, count(1) cnt from read_csv_auto('data/csv/auto/test_multiple_columns.csv') group by foo order by cnt desc
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select foo, count(1) cnt from read_csv_auto('data/csv/auto/test_multiple_columns_rn.csv') group by foo order by cnt desc
-- bwc_tag:end_query

