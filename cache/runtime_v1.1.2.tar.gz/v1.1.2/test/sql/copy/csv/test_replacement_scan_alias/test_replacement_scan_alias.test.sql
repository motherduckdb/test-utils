-- bwc_tag:needed_extensions=parquet;json
-- bwc_tag:nb_steps=9
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select * from 'data/csv/test/dateformat.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select * from 'data/csv/test/dateformat.csv', 'data/csv/test/dateformat_2.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select mytbl.column0 from 'data/csv/test/dateformat.csv'mytbl;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select mytbl.mycol from 'data/csv/test/dateformat.csv' mytbl(mycol);
-- bwc_tag:end_query

LOAD 'parquet';
-- bwc_tag:end_query

select blob.ids from 'data/parquet-testing/blob.parquet'
-- bwc_tag:end_query

LOAD 'json';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select example_n.id from 'data/json/example_n.ndjson'
-- bwc_tag:end_query

