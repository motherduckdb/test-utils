-- bwc_tag:nb_steps=5
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE no_newline (a INTEGER, b INTEGER, c VARCHAR(10));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY no_newline FROM 'data/csv/test/no_newline.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE no_newline_unicode (a INTEGER, b INTEGER, c VARCHAR(10));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY no_newline_unicode FROM 'data/csv/test/no_newline_unicode.csv' DELIMITER '🦆';
-- bwc_tag:end_query

