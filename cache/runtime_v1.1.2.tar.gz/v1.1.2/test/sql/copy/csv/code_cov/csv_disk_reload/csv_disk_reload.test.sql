-- bwc_tag:nb_steps=6
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t1 AS select i, (i+1) as j from range(0,300000) tbl(i)
-- bwc_tag:end_query

COPY t1 TO 'output/t1.csv' (FORMAT CSV, DELIMITER '|', HEADER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA memory_limit='2M'
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA threads=2
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select count(*) from read_csv_auto('output/t1.csv',buffer_size = 262144, sample_size=-1)
-- bwc_tag:end_query

