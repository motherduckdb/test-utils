-- bwc_tag:nb_steps=57
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv('data/csv/glob/crawl/stackoverflow/**/*.csv', auto_detect=1) ORDER BY 2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv('data/csv/glob/crawl/stackoverflow/**', auto_detect=1) ORDER BY 2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv('data/csv/glob/crawl/samename/**/*.csv', auto_detect=1);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT sum(column0) FROM read_csv('data/csv/glob/crawl/samename/**', auto_detect=1);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT count(*) FROM read_csv('data/csv/glob/crawl/d/**/*.csv', auto_detect=1);
-- bwc_tag:end_query

SELECT count(*) FROM glob('data/csv/glob/crawl/d/**');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT sum(column0) FROM read_csv('data/csv/glob/crawl/d/**', auto_detect=1);
-- bwc_tag:end_query

SELECT count(*) FROM glob('data/csv/glob/crawl/d/**/');
-- bwc_tag:end_query

SELECT count(*) FROM glob('data/csv/glob/crawl/d/**/mid/*.csv');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT count(*) FROM 'data/csv/glob/crawl/d/**/mid/*.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT count(*) FROM 'data/csv/glob/crawl/d/**/mid/*/*.csv';
-- bwc_tag:end_query

SELECT count(*) FROM glob('data/csv/glob/crawl/d/**/mid/*/');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT count(*) FROM 'data/csv/glob/crawl/d/**/mid/**/*.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT count(*) FROM 'data/csv/glob/crawl/d/**/???/*/*.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT count(*) FROM 'data/csv/glob/crawl/d/*/???/**/*.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT count(*) FROM 'data/csv/glob/crawl/d/*/mid/**/*.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT count(*) FROM 'data/csv/glob/crawl/d/*/*/*/mid/**/*.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT count(*) FROM 'data/csv/glob/crawl/d/**/???/*.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT count(*) FROM 'data/csv/glob/crawl/d/*/???/*.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT count(*) FROM 'data/csv/glob/crawl/d/**/*/**/*.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT count(*) FROM 'data/csv/glob/crawl/d/**/d2?/*/*.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT count(*) FROM 'data/csv/glob/crawl/d/*/*/d2?/**/*.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT sum(column0) FROM read_csv('data/csv/glob/crawl/d/*/*/d2?/**', auto_detect=1);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT count(*) FROM 'data/csv/glob/crawl/d/**/d?0/*.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT count(*) FROM 'data/csv/glob/crawl/d/*/**/d?0/*.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT count(*) FROM 'data/csv/glob/crawl/d/**/**/**/**/*.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv_auto('data/csv/glob/crawl/hidden/**');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t0 AS SELECT (i%2) AS c_2, (i%3) AS c_3, (i*i) AS c_pow FROM RANGE(0,10) tbl(i);
-- bwc_tag:end_query

COPY t0 TO 'output/partitioned0' (PARTITION_BY(c_2,c_3));
-- bwc_tag:end_query

from glob('output/partitioned0/*');
-- bwc_tag:end_query

select count(*) from glob('output/partitioned0/*');
-- bwc_tag:end_query

select count(*) from glob('output/partitioned0/*/*/*');
-- bwc_tag:end_query

select count(*) from glob('output/partitioned0/*/*/**')
-- bwc_tag:end_query

select count(*) from glob('output/partitioned0/*/*/*/**')
-- bwc_tag:end_query

select count(*) from glob('output/partitioned0/**');
-- bwc_tag:end_query

select count(*) from glob('output/partitioned0/**/*');
-- bwc_tag:end_query

select count(*) from glob('output/partitioned0/*/**');
-- bwc_tag:end_query

select count(*) from glob('output/partitioned0/**/data_0.csv');
-- bwc_tag:end_query

select count(*) from glob('output/partitioned0/**/*/data_0.csv')
-- bwc_tag:end_query

select count(*) from glob('output/partitioned0/**/c_3=0/data_0.csv')
-- bwc_tag:end_query

select count(*) from glob('output/partitioned0/c_2=0/**/data_0.csv')
-- bwc_tag:end_query

COPY t0 TO 'output/partitioned0/data_1.csv';
-- bwc_tag:end_query

select count(*) from glob('output/partitioned0/*');
-- bwc_tag:end_query

select count(*) from glob('output/partitioned0/*');
-- bwc_tag:end_query

select count(*) from glob('output/partitioned0/*/*/*');
-- bwc_tag:end_query

select count(*) from glob('output/partitioned0/*/*/**')
-- bwc_tag:end_query

select count(*) from glob('output/partitioned0/*/*/*/**')
-- bwc_tag:end_query

select count(*) from glob('output/partitioned0/**');
-- bwc_tag:end_query

select count(*) from glob('output/partitioned0/**/*');
-- bwc_tag:end_query

select count(*) from glob('output/partitioned0/*/**');
-- bwc_tag:end_query

select count(*) from glob('output/partitioned0/**/data_0.csv');
-- bwc_tag:end_query

select count(*) from glob('output/partitioned0/**/*/data_0.csv')
-- bwc_tag:end_query

select count(*) from glob('output/partitioned0/**/c_3=0/data_0.csv')
-- bwc_tag:end_query

select count(*) from glob('output/partitioned0/c_2=0/**/data_0.csv')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv_auto('data/csv/glob/crawl/.symbolic_link/**');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT sum(column0) FROM read_csv('data/csv/glob/crawl/d/**/', auto_detect=1);
-- bwc_tag:end_query

