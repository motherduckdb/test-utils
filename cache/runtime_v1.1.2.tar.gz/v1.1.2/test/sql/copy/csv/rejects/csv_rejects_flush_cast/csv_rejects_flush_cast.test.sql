-- bwc_tag:nb_steps=2
-- bwc_tag:execute_from_sql
SELECT first(a), first(b), typeof(first(a)), typeof(first(b)), COUNT(*) FROM read_csv(
    'data/csv/error/flush_cast.csv',
    columns = {'a': 'DATE', 'b': 'VARCHAR'},
    store_rejects = true,
    delim = ',',
    dateformat = '%d-%m-%Y');
-- bwc_tag:end_query

SELECT * EXCLUDE (scan_id) FROM reject_errors order by all;
-- bwc_tag:end_query

