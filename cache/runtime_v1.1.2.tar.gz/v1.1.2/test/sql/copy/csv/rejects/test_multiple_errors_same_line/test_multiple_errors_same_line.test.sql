-- bwc_tag:nb_steps=70
-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/rejects/multiple_errors/cast_and_more_col.csv',
    columns = {'name': 'VARCHAR', 'age': 'INTEGER', 'current_day': 'DATE', 'barks': 'INTEGER'},
    store_rejects = true, auto_detect=false, header = 1);
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
SElECT * EXCLUDE (scan_id) FROM reject_errors ORDER BY ALL;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/rejects/multiple_errors/multiple_cast_implicit.csv',
    columns = {'name': 'VARCHAR', 'age': 'INTEGER', 'current_day': 'DATE', 'barks': 'INTEGER'},
    store_rejects = true, auto_detect=false, header = 1);
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
SElECT * EXCLUDE (scan_id) FROM reject_errors ORDER BY ALL;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/rejects/multiple_errors/multiple_casts_flush.csv',
    columns = {'name': 'VARCHAR', 'age': 'INTEGER', 'current_day': 'DATE', 'tomorrow': 'DATE'},
    store_rejects = true, auto_detect=false, header = 1);
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
SElECT * EXCLUDE (scan_id) FROM reject_errors ORDER BY ALL;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/rejects/multiple_errors/multiple_casts_mixed.csv',
    columns = {'name': 'VARCHAR', 'age': 'INTEGER', 'current_day': 'DATE', 'barks': 'INTEGER'},
    store_rejects = true, auto_detect=false, header = 1);
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
SElECT * EXCLUDE (scan_id) FROM reject_errors ORDER BY ALL;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/rejects/multiple_errors/cast_and_less_col.csv',
    columns = {'name': 'VARCHAR', 'age': 'INTEGER', 'current_day': 'DATE', 'barks': 'INTEGER'},
    store_rejects = true, auto_detect=false, header = 1);
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
SElECT * EXCLUDE (scan_id) FROM reject_errors ORDER BY ALL;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/rejects/multiple_errors/cast_and_maxline.csv',
    columns = {'name': 'VARCHAR', 'age': 'INTEGER', 'current_day': 'DATE', 'barks': 'INTEGER'},
    store_rejects = true, auto_detect=false, header = 1, max_line_size=40);
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
SElECT * EXCLUDE (scan_id) FROM reject_errors ORDER BY ALL;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/rejects/multiple_errors/less_col_and_max_line.csv',
    columns = {'name': 'VARCHAR', 'age': 'INTEGER', 'current_day': 'DATE', 'barks': 'INTEGER'},
    store_rejects = true, auto_detect=false, header = 1, max_line_size=40);
-- bwc_tag:end_query

SElECT * EXCLUDE (scan_id) FROM reject_errors ORDER BY byte_position;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/rejects/multiple_errors/more_col_and_max_line.csv',
    columns = {'name': 'VARCHAR', 'age': 'INTEGER', 'current_day': 'DATE', 'barks': 'INTEGER'},
    store_rejects = true, auto_detect=false, header = 1, max_line_size=40);
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
SElECT * EXCLUDE (scan_id) FROM reject_errors ORDER BY byte_position;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/rejects/multiple_errors/unquoted_cast.csv',
    columns = {'name': 'VARCHAR', 'age': 'INTEGER', 'current_day': 'DATE', 'barks': 'INTEGER'},
    store_rejects = true, auto_detect=false, header = 1, max_line_size=40);
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
SElECT * EXCLUDE (scan_id)  FROM reject_errors ORDER BY byte_position;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/rejects/multiple_errors/unquoted_less.csv',
    columns = {'name': 'VARCHAR', 'age': 'INTEGER', 'current_day': 'DATE', 'barks': 'INTEGER'},
    store_rejects = true, auto_detect=false, header = 1, max_line_size=40);
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
SElECT * EXCLUDE (scan_id)  FROM reject_errors ORDER BY byte_position;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/rejects/multiple_errors/unquoted_maxline.csv',
    columns = {'name': 'VARCHAR', 'age': 'INTEGER', 'current_day': 'DATE', 'barks': 'INTEGER'},
    store_rejects = true, auto_detect=false, header = 1, max_line_size=40);
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
SElECT * EXCLUDE (scan_id)  FROM reject_errors ORDER BY byte_position;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/rejects/multiple_errors/unquoted_more.csv',
    columns = {'name': 'VARCHAR', 'age': 'INTEGER', 'current_day': 'DATE', 'barks': 'INTEGER'},
    store_rejects = true, auto_detect=false, header = 1, max_line_size=40);
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
SElECT * EXCLUDE (scan_id)  FROM reject_errors ORDER BY byte_position;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/rejects/multiple_errors/invalid_utf_cast.csv',
    columns = {'name': 'VARCHAR', 'age': 'INTEGER', 'current_day': 'DATE', 'barks': 'INTEGER'},
    store_rejects = true, auto_detect=false, header = 1, max_line_size=40);
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
SElECT * EXCLUDE (scan_id)  FROM reject_errors ORDER BY byte_position;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/rejects/multiple_errors/invalid_utf_less.csv',
    columns = {'name': 'VARCHAR', 'age': 'INTEGER', 'current_day': 'DATE', 'barks': 'INTEGER'},
    store_rejects = true, auto_detect=false, header = 1, max_line_size=40);
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
SElECT * EXCLUDE (scan_id)  FROM reject_errors ORDER BY byte_position;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/rejects/multiple_errors/invalid_utf_max_line.csv',
    columns = {'name': 'VARCHAR', 'age': 'INTEGER', 'current_day': 'DATE', 'barks': 'INTEGER'},
    store_rejects = true, auto_detect=false, header = 1, max_line_size=40);
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
SElECT * EXCLUDE (scan_id)  FROM reject_errors ORDER BY byte_position, error_message;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/rejects/multiple_errors/invalid_utf_more.csv',
    columns = {'name': 'VARCHAR', 'age': 'INTEGER', 'current_day': 'DATE', 'barks': 'INTEGER'},
    store_rejects = true, auto_detect=false, header = 1, max_line_size=40);
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
SElECT * EXCLUDE (scan_id)  FROM reject_errors ORDER BY byte_position;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/rejects/multiple_errors/invalid_utf_unquoted.csv',
    columns = {'name': 'VARCHAR', 'last_name': 'VARCHAR', 'age': 'INTEGER', 'current_day': 'DATE', 'barks': 'INTEGER'},
    store_rejects = true, auto_detect=false, header = 1, max_line_size=40);
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
SElECT * EXCLUDE (scan_id)  FROM reject_errors ORDER BY byte_position;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/rejects/multiple_errors/multiple_errors.csv',
    columns = {'name': 'VARCHAR', 'age': 'INTEGER', 'current_day': 'DATE', 'barks': 'INTEGER'},
    store_rejects = true, auto_detect=false, header = 1, max_line_size=40);
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
SELECT * EXCLUDE (scan_id) FROM reject_errors ORDER BY ALL;
-- bwc_tag:end_query

