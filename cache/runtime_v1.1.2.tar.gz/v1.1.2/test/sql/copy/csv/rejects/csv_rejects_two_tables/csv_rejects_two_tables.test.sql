-- bwc_tag:nb_steps=30
-- bwc_tag:execute_from_sql
SELECT typeof(first(column0)), typeof(first(column1)), COUNT(*), SUM(column0), MAX(len(column1)) FROM read_csv_auto(
    'data/csv/error/mismatch/big_bad*.csv',
    sample_size=1,
    store_rejects=true);
-- bwc_tag:end_query

SELECT * EXCLUDE (scan_id) FROM reject_scans order by all;
-- bwc_tag:end_query

SELECT * EXCLUDE (scan_id) FROM reject_errors order by all;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT typeof(first(column0)), typeof(first(column1)), COUNT(*), SUM(column0), MAX(len(column1)) FROM read_csv_auto(
    'data/csv/error/mismatch/big_bad*.csv',
    sample_size=1,
    rejects_table = 'rejects_errors_2');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop table reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT typeof(first(column0)), typeof(first(column1)), COUNT(*), SUM(column0), MAX(len(column1)) FROM read_csv_auto(
    'data/csv/error/mismatch/big_bad*.csv',
    sample_size=1,
    rejects_table = 'rejects_errors_2'
    );
-- bwc_tag:end_query

SELECT * EXCLUDE (scan_id) FROM reject_scans order by all;
-- bwc_tag:end_query

SELECT * EXCLUDE (scan_id) FROM rejects_errors_2 order by all;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop table reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT typeof(first(column0)), typeof(first(column1)), COUNT(*), SUM(column0), MAX(len(column1)) FROM read_csv_auto(
    'data/csv/error/mismatch/big_bad*.csv',
    sample_size=1,
    rejects_scan = 'rejects_scan_2');
-- bwc_tag:end_query

SELECT * EXCLUDE (scan_id) FROM rejects_scan_2 order by all;
-- bwc_tag:end_query

SELECT * EXCLUDE (scan_id) FROM reject_errors order by all;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT typeof(first(column0)), typeof(first(column1)), COUNT(*), SUM(column0), MAX(len(column1)) FROM read_csv_auto(
    'data/csv/error/mismatch/big_bad*.csv',
    sample_size=1,
    rejects_scan = 'rejects_scan_3',
     rejects_table = 'rejects_errors_3'
    );
-- bwc_tag:end_query

SELECT * EXCLUDE (scan_id)
FROM rejects_scan_3 order by all;
-- bwc_tag:end_query

SELECT * EXCLUDE (scan_id) FROM rejects_errors_3 order by all;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop table reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop table reject_scans;
-- bwc_tag:end_query

create temporary table t (a integer);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT typeof(first(column0)), typeof(first(column1)), COUNT(*), SUM(column0), MAX(len(column1)) FROM read_csv_auto(
    'data/csv/error/mismatch/big_bad*.csv',
    sample_size=1,
    rejects_table = 't'
    );
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT typeof(first(column0)), typeof(first(column1)), COUNT(*), SUM(column0), MAX(len(column1)) FROM read_csv_auto(
    'data/csv/error/mismatch/big_bad*.csv',
    sample_size=1,
    rejects_scan = 't'
    );
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT typeof(first(column0)), typeof(first(column1)), COUNT(*), SUM(column0), MAX(len(column1)) FROM read_csv_auto(
    'data/csv/error/mismatch/big_bad*.csv',
    sample_size=1,
    rejects_table = 't',
    rejects_scan = 't'
    );
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT typeof(first(column0)), typeof(first(column1)), COUNT(*), SUM(column0), MAX(len(column1)) FROM read_csv_auto(
    'data/csv/error/mismatch/big_bad*.csv',
    sample_size=1,
    rejects_scan = 'rejects_scan_3',
     rejects_table = 'rejects_errors_3',
     ignore_errors = false
    );
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT typeof(first(column0)), typeof(first(column1)), COUNT(*), SUM(column0), MAX(len(column1)) FROM read_csv_auto(
    'data/csv/error/mismatch/big_bad*.csv',
    sample_size=1,
    store_rejects = true,
     ignore_errors = false
    );
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT typeof(first(column0)), typeof(first(column1)), COUNT(*), SUM(column0), MAX(len(column1)) FROM read_csv_auto(
    'data/csv/error/mismatch/big_bad*.csv',
    sample_size=1,
     rejects_table = 'rejects_errors_3',
     ignore_errors = false
    );
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT typeof(first(column0)), typeof(first(column1)), COUNT(*), SUM(column0), MAX(len(column1)) FROM read_csv_auto(
    'data/csv/error/mismatch/big_bad*.csv',
    sample_size=1,
    rejects_scan = 'rejects_scan_3',
     ignore_errors = false
    );
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT typeof(first(column0)), typeof(first(column1)), COUNT(*), SUM(column0), MAX(len(column1)) FROM read_csv_auto(
    'data/csv/error/mismatch/big_bad*.csv',
    sample_size=1,
    rejects_scan = 'rejects_scan_3',
     rejects_table = 'rejects_errors_3',
     store_rejects = false
    );
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT typeof(first(column0)), typeof(first(column1)), COUNT(*), SUM(column0), MAX(len(column1)) FROM read_csv_auto(
    'data/csv/error/mismatch/big_bad*.csv',
    sample_size=1,
     rejects_table = 'rejects_errors_3',
     store_rejects = false
    );
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT typeof(first(column0)), typeof(first(column1)), COUNT(*), SUM(column0), MAX(len(column1)) FROM read_csv_auto(
    'data/csv/error/mismatch/big_bad*.csv',
    sample_size=1,
    rejects_scan = 'rejects_scan_3',
     store_rejects = false
    );
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT typeof(first(column0)), typeof(first(column1)), COUNT(*), SUM(column0), MAX(len(column1)) FROM read_csv_auto(
    'data/csv/error/mismatch/big_bad*.csv',
    sample_size=1,
    rejects_scan = 'same_name_because_why_not',
    rejects_table = 'same_name_because_why_not',
    store_rejects = true
    );
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT typeof(first(column0)), typeof(first(column1)), COUNT(*), SUM(column0), MAX(len(column1)) FROM read_csv_auto(
    'data/csv/error/mismatch/big_bad*.csv',
    sample_size=1,
    rejects_scan = 'same_name_because_why_not',
    rejects_table = 'same_name_because_why_not_2',
    store_rejects = true);
-- bwc_tag:end_query

