-- bwc_tag:nb_steps=2
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

SELECT quote FROM sniff_csv('data/csv/all_quotes.csv', ignore_errors = 1)
-- bwc_tag:end_query

