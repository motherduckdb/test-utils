-- bwc_tag:nb_steps=6
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test (a VARCHAR, b INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY test FROM 'data/csv/test/quoted_newline.csv' (DELIMITER ',', AUTO_DETECT 0);
-- bwc_tag:end_query

SELECT SUM(b) FROM test;
-- bwc_tag:end_query

SELECT string_split_regex(a, '[\r\n]+') FROM test ORDER BY a;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

