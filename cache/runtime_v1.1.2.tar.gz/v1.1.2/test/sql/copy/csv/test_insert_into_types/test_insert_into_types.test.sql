-- bwc_tag:nb_steps=47
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE users (
        id INTEGER NOT NULL,  /*primary key*/
        name VARCHAR(10) NOT NULL,
        email VARCHAR
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO users
SELECT *
FROM read_csv('data/csv/glob/f_*.csv', ignore_errors=true, null_padding=true);
-- bwc_tag:end_query

select * from users;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE users;
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE users (
        id INTEGER NOT NULL,  /*primary key*/
        name VARCHAR(10) NOT NULL,
        email VARCHAR
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO users
SELECT *
FROM read_csv('data/csv/file_error.csv', ignore_errors=true, null_padding=true);
-- bwc_tag:end_query

select * from users;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE proj (
        id INTEGER NOT NULL,  /*primary key*/
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO proj
SELECT id
FROM read_csv('data/csv/file_error.csv', ignore_errors=true, null_padding=true);
-- bwc_tag:end_query

select * from proj;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO proj
SELECT id
FROM read_csv('data/csv/file_error.csv');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP table proj;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE proj (
        name VARCHAR(10) NOT NULL,
        id INTEGER NOT NULL,  /*primary key*/
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO proj
SELECT name, id
FROM read_csv('data/csv/file_error.csv', ignore_errors=true, null_padding=true);
-- bwc_tag:end_query

select * from proj;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO proj
SELECT name, id
FROM read_csv('data/csv/file_error.csv');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP table proj;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE proj (
        email VARCHAR,
        id INTEGER NOT NULL,  /*primary key*/
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO proj
SELECT email, id
FROM read_csv('data/csv/file_error.csv', ignore_errors=true, null_padding=true);
-- bwc_tag:end_query

select * from proj;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO proj
SELECT name, id
FROM read_csv('data/csv/file_error.csv');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP table proj;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE proj (
        email VARCHAR,
        id VARCHAR NOT NULL,  /*primary key*/
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO proj
SELECT name, id::INTEGER
FROM read_csv('data/csv/file_error.csv');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP table proj;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE proj (
        email VARCHAR,
        id integer NOT NULL,  /*primary key*/
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO proj
SELECT 'Pedro', id
FROM read_csv('data/csv/file_error.csv');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE ppl (
        name VARCHAR
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into ppl values ('alice'), ('bob'), ('pedro')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO proj
SELECT ppl.name,id
FROM read_csv('data/csv/file_error.csv') T inner join ppl on (ppl.name = T.name);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO proj
SELECT T.name,id
FROM read_csv('data/csv/file_error.csv') T inner join ppl on (ppl.name = T.name);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP table users;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE users (
        id INTEGER NOT NULL,  /*primary key*/
        name VARCHAR(10) NOT NULL,
        email VARCHAR
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO users
SELECT *
FROM read_csv('data/csv/glob/f_*.csv', ignore_errors=true, null_padding=true);
-- bwc_tag:end_query

select * from users;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP table proj;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE proj (
        email VARCHAR,
        id integer NOT NULL
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO proj
SELECT email, id
FROM read_csv('data/csv/glob/f_*.csv', ignore_errors=true, null_padding=true);
-- bwc_tag:end_query

select * from proj;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE users_age (
        id INTEGER NOT NULL,
        name VARCHAR(10) NOT NULL,
        email VARCHAR,
        age integer
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO users_age
SELECT *
FROM read_csv('data/csv/union-by-name/type_mismatch/f_*.csv', ignore_errors=true, null_padding=true, union_by_name=true);
-- bwc_tag:end_query

select * from users_age;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table timestamps(ts timestamp, dt date);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into timestamps select ts,ts from read_csv('data/csv/timestamp.csv');
-- bwc_tag:end_query

from timestamps;
-- bwc_tag:end_query

