-- bwc_tag:nb_steps=6
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT typeof(number) FROM read_csv('data/csv/double_trouble.csv', decimal_separator=',') limit 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT typeof(number) FROM read_csv('data/csv/double_trouble.csv', decimal_separator=',', auto_type_candidates = ['FLOAT']) limit 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT typeof(number) FROM read_csv('data/csv/double_trouble.csv', decimal_separator=',', auto_type_candidates = ['FLOAT', 'DOUBLE']) limit 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT typeof(number) FROM read_csv('data/csv/double_trouble.csv', decimal_separator=',', auto_type_candidates = ['DOUBLE', 'FLOAT']) limit 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT typeof(number) FROM read_csv('data/csv/double_trouble.csv', decimal_separator=',', auto_type_candidates = ['DECIMAL']) limit 1;
-- bwc_tag:end_query

