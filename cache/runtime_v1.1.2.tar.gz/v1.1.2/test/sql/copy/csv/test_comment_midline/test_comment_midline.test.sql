-- bwc_tag:nb_steps=18
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM 'data/csv/comments/only_midline.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/comments/only_midline.csv', comment = '#');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM 'data/csv/comments/mid_line.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM 'data/csv/comments/mid_line_header.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM 'data/csv/comments/mid_line_quote.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM 'data/csv/comments/mid_line_null.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM 'data/csv/comments/simple_mid_line.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM 'data/csv/comments/midline_empty_space.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/comments/mid_line_invalid.csv', ignore_errors = true, delim = ';', comment = '#', auto_detect = false, columns= {'a':'integer', 'b':'integer'});
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM 'data/csv/comments/midline_big.csv' limit 5;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM 'data/csv/comments/midline_big.csv' where  a = 20
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT count(*) FROM 'data/csv/comments/midline_big.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/comments/simple_mid_line.csv', buffer_size = 30) limit 5;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/comments/simple_mid_line.csv', buffer_size = 31) limit 5;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/comments/simple_mid_line.csv', buffer_size = 32) limit 5;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/comments/simple_mid_line.csv', buffer_size = 33) limit 5;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/comments/simple_mid_line.csv', buffer_size = 34) limit 5;
-- bwc_tag:end_query

