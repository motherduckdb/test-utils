-- bwc_tag:nb_steps=4
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
from read_csv('data/csv/bug_12596.csv', skip=1, delim=',', header=false, columns={'c1': 'INTEGER', 'c2': 'INTEGER', 'column2': 'VARCHAR'}, null_padding = true);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
from read_csv('data/csv/bug_12596.csv', skip=1, delim=',', header=false, columns={'c1': 'INTEGER', 'c2': 'INTEGER', 'column2': 'VARCHAR'}, null_padding = true, parallel = false, auto_detect = false);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
from read_csv('data/csv/bug_12596.csv', skip=1, delim=',', header=false, columns={'c1': 'INTEGER', 'c2': 'INTEGER', 'column2': 'VARCHAR'}, null_padding = true, parallel = false);
-- bwc_tag:end_query

