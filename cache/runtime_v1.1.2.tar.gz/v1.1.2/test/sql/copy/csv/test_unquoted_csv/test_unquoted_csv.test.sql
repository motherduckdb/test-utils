-- bwc_tag:nb_steps=3
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

FROM read_csv('data/csv/click_mini.tsv.gz')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/click_mini.tsv.gz', quote = '')
-- bwc_tag:end_query

