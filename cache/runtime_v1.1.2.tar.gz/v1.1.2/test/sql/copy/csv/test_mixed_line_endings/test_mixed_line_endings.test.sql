-- bwc_tag:nb_steps=6
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test (a INTEGER, b VARCHAR, c INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into test select * from read_csv_auto('data/csv/test/mixed_line_endings.csv');
-- bwc_tag:end_query

SELECT LENGTH(b) FROM test ORDER BY a;
-- bwc_tag:end_query

select * from test;
-- bwc_tag:end_query

SELECT SUM(a), SUM(c) FROM test;
-- bwc_tag:end_query

