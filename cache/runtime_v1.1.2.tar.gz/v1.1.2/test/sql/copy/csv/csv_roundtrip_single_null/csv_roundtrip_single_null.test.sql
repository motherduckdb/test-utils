-- bwc_tag:nb_steps=5
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

COPY (SELECT NULL) TO 'output/single_null.csv' (HEADER 0)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY integers FROM 'output/single_null.csv' (HEADER 0)
-- bwc_tag:end_query

FROM integers
-- bwc_tag:end_query

