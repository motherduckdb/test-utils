-- bwc_tag:nb_steps=14
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/bad_escape.csv')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv_auto('data/csv/test/dateformat.csv')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE dates (d DATE);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO dates SELECT * FROM read_csv('data/csv/test/dateformat.csv', columns=STRUCT_PACK(d := 'DATE'), header=0)
-- bwc_tag:end_query

SELECT * FROM dates
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO dates SELECT * FROM read_csv_auto('data/csv/test/dateformat.csv', dateformat='%m/%d/%Y')
-- bwc_tag:end_query

SELECT * FROM dates ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE timestamps AS SELECT * FROM read_csv_auto('data/csv/test/dateformat.csv', timestampformat='%m/%d/%Y', columns=STRUCT_PACK(d := 'TIMESTAMP'))
-- bwc_tag:end_query

SELECT * FROM timestamps
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW lineitem AS SELECT * FROM read_csv('data/csv/real/lineitem_sample.csv', sep='|', columns=STRUCT_PACK(l_orderkey := 'INT', l_partkey := 'INT', l_suppkey := 'INT', l_linenumber := 'INT', l_quantity := 'INTEGER', l_extendedprice := 'DOUBLE', l_discount := 'DOUBLE', l_tax := 'DOUBLE', l_returnflag := 'VARCHAR', l_linestatus := 'VARCHAR', l_shipdate := 'DATE', l_commitdate := 'DATE', l_receiptdate := 'DATE', l_shipinstruct := 'VARCHAR', l_shipmode := 'VARCHAR', l_comment := 'VARCHAR'));
-- bwc_tag:end_query

SELECT COUNT(*) FROM lineitem
-- bwc_tag:end_query

SELECT l_partkey, RTRIM(l_comment) FROM lineitem WHERE l_orderkey=1 ORDER BY l_linenumber;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT * FROM read_csv('data/csv/real/lineitem_sample.csv', sep='|', columns=STRUCT_PACK(l_orderkey := 5))
-- bwc_tag:end_query

