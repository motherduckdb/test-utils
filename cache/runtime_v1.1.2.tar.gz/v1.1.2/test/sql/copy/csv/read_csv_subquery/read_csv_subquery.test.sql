-- bwc_tag:nb_steps=5
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

WITH urls AS (
	SELECT 'a.csv' AS url UNION ALL SELECT 'b.csv'
)
SELECT *
FROM read_csv_auto((SELECT url FROM urls LIMIT 3), delim=',')
WHERE properties.height > -1.0
LIMIT 10
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT *
FROM read_csv_auto(sum(a) over ())
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT *
FROM read_csv_auto(sum(a))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT *
FROM read_csv_auto('a.csv', delim=',', 42)
-- bwc_tag:end_query

