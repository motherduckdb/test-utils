-- bwc_tag:nb_steps=4
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select * from 'data/csv/issue5077_aligned.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select * from read_csv('data/csv/issue5077.csv', header=0)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select * from 'data/csv/lineitem-carriage.csv';
-- bwc_tag:end_query

