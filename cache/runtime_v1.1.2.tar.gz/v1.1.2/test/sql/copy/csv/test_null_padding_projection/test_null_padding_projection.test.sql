-- bwc_tag:nb_steps=20
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

from read_csv('data/csv/nullpadding.csv',null_padding=true, columns={
'a': 'INTEGER','b': 'INTEGER','c': 'INTEGER','d': 'INTEGER'}, auto_detect = false)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW np AS  from read_csv('data/csv/nullpadding.csv',null_padding=true, columns={
'a': 'INTEGER','b': 'INTEGER','c': 'INTEGER','d': 'INTEGER'}, auto_detect = false, ignore_errors = true);
-- bwc_tag:end_query

from np
-- bwc_tag:end_query

select a from np
-- bwc_tag:end_query

select b,d from np
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
from read_csv('data/csv/nullpadding.csv',null_padding=true, columns={
'a': 'INTEGER','b': 'INTEGER','c': 'INTEGER','d': 'INTEGER'}, auto_detect => false, ignore_errors => true, filename => true);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select a, filename from read_csv('data/csv/nullpadding.csv',null_padding=true, columns={
'a': 'INTEGER','b': 'INTEGER','c': 'INTEGER','d': 'INTEGER'}, auto_detect => false, ignore_errors => true, filename => true);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select filename from read_csv('data/csv/nullpadding.csv',null_padding=true, columns={
'a': 'INTEGER','b': 'INTEGER','c': 'INTEGER','d': 'INTEGER'}, auto_detect => false, ignore_errors => true, filename => true);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select a from read_csv('data/csv/nullpadding.csv',null_padding=true, columns={
'a': 'INTEGER','b': 'INTEGER','c': 'INTEGER','d': 'INTEGER'}, auto_detect = false, ignore_errors => true, filename => true);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select * from read_csv('data/csv/nullpadding.csv',null_padding=true, columns={
'a': 'INTEGER','b': 'INTEGER','c': 'INTEGER','d': 'INTEGER'}, auto_detect := false, ignore_errors := true)
where  b = 100;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select * from read_csv('data/csv/nullpadding.csv',null_padding=true, columns={
'a': 'INTEGER','b': 'INTEGER','c': 'INTEGER','d': 'INTEGER'}, auto_detect = false, ignore_errors = true, filename = true)
where a = 10 and d = 10000;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select * from read_csv('data/csv/nullpadding.csv',null_padding=true, columns={
'a': 'INTEGER','b': 'INTEGER','c': 'INTEGER','d': 'INTEGER', 'e': 'INTEGER'}, auto_detect = false, filename = true)
where a = 10 and d = 10000;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select * from read_csv('data/csv/nullpadding.csv',null_padding=true, columns={
'a': 'INTEGER','b': 'INTEGER','c': 'INTEGER','d': 'INTEGER', 'e': 'INTEGER'}, auto_detect := false)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select * from read_csv('data/csv/nullpadding.csv',null_padding=true, columns={
'a': 'INTEGER','b': 'INTEGER','c': 'INTEGER','d': 'INTEGER', 'e': 'INTEGER', 'f': 'INTEGER'}, auto_detect = false)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select * from read_csv('data/csv/nullpadding.csv',null_padding=true, columns={
'a': 'INTEGER','b': 'INTEGER','c': 'INTEGER','d': 'INTEGER', 'e': 'INTEGER', 'f': 'INTEGER', 'g': 'INTEGER'}, auto_detect = false)
-- bwc_tag:end_query

-- bwc_tag:skip_query
set threads =1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create view T as
SELECT SETTLEMENTDATE, DUID, I, filename, UNIT, CAST(LOWER6SEC AS DOUBLE) AS LOWER6SEC, CAST(LOWER6SECFLAGS AS DOUBLE) AS LOWER6SECFLAGS, CAST(LOWER60SECFLAGS AS DOUBLE) AS LOWER60SECFLAGS, CAST(RAISE5MINACTUALAVAILABILITY AS DOUBLE) AS RAISE5MINACTUALAVAILABILITY, CAST(INTERVENTION AS DOUBLE) AS INTERVENTION, CAST(LOWER5MINFLAGS AS DOUBLE) AS LOWER5MINFLAGS, CAST(RAISEREGAVAILABILITY AS DOUBLE) AS RAISEREGAVAILABILITY, CAST(LOWERREGACTUALAVAILABILITY AS DOUBLE) AS LOWERREGACTUALAVAILABILITY, CAST(VIOLATION60SECDEGREE AS DOUBLE) AS VIOLATION60SECDEGREE, CAST(LOWER60SEC AS DOUBLE) AS LOWER60SEC, CAST(MARGINAL5MINVALUE AS DOUBLE) AS MARGINAL5MINVALUE, CAST(RAISE60SEC AS DOUBLE) AS RAISE60SEC, CAST(RAMPUPRATE AS DOUBLE) AS RAMPUPRATE, CAST(TOTALCLEARED AS DOUBLE) AS TOTALCLEARED, CAST(VIOLATION5MINDEGREE AS DOUBLE) AS VIOLATION5MINDEGREE, CAST(LOWER6SECACTUALAVAILABILITY AS DOUBLE) AS LOWER6SECACTUALAVAILABILITY, CAST(AGCSTATUS AS DOUBLE) AS AGCSTATUS, CAST(RAISE60SECFLAGS AS DOUBLE) AS RAISE60SECFLAGS, CAST("VERSION" AS DOUBLE) AS "VERSION", CAST(RAISE5MINFLAGS AS DOUBLE) AS RAISE5MINFLAGS, CAST(LOWER60SECACTUALAVAILABILITY AS DOUBLE) AS LOWER60SECACTUALAVAILABILITY, CAST(RAMPDOWNRATE AS DOUBLE) AS RAMPDOWNRATE, CAST(RAISE6SECFLAGS AS DOUBLE) AS RAISE6SECFLAGS, CAST(RAISE60SECACTUALAVAILABILITY AS DOUBLE) AS RAISE60SECACTUALAVAILABILITY, CAST(VIOLATIONDEGREE AS DOUBLE) AS VIOLATIONDEGREE, CAST(RAISE5MIN AS DOUBLE) AS RAISE5MIN, CAST(MARGINALVALUE AS DOUBLE) AS MARGINALVALUE, CAST(LOWERREGFLAGS AS DOUBLE) AS LOWERREGFLAGS, CAST(RAISEREG AS DOUBLE) AS RAISEREG, CAST(LOWERREGENABLEMENTMIN AS DOUBLE) AS LOWERREGENABLEMENTMIN, CAST(LOWERREGENABLEMENTMAX AS DOUBLE) AS LOWERREGENABLEMENTMAX, CAST(DISPATCHMODE AS DOUBLE) AS DISPATCHMODE, CAST(VIOLATION6SECDEGREE AS DOUBLE) AS VIOLATION6SECDEGREE, CAST(LOWERREG AS DOUBLE) AS LOWERREG, CAST(LOWERREGAVAILABILITY AS DOUBLE) AS LOWERREGAVAILABILITY, CAST(RAISEREGACTUALAVAILABILITY AS DOUBLE) AS RAISEREGACTUALAVAILABILITY, CAST(RAISEREGFLAGS AS DOUBLE) AS RAISEREGFLAGS, CAST(MARGINAL60SECVALUE AS DOUBLE) AS MARGINAL60SECVALUE, CAST(LOWER5MINACTUALAVAILABILITY AS DOUBLE) AS LOWER5MINACTUALAVAILABILITY, CAST(RAISEREGENABLEMENTMAX AS DOUBLE) AS RAISEREGENABLEMENTMAX, CAST(INITIALMW AS DOUBLE) AS INITIALMW, CAST(AVAILABILITY AS DOUBLE) AS AVAILABILITY, CAST(RUNNO AS DOUBLE) AS RUNNO, CAST(RAISE6SECACTUALAVAILABILITY AS DOUBLE) AS RAISE6SECACTUALAVAILABILITY, CAST(MARGINAL6SECVALUE AS DOUBLE) AS MARGINAL6SECVALUE, CAST(RAISE6SEC AS DOUBLE) AS RAISE6SEC, CAST(XX AS DOUBLE) AS XX, CAST(RAISEREGENABLEMENTMIN AS DOUBLE) AS RAISEREGENABLEMENTMIN, CAST(LOWER5MIN AS DOUBLE) AS LOWER5MIN FROM (SELECT *
FROM read_csv(main.list_value('data/csv/public_daily_sample.csv','data/csv/public_daily_sample.csv','data/csv/public_daily_sample.csv')
, ("Skip" = 1), ("header" = 0), (all_varchar = 1), ("columns" = main.struct_pack(I := 'VARCHAR', UNIT := 'VARCHAR', XX := 'VARCHAR', "VERSION" := 'VARCHAR', SETTLEMENTDATE := 'VARCHAR', RUNNO := 'VARCHAR', DUID := 'VARCHAR', INTERVENTION := 'VARCHAR', DISPATCHMODE := 'VARCHAR', AGCSTATUS := 'VARCHAR', INITIALMW := 'VARCHAR', TOTALCLEARED := 'VARCHAR', RAMPDOWNRATE := 'VARCHAR', RAMPUPRATE := 'VARCHAR', LOWER5MIN := 'VARCHAR', LOWER60SEC := 'VARCHAR', LOWER6SEC := 'VARCHAR', RAISE5MIN := 'VARCHAR', RAISE60SEC := 'VARCHAR', RAISE6SEC := 'VARCHAR', MARGINAL5MINVALUE := 'VARCHAR', MARGINAL60SECVALUE := 'VARCHAR', MARGINAL6SECVALUE := 'VARCHAR', MARGINALVALUE := 'VARCHAR', VIOLATION5MINDEGREE := 'VARCHAR', VIOLATION60SECDEGREE := 'VARCHAR', VIOLATION6SECDEGREE := 'VARCHAR', VIOLATIONDEGREE := 'VARCHAR', LOWERREG := 'VARCHAR', RAISEREG := 'VARCHAR', AVAILABILITY := 'VARCHAR', RAISE6SECFLAGS := 'VARCHAR', RAISE60SECFLAGS := 'VARCHAR', RAISE5MINFLAGS := 'VARCHAR', RAISEREGFLAGS := 'VARCHAR', LOWER6SECFLAGS := 'VARCHAR', LOWER60SECFLAGS := 'VARCHAR', LOWER5MINFLAGS := 'VARCHAR', LOWERREGFLAGS := 'VARCHAR', RAISEREGAVAILABILITY := 'VARCHAR', RAISEREGENABLEMENTMAX := 'VARCHAR', RAISEREGENABLEMENTMIN := 'VARCHAR', LOWERREGAVAILABILITY := 'VARCHAR', LOWERREGENABLEMENTMAX := 'VARCHAR', LOWERREGENABLEMENTMIN := 'VARCHAR', RAISE6SECACTUALAVAILABILITY := 'VARCHAR', RAISE60SECACTUALAVAILABILITY := 'VARCHAR', RAISE5MINACTUALAVAILABILITY := 'VARCHAR', RAISEREGACTUALAVAILABILITY := 'VARCHAR', LOWER6SECACTUALAVAILABILITY := 'VARCHAR', LOWER60SECACTUALAVAILABILITY := 'VARCHAR', LOWER5MINACTUALAVAILABILITY := 'VARCHAR', LOWERREGACTUALAVAILABILITY := 'VARCHAR')), (filename = 1), (null_padding = CAST('t' AS BOOLEAN)), (ignore_errors = 1), (auto_detect = CAST('f' AS BOOLEAN))) WHERE ((I = 'D') AND (UNIT = 'DUNIT')));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create view T_2 as
SELECT * EXCLUDE (SETTLEMENTDATE, XX, filename, I), CAST(SETTLEMENTDATE AS TIMESTAMP) AS SETTLEMENTDATE, split(filename, '/')[8] AS file, isoyear(CAST(SETTLEMENTDATE AS TIMESTAMP)) AS "YEAR" FROM T
-- bwc_tag:end_query

select count(*) from T_2
-- bwc_tag:end_query

