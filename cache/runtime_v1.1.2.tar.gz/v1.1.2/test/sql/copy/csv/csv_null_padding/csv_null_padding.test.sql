-- bwc_tag:nb_steps=6
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv_auto('data/csv/nullpadding_header.csv', null_padding=True, comment = '')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv_auto('data/csv/nullpadding_header.csv', null_padding=False, header = 0)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv_auto('data/csv/nullpadding_header.csv', null_padding=False, skip=1, header = 0, comment = '')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv_auto('data/csv/nullpadding_header.csv', null_padding=False, skip=2)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv_auto('data/csv/blank_line.csv', null_padding=True)
-- bwc_tag:end_query

