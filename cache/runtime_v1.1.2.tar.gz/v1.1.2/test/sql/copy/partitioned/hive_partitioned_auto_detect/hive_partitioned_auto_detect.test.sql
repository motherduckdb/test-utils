-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=81
-- bwc_tag:execute_from_sql
CREATE TABLE t AS SELECT i%2 AS year, i%3 AS month, i%4 AS c, i%5 AS d FROM RANGE(0,20) tbl(i);
-- bwc_tag:end_query

COPY t TO 'output/csv_partition_1' (partition_by(year));
-- bwc_tag:end_query

select count(*) from glob('output/csv_partition_1/**');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select alias(columns(*)) from read_csv_auto('output/csv_partition_1/**', names=['a','b','c','d'], HIVE_PARTITIONING=0) LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select alias(columns(*)) from read_csv_auto('output/csv_partition_1/**', names=['a','b','c','d'], HIVE_PARTITIONING=1) LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select alias(columns(*)) from read_csv_auto('output/csv_partition_1/**', names=['a','b','c','d']) LIMIT 1;
-- bwc_tag:end_query

COPY t TO 'output/csv_partition_2' (partition_by(year,month));
-- bwc_tag:end_query

select count(*) from glob('output/csv_partition_2/**');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select alias(columns(*)) from read_csv_auto('output/csv_partition_2/**', names=['a','b','c','d'], HIVE_PARTITIONING=0) LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select alias(columns(*)) from read_csv_auto('output/csv_partition_2/**', names=['a','b','c','d'], HIVE_PARTITIONING=1) LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select alias(columns(*)) from read_csv_auto('output/csv_partition_2/**', names=['a','b','c','d']) LIMIT 1;
-- bwc_tag:end_query

select count(*) from glob('output/t.csv');
-- bwc_tag:end_query

COPY t TO 'output/bad_file.csv';
-- bwc_tag:end_query

select count(*) from glob('output/bad_file.csv');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select alias(columns(*)) from read_csv_auto('output/bad_file.csv', names=['a','b','c','d'], HIVE_PARTITIONING=0) LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select alias(columns(*)) from read_csv_auto('output/bad_file.csv', names=['a','b','c','d'], HIVE_PARTITIONING=1) LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select alias(columns(*)) from read_csv_auto('output/bad_file.csv', names=['a','b','c','d']) LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select alias(columns(*)) from read_csv_auto(['output/csv_partition_2/**', 'output/bad_file.csv'], HIVE_PARTITIONING=0, names=['a','b','c','d']) LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

select alias(columns(*)) from read_csv_auto(['output/csv_partition_2/**', 'output/bad_file.csv'], HIVE_PARTITIONING=1, names=['a','b','c','d']) LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select alias(columns(*)) from read_csv_auto(['output/csv_partition_2/**', 'output/bad_file.csv'], names=['a','b','c','d']) LIMIT 1;
-- bwc_tag:end_query

LOAD 'parquet';
-- bwc_tag:end_query

COPY t TO 'output/parquet_partition_1' (format parquet, partition_by(year));
-- bwc_tag:end_query

select count(*) from glob('output/parquet_partition_1/**');
-- bwc_tag:end_query

select alias(columns(*)) from read_parquet('output/parquet_partition_1/**', HIVE_PARTITIONING=0) LIMIT 1;
-- bwc_tag:end_query

select alias(columns(*)) from read_parquet('output/parquet_partition_1/**', HIVE_PARTITIONING=1) LIMIT 1;
-- bwc_tag:end_query

select alias(columns(*)) from read_parquet('output/parquet_partition_1/**') LIMIT 1;
-- bwc_tag:end_query

COPY t TO 'output/parquet_partition_2' (format parquet, partition_by(year,month));
-- bwc_tag:end_query

select count(*) from glob('output/parquet_partition_2/**');
-- bwc_tag:end_query

select alias(columns(*)) from read_parquet('output/parquet_partition_2/**', HIVE_PARTITIONING=0) LIMIT 1;
-- bwc_tag:end_query

select alias(columns(*)) from read_parquet('output/parquet_partition_2/**', HIVE_PARTITIONING=1) LIMIT 1;
-- bwc_tag:end_query

select alias(columns(*)) from read_parquet('output/parquet_partition_2/**') LIMIT 1;
-- bwc_tag:end_query

select count(*) from glob('output/t.parquet');
-- bwc_tag:end_query

COPY t TO 'output/t.parquet' (format parquet);
-- bwc_tag:end_query

select count(*) from glob('output/t.parquet');
-- bwc_tag:end_query

select alias(columns(*)) from read_parquet('output/t.parquet', HIVE_PARTITIONING=0) LIMIT 1;
-- bwc_tag:end_query

select alias(columns(*)) from read_parquet('output/t.parquet', HIVE_PARTITIONING=1) LIMIT 1;
-- bwc_tag:end_query

select alias(columns(*)) from read_parquet('output/t.parquet') LIMIT 1;
-- bwc_tag:end_query

select alias(columns(*)) from read_parquet(['output/parquet_partition_2/**', 'output/t.parquet'], HIVE_PARTITIONING=0) LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select alias(columns(*)) from read_parquet(['output/parquet_partition_2/**', 'output/t.parquet'], HIVE_PARTITIONING=1) LIMIT 1;
-- bwc_tag:end_query

select alias(columns(*)) from read_parquet(['output/parquet_partition_2/**', 'output/t.parquet']) LIMIT 1;
-- bwc_tag:end_query

COPY t TO 'output/csv_partition_1' (partition_by(year), overwrite_or_ignore, write_partition_columns);
-- bwc_tag:end_query

select count(*) from glob('output/csv_partition_1/**');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select alias(columns(*)) from read_csv_auto('output/csv_partition_1/**', names=['a','b','c','d'], HIVE_PARTITIONING=0) LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select alias(columns(*)) from read_csv_auto('output/csv_partition_1/**', names=['a','b','c','d'], HIVE_PARTITIONING=1) LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select alias(columns(*)) from read_csv_auto('output/csv_partition_1/**', names=['a','b','c','d']) LIMIT 1;
-- bwc_tag:end_query

COPY t TO 'output/csv_partition_2' (partition_by(year,month), overwrite_or_ignore, write_partition_columns);
-- bwc_tag:end_query

select count(*) from glob('output/csv_partition_2/**');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select alias(columns(*)) from read_csv_auto('output/csv_partition_2/**', names=['a','b','c','d'], HIVE_PARTITIONING=0) LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select alias(columns(*)) from read_csv_auto('output/csv_partition_2/**', names=['a','b','c','d'], HIVE_PARTITIONING=1) LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select alias(columns(*)) from read_csv_auto('output/csv_partition_2/**', names=['a','b','c','d']) LIMIT 1;
-- bwc_tag:end_query

select count(*) from glob('output/t.csv');
-- bwc_tag:end_query

COPY t TO 'output/bad_file.csv';
-- bwc_tag:end_query

select count(*) from glob('output/bad_file.csv');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select alias(columns(*)) from read_csv_auto('output/bad_file.csv', names=['a','b','c','d'], HIVE_PARTITIONING=0) LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select alias(columns(*)) from read_csv_auto('output/bad_file.csv', names=['a','b','c','d'], HIVE_PARTITIONING=1) LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select alias(columns(*)) from read_csv_auto('output/bad_file.csv', names=['a','b','c','d']) LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select alias(columns(*)) from read_csv_auto(['output/csv_partition_2/**', 'output/bad_file.csv'], HIVE_PARTITIONING=0, names=['a','b','c','d']) LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

select alias(columns(*)) from read_csv_auto(['output/csv_partition_2/**', 'output/bad_file.csv'], HIVE_PARTITIONING=1, names=['a','b','c','d']) LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select alias(columns(*)) from read_csv_auto(['output/csv_partition_2/**', 'output/bad_file.csv'], names=['a','b','c','d']) LIMIT 1;
-- bwc_tag:end_query

LOAD 'parquet';
-- bwc_tag:end_query

COPY t TO 'output/parquet_partition_1' (format parquet, partition_by(year), overwrite_or_ignore, write_partition_columns);
-- bwc_tag:end_query

select count(*) from glob('output/parquet_partition_1/**');
-- bwc_tag:end_query

select alias(columns(*)) from read_parquet('output/parquet_partition_1/**', HIVE_PARTITIONING=0) LIMIT 1;
-- bwc_tag:end_query

select alias(columns(*)) from read_parquet('output/parquet_partition_1/**', HIVE_PARTITIONING=1) LIMIT 1;
-- bwc_tag:end_query

select alias(columns(*)) from read_parquet('output/parquet_partition_1/**') LIMIT 1;
-- bwc_tag:end_query

COPY t TO 'output/parquet_partition_2' (format parquet, partition_by(year,month), overwrite_or_ignore, write_partition_columns);
-- bwc_tag:end_query

select count(*) from glob('output/parquet_partition_2/**');
-- bwc_tag:end_query

select alias(columns(*)) from read_parquet('output/parquet_partition_2/**', HIVE_PARTITIONING=0) LIMIT 1;
-- bwc_tag:end_query

select alias(columns(*)) from read_parquet('output/parquet_partition_2/**', HIVE_PARTITIONING=1) LIMIT 1;
-- bwc_tag:end_query

select alias(columns(*)) from read_parquet('output/parquet_partition_2/**') LIMIT 1;
-- bwc_tag:end_query

COPY t TO 'output/t.parquet' (format parquet);
-- bwc_tag:end_query

select count(*) from glob('output/t.parquet');
-- bwc_tag:end_query

select alias(columns(*)) from read_parquet('output/t.parquet', HIVE_PARTITIONING=0) LIMIT 1;
-- bwc_tag:end_query

select alias(columns(*)) from read_parquet('output/t.parquet', HIVE_PARTITIONING=1) LIMIT 1;
-- bwc_tag:end_query

select alias(columns(*)) from read_parquet('output/t.parquet') LIMIT 1;
-- bwc_tag:end_query

select alias(columns(*)) from read_parquet(['output/parquet_partition_2/**', 'output/t.parquet'], HIVE_PARTITIONING=0) LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select alias(columns(*)) from read_parquet(['output/parquet_partition_2/**', 'output/t.parquet'], HIVE_PARTITIONING=1) LIMIT 1;
-- bwc_tag:end_query

select alias(columns(*)) from read_parquet(['output/parquet_partition_2/**', 'output/t.parquet']) LIMIT 1;
-- bwc_tag:end_query

select i,j,k,x 
from read_parquet('data/parquet-testing/hive-partitioning/union_by_name/*/*.parquet', hive_partitioning=0, union_by_name=1) 
order by j,x nulls last;
-- bwc_tag:end_query

select i,j,k,x 
from read_parquet('data/parquet-testing/hive-partitioning/union_by_name/*/*.parquet', hive_partitioning=1, union_by_name=1) 
order by j,x nulls last;
-- bwc_tag:end_query

select i,j,k,x 
from read_parquet('data/parquet-testing/hive-partitioning/union_by_name/*/*.parquet', union_by_name=1) 
order by j,x nulls last;
-- bwc_tag:end_query

