-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=26
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test as SELECT i%2 as part_col, (i+1)%5 as value_col, i as value2_col from range(0,10) tbl(i);
-- bwc_tag:end_query

COPY test TO 'output/partitioned1' (FORMAT PARQUET, PARTITION_BY (part_col));
-- bwc_tag:end_query

SELECT part_col, value_col, value2_col FROM 'output/partitioned1/part_col=0/*.parquet' ORDER BY value2_col;
-- bwc_tag:end_query

SELECT part_col, value_col, value2_col FROM 'output/partitioned1/part_col=1/*.parquet' ORDER BY value2_col;
-- bwc_tag:end_query

COPY (SELECT * EXCLUDE (part_col), 'prefix-'::VARCHAR || part_col::VARCHAR as part_col FROM test) TO 'output/partitioned2' (FORMAT PARQUET, PARTITION_BY (part_col));
-- bwc_tag:end_query

SELECT part_col, value_col, value2_col FROM 'output/partitioned2/part_col=prefix-0/*.parquet' ORDER BY value2_col;
-- bwc_tag:end_query

SELECT part_col, value_col, value2_col FROM 'output/partitioned2/part_col=prefix-1/*.parquet' ORDER BY value2_col;
-- bwc_tag:end_query

COPY test TO 'output/partitioned3' (FORMAT PARQUET, PARTITION_BY '*', WRITE_PARTITION_COLUMNS);
-- bwc_tag:end_query

SELECT min(value2_col) as min_val
FROM parquet_scan('output/partitioned3/part_col=*/value_col=*/value2_col=*/*.parquet', FILENAME=1)
GROUP BY filename
ORDER BY min_val
-- bwc_tag:end_query

COPY test TO 'output/partitioned4' (FORMAT PARQUET, PARTITION_BY part_col);
-- bwc_tag:end_query

SELECT part_col, value_col, value2_col FROM parquet_scan('output/partitioned4/part_col=*/*.parquet', HIVE_PARTITIONING=1) WHERE part_col=0 ORDER BY value2_col;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

COPY test TO 'output/partitioned4' (FORMAT PARQUET, PARTITION_BY part_col);
-- bwc_tag:end_query

COPY test TO 'output/partitioned5/' (FORMAT PARQUET, PARTITION_BY part_col);
-- bwc_tag:end_query

SELECT part_col, value_col, value2_col FROM 'output/partitioned5/part_col=0/*.parquet' ORDER BY value2_col;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

COPY test TO 'output/partitioned6' (FORMAT PARQUET, PARTITION_BY part_col, USE_TMP_FILE TRUE);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

COPY test TO 'output/partitioned6' (FORMAT PARQUET, PARTITION_BY part_col, PER_THREAD_OUTPUT TRUE);
-- bwc_tag:end_query

COPY test TO 'output/partitioned7' (FORMAT CSV, PARTITION_BY part_col);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT part_col, value_col, value2_col FROM 'output/partitioned7/part_col=0/*.csv' ORDER BY value2_col;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT part_col, value_col, value2_col FROM 'output/partitioned7/part_col=1/*.csv' ORDER BY value2_col;
-- bwc_tag:end_query

COPY test TO 'output/partitioned8' (FORMAT PARQUET, PARTITION_BY pArt_cOl);
-- bwc_tag:end_query

SELECT part_col, value_col, value2_col FROM 'output/partitioned8/part_col=0/*.parquet' ORDER BY value2_cOl;
-- bwc_tag:end_query

COPY test TO 'output/partitioned9' (FORMAT PARQUET, PARTITION_BY (part_col, value_col));
-- bwc_tag:end_query

SELECT min(value2_col) as min_val
FROM parquet_scan('output/partitioned9/part_col=*/value_col=*/*.parquet', FILENAME=1)
GROUP BY filename
ORDER BY min_val
-- bwc_tag:end_query

COPY test TO 'output/partitioned10' (FORMAT PARQUET, PARTITION_BY (value_col, part_col));
-- bwc_tag:end_query

SELECT min(value2_col) as min_val
FROM parquet_scan('output/partitioned10/value_col=*/part_col=*/*.parquet', FILENAME=1)
GROUP BY filename
ORDER BY min_val
-- bwc_tag:end_query

