-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=12
LOAD 'parquet';
-- bwc_tag:end_query

COPY (SELECT i::VARCHAR as a, (i*10)::VARCHAR as b, (i*100)::VARCHAR as c from range(0,10) tbl(i)) TO 'output/hive_pushdown_bug' (FORMAT PARQUET, PARTITION_BY c);
-- bwc_tag:end_query

explain SELECT * FROM parquet_scan('output/hive_pushdown_bug/*/*.parquet', HIVE_PARTITIONING=1) where a > b;
-- bwc_tag:end_query

explain SELECT * FROM parquet_scan('output/hive_pushdown_bug/*/*.parquet', HIVE_PARTITIONING=1) where a > b;
-- bwc_tag:end_query

explain SELECT * FROM parquet_scan('output/hive_pushdown_bug/*/*.parquet') where a > b;
-- bwc_tag:end_query

explain SELECT * FROM parquet_scan('output/hive_pushdown_bug/*/*.parquet', HIVE_PARTITIONING=1) where a::VARCHAR > c::VARCHAR;
-- bwc_tag:end_query

explain SELECT * FROM parquet_scan('output/hive_pushdown_bug/*/*.parquet', HIVE_PARTITIONING=1) where a::VARCHAR > c::VARCHAR;
-- bwc_tag:end_query

explain SELECT * FROM parquet_scan('output/hive_pushdown_bug/*/*.parquet') where a::VARCHAR > c::VARCHAR;
-- bwc_tag:end_query

explain SELECT * FROM parquet_scan('output/hive_pushdown_bug/*/*.parquet', HIVE_PARTITIONING=1, HIVE_TYPES_AUTOCAST=1) where c=500;
-- bwc_tag:end_query

explain SELECT * FROM parquet_scan('output/hive_pushdown_bug/*/*.parquet', HIVE_PARTITIONING=1, HIVE_TYPES_AUTOCAST=1) where c=500 and b='20';
-- bwc_tag:end_query

COPY (SELECT i::VARCHAR as a, (i*10)::VARCHAR as b, (i*100)::VARCHAR as c from range(0,10) tbl(i)) TO 'output/hive_pushdown_bug_csv' (FORMAT CSV, PARTITION_BY c);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
explain SELECT * FROM read_csv_auto('output/hive_pushdown_bug_csv/*/*.csv', HIVE_PARTITIONING=1, HIVE_TYPES_AUTOCAST=1, names=['a','b','c']) where c=500;
-- bwc_tag:end_query

