-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=5
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS VALUES ('a', 'foo', 1), ('a', 'foo', 2), ('a', 'bar', 1), ('b', 'bar', 1);
-- bwc_tag:end_query

COPY (FROM test) TO 'output/hive_partition_compress' (FORMAT parquet, COMPRESSION 'gzip', PARTITION_BY ('col0', 'col1'));
-- bwc_tag:end_query

FROM read_parquet('output/hive_partition_compress/*/*/*.parquet')
ORDER BY ALL
-- bwc_tag:end_query

