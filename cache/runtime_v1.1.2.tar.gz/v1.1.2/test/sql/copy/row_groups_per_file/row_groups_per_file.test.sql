-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=34
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE bigdata AS SELECT i AS col_a, i AS col_b FROM range(0,10000) tbl(i);
-- bwc_tag:end_query

-- bwc_tag:skip_query
set threads=1
-- bwc_tag:end_query

COPY bigdata TO 'output/row_groups_per_file1' (FORMAT PARQUET, ROW_GROUP_SIZE 2000, ROW_GROUPS_PER_FILE 1)
-- bwc_tag:end_query

SELECT count(*) FROM 'output/row_groups_per_file1/*.parquet'
-- bwc_tag:end_query

SELECT count(*) FROM glob('output/row_groups_per_file1/*.parquet')
-- bwc_tag:end_query

COPY bigdata TO 'output/row_groups_per_file2' (FORMAT PARQUET, ROW_GROUP_SIZE 4000, ROW_GROUPS_PER_FILE 1)
-- bwc_tag:end_query

SELECT count(*) FROM 'output/row_groups_per_file2/*.parquet'
-- bwc_tag:end_query

SELECT count(*) FROM glob('output/row_groups_per_file2/*.parquet')
-- bwc_tag:end_query

COPY bigdata TO 'output/row_groups_per_file3' (FORMAT PARQUET, ROW_GROUP_SIZE 2000, ROW_GROUPS_PER_FILE 2)
-- bwc_tag:end_query

SELECT count(*) FROM 'output/row_groups_per_file3/*.parquet'
-- bwc_tag:end_query

SELECT count(*) FROM glob('output/row_groups_per_file3/*.parquet')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA verify_parallelism
-- bwc_tag:end_query

-- bwc_tag:skip_query
set threads=4
-- bwc_tag:end_query

COPY bigdata TO 'output/row_groups_per_file4' (FORMAT PARQUET, ROW_GROUP_SIZE 2000, ROW_GROUPS_PER_FILE 1)
-- bwc_tag:end_query

SELECT count(*) FROM 'output/row_groups_per_file4/*.parquet'
-- bwc_tag:end_query

SELECT count(*) BETWEEN 1 and 10 FROM glob('output/row_groups_per_file4/*.parquet')
-- bwc_tag:end_query

COPY bigdata TO 'output/row_groups_per_file5' (FORMAT PARQUET, ROW_GROUP_SIZE 4000, ROW_GROUPS_PER_FILE 1)
-- bwc_tag:end_query

SELECT count(*) FROM 'output/row_groups_per_file5/*.parquet'
-- bwc_tag:end_query

SELECT count(*) BETWEEN 1 and 10 FROM glob('output/row_groups_per_file5/*.parquet')
-- bwc_tag:end_query

COPY bigdata TO 'output/row_groups_per_file6' (FORMAT PARQUET, ROW_GROUP_SIZE 2000, ROW_GROUPS_PER_FILE 2)
-- bwc_tag:end_query

SELECT count(*) FROM 'output/row_groups_per_file6/*.parquet'
-- bwc_tag:end_query

SELECT count(*) BETWEEN 1 and 10 FROM glob('output/row_groups_per_file6/*.parquet')
-- bwc_tag:end_query

COPY bigdata TO 'output/row_groups_per_file7' (FORMAT PARQUET, PER_THREAD_OUTPUT TRUE, ROW_GROUP_SIZE 2000, ROW_GROUPS_PER_FILE 1)
-- bwc_tag:end_query

SELECT count(*) FROM 'output/row_groups_per_file7/*.parquet'
-- bwc_tag:end_query

SELECT count(*) BETWEEN 1 AND 10 FROM glob('output/row_groups_per_file7/*.parquet')
-- bwc_tag:end_query

COPY bigdata TO 'output/row_groups_per_file8' (FORMAT PARQUET, PER_THREAD_OUTPUT TRUE, ROW_GROUP_SIZE 4000, ROW_GROUPS_PER_FILE 1)
-- bwc_tag:end_query

SELECT count(*) FROM 'output/row_groups_per_file8/*.parquet'
-- bwc_tag:end_query

SELECT count(*) BETWEEN 1 AND 10 FROM glob('output/row_groups_per_file8/*.parquet')
-- bwc_tag:end_query

COPY bigdata TO 'output/row_groups_per_file9' (FORMAT PARQUET, PER_THREAD_OUTPUT TRUE, ROW_GROUP_SIZE 2000, ROW_GROUPS_PER_FILE 2)
-- bwc_tag:end_query

SELECT count(*) FROM 'output/row_groups_per_file9/*.parquet'
-- bwc_tag:end_query

SELECT count(*) BETWEEN 1 AND 10 FROM glob('output/row_groups_per_file9/*.parquet')
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

COPY bigdata TO 'output/row_groups_per_file_error' (FORMAT PARQUET, ROW_GROUPS_PER_FILE 1, USE_TMP_FILE TRUE);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

COPY bigdata TO 'output/row_groups_per_file_error' (FORMAT PARQUET, ROW_GROUPS_PER_FILE 1, PARTITION_BY col_a);
-- bwc_tag:end_query

