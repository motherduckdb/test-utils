-- bwc_tag:nb_steps=25
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER, j INTEGER, k INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (2, 3, 5), (4, 5, 6), (2, 7, 6);
-- bwc_tag:end_query

SELECT DISTINCT ON (i) i, j FROM integers ORDER BY i, j DESC;
-- bwc_tag:end_query

SELECT DISTINCT ON (i) i, j FROM integers ORDER BY i, j;
-- bwc_tag:end_query

SELECT DISTINCT ON (i) i, j FROM integers ORDER BY j DESC;
-- bwc_tag:end_query

SELECT DISTINCT ON (i) i, j FROM integers ORDER BY j;
-- bwc_tag:end_query

SELECT i, j, (SELECT DISTINCT ON(i) j) AS k FROM integers ORDER BY i, j;
-- bwc_tag:end_query

SELECT i, j, (SELECT DISTINCT ON(i) j ORDER BY i, j DESC) AS k FROM integers ORDER BY i, j;
-- bwc_tag:end_query

SELECT i, j, (SELECT DISTINCT ON(i) j ORDER BY i, k) AS k FROM integers ORDER BY i, j;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (2, 3, 7), (4, 5, 11);
-- bwc_tag:end_query

SELECT DISTINCT ON(i) i, j, k FROM integers ORDER BY i, j ASC, k ASC
-- bwc_tag:end_query

SELECT DISTINCT ON(i) i, j, k FROM integers ORDER BY i, j ASC, k DESC
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (2, NULL, 27), (4, 88, NULL);
-- bwc_tag:end_query

SELECT DISTINCT ON(i) i, j, k FROM integers ORDER BY i, j NULLS FIRST, k DESC NULLS LAST;
-- bwc_tag:end_query

SELECT DISTINCT ON(i) i, j, k FROM integers ORDER BY i, j NULLS FIRST, k NULLS FIRST;
-- bwc_tag:end_query

SELECT DISTINCT ON(i) i, j, k FROM integers ORDER BY i, k NULLS FIRST, j NULLS FIRST;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table foo(a real, b real);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into foo values (1, 69), (1, 420), (2, 69), (2, 420);
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
select distinct on(a) a, b from foo order by b asc;
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
select distinct on(a) a, b from foo order by b desc;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE example (
    id               INT,
    person_id        INT,
    address_id       INT,
    effective_date   DATE
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO
    example (id, person_id, address_id, effective_date)
VALUES
    (1, 2, 1, '2000-01-01'),  -- Moved to first house
    (5, 2, 2, '2004-08-19'),  -- Went to uni
    (9, 2, 1, '2007-06-12'),  -- Moved back home
    (2, 4, 3, '2007-05-18'),  -- Moved to first house
    (3, 4, 4, '2016-02-09')   -- Moved to new house
;
-- bwc_tag:end_query

SELECT DISTINCT ON (person_id)
    *
FROM
    example
ORDER BY
    person_id,
    effective_date ASC
;
-- bwc_tag:end_query

SELECT DISTINCT ON (person_id)
    *
FROM
    example
ORDER BY
    person_id,
    effective_date DESC
;
-- bwc_tag:end_query

