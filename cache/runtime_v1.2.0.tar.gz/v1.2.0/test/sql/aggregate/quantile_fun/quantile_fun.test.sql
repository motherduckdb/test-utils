-- bwc_tag:needed_extensions=tpch
-- bwc_tag:nb_steps=29
LOAD 'tpch';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table quantiles as select range r, random() FROM range(100) union all values (NULL, 0.1), (NULL, 0.5), (NULL, 0.9) order by 2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CALL dbgen(sf=0.001);
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification;
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA verify_external;
-- bwc_tag:end_query

SELECT quantile_disc(0.1::decimal(4,1), [0.1, 0.5, 0.9]);
-- bwc_tag:end_query

SELECT PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY "l_extendedprice") FROM lineitem;
-- bwc_tag:end_query

SET default_null_order='nulls_first';
-- bwc_tag:end_query

SELECT quantile_disc(r::decimal(4,1), 0.1) FROM quantiles
-- bwc_tag:end_query

SELECT quantile_disc(r::decimal(4,1), [0.1, 0.5, 0.9]) FROM quantiles
-- bwc_tag:end_query

SELECT quantile_cont(r::decimal(4,1), 0.15) FROM quantiles
-- bwc_tag:end_query

SELECT quantile_cont(r::decimal(4,1), [0.15, 0.5, 0.9]) FROM quantiles
-- bwc_tag:end_query

SELECT quantile_disc(r::decimal(8,1), 0.1) FROM quantiles
-- bwc_tag:end_query

SELECT quantile_disc(r::decimal(8,1), [0.1, 0.5, 0.9]) FROM quantiles
-- bwc_tag:end_query

SELECT quantile_cont(r::decimal(8,1), 0.15) FROM quantiles
-- bwc_tag:end_query

SELECT quantile_cont(r::decimal(8,1), [0.15, 0.5, 0.9]) FROM quantiles
-- bwc_tag:end_query

SELECT quantile_disc(r::decimal(12,1), 0.1) FROM quantiles
-- bwc_tag:end_query

SELECT quantile_disc(r::decimal(12,1), [0.1, 0.5, 0.9]) FROM quantiles
-- bwc_tag:end_query

SELECT quantile_cont(r::decimal(12,1), 0.15) FROM quantiles
-- bwc_tag:end_query

SELECT quantile_cont(r::decimal(12,1), [0.15, 0.5, 0.9]) FROM quantiles
-- bwc_tag:end_query

SELECT quantile_disc(r::decimal(18,1), 0.1) FROM quantiles
-- bwc_tag:end_query

SELECT quantile_disc(r::decimal(18,1), [0.1, 0.5, 0.9]) FROM quantiles
-- bwc_tag:end_query

SELECT quantile_cont(r::decimal(18,1), 0.15) FROM quantiles
-- bwc_tag:end_query

SELECT quantile_cont(r::decimal(18,1), [0.15, 0.5, 0.9]) FROM quantiles
-- bwc_tag:end_query

SELECT quantile_disc(r::decimal(24,1), 0.1) FROM quantiles
-- bwc_tag:end_query

SELECT quantile_disc(r::decimal(24,1), [0.1, 0.5, 0.9]) FROM quantiles
-- bwc_tag:end_query

SELECT quantile_cont(r::decimal(24,1), 0.15) FROM quantiles
-- bwc_tag:end_query

SELECT quantile_cont(r::decimal(24,1), [0.15, 0.5, 0.9]) FROM quantiles
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT quantile_cont(NULL, CAST(NULL AS DOUBLE[]))
-- bwc_tag:end_query

