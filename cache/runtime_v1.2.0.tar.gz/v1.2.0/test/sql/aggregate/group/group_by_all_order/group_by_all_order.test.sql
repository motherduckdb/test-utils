-- bwc_tag:nb_steps=9
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA verify_external
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(g integer, i integer);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers values (0, 1), (0, 2), (1, 3), (1, NULL);
-- bwc_tag:end_query

SELECT SUM(i) FROM integers
-- bwc_tag:end_query

SELECT SUM(i) FROM integers GROUP BY ALL
-- bwc_tag:end_query

SELECT SUM(i) FROM integers GROUP BY ALL ORDER BY ALL
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT SUM(i) FROM integers GROUP BY ALL ORDER BY g
-- bwc_tag:end_query

SELECT g, SUM(i) FROM integers GROUP BY ALL ORDER BY g
-- bwc_tag:end_query

