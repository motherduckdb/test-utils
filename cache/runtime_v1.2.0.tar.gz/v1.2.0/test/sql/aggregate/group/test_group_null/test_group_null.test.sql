-- bwc_tag:nb_steps=4
SET default_null_order='nulls_first';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER, j INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (3, 4), (NULL, 4), (2, 4);
-- bwc_tag:end_query

SELECT i, SUM(j) FROM integers GROUP BY i ORDER BY i
-- bwc_tag:end_query

