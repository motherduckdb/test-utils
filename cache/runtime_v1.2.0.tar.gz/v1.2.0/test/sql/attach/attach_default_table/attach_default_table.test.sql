-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=20
LOAD 'parquet';
-- bwc_tag:end_query

attach 'output/test.db' as ddb (default_table 'my_table')
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

FROM ddb
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE ddb.my_table AS (SELECT 1337 as value);
-- bwc_tag:end_query

from ddb
-- bwc_tag:end_query

from ddb.my_table
-- bwc_tag:end_query

from ddb.main.my_table
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table ddb as select 42 as value
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

from ddb
-- bwc_tag:end_query

from memory.main.ddb
-- bwc_tag:end_query

SELECT
    t1.value,
    t2.value
FROM
    memory.main.ddb as t1
JOIN
    ddb.main.my_table as t2
ON
    t1.value != t2.value
-- bwc_tag:end_query

use ddb
-- bwc_tag:end_query

from ddb
-- bwc_tag:end_query

from my_table
-- bwc_tag:end_query

from main.my_table
-- bwc_tag:end_query

use memory
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE memory.main.ddb
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW ddb as SELECT 1
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

FROM ddb
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP VIEW ddb;
-- bwc_tag:end_query

