-- bwc_tag:nb_steps=10
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

ATTACH 'output/persistent_attach.db'
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

ATTACH 'output/persistent_attach.db'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE persistent_attach.integers(i INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO persistent_attach.integers VALUES (42)
-- bwc_tag:end_query

SELECT SUM(i) FROM persistent_attach.integers
-- bwc_tag:end_query

DETACH persistent_attach
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT SUM(i) FROM persistent_attach.integers
-- bwc_tag:end_query

ATTACH 'output/persistent_attach.db'
-- bwc_tag:end_query

SELECT SUM(i) FROM persistent_attach.integers
-- bwc_tag:end_query

