-- bwc_tag:nb_steps=11
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

SELECT CAST(0.55 AS TINYINT) as x;
-- bwc_tag:end_query

SELECT CAST(-0.55 AS TINYINT) as x;
-- bwc_tag:end_query

SELECT CAST(0.55 AS SMALLINT) as x;
-- bwc_tag:end_query

SELECT CAST(-0.55 AS SMALLINT) as x;
-- bwc_tag:end_query

SELECT CAST(0.55 AS INTEGER) as x;
-- bwc_tag:end_query

SELECT CAST(-0.55 AS INTEGER) as x;
-- bwc_tag:end_query

SELECT CAST(0.55 AS BIGINT) as x;
-- bwc_tag:end_query

SELECT CAST(-0.55 AS BIGINT) as x;
-- bwc_tag:end_query

SELECT CAST(0.55 AS HUGEINT) as x;
-- bwc_tag:end_query

SELECT CAST(-0.55 AS HUGEINT) as x;
-- bwc_tag:end_query

