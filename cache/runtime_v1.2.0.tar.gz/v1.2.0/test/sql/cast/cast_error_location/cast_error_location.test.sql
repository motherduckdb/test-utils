-- bwc_tag:nb_steps=30
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT 1::STRUCT(i INTEGER)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT 1000::utinyint
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT 'hello'::int
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT 1000::decimal(2,1)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT 1000.0::decimal(5,1)::decimal(2,1)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT [1000]::utinyint[]
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT {'x': 1000}::row(x tinyint)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select 1e308::float
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select 1e308::hugeint
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select 1000000000000000000000000000000::hugeint::int
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select nth_value(42, 'hello') over ()
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select '1900'::date
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select 42::utinyint + 'hello'
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT bitstring('1', 9)::BOOL;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT [1,2,3]::INT[2]
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT '\x'::BYTEA
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE cast_table(i INTEGER, s VARCHAR, d DECIMAL(5,1), l INT[], int_struct ROW(i INTEGER), dbl DOUBLE, hge HUGEINT, invalid_blob_str VARCHAR);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO cast_table VALUES (1000, 'hello', 1000.0, [1000], {'i': 1000}, 1e308, 1000000000000000000000000000000, '\x')
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT i::utinyint from cast_table
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT s::int FROM cast_table
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT i::decimal(2,1) FROM cast_table
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT d::decimal(2,1) FROM cast_table
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT l::utinyint[] FROM cast_table
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT int_struct::ROW(x TINYINT) FROM cast_table
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select dbl::float FROM cast_table
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select dbl::hugeint FROM cast_table
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select hge::hugeint::int FROM cast_table
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT l::INT[3] FROM cast_table
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT invalid_blob_str::BYTEA FROM cast_table
-- bwc_tag:end_query

