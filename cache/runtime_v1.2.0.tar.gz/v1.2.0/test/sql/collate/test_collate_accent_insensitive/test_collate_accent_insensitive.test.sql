-- bwc_tag:nb_steps=16
-- bwc_tag:execute_from_sql
CREATE TABLE collate_test(s VARCHAR COLLATE NOACCENT)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO collate_test VALUES ('Mühleisen'), ('Hëllö')
-- bwc_tag:end_query

SELECT * FROM collate_test WHERE s='Muhleisen'
-- bwc_tag:end_query

SELECT * FROM collate_test WHERE s='mühleisen'
-- bwc_tag:end_query

SELECT * FROM collate_test WHERE s='Hello'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE collate_join_table(s VARCHAR, i INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO collate_join_table VALUES ('Hello', 1), ('Muhleisen', 3)
-- bwc_tag:end_query

SELECT collate_test.s, collate_join_table.s, i FROM collate_test JOIN collate_join_table ON (collate_test.s=collate_join_table.s) ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE collate_test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE collate_test(s VARCHAR COLLATE NOACCENT)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO collate_test VALUES ('Hällo'), ('Hallo'), ('Hello')
-- bwc_tag:end_query

SELECT * FROM collate_test ORDER BY s
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE collate_test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE collate_test(s VARCHAR COLLATE NOACCENT)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO collate_test VALUES ('Hällo'), ('Hallo')
-- bwc_tag:end_query

SELECT DISTINCT s FROM collate_test
-- bwc_tag:end_query

