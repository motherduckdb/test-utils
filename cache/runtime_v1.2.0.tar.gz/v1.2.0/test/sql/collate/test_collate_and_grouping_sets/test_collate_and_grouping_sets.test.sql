-- bwc_tag:needed_extensions=icu
-- bwc_tag:nb_steps=14
LOAD 'icu';
-- bwc_tag:end_query

set default_collation=c;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE sales (
   product_id INT,
   region VARCHAR(50),
   year INT,
   amount_sold DECIMAL(10,2)
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO sales VALUES
  (1, 'North', 2020, 1000.00),
  (1, 'North', 2021, 1500.00),
  (1, 'South', 2020, 800.00),
  (1, 'South', 2021, 700.00),
  (2, 'North', 2020, 500.00),
  (2, 'North', 2021, 600.00),
  (2, 'South', 2020, 400.00),
  (2, 'South', 2021, 550.00);
-- bwc_tag:end_query

set default_collation=c;
-- bwc_tag:end_query

SELECT product_id, region, SUM(amount_sold) AS total_amount
FROM sales
GROUP BY GROUPING SETS ((product_id), (region), ())
ORDER BY product_id, region, total_amount;
-- bwc_tag:end_query

set default_collation=en_us;
-- bwc_tag:end_query

SELECT product_id, region, SUM(amount_sold) AS total_amount
FROM sales
GROUP BY GROUPING SETS ((product_id), (region), ())
ORDER BY product_id, region, total_amount;
-- bwc_tag:end_query

set default_collation=c
-- bwc_tag:end_query

select NULL product_id, region, sum(amount_sold) from sales group by region
UNION ALL
select NULL product_id, NULL region, sum(amount_sold) from sales
UNION ALL
select product_id, NULL region, sum(amount_sold) from sales group by product_id order by 1,2;
-- bwc_tag:end_query

set default_collation=en_us;
-- bwc_tag:end_query

select NULL product_id, region, sum(amount_sold) from sales group by region
UNION ALL
select NULL product_id, NULL region, sum(amount_sold) from sales
UNION ALL
select product_id, NULL region, sum(amount_sold) from sales group by product_id order by 1,2;
-- bwc_tag:end_query

SELECT product_id, region, SUM(amount_sold) AS total_amount
FROM sales
GROUP BY GROUPING SETS ((product_id), (region), ())
ORDER BY product_id, region, total_amount;
-- bwc_tag:end_query

select NULL product_id, region, sum(amount_sold) from sales group by region
UNION ALL
select NULL product_id, NULL region, sum(amount_sold) from sales
UNION ALL
select product_id, NULL region, sum(amount_sold) from sales group by product_id order by 1,2;
-- bwc_tag:end_query

