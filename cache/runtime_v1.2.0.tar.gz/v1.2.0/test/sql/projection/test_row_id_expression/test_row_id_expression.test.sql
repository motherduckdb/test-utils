-- bwc_tag:nb_steps=32
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table a(i integer);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into a values (42);
-- bwc_tag:end_query

SELECT rowid + 1, rowid - 1, rowid + rowid, i + rowid FROM a
-- bwc_tag:end_query

SELECT -rowid, +rowid, abs(rowid) FROM a
-- bwc_tag:end_query

SELECT rowid BETWEEN -1 AND 1, 0 BETWEEN rowid AND 1, 1 BETWEEN -3 AND rowid FROM a
-- bwc_tag:end_query

SELECT rowid < i, rowid = NULL, rowid = i, rowid <> 0 FROM a
-- bwc_tag:end_query

SELECT SUM(rowid), MIN(rowid), MAX(rowid), COUNT(rowid), FIRST(rowid) FROM a
-- bwc_tag:end_query

SELECT SUM(rowid), MIN(rowid), MAX(rowid), COUNT(rowid), LAST(rowid) FROM a
-- bwc_tag:end_query

SELECT COUNT(*) FROM a
-- bwc_tag:end_query

SELECT SUM(rowid), MIN(rowid), MAX(rowid), COUNT(rowid), FIRST(rowid), LAST(rowid) FROM a GROUP BY i
-- bwc_tag:end_query

SELECT SUM(i) FROM a GROUP BY rowid
-- bwc_tag:end_query

SELECT * FROM a, a a2 WHERE a.rowid=a2.rowid
-- bwc_tag:end_query

SELECT * FROM a, a a2 WHERE a.rowid<>a2.rowid
-- bwc_tag:end_query

SELECT * FROM a, a a2 WHERE a.rowid>=a2.rowid
-- bwc_tag:end_query

SELECT * FROM a ORDER BY rowid
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO a SELECT rowid FROM a
-- bwc_tag:end_query

SELECT * FROM a ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
UPDATE a SET i=rowid
-- bwc_tag:end_query

SELECT * FROM a ORDER BY 1
-- bwc_tag:end_query

SELECT * FROM a WHERE rowid=0
-- bwc_tag:end_query

SELECT * FROM a WHERE rowid BETWEEN -100 AND 100 ORDER BY 1
-- bwc_tag:end_query

SELECT * FROM a WHERE rowid=0 OR rowid=1
-- bwc_tag:end_query

SELECT row_number() OVER (PARTITION BY rowid) FROM a ORDER BY rowid
-- bwc_tag:end_query

SELECT row_number() OVER (ORDER BY rowid) FROM a ORDER BY rowid
-- bwc_tag:end_query

SELECT row_number() OVER (ORDER BY rowid DESC) FROM a ORDER BY rowid
-- bwc_tag:end_query

SELECT (SELECT rowid FROM a LIMIT 1)
-- bwc_tag:end_query

SELECT 0 IN (SELECT rowid FROM a)
-- bwc_tag:end_query

SELECT EXISTS(SELECT rowid FROM a)
-- bwc_tag:end_query

SELECT (SELECT a2.rowid FROM a a2 WHERE a.rowid=a2.rowid) FROM a
-- bwc_tag:end_query

SELECT a.rowid IN (SELECT a2.rowid FROM a a2 WHERE a.rowid>=a2.rowid) FROM a
-- bwc_tag:end_query

SELECT EXISTS(SELECT a2.rowid FROM a a2 WHERE a.rowid>=a2.rowid) FROM a
-- bwc_tag:end_query

