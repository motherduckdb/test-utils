-- bwc_tag:nb_steps=21
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test(i INTEGER, j INTEGER NOT NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (1, 1), (2, 2)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO test VALUES (3, NULL)
-- bwc_tag:end_query

SELECT * FROM test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test ALTER COLUMN j DROP NOT NULL
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (3, NULL)
-- bwc_tag:end_query

SELECT * FROM test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test2(i INTEGER, j INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test2 VALUES (1, 1), (2, 2)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test2 ALTER COLUMN j DROP NOT NULL
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (3, NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE IF EXISTS test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test(i AS (1), j INTEGER NOT NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (1), (2)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO test VALUES (NULL)
-- bwc_tag:end_query

SELECT * FROM test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test ALTER COLUMN i DROP NOT NULL
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test ALTER COLUMN j DROP NOT NULL
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (NULL)
-- bwc_tag:end_query

SELECT * FROM test
-- bwc_tag:end_query

