-- bwc_tag:nb_steps=14
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE duplicates (i INTEGER, j INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO duplicates VALUES (1, 10), (2, 20), (3, 30), (1, 100)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE duplicates ADD PRIMARY KEY (i)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE nulls (i INTEGER, j INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO nulls VALUES (1, 10), (2, NULL), (3, 30), (4, 40);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE nulls ADD PRIMARY KEY (i, j);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE nulls;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE nulls (i INTEGER, j INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO nulls VALUES (5, 10), (NULL, 20), (7, 30), (8, 100);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE nulls ADD PRIMARY KEY (i)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE nulls_compound (i INTEGER, j INTEGER, k VARCHAR)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO nulls_compound VALUES (1, 10, 'hello'), (2, 20, 'world'), (NULL, NULL, NULL), (3, 100, 'yay');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE nulls_compound ADD PRIMARY KEY (k, i)
-- bwc_tag:end_query

