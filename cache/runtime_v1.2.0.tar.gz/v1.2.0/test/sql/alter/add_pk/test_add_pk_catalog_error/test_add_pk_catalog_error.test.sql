-- bwc_tag:nb_steps=10
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test (i INTEGER, j INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE test ADD PRIMARY KEY (i_do_not_exist)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE i_do_not_exist ADD PRIMARY KEY (i, j)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE uniq (i INTEGER UNIQUE, j INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO uniq VALUES (1, 10), (2, 20), (3, 30)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO uniq VALUES (1, 100)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE uniq ADD PRIMARY KEY (i)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO uniq VALUES (1, 101)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO uniq VALUES (NULL, 100)
-- bwc_tag:end_query

