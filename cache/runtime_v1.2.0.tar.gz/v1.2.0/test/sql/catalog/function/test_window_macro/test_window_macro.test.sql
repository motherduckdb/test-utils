-- bwc_tag:nb_steps=10
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE MACRO my_agg(x) AS SUM(CASE WHEN x THEN 1 END);
-- bwc_tag:end_query

select my_agg(range) 
from range(2);
-- bwc_tag:end_query

select my_agg(range) OVER () 
from range(2);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE MACRO my_func(x) AS mod(x, 2);
-- bwc_tag:end_query

select my_func(range) 
from range(2);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select my_func(range) OVER () 
from range(2);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE MACRO my_case(x) AS (CASE WHEN x THEN 1 END);
-- bwc_tag:end_query

select my_case(range) 
from range(2);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select my_case(range) OVER () 
from range(2);
-- bwc_tag:end_query

