-- bwc_tag:nb_steps=7
-- bwc_tag:execute_from_sql
CREATE TABLE tst(a varchar, b varchar,PRIMARY KEY(a,b))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO tst VALUES ('hell', 'hello'), ('hell','hello')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO tst VALUES ('hell', 'hello'), ('hello','hell'), ('hel','hell'), ('hell','hel')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO tst VALUES ('hell', 'hello'),('hel', 'hello');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO tst VALUES ('hel', 'hello');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

UPDATE tst SET b='hello' WHERE b='hel'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
UPDATE tst SET b='hell' WHERE b='hel'
-- bwc_tag:end_query

