-- bwc_tag:nb_steps=27
-- bwc_tag:execute_from_sql
CREATE TABLE t1(i1 INTEGER UNIQUE)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES (1), (2), (3), (4)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t2(i2 INTEGER PRIMARY KEY, FOREIGN KEY (i2) REFERENCES t1(i1))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t2 VALUES (1), (2), (3)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t3(i3 INTEGER UNIQUE, FOREIGN KEY (i3) REFERENCES t2(i2))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t3 VALUES (1), (2)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t4(i4 INTEGER, FOREIGN KEY (i4) REFERENCES t3(i3))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t4 VALUES (1)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO t2 VALUES (5)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO t3 VALUES (4)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO t4 VALUES (3)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t2 VALUES (4)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t3 VALUES (3)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t4 VALUES (2)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DELETE FROM t1 WHERE i1=4
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DELETE FROM t2 WHERE i2=3
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DELETE FROM t3 WHERE i3=2
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DELETE FROM t2 WHERE i2=4
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DELETE FROM t3 WHERE i3=3
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DELETE FROM t4 WHERE i4=2
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DROP TABLE t1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DROP TABLE t2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DROP TABLE t3;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE t4;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE t3;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE t2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE t1;
-- bwc_tag:end_query

