-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=24
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE decimals(
	dec4 DECIMAL(4,1),
	dec9 DECIMAL(9,2),
	dec18 DECIMAL(18,3),
	dec38 DECIMAL(38,4)
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO decimals VALUES (
	-999.9,
	-9999999.99,
	-999999999999999.999,
	-999999999999999999999999999999999.9999
), (
	NULL, NULL, NULL, NULL
), (
 	42, 42, 42, 42
), (
 	-42, -42, -42, -42
), (
  	0, 0, 0, 0
 ), (
  	999.9,
  	9999999.99,
  	999999999999999.999,
  	999999999999999999999999999999999.9999
);
-- bwc_tag:end_query

COPY decimals TO 'output/decimals.parquet';
-- bwc_tag:end_query

SELECT * FROM decimals;
-- bwc_tag:end_query

SELECT * FROM 'output/decimals.parquet';
-- bwc_tag:end_query

SELECT stats_min, stats_max, stats_min_value, stats_max_value FROM parquet_metadata('output/decimals.parquet');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DELETE FROM decimals WHERE dec4<-42 OR dec4>42
-- bwc_tag:end_query

COPY decimals TO 'output/decimals.parquet';
-- bwc_tag:end_query

SELECT * FROM 'output/decimals.parquet' WHERE dec4=42
-- bwc_tag:end_query

SELECT * FROM 'output/decimals.parquet' WHERE dec4=-43
-- bwc_tag:end_query

SELECT * FROM 'output/decimals.parquet' WHERE dec4=43
-- bwc_tag:end_query

SELECT * FROM 'output/decimals.parquet' WHERE dec9=42
-- bwc_tag:end_query

SELECT * FROM 'output/decimals.parquet' WHERE dec9=-43
-- bwc_tag:end_query

SELECT * FROM 'output/decimals.parquet' WHERE dec9=43
-- bwc_tag:end_query

SELECT * FROM 'output/decimals.parquet' WHERE dec18=42
-- bwc_tag:end_query

SELECT * FROM 'output/decimals.parquet' WHERE dec18=-43
-- bwc_tag:end_query

SELECT * FROM 'output/decimals.parquet' WHERE dec18=43
-- bwc_tag:end_query

SELECT * FROM 'output/decimals.parquet' WHERE dec38=42
-- bwc_tag:end_query

SELECT * FROM 'output/decimals.parquet' WHERE dec38=-43
-- bwc_tag:end_query

SELECT * FROM 'output/decimals.parquet' WHERE dec38=43
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA disable_verification
-- bwc_tag:end_query

SELECT stats(dec4), stats(dec9), stats(dec18), stats(dec38) FROM 'output/decimals.parquet' LIMIT 1
-- bwc_tag:end_query

