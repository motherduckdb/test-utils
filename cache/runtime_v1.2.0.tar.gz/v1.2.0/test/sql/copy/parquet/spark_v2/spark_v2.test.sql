-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=5
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

SELECT count(*) FROM 'data/parquet-testing/spark-store.parquet'
-- bwc_tag:end_query

SELECT s_store_sk, s_floor_space, trim(s_street_name) FROM 'data/parquet-testing/spark-store.parquet'
-- bwc_tag:end_query

SELECT * FROM 'data/parquet-testing/spark-ontime.parquet'
-- bwc_tag:end_query

