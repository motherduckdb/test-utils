-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=4
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

select timestamp from 'data/parquet-testing/issue_5533_timestamp_ms_stats.parquet' order by 1;
-- bwc_tag:end_query

select timestamp from 'data/parquet-testing/issue_5533_timestamp_ms_stats.parquet' where timestamp >= '2022-11-27 00:00:00'
-- bwc_tag:end_query

