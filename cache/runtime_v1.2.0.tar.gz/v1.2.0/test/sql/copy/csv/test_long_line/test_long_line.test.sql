-- bwc_tag:nb_steps=5
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test (a INTEGER, b VARCHAR, c INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY test FROM 'data/csv/test/test_long_line.csv';
-- bwc_tag:end_query

SELECT LENGTH(b) FROM test ORDER BY a;
-- bwc_tag:end_query

SELECT SUM(a), SUM(c) FROM test;
-- bwc_tag:end_query

