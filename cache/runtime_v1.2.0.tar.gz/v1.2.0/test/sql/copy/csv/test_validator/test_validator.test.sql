-- bwc_tag:nb_steps=12
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

FROM read_csv('data/csv/evil_nullpadding.csv', buffer_size=20, quote = '"')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/evil_nullpadding.csv', buffer_size=20)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/validator/single_column.csv', header = 0)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

FROM read_csv('data/csv/validator/single_column.csv', header = 0, columns = {'a': 'integer'}, auto_detect = false)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

FROM read_csv('data/csv/validator/single_column.csv', header = 0, columns = {'a': 'integer'}, auto_detect = false, buffer_size = 11)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

FROM read_csv('data/csv/validator/single_column.csv', header = 0, columns = {'a': 'integer'}, auto_detect = false, buffer_size = 11, parallel = false)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/validator/quoted_new_value.csv')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/validator/quoted_new_value.csv', columns = {'band': 'varchar', 'album': 'varchar', 'release': 'varchar'}, quote = '''', delim = ';', header = 0)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/validator/quoted_new_value.csv', columns = {'band': 'varchar', 'album': 'varchar', 'release': 'varchar'}, quote = '''', delim = ';', header = 0, buffer_size = 46)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/validator/single_column_quoted_newline.csv', columns = {'Raffaella Carrà': 'varchar'}, quote = '"',  buffer_size = 24)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/validator/single_column_notquoted_newline.csv', columns = {'Raffaella Carrà': 'varchar'}, quote = '"',  buffer_size = 22)
-- bwc_tag:end_query

