-- bwc_tag:nb_steps=2
-- bwc_tag:execute_from_sql
SELECT * FROM read_csv(
    'data/csv/rejects/flush.csv',
    columns = {'a': 'DECIMAL'},
    store_rejects = true);
-- bwc_tag:end_query

SELECT * EXCLUDE (scan_id) FROM reject_errors order by all;
-- bwc_tag:end_query

