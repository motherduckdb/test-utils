-- bwc_tag:nb_steps=12
-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT * FROM read_csv(
    'data/csv/error/mismatch/bad.csv',
    columns = {'col0': 'INTEGER', 'col1': 'INTEGER', 'col2': 'VARCHAR'},
    ignore_errors=false,
    store_rejects=true
)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT * FROM read_csv(
    'data/csv/error/mismatch/bad.csv',
    columns = {'col0': 'INTEGER', 'col1': 'INTEGER', 'col2': 'VARCHAR'},
    ignore_errors=true,
    rejects_table='')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT * FROM read_csv(
    'data/csv/error/mismatch/bad.csv',
    columns = {'col0': 'INTEGER', 'col1': 'INTEGER', 'col2': 'VARCHAR'},
    ignore_errors=true,
    rejects_table='csv_rejects_table',
    union_by_name=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT * FROM read_csv(
    'data/csv/error/mismatch/bad.csv',
    columns = {'col0': 'INTEGER', 'col1': 'INTEGER', 'col2': 'VARCHAR'},
    ignore_errors=true,
    rejects_limit=10)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT * FROM read_csv(
    'data/csv/error/mismatch/bad.csv',
    columns = {'col0': 'INTEGER', 'col1': 'INTEGER', 'col2': 'VARCHAR'},
    ignore_errors=true,
    rejects_table='csv_rejects_table',
    rejects_limit=-1)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT * FROM read_csv_auto(
    'data/csv/error/mismatch/bad.csv',
    ignore_errors=false,
    rejects_table='csv_rejects_table'
)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT * FROM read_csv_auto(
    'data/csv/error/mismatch/bad.csv',
    ignore_errors=true,
    rejects_table='')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT * FROM read_csv_auto(
    'data/csv/error/mismatch/bad.csv',
    ignore_errors=true,
    rejects_table='csv_rejects_table',
    union_by_name=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT * FROM read_csv_auto(
    'data/csv/error/mismatch/bad.csv',
    ignore_errors=true,
    rejects_limit=10)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT * FROM read_csv_auto(
    'data/csv/error/mismatch/bad.csv',
    ignore_errors=true,
    rejects_table='csv_rejects_table',
    rejects_limit=-1)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT typeof(first(column0)), typeof(first(column1)), COUNT(*) FROM read_csv_auto(
    'data/csv/error/mismatch/big_bad*.csv',
    sample_size=3000,
    rejects_table='csv_rejects_table',
    ignore_errors=true, header = 0);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE csv_rejects_table;
-- bwc_tag:end_query

