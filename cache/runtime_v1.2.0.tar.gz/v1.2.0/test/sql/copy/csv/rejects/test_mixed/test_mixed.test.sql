-- bwc_tag:nb_steps=2
-- bwc_tag:execute_from_sql
SELECT * FROM read_csv(
    'data/csv/rejects/frankstein/nightmare.csv',
    columns = {'a': 'INTEGER', 'b': 'INTEGER', 'c': 'VARCHAR'},
    store_rejects = true, auto_detect=false, header = 1, max_line_size=20, strict_mode=true);
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
SELECT * EXCLUDE (scan_id) FROM reject_errors ORDER BY ALL;
-- bwc_tag:end_query

