-- bwc_tag:nb_steps=3
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT count(*) FROM read_csv_auto( ['data/csv/error/mismatch/half1.csv', 'data/csv/error/mismatch/half2.csv'], ignore_errors=true, sample_size=1);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT count(*) FROM read_csv_auto( ['data/csv/error/mismatch/half2.csv', 'data/csv/error/mismatch/half1.csv'], ignore_errors=true, sample_size=1);
-- bwc_tag:end_query

