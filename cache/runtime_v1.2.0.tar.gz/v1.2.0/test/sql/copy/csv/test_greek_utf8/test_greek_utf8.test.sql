-- bwc_tag:nb_steps=8
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE greek_utf8 AS SELECT i, nfc_normalize(j) j, k FROM read_csv('data/csv/real/greek_utf8.csv', columns=STRUCT_PACK(i := 'INTEGER', j := 'VARCHAR', k := 'INTEGER'), delim='|')
-- bwc_tag:end_query

SELECT * FROM greek_utf8 ORDER BY 1;
-- bwc_tag:end_query

COPY greek_utf8 TO 'output/greek_utf8.csv' DELIMITER ' ' HEADER;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DELETE FROM greek_utf8;
-- bwc_tag:end_query

SELECT * FROM greek_utf8;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY greek_utf8 FROM 'output/greek_utf8.csv' DELIMITER ' ' HEADER;
-- bwc_tag:end_query

SELECT * FROM greek_utf8 ORDER BY 1;
-- bwc_tag:end_query

