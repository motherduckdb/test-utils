-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=8
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

COPY (SELECT 1 as a, 2 as a, 3 as a) TO 'output/dupe_cols.csv' (FORMAT CSV, HEADER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT a, "a_1", "a_2" FROM 'output/dupe_cols.csv';
-- bwc_tag:end_query

COPY (SELECT 1 as a, 2 as a, 3 as "a_1") TO 'output/dupe_cols.csv' (FORMAT CSV, HEADER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT a, "a_1", "a_1_1" FROM 'output/dupe_cols.csv';
-- bwc_tag:end_query

COPY (SELECT 1 as a, 3 as "a_1", 2 as a) TO 'output/dupe_cols.csv' (FORMAT CSV, HEADER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT a, "a_1", "a_2" FROM 'output/dupe_cols.csv';
-- bwc_tag:end_query

