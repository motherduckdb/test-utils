-- bwc_tag:nb_steps=17
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test (col_a INTEGER, col_b VARCHAR(10), col_c VARCHAR(10));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY test FROM 'data/csv/test/force_quote.csv' (HEADER 0);
-- bwc_tag:end_query

COPY test TO 'output/test_star.csv' (FORCE_QUOTE *, HEADER 0);
-- bwc_tag:end_query

COPY test TO 'output/test_chosen_columns.csv' (FORCE_QUOTE (col_a, col_c), QUOTE 't', NULL 'ea');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test2 (col_a INTEGER, col_b VARCHAR(10), col_c VARCHAR(10));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY test2 FROM 'output/test_chosen_columns.csv' (QUOTE 't', NULL 'ea');
-- bwc_tag:end_query

SELECT * FROM test2
-- bwc_tag:end_query

COPY test (col_b, col_c, col_a) TO 'output/test_reorder.csv' (FORCE_QUOTE (col_c, col_b), NULL 'test');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test3 (col_a INTEGER, col_b VARCHAR(10), col_c VARCHAR(10));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY test3(col_b, col_c, col_a) FROM 'output/test_reorder.csv' (NULL 'test');
-- bwc_tag:end_query

SELECT * FROM test2
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

COPY test (col_b, col_a) TO 'output/test_reorder.csv' (FORCE_QUOTE (col_c, col_b));
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

COPY test TO 'output/test_reorder.csv' (FORCE_QUOTE (col_c, col_d));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY test FROM 'output/test_reorder.csv' (FORCE_QUOTE (col_c, col_d));
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

COPY test TO 'output/test_reorder.csv' (FORCE_QUOTE);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

COPY test TO 'output/test_reorder.csv' (FORCE_QUOTE 42);
-- bwc_tag:end_query

