-- bwc_tag:nb_steps=9
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table t (a integer)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into t values (1),(2),(NULL)
-- bwc_tag:end_query

COPY t TO 'output/t_default.tsv' WITH (DELIMITER '\t');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select * from read_csv_auto('output/t_default.tsv', header = 0)
-- bwc_tag:end_query

COPY t TO 'output/t_default.tsv' WITH (DELIMITER '\t');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select * from read_csv_auto('output/t_default.tsv', header = 0)
-- bwc_tag:end_query

COPY t TO 'output/t_default.tsv' WITH (DELIMITER '\t', HEADER 0);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select * from read_csv_auto('output/t_default.tsv', header = 0)
-- bwc_tag:end_query

