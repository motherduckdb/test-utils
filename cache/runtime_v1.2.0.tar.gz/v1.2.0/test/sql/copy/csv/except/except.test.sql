-- bwc_tag:nb_steps=3
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

COPY (SELECT 1 a, 2 b) TO 'output/mismatch_types_except.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM 'output/mismatch_types_except.csv' EXCEPT select 'bla' as a, 1 as b;
-- bwc_tag:end_query

