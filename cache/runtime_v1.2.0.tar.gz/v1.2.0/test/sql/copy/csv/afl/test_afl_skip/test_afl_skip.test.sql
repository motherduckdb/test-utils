-- bwc_tag:nb_steps=3
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/skip/1.csv', skip=1)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/skip/2.csv', skip=1)
-- bwc_tag:end_query

