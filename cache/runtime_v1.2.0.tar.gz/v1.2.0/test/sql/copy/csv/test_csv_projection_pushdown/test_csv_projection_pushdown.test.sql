-- bwc_tag:nb_steps=15
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select l_returnflag, l_linenumber from read_csv('data/csv/real/lineitem_sample.csv', delim='|', header=False, columns={
	'l_orderkey': 'INT',
	'l_partkey': 'INT',
	'l_suppkey': 'INT',
	'l_linenumber': 'INT',
	'l_quantity': 'INTEGER',
	'l_extendedprice': 'DECIMAL(15,2)',
	'l_discount': 'DECIMAL(15,2)',
	'l_tax': 'DECIMAL(15,2)',
	'l_returnflag': 'VARCHAR(1)',
	'l_linestatus': 'VARCHAR(1)',
	'l_shipdate': 'DATE',
	'l_commitdate': 'DATE',
	'l_receiptdate': 'DATE',
	'l_shipinstruct': 'VARCHAR(25)',
	'l_shipmode': 'VARCHAR(10)',
	'l_comment': 'VARCHAR(44)'
})
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT COUNT(*) FROM 'data/csv/real/lineitem_sample.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW lineitem_csv AS SELECT * FROM read_csv('data/csv/real/lineitem_sample.csv', delim='|', header=False, columns={
	'l_orderkey': 'INT',
	'l_partkey': 'INT',
	'l_suppkey': 'INT',
	'l_linenumber': 'INT',
	'l_quantity': 'INTEGER',
	'l_extendedprice': 'DECIMAL(15,2)',
	'l_discount': 'DECIMAL(15,2)',
	'l_tax': 'DECIMAL(15,2)',
	'l_returnflag': 'VARCHAR(1)',
	'l_linestatus': 'VARCHAR(1)',
	'l_shipdate': 'DATE',
	'l_commitdate': 'DATE',
	'l_receiptdate': 'DATE',
	'l_shipinstruct': 'VARCHAR(25)',
	'l_shipmode': 'VARCHAR(10)',
	'l_comment': 'VARCHAR(44)'
})
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW lineitem_csv_auto AS SELECT * FROM read_csv_auto('data/csv/real/lineitem_sample.csv', header=False) lineitem(l_orderkey, l_partkey, l_suppkey, l_linenumber, l_quantity, l_extendedprice, l_discount, l_tax, l_returnflag, l_linestatus, l_shipdate, l_commitdate, l_receiptdate, l_shipinstruct, l_shipmode, l_comment)
-- bwc_tag:end_query

SELECT l_orderkey FROM lineitem_csv
-- bwc_tag:end_query

SELECT l_partkey FROM lineitem_csv
-- bwc_tag:end_query

SELECT l_shipdate FROM lineitem_csv
-- bwc_tag:end_query

SELECT COUNT(*) FROM lineitem_csv
-- bwc_tag:end_query

SELECT l_orderkey FROM lineitem_csv_auto
-- bwc_tag:end_query

SELECT l_partkey FROM lineitem_csv_auto
-- bwc_tag:end_query

SELECT l_shipdate FROM lineitem_csv_auto
-- bwc_tag:end_query

SELECT COUNT(*) FROM lineitem_csv_auto
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select count(*) from read_csv('data/csv/projection_buffer.csv', quote = '"', escape = '"',  buffer_size=35)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select d,b,a from read_csv('data/csv/projection_buffer.csv', quote = '"', escape = '"',  buffer_size=35)
-- bwc_tag:end_query

