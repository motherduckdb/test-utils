-- bwc_tag:nb_steps=57
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA verify_parallelism
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/repromarket.csv',
   columns={
      'email': 'varchar',
      'password': 'varchar'
   },
   all_varchar=true,
   delim=':',
   header=false,
   skip=0,
   null_padding=true,
   ignore_errors=true,
   strict_mode=true
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/pipe_delim.csv', columns={'a': 'VARCHAR'}, auto_detect=False)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/nullterm.csv')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/nullterm.csv', quote = '"', escape = '"')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/single_quote.csv', quote = '"')
-- bwc_tag:end_query

select columns FROM sniff_csv('data/csv/auto/mock_duckdb_test_data.csv', ignore_errors = true);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/auto/mock_duckdb_test_data.csv', ignore_errors = true,
   strict_mode=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

select * from read_csv_auto('data/csv/dates.csv', auto_detect=false, delim=',', quote='"', columns={'a': 'VARCHAR'},
   strict_mode=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select * from read_csv_auto('data/csv/dates.csv')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select * from read_csv_auto('data/csv/from_df.csv', quote='''')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/rfc_conform.csv');
-- bwc_tag:end_query

SELECT * FROM test ORDER BY column0;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/rfc_conform_quote.csv');
-- bwc_tag:end_query

SELECT * FROM test ORDER BY column0;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/leading_space_numerics.csv');
-- bwc_tag:end_query

SELECT * FROM test ORDER BY column0;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/pipe_delim.csv');
-- bwc_tag:end_query

SELECT * FROM test ORDER BY column0;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/pipe_delim_quote.csv');
-- bwc_tag:end_query

SELECT * FROM test ORDER BY column0;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/quote_escape.csv');
-- bwc_tag:end_query

SELECT * FROM test ORDER BY column0;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/backslash_escape.csv');
-- bwc_tag:end_query

SELECT * FROM test ORDER BY column0;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/single_quote_backslash.csv');
-- bwc_tag:end_query

SELECT * FROM test ORDER BY column0;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/semicolon_delim.csv');
-- bwc_tag:end_query

SELECT * FROM test ORDER BY column0;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/semicolon_quote.csv');
-- bwc_tag:end_query

SELECT * FROM test ORDER BY column0;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/semicolon_escape.csv');
-- bwc_tag:end_query

SELECT * FROM test ORDER BY column0;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/tab.csv');
-- bwc_tag:end_query

SELECT * FROM test ORDER BY column0;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/tab_single_quote.csv');
-- bwc_tag:end_query

SELECT * FROM test ORDER BY column0;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/tab_single_quote_varchar.csv');
-- bwc_tag:end_query

SELECT * FROM test ORDER BY column0;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT * FROM read_csv_auto ('data/csv/auto/issue_1254.csv');
-- bwc_tag:end_query

SELECT a, b FROM test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

