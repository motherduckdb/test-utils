-- bwc_tag:nb_steps=12
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

select * from read_csv('data/csv/test/multi_column_string.csv',  COLUMN_TYPES=STRUCT_PACK(a := 'INTEGER'))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

select * from read_csv_auto('data/csv/test/multi_column_string.csv',  COLUMN_TYPES=1)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

select * from read_csv_auto('data/csv/test/multi_column_string.csv',  COLUMN_TYPES=STRUCT_PACK())
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

select * from read_csv_auto('data/csv/test/multi_column_string.csv',  COLUMN_TYPES=STRUCT_PACK(a := 'BLA'))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

select * from read_csv_auto('data/csv/test/multi_column_string.csv',  COLUMN_TYPES=STRUCT_PACK(bla := 'INTEGER'))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

select * from read_csv_auto('data/csv/test/multi_column_string.csv',  COLUMN_TYPES=STRUCT_PACK(column3 := 'INTEGER'))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT typeof(#1) from read_csv_auto('data/csv/test/multi_column_string.csv',  COLUMN_TYPES=STRUCT_PACK(column0 := 'DOUBLE')) LIMIT 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT typeof(#1) from read_csv_auto('data/csv/test/multi_column_string.csv',  COLUMN_TYPES=STRUCT_PACK(column0 := 'INTEGER')) LIMIT 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT typeof(#3) from read_csv_auto('data/csv/test/multi_column_string.csv',  COLUMN_TYPES=STRUCT_PACK( column2 := 'HUGEINT')) LIMIT 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT typeof(#1),typeof(#3) from read_csv_auto('data/csv/test/multi_column_string.csv',  COLUMN_TYPES=STRUCT_PACK(column0 := 'BIGINT', column2 := 'HUGEINT')) LIMIT 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * from read_csv_auto('data/csv/test/multi_column_string.csv',  COLUMN_TYPES=STRUCT_PACK(column0 := 'BIGINT', column2 := 'HUGEINT'))
-- bwc_tag:end_query

