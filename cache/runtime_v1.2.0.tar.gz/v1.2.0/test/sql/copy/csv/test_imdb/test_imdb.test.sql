-- bwc_tag:nb_steps=4
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE movie_info (id integer NOT NULL PRIMARY KEY, movie_id integer NOT NULL, info_type_id integer NOT NULL, info text NOT NULL, note text);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY movie_info FROM 'data/csv/real/imdb_movie_info_escaped.csv' DELIMITER ',' ESCAPE '\';
-- bwc_tag:end_query

SELECT * FROM movie_info;
-- bwc_tag:end_query

