-- bwc_tag:needed_extensions=icu
-- bwc_tag:nb_steps=22
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

SELECT * FROM range(1, NULL, 1);
-- bwc_tag:end_query

SELECT * FROM (SELECT NULL a), range(a);
-- bwc_tag:end_query

SELECT * FROM (SELECT NULL a), range(timestamp '2010-01-01', a, null);
-- bwc_tag:end_query

SELECT * FROM range(3) t(i), range(i) t2(j) ORDER BY i, j;
-- bwc_tag:end_query

SELECT * FROM range(4) t(i), range(i) t2(j), range(j) t3(k) ORDER BY i, j, k;
-- bwc_tag:end_query

SELECT * FROM generate_series(0,2) t(i), generate_series(0,i) t2(j), generate_series(0,j) t3(k) ORDER BY i, j, k;
-- bwc_tag:end_query

SELECT i, j, l, str FROM (SELECT ARRAY['null'], NULL, 'null' UNION ALL SELECT ARRAY['five'], 5, 'five' UNION ALL SELECT ARRAY['two'], 2, 'two') t(l, i, str), generate_series(0,i-1) t2(j) order by i, j
-- bwc_tag:end_query

SELECT * FROM (SELECT 42 WHERE 42>84) t(i), range(i) t2(j)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM (SELECT '5'::VARCHAR) t(str), range(str) t2(j)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PREPARE v1 AS SELECT * FROM range(?);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
EXECUTE v1(5)
-- bwc_tag:end_query

SELECT * FROM (SELECT 3, 1, -1 UNION ALL SELECT 1, 3, 2) t(s, e, increment), range(s, e, increment) t2(j) ORDER BY s, j
-- bwc_tag:end_query

SELECT * FROM (SELECT DATE '2000-01-01', DATE '2000-10-1', INTERVAL '3' MONTHS) t(s, e, increment), range(s, e, increment) t2(j) ORDER BY s, j
-- bwc_tag:end_query

SELECT * FROM (SELECT DATE '2000-01-01', DATE '2000-10-1', INTERVAL '3' MONTHS) t(s, e, increment), generate_series(s, e, increment) t2(j) ORDER BY s, j
-- bwc_tag:end_query

SELECT * FROM (SELECT DATE '2000-01-01', DATE '2000-10-1', NULL) t(s, e, increment), generate_series(s, e, increment) t2(j) ORDER BY s, j
-- bwc_tag:end_query

select count(*) from (values (1), (10), (100), (1000), (10000)) t(a), range(a);
-- bwc_tag:end_query

LOAD 'icu';
-- bwc_tag:end_query

SET TimeZone='UTC'
-- bwc_tag:end_query

SELECT * FROM (SELECT TIMESTAMPTZ '2000-01-01', TIMESTAMPTZ '2000-10-1', INTERVAL '3' MONTHS) t(s, e, increment), range(s, e, increment) t2(j) ORDER BY s, j
-- bwc_tag:end_query

SELECT * FROM (SELECT TIMESTAMPTZ '2000-01-01', TIMESTAMPTZ '2000-10-1', NULL) t(s, e, increment), range(s, e, increment) t2(j) ORDER BY s, j
-- bwc_tag:end_query

SELECT * FROM (SELECT TIMESTAMPTZ '2000-01-01', TIMESTAMPTZ '2000-10-1', NULL UNION ALL SELECT TIMESTAMPTZ '2000-10-01', TIMESTAMPTZ '2000-01-1', INTERVAL '-3 months') t(s, e, increment), range(s, e, increment) t2(j) ORDER BY s, j
-- bwc_tag:end_query

