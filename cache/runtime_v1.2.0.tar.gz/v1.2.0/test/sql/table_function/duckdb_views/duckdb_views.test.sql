-- bwc_tag:nb_steps=7
SELECT COUNT(*) FROM duckdb_views;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW v1 AS SELECT 42;
-- bwc_tag:end_query

CREATE TEMPORARY VIEW v2 AS SELECT 42;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA myschema;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW myschema.v2 AS SELECT 42;
-- bwc_tag:end_query

SELECT database_name, schema_name, view_name, temporary FROM duckdb_views() WHERE NOT internal ORDER BY view_name;
-- bwc_tag:end_query

SELECT database_name, schema_name, view_name, temporary FROM duckdb_views ORDER BY view_name;
-- bwc_tag:end_query

