-- bwc_tag:nb_steps=19
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (1), (2), (3), (NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers SELECT * FROM integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers SELECT * FROM integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers SELECT * FROM integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers SELECT * FROM integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers SELECT * FROM integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers SELECT * FROM integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers SELECT * FROM integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers SELECT * FROM integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers SELECT * FROM integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers SELECT * FROM integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers SELECT * FROM integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers SELECT * FROM integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers SELECT * FROM integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers SELECT * FROM integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers SELECT * FROM integers
-- bwc_tag:end_query

SELECT COUNT(*), COUNT(i), SUM(i) FROM integers
-- bwc_tag:end_query

