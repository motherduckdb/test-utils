-- bwc_tag:nb_steps=2
-- bwc_tag:expected_result=error

ATTACH 'dummy_extension:/hello.world';
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

ATTACH 'file://dummy.csv'
-- bwc_tag:end_query

