-- bwc_tag:nb_steps=3
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

ATTACH DATABASE ':memory:' AS varchar;
-- bwc_tag:end_query

DETACH varchar
-- bwc_tag:end_query

