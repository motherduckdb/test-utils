-- bwc_tag:nb_steps=11
set storage_compatibility_version='v0.10.2'
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE IF NOT EXISTS test (val INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test(val) VALUES (1), (2), (3);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE VIEW foo AS (SELECT * FROM test);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE VIEW foo AS (SELECT * FROM foo);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM foo;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE VIEW foo AS (SELECT * FROM test);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE VIEW foo2 AS (SELECT * FROM foo);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE VIEW foo AS (SELECT (SELECT * FROM foo2));
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM foo;
-- bwc_tag:end_query

