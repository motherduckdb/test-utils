-- bwc_tag:nb_steps=14
-- bwc_tag:execute_from_sql
create sequence seq1 INCREMENT BY 1 MINVALUE 9223372036854775800 MAXVALUE 9223372036854775807 CYCLE;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('seq1') from generate_series(0,20);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create sequence seq2 INCREMENT BY -1 MINVALUE -9223372036854775808 MAXVALUE -9223372036854775800 CYCLE;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('seq2') from generate_series(0,20);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create sequence seq3 INCREMENT BY 1 MINVALUE 9223372036854775800 MAXVALUE 9223372036854775807;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT nextval('seq3') from generate_series(0,20);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create sequence seq4 INCREMENT BY -1 MINVALUE -9223372036854775808 MAXVALUE -9223372036854775800;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT nextval('seq4') from generate_series(0,20);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create sequence seq5 INCREMENT BY 9223372036854775807 MINVALUE 9223372036854775800 MAXVALUE 9223372036854775807 CYCLE;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('seq5') from generate_series(0,20);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create sequence seq6 INCREMENT BY 9223372036854775807 MINVALUE 9223372036854775800 MAXVALUE 9223372036854775807;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT nextval('seq6') from generate_series(0,20);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create sequence seq7 INCREMENT BY -9223372036854775808 MINVALUE -9223372036854775808 MAXVALUE -9223372036854775800;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT nextval('seq7') from generate_series(0,20);
-- bwc_tag:end_query

