-- bwc_tag:nb_steps=3
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create view r AS from read_csv_auto('data/csv/hive-partitioning/mismatching_contents/*/*.csv', UNION_BY_NAME=1, HIVE_PARTITIONING=1)
-- bwc_tag:end_query

WITH RECURSIVE t(i, j) AS
(
	SELECT 1, 0
	UNION ALL
	(
		SELECT i + 1, j + a
		FROM t, r
		WHERE i <= part
	)
)
SELECT * FROM t ORDER BY i;
-- bwc_tag:end_query

