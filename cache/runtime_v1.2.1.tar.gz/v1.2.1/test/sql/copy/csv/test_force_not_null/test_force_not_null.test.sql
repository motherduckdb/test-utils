-- bwc_tag:nb_steps=14
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test (col_a INTEGER, col_b VARCHAR(10), col_c VARCHAR(10));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY test FROM 'data/csv/test/force_not_null.csv' (FORCE_NOT_NULL (col_b), NULL 'test', HEADER 0,allow_quoted_nulls false );
-- bwc_tag:end_query

SELECT * FROM test ORDER BY 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DELETE FROM test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY test (col_a, col_b, col_c) FROM 'data/csv/test/force_not_null.csv' (FORCE_NOT_NULL (col_b), NULL 'test', HEADER 0, allow_quoted_nulls false);
-- bwc_tag:end_query

SELECT * FROM test ORDER BY 1;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

COPY test TO 'data/csv/test/force_not_null.csv' (FORCE_NOT_NULL (col_b), NULL 'test', HEADER 0);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY test FROM 'data/csv/test/force_not_null.csv' (FORCE_NOT_NULL, NULL 'test');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY test FROM 'data/csv/test/force_not_null.csv' (FORCE_NOT_NULL 42, NULL 'test');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY test (col_b, col_a) FROM 'data/csv/test/force_not_null_reordered.csv' (FORCE_NOT_NULL (col_c, col_b));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY test FROM 'data/csv/test/force_not_null_reordered.csv' (FORCE_NOT_NULL (col_c, col_d));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY test FROM 'data/csv/test/force_not_null.csv' (FORCE_NOT_NULL (col_a), HEADER 0);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY test FROM 'data/csv/test/force_not_null_inull.csv' (FORCE_NOT_NULL (col_a), HEADER 0);
-- bwc_tag:end_query

