-- bwc_tag:needed_extensions=icu
-- bwc_tag:nb_steps=9
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tbl(id int, ts timestamp);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY tbl FROM 'data/csv/timestamp_with_tz.csv' (HEADER)
-- bwc_tag:end_query

LOAD 'icu';
-- bwc_tag:end_query

SET autoload_known_extensions=false;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tbl_tz(id int, ts timestamptz);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY tbl_tz FROM 'data/csv/timestamp_with_tz.csv' (HEADER)
-- bwc_tag:end_query

SET TimeZone='UTC'
-- bwc_tag:end_query

SELECT * FROM tbl_tz
-- bwc_tag:end_query

