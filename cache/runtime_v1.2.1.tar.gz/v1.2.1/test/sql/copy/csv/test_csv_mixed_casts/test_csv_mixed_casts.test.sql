-- bwc_tag:nb_steps=9
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv(
    'data/csv/mixed_dates.csv',
    auto_detect = false,
    header = true,
     columns = {
      'A': 'INTEGER',
      'B': 'DATE',
    },
    dateformat = '%m/%d/%Y',
    ignore_errors = true
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv(
    'data/csv/mixed_timestamps.csv',
    auto_detect = false,
    header = true,
     columns = {
      'A': 'INTEGER',
      'B': 'TIMESTAMP',
    },
    timestampformat = '%m/%d/%Y %H:%M:%S',
    ignore_errors = true
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv(
    'data/csv/mixed_double.csv',
    auto_detect = false,
    header = true,
     columns = {
      'A': 'INTEGER',
      'B': 'FLOAT',
    },
    ignore_errors = true
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv(
    'data/csv/mixed_double.csv',
    auto_detect = false,
    header = true,
     columns = {
      'A': 'INTEGER',
      'B': 'DOUBLE',
    },
    ignore_errors = true
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv(
    'data/csv/mixed_double.csv',
    auto_detect = false,
    header = true,
     columns = {
      'A': 'INTEGER',
      'B': 'DECIMAL',
    },
    ignore_errors = true
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv(
    'data/csv/mixed_decimal.csv',
    auto_detect = false,
    header = true,
    delim = ';',
     columns = {
      'A': 'INTEGER',
      'B': 'DECIMAL',
    },
    ignore_errors = true
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv(
    'data/csv/mixed_decimal.csv',
    auto_detect = false,
    header = true,
    delim = ';',
    decimal_separator = ',',
     columns = {
      'A': 'INTEGER',
      'B': 'DECIMAL',
    },
    ignore_errors = true
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

FROM read_csv(
    'data/csv/mixed_decimal.csv',
    auto_detect = false,
    header = true,
    delim = '|',
    decimal_separator = ';',
     columns = {
      'A': 'INTEGER',
      'B': 'DECIMAL',
    },
    ignore_errors = true
);
-- bwc_tag:end_query

