-- bwc_tag:nb_steps=49
-- bwc_tag:execute_from_sql
-- bwc_tag:sort=row_sort
SELECT * FROM read_csv(
    'data/csv/error/mismatch/bad.csv',
    columns = {'col0': 'INTEGER', 'col1': 'INTEGER', 'col2': 'VARCHAR'},
    store_rejects = true, auto_detect=true);
-- bwc_tag:end_query

SELECT * EXCLUDE (scan_id) FROM reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:sort=row_sort
SELECT * FROM read_csv(
    'data/csv/error/mismatch/bad2.csv',
    columns = {'col0': 'INTEGER', 'col1': 'INTEGER', 'col2': 'INTEGER'},
    store_rejects = true, auto_detect=false);
-- bwc_tag:end_query

SELECT * EXCLUDE (scan_id) FROM reject_errors ORDER BY ALL;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:sort=row_sort
SELECT * FROM read_csv(
    'data/csv/error/mismatch/bad*.csv',
    columns = {'col0': 'INTEGER', 'col1': 'INTEGER', 'col2': 'VARCHAR'},
    store_rejects = true, auto_detect=false);
-- bwc_tag:end_query

SELECT * EXCLUDE (scan_id) FROM reject_errors ORDER BY ALL;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:sort=row_sort
SELECT * FROM read_csv(
    'data/csv/error/mismatch/bad*.csv',
    columns = {'col0': 'INTEGER', 'col1': 'INTEGER', 'col2': 'VARCHAR'},
    store_rejects = true,rejects_limit=2, ignore_errors=true, auto_detect=false);
-- bwc_tag:end_query

SELECT COUNT(*) FROM reject_errors
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT SUM(num) FROM read_csv(
    'data/csv/error/mismatch/big_bad.csv',
    columns = {'num': 'INTEGER', 'str': 'VARCHAR'},
    store_rejects = true, auto_detect=false);
-- bwc_tag:end_query

SELECT * EXCLUDE (scan_id) FROM reject_errors ORDER BY ALL;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT SUM(num) FROM read_csv(
    'data/csv/error/mismatch/big_bad2.csv',
    columns = {'num': 'INTEGER', 'str': 'VARCHAR'},
    store_rejects = true,  auto_detect=false)
-- bwc_tag:end_query

SELECT * EXCLUDE (scan_id) FROM reject_errors ORDER BY ALL;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT SUM(num) FROM read_csv(
    'data/csv/error/mismatch/big_*.csv',
    columns = {'num': 'INTEGER', 'str': 'VARCHAR'},
    store_rejects = true, auto_detect=false);
-- bwc_tag:end_query

SELECT * EXCLUDE (scan_id) FROM reject_errors ORDER BY ALL;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:sort=row_sort
SELECT *
FROM read_csv(
    'data/csv/error/mismatch/small1.csv',
    columns = {'num': 'INTEGER', 'str': 'VARCHAR'},
    store_rejects = true) as L
JOIN read_csv(
    'data/csv/error/mismatch/small2.csv',
    columns = {'num': 'INTEGER', 'str': 'VARCHAR'},
   store_rejects = true) as R
ON L.num = R.num;
-- bwc_tag:end_query

SELECT * EXCLUDE (scan_id, file_id) FROM reject_scans ORDER BY ALL;
-- bwc_tag:end_query

SELECT * EXCLUDE (scan_id, file_id) FROM reject_errors ORDER BY ALL;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:sort=row_sort
SELECT *
FROM read_csv(
    'data/csv/error/mismatch/small1.csv',
    columns = {'num': 'INTEGER', 'str': 'VARCHAR'},
    store_rejects = true) as L
JOIN read_csv(
    'data/csv/error/mismatch/small2.csv',
    columns = {'num': 'INTEGER', 'str': 'VARCHAR'},
    store_rejects = true, rejects_limit=1) as R
ON L.num = R.num;
-- bwc_tag:end_query

SELECT * EXCLUDE (scan_id, file_id) FROM reject_errors ORDER BY ALL;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:sort=row_sort
FROM read_csv('data/csv/rejects/dr_who.csv', columns={ 'date': 'DATE', 'datetime': 'TIMESTAMPTZ', 'time': 'TIME', 'timestamp': 'TIMESTAMP', 'time_tz': 'TIMETZ' }, store_rejects=true);
-- bwc_tag:end_query

SELECT * EXCLUDE (scan_id, file_id) FROM reject_errors ORDER BY column_name;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/comments/error.csv', store_rejects = true, comment = '#');
-- bwc_tag:end_query

SELECT * EXCLUDE (scan_id, file_id) FROM reject_errors ORDER BY column_name;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/error.csv', store_rejects=1, strict_mode=True);
-- bwc_tag:end_query

SELECT * EXCLUDE (scan_id, file_id) FROM reject_errors ORDER BY column_name;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

