-- bwc_tag:nb_steps=11
-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER, j INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY integers FROM 'data/csv/test/error_too_little_end_of_filled_chunk.csv' (HEADER, IGNORE_ERRORS, NULL_PADDING 0, AUTO_DETECT 0)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY integers FROM 'data/csv/test/error_too_little_end_of_filled_chunk.csv' (HEADER, NULL_PADDING 0, AUTO_DETECT 0)
-- bwc_tag:end_query

SELECT * FROM integers limit 1
-- bwc_tag:end_query

select count(*) from integers;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE integers;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER, j INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY integers FROM 'data/csv/test/error_too_little_end_of_filled_chunk.csv' (HEADER, IGNORE_ERRORS, NULL_PADDING 0)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY integers FROM 'data/csv/test/error_too_little_end_of_filled_chunk.csv' (HEADER, NULL_PADDING 0)
-- bwc_tag:end_query

SELECT * FROM integers limit 1
-- bwc_tag:end_query

select count(*) from integers;
-- bwc_tag:end_query

