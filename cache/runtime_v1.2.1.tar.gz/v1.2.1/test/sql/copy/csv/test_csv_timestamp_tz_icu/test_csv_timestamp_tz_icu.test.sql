-- bwc_tag:needed_extensions=icu
-- bwc_tag:nb_steps=6
-- bwc_tag:skip_query
pragma enable_verification
-- bwc_tag:end_query

LOAD 'icu';
-- bwc_tag:end_query

SET Calendar = 'gregorian';
-- bwc_tag:end_query

SET TimeZone = 'America/Los_Angeles';
-- bwc_tag:end_query

COPY (
    SELECT make_timestamptz(1713193669561000) AS t
) TO 'output/timestamp-format.csv' (FORMAT CSV, timestampformat '%x %X.%g%z');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select * from read_csv('output/timestamp-format.csv', all_varchar=true)
-- bwc_tag:end_query

