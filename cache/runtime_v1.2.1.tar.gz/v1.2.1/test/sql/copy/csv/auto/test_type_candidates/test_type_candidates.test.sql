-- bwc_tag:nb_steps=24
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table t (a integer, b double, c varchar)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into t values (1,1.1,'bla');
-- bwc_tag:end_query

COPY (SELECT * from t) TO 'output/csv_file.csv'  (FORMAT CSV, DELIMITER '|', HEADER 0);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv_auto ('output/csv_file.csv');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT typeof(column0), typeof(column1), typeof(column2) FROM read_csv_auto ('output/csv_file.csv');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv_auto ('output/csv_file.csv', auto_type_candidates=['BIGINT', 'DOUBLE', 'VARCHAR']);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT * FROM read_csv_auto ('output/csv_file.csv', auto_type_candidates=['MAP']);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT typeof(column0), typeof(column1), typeof(column2) FROM read_csv_auto ('output/csv_file.csv', auto_type_candidates=['BIGINT', 'DOUBLE', 'VARCHAR']);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv_auto ('output/csv_file.csv', auto_type_candidates=['VARCHAR'], header = 0);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT typeof(column0), typeof(column1), typeof(column2) FROM read_csv_auto ('output/csv_file.csv', auto_type_candidates=['VARCHAR'], header = 0);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv_auto ('output/csv_file.csv', auto_type_candidates=['BIGINT']);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT typeof(column0), typeof(column1), typeof(column2) FROM read_csv_auto ('output/csv_file.csv', auto_type_candidates=['BIGINT']);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv_auto ('output/csv_file.csv', auto_type_candidates=['BIGINT','VARCHAR']);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT typeof(column0), typeof(column1), typeof(column2) FROM read_csv_auto ('output/csv_file.csv', auto_type_candidates=['BIGINT','VARCHAR']);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv_auto ('output/csv_file.csv', auto_type_candidates=['FLOAT','VARCHAR']);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT typeof(column0), typeof(column1), typeof(column2) FROM read_csv_auto ('output/csv_file.csv', auto_type_candidates=['FLOAT','VARCHAR']);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv_auto ('output/csv_file.csv', auto_type_candidates=['SMALLINT','BIGINT', 'DOUBLE', 'FLOAT','VARCHAR']);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT typeof(column0), typeof(column1), typeof(column2) FROM read_csv_auto ('output/csv_file.csv', auto_type_candidates=['SMALLINT','BIGINT', 'DOUBLE', 'FLOAT','VARCHAR']);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv_auto ('output/csv_file.csv', auto_type_candidates=['SMALLINT','BIGINT', 'DOUBLE', 'FLOAT','VARCHAR','SMALLINT','BIGINT', 'DOUBLE', 'FLOAT','VARCHAR']);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT typeof(column0), typeof(column1), typeof(column2) FROM read_csv_auto ('output/csv_file.csv', auto_type_candidates=['SMALLINT','BIGINT', 'DOUBLE', 'FLOAT','VARCHAR','SMALLINT','BIGINT', 'DOUBLE', 'FLOAT','VARCHAR']);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT * FROM read_csv_auto ('output/csv_file.csv', auto_type_candidates=['USMALLINT', 'VARCHAR']);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT * FROM read_csv_auto ('output/csv_file.csv', auto_type_candidates=['bla', 'VARCHAR'])
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT * FROM read_csv_auto ('output/csv_file.csv', auto_type_candidates=[]);
-- bwc_tag:end_query

