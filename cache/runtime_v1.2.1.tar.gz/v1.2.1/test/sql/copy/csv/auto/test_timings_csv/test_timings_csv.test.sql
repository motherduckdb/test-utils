-- bwc_tag:nb_steps=4
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA verify_parallelism
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE timings(tool string, sf float, day string, batch_type string, q string, parameters string, time float);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY timings FROM 'data/csv/timings.csv' (HEADER, DELIMITER '|')
-- bwc_tag:end_query

