-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=5
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

COPY (SELECT 42 a) to 'output/lists.my_file_extension' (FORMAT PARQUET);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

FROM 'output/lists.my_file_extension';
-- bwc_tag:end_query

FROM read_parquet('output/lists.my_file_extension')
-- bwc_tag:end_query

