-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=17
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE int_maps(m MAP(INTEGER,INTEGER));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO int_maps VALUES 
	(MAP([42, 84], [1, 2])), 
	(MAP([101, 201, 301], [3, NULL, 5])),
	(MAP([55, 66, 77], [6, 7, NULL]))
;
-- bwc_tag:end_query

COPY int_maps TO 'output/int_map.parquet' (FORMAT PARQUET)
-- bwc_tag:end_query

SELECT * FROM 'output/int_map.parquet'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO int_maps VALUES
	(MAP([NULL], [NULL]))
;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

COPY string_map TO 'output/int_maps.parquet' (FORMAT PARQUET)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE string_map(m MAP(VARCHAR,VARCHAR));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO string_map VALUES 
	(MAP(['key1', 'key2'], ['value1', 'value2'])), 
	(MAP(['best band', 'best boyband', 'richest person'], ['Tenacious D', 'Backstreet Boys', 'Jon Lajoie'])),
	(MAP([], [])),
	(NULL),
	(MAP(['option'], [NULL]))
;
-- bwc_tag:end_query

COPY string_map TO 'output/string_map.parquet' (FORMAT PARQUET)
-- bwc_tag:end_query

SELECT * FROM 'output/string_map.parquet'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO string_map VALUES
	(MAP([NULL], [NULL]))
;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE list_map(m MAP(INT[],INT[]));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO list_map VALUES 
	(MAP([[1, 2, 3], [], [4, 5]], [[6, 7, 8], NULL, [NULL]])),
	(MAP([], [])),
	(MAP([[1]], [NULL])),
	(MAP([[10, 12, 14, 16, 18, 20], []], [[1], [2]]))
;
-- bwc_tag:end_query

COPY list_map TO 'output/list_map.parquet' (FORMAT PARQUET)
-- bwc_tag:end_query

SELECT * FROM 'output/list_map.parquet'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO list_map VALUES
	(MAP([NULL], [NULL]))
;
-- bwc_tag:end_query

