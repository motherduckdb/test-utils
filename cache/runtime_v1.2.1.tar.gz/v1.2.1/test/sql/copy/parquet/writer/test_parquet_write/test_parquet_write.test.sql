-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=9
LOAD 'parquet';
-- bwc_tag:end_query

COPY (SELECT 42) TO 'output/scalar.parquet' (FORMAT 'parquet');
-- bwc_tag:end_query

SELECT * FROM parquet_scan('output/scalar.parquet');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE empty(i INTEGER)
-- bwc_tag:end_query

COPY (SELECT * FROM empty) TO 'output/empty.parquet' (FORMAT 'parquet')
-- bwc_tag:end_query

SELECT COUNT(*) FROM parquet_scan('output/empty.parquet')
-- bwc_tag:end_query

-- bwc_tag:skip_query
SET threads=4;
-- bwc_tag:end_query

COPY (SELECT * FROM empty) TO 'output/empty_multithread' (FORMAT 'parquet', PER_THREAD_OUTPUT True)
-- bwc_tag:end_query

SELECT COUNT(*) FROM parquet_scan('output/empty_multithread/*.parquet')
-- bwc_tag:end_query

