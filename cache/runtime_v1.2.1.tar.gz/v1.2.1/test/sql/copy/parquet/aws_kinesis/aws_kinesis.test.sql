-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=4
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

SELECT * FROM 'data/parquet-testing/aws_kinesis.parquet'
-- bwc_tag:end_query

SELECT * FROM 'data/parquet-testing/aws_kinesis.parquet' WHERE event_timestamp=TIMESTAMP '2022-11-22 00:01:13.175';
-- bwc_tag:end_query

