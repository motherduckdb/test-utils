-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=2
LOAD 'parquet';
-- bwc_tag:end_query

SELECT * FROM 'data/parquet-testing/issue10279_delta_encoding.parquet'
-- bwc_tag:end_query

