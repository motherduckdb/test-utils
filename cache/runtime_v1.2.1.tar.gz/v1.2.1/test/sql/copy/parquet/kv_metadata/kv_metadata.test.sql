-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=10
LOAD 'parquet';
-- bwc_tag:end_query

COPY (SELECT 1, 'foo') TO  'output/kv_metadata_test.parquet' (FORMAT PARQUET, KV_METADATA {foo: 'bar', baz: 42, quz: '\xC3\xB6\xC3\xA4\xC3\xA5'::BLOB});
-- bwc_tag:end_query

SELECT key::VARCHAR, value::VARCHAR FROM parquet_kv_metadata('output/kv_metadata_test.parquet');
-- bwc_tag:end_query

SELECT * FROM 'output/kv_metadata_test.parquet'
-- bwc_tag:end_query

SELECT key::VARCHAR, decode(value) FROM parquet_kv_metadata('output/kv_metadata_test.parquet') WHERE key = 'quz';
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

COPY (SELECT 1, 'foo') TO  'output/kv_metadata_test_fail.parquet' (FORMAT PARQUET, KV_METADATA 'foobar');
-- bwc_tag:end_query

COPY (SELECT 3, 'baz') TO 'output/kv_metadata_test3.parquet' (FORMAT PARQUET);
-- bwc_tag:end_query

SELECT key::VARCHAR, value::VARCHAR FROM parquet_kv_metadata('output/kv_metadata_test3.parquet');
-- bwc_tag:end_query

COPY (SELECT 2, 'bar') TO  'output/kv_metadata_test2.parquet' (FORMAT PARQUET, KV_METADATA {a: 'b', c: 'd'});
-- bwc_tag:end_query

SELECT replace(replace(file_name, '\', '/'),replace('output/', '\', '/'), '') AS file_name, key::VARCHAR, value::VARCHAR FROM parquet_kv_metadata('output/kv_metadata_tes*') ORDER BY 1, 2;
-- bwc_tag:end_query

