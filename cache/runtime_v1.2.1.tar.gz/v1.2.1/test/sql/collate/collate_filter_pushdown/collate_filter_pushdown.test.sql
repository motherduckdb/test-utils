-- bwc_tag:nb_steps=6
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t0(c0 BOOLEAN, PRIMARY KEY(c0));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t63(c0 VARCHAR COLLATE C, PRIMARY KEY(c0));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into t0(c0) values (0.7);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into t63(c0) values ('1');
-- bwc_tag:end_query

SELECT t63.c0 FROM t0 NATURAL LEFT JOIN t63;
-- bwc_tag:end_query

