-- bwc_tag:nb_steps=4
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table tbl(id int, val varchar);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into tbl values (0, 'a'), (1, 'B');
-- bwc_tag:end_query

select list(id order by val collate nocase) from tbl;
-- bwc_tag:end_query

