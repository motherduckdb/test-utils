-- bwc_tag:nb_steps=8
-- bwc_tag:execute_from_sql
CREATE TABLE collate_test(s VARCHAR, t VARCHAR)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO collate_test VALUES ('mark', 'muhleisen')
-- bwc_tag:end_query

SELECT COUNT(*) FROM collate_test WHERE 'mórritz' BETWEEN s AND t
-- bwc_tag:end_query

SELECT COUNT(*) FROM collate_test WHERE 'mórritz' COLLATE NOACCENT BETWEEN s AND t
-- bwc_tag:end_query

SELECT COUNT(*) FROM collate_test WHERE 'mórritz' BETWEEN (s COLLATE NOACCENT) AND t
-- bwc_tag:end_query

SELECT COUNT(*) FROM collate_test WHERE 'mórritz' BETWEEN s AND (t COLLATE NOACCENT)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA default_collation='NOACCENT'
-- bwc_tag:end_query

SELECT COUNT(*) FROM collate_test WHERE 'mórritz' BETWEEN s AND t
-- bwc_tag:end_query

