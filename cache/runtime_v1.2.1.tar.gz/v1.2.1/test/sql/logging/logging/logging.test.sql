-- bwc_tag:nb_steps=11
from duckdb_logs
-- bwc_tag:end_query

set logging_level='debug';
-- bwc_tag:end_query

set enable_logging=true;
-- bwc_tag:end_query

SELECT 1;
-- bwc_tag:end_query

SELECT * EXCLUDE (timestamp, client_context, transaction_id) FROM duckdb_logs
-- bwc_tag:end_query

set enable_logging=false;
-- bwc_tag:end_query

SELECT * EXCLUDE (timestamp, client_context, transaction_id) FROM duckdb_logs
-- bwc_tag:end_query

set logging_storage='stdout';
-- bwc_tag:end_query

set logging_storage='memory';
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

set logging_storage='quack';
-- bwc_tag:end_query

SELECT * EXCLUDE (timestamp, client_context, transaction_id) FROM duckdb_logs
-- bwc_tag:end_query

