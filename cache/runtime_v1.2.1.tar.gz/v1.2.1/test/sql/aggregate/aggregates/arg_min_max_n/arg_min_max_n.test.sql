-- bwc_tag:nb_steps=26
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t1 (val VARCHAR, arg INT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES ('a', 2), ('a', 1), ('b', 5), ('b', 4), ('a', 3), ('b', 6);
-- bwc_tag:end_query

SELECT arg_max(val, arg, 3 ORDER BY val DESC) FROM t1;
-- bwc_tag:end_query

SELECT list(rs.val) FROM (SELECT val, arg, row_number() OVER (ORDER BY arg DESC) as rid FROM t1 ORDER BY val) as rs WHERE rid < 4;
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
SELECT arg_max(arg, val, 2 ORDER BY arg) FROM t1 GROUP BY val;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t2 AS SELECT i%5 as even_groups, i FROM range(10000) t(i);
-- bwc_tag:end_query

SELECT arg_max(even_groups, i, 3) FROM t2;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select min(arg, NULL) from t1;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT min(arg, -1) FROM t1;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select min(arg, 1000000) from t1;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select max(arg, NULL) from t1;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT max(arg, -1) FROM t1;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select max(arg, 1000000) from t1;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select arg_min(arg, val, NULL) from t1;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT arg_min(arg, val, -1) FROM t1;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select arg_min(arg, val, 1000000) from t1;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select arg_max(arg, val, NULL) from t1;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT arg_max(arg, val, -1) FROM t1;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select arg_max(arg, val, 1000000) from t1;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select min_by(arg, val, NULL) from t1;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT min_by(arg, val, -1) FROM t1;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select min_by(arg, val, 1000000) from t1;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select max_by(arg, val, NULL) from t1;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT max_by(arg, val, -1) FROM t1;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select max_by(arg, val, 1000000) from t1;
-- bwc_tag:end_query

