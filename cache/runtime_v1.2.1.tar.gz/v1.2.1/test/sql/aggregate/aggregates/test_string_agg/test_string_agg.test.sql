-- bwc_tag:nb_steps=35
SET default_null_order='nulls_first';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA verify_external
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT STRING_AGG()
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT STRING_AGG('a', 'b', 'c')
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT STRING_AGG(STRING_AGG('a',','))
-- bwc_tag:end_query

SELECT STRING_AGG('a',',')
-- bwc_tag:end_query

SELECT STRING_AGG('a',','), STRING_AGG(NULL,','), STRING_AGG('a', NULL), STRING_AGG(NULL,NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE strings(g INTEGER, x VARCHAR, y VARCHAR);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO strings VALUES (1,'a','/'), (1,'b','-'), (2,'i','/'), (2,NULL,'-'), (2,'j','+'), (3,'p','/'), (4,'x','/'), (4,'y','-'), (4,'z','+')
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT STRING_AGG(x,','), STRING_AGG(x,y) FROM strings
-- bwc_tag:end_query

SELECT g, STRING_AGG(x,'|') FROM strings GROUP BY g ORDER BY g
-- bwc_tag:end_query

SELECT STRING_AGG(x,',') FROM strings WHERE g > 100
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT STRING_AGG(1, 2)
-- bwc_tag:end_query

SELECT GROUP_CONCAT('a', ',')
-- bwc_tag:end_query

SELECT GROUP_CONCAT('a')
-- bwc_tag:end_query

SELECT g, GROUP_CONCAT(x) FROM strings GROUP BY g ORDER BY g
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA verify_parallelism
-- bwc_tag:end_query

SELECT STRING_AGG(x ORDER BY x ASC), STRING_AGG(x, '|' ORDER BY x ASC) FROM strings
-- bwc_tag:end_query

SELECT STRING_AGG(x ORDER BY x DESC), STRING_AGG(x,'|' ORDER BY x DESC) FROM strings
-- bwc_tag:end_query

SELECT g, STRING_AGG(x ORDER BY x ASC), STRING_AGG(x, '|' ORDER BY x ASC) FROM strings GROUP BY g ORDER BY 1
-- bwc_tag:end_query

SELECT g, STRING_AGG(x ORDER BY x DESC), STRING_AGG(x, '|' ORDER BY x DESC) FROM strings GROUP BY g ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT g, STRING_AGG(x, y ORDER BY x ASC) FROM strings GROUP BY g ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT g, STRING_AGG(x, y ORDER BY x DESC) FROM strings GROUP BY g ORDER BY 1
-- bwc_tag:end_query

SELECT STRING_AGG(g::VARCHAR, ',' ORDER BY CONCAT(x, y) ASC) FROM strings ORDER BY 1
-- bwc_tag:end_query

SELECT STRING_AGG(g::VARCHAR, ',' ORDER BY x, y) FROM strings ORDER BY 1
-- bwc_tag:end_query

SELECT STRING_AGG(x, ',' ORDER BY x DESC), STRING_AGG(x, ',' ORDER BY x ASC) FROM strings;
-- bwc_tag:end_query

SELECT y, STRING_AGG(x, ',' ORDER BY x DESC) FILTER (WHERE g < 3)
FROM strings
GROUP BY y
ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT g, STRING_AGG(DISTINCT y, ',' ORDER BY x DESC) FILTER (WHERE g < 4)
FROM strings
GROUP BY g
ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers (VALUES (1), (2), (3), (NULL));
-- bwc_tag:end_query

SELECT i1.i, (SELECT STRING_AGG(i::VARCHAR, ',' ORDER BY i1.i+i) FROM integers WHERE i<=i1.i) c1
FROM integers i1
ORDER BY 1 NULLS LAST
-- bwc_tag:end_query

SELECT string_agg(DISTINCT CellType, '&' ORDER BY list_position(['L900','L1800','L2100','L2600'], CellType))
FROM (VALUES 
	('L900'),
	('L2600'),
	('L2100'),
	('L2100'),
	('L1800')
	) AS t(CellType);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT first(DISTINCT i ORDER BY random() * i)
FROM (VALUES 
	(900),
	(2600),
	(2100),
	(2100),
	(1800)
	) AS t(i);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT first(DISTINCT random() * i ORDER BY i)
FROM (VALUES 
	(900),
	(2600),
	(2100),
	(2100),
	(1800)
	) AS t(i);
-- bwc_tag:end_query

