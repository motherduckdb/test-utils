-- bwc_tag:nb_steps=54
SET default_null_order='nulls_first';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW intlists AS SELECT * FROM (VALUES
	(21, [1]),
	(22, [NULL]),
	(23, []),
	(24, [2, 3]),
	(NULL::INTEGER, [13]),
	(32, [NULL]),
	(34, [2, 3])
	) lv(v, k);
-- bwc_tag:end_query

SELECT k, SUM(v) FROM intlists GROUP BY k ORDER BY 2
-- bwc_tag:end_query

SELECT k, LEAST(v, 21) as c, SUM(v) FROM intlists GROUP BY k, c ORDER BY 2, 3
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW strlists AS SELECT * FROM (VALUES
	(21, ['a']),
	(22, [NULL]),
	(23, []),
	(24, ['Branta Canadensis', 'c']),
	(NULL::INTEGER, ['Somateria mollissima']),
	(32, [NULL]),
	(34, ['Branta Canadensis', 'c'])
	) lv(v, k);
-- bwc_tag:end_query

SELECT k, SUM(v) FROM strlists GROUP BY k ORDER BY 2
-- bwc_tag:end_query

SELECT k, LEAST(v, 21) as c, SUM(v) FROM strlists GROUP BY k, c ORDER BY 2, 3
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW structs AS SELECT * FROM (VALUES
	(21, {'x': 1, 'y': 'a'}),
	(22, {'x': NULL, 'y': NULL}),
	(23, {'x': 0, 'y': ''}),
	(24, {'x': 2, 'y': 'c'}),
	(NULL::INTEGER, {'x': 13, 'y': 'Somateria mollissima'}),
	(32, {'x': NULL, 'y': NULL}),
	(34, {'x': 2, 'y': 'c'})
	) sv(v, k);
-- bwc_tag:end_query

SELECT k, SUM(v) FROM structs GROUP BY k ORDER BY 2
-- bwc_tag:end_query

SELECT k, LEAST(v, 21) as c, SUM(v) FROM structs GROUP BY k, c ORDER BY 2, 3
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW struct_lint_lstr AS SELECT * FROM (VALUES
	(21, {'x': [1], 'y': ['a']}),
	(22, {'x': [NULL], 'y': [NULL]}),
	(23, {'x': [], 'y': []}),
	(24, {'x': [2, 3], 'y': ['Branta Canadensis', 'c']}),
	(NULL::INTEGER, {'x': [13], 'y': ['Somateria mollissima']}),
	(32, {'x': [NULL], 'y': [NULL]}),
	(34, {'x': [2, 3], 'y': ['Branta Canadensis', 'c']})
	) sv(v, k);
-- bwc_tag:end_query

SELECT k, SUM(v) FROM struct_lint_lstr
GROUP BY k
ORDER BY 2
-- bwc_tag:end_query

SELECT k, LEAST(v, 21) as c, SUM(v) FROM struct_lint_lstr
GROUP BY k, c
ORDER BY 2, 3
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW r2l3r4l5i4i2l3v AS SELECT * FROM (VALUES
	(21, {'x': [{'l4': [51], 'i4': 41}], 'y': ['a']}),
	(22, {'x': [NULL], 'y': [NULL]}),
	(23, {'x': [], 'y': []}),
	(24, {'x': [{'l4': [52, 53], 'i4': 42}, {'l4': [54, 55], 'i4': 43}], 'y': ['Branta Canadensis', 'c']}),
	(NULL::INTEGER, {'x': [{'l4': [62], 'i4': 47}], 'y': ['Somateria mollissima']}),
	(32, {'x': [NULL], 'y': [NULL]}),
	(34, {'x': [{'l4': [52, 53], 'i4': 42}, {'l4': [54, 55], 'i4': 43}], 'y': ['Branta Canadensis', 'c']})
	) sv(v, k);
-- bwc_tag:end_query

SELECT k, SUM(v) FROM r2l3r4l5i4i2l3v
GROUP BY k
ORDER BY 2
-- bwc_tag:end_query

SELECT k, LEAST(v, 21) as c, SUM(v) FROM r2l3r4l5i4i2l3v
GROUP BY k, c
ORDER BY 2, 3
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW longlists AS
SELECT *
FROM ((VALUES
	(21, [1]),
	(22, [NULL]),
	(23, []),
	(NULL::INTEGER, [13]),
	(32, [NULL])
	)
UNION ALL
	select 24 as i, list(r) as pk from range(2000) tbl(r)
UNION ALL
	select 34 as i, list(r) as pk from range(2000) tbl(r)
) sv(v, k);
-- bwc_tag:end_query

SELECT k, SUM(v) FROM longlists
GROUP BY k
ORDER BY 2
-- bwc_tag:end_query

SELECT k, LEAST(v, 21) as c, SUM(v) FROM longlists
GROUP BY k, c
ORDER BY 2, 3
-- bwc_tag:end_query

select [1,2,3] a, count(*)
from range(5) tbl(b)
group by a;
-- bwc_tag:end_query

select {'x': 1, 'y': 2, 'z': 3} a, count(*)
from range(5) tbl(b)
group by a;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP VIEW intlists;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP VIEW strlists;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP VIEW structs;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP VIEW struct_lint_lstr;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP VIEW r2l3r4l5i4i2l3v;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP VIEW longlists;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE intlists AS SELECT * FROM (VALUES
	(21, [1]),
	(22, [NULL]),
	(23, []),
	(24, [2, 3]),
	(NULL::INTEGER, [13]),
	(32, [NULL]),
	(34, [2, 3])
	) lv(v, k);
-- bwc_tag:end_query

SELECT k, SUM(v) FROM intlists GROUP BY k ORDER BY 2
-- bwc_tag:end_query

SELECT k, LEAST(v, 21) as c, SUM(v) FROM intlists GROUP BY k, c ORDER BY 2, 3
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE strlists AS SELECT * FROM (VALUES
	(21, ['a']),
	(22, [NULL]),
	(23, []),
	(24, ['Branta Canadensis', 'c']),
	(NULL::INTEGER, ['Somateria mollissima']),
	(32, [NULL]),
	(34, ['Branta Canadensis', 'c'])
	) lv(v, k);
-- bwc_tag:end_query

SELECT k, SUM(v) FROM strlists GROUP BY k ORDER BY 2
-- bwc_tag:end_query

SELECT k, LEAST(v, 21) as c, SUM(v) FROM strlists GROUP BY k, c ORDER BY 2, 3
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE structs AS SELECT * FROM (VALUES
	(21, {'x': 1, 'y': 'a'}),
	(22, {'x': NULL, 'y': NULL}),
	(23, {'x': 0, 'y': ''}),
	(24, {'x': 2, 'y': 'c'}),
	(NULL::INTEGER, {'x': 13, 'y': 'Somateria mollissima'}),
	(32, {'x': NULL, 'y': NULL}),
	(34, {'x': 2, 'y': 'c'})
	) sv(v, k);
-- bwc_tag:end_query

SELECT k, SUM(v) FROM structs GROUP BY k ORDER BY 2
-- bwc_tag:end_query

SELECT k, LEAST(v, 21) as c, SUM(v) FROM structs GROUP BY k, c ORDER BY 2, 3
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE struct_lint_lstr AS SELECT * FROM (VALUES
	(21, {'x': [1], 'y': ['a']}),
	(22, {'x': [NULL], 'y': [NULL]}),
	(23, {'x': [], 'y': []}),
	(24, {'x': [2, 3], 'y': ['Branta Canadensis', 'c']}),
	(NULL::INTEGER, {'x': [13], 'y': ['Somateria mollissima']}),
	(32, {'x': [NULL], 'y': [NULL]}),
	(34, {'x': [2, 3], 'y': ['Branta Canadensis', 'c']})
	) sv(v, k);
-- bwc_tag:end_query

SELECT k, SUM(v) FROM struct_lint_lstr
GROUP BY k
ORDER BY 2
-- bwc_tag:end_query

SELECT k, LEAST(v, 21) as c, SUM(v) FROM struct_lint_lstr
GROUP BY k, c
ORDER BY 2, 3
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE r2l3r4l5i4i2l3v AS SELECT * FROM (VALUES
	(21, {'x': [{'l4': [51], 'i4': 41}], 'y': ['a']}),
	(22, {'x': [NULL], 'y': [NULL]}),
	(23, {'x': [], 'y': []}),
	(24, {'x': [{'l4': [52, 53], 'i4': 42}, {'l4': [54, 55], 'i4': 43}], 'y': ['Branta Canadensis', 'c']}),
	(NULL::INTEGER, {'x': [{'l4': [62], 'i4': 47}], 'y': ['Somateria mollissima']}),
	(32, {'x': [NULL], 'y': [NULL]}),
	(34, {'x': [{'l4': [52, 53], 'i4': 42}, {'l4': [54, 55], 'i4': 43}], 'y': ['Branta Canadensis', 'c']})
	) sv(v, k);
-- bwc_tag:end_query

SELECT k, SUM(v) FROM r2l3r4l5i4i2l3v
GROUP BY k
ORDER BY 2
-- bwc_tag:end_query

SELECT k, LEAST(v, 21) as c, SUM(v) FROM r2l3r4l5i4i2l3v
GROUP BY k, c
ORDER BY 2, 3
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE longlists AS
SELECT *
FROM ((VALUES
	(21, [1]),
	(22, [NULL]),
	(23, []),
	(NULL::INTEGER, [13]),
	(32, [NULL])
	)
UNION ALL
	select 24 as i, list(r) as pk from range(2000) tbl(r)
UNION ALL
	select 34 as i, list(r) as pk from range(2000) tbl(r)
) sv(v, k);
-- bwc_tag:end_query

SELECT k, SUM(v) FROM longlists
GROUP BY k
ORDER BY 2
-- bwc_tag:end_query

SELECT k, LEAST(v, 21) as c, SUM(v) FROM longlists
GROUP BY k, c
ORDER BY 2, 3
-- bwc_tag:end_query

select [1,2,3] a, count(*)
from range(5) tbl(b)
group by a;
-- bwc_tag:end_query

select {'x': 1, 'y': 2, 'z': 3} a, count(*)
from range(5) tbl(b)
group by a;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE intlists;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE strlists;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE structs;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE struct_lint_lstr;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE r2l3r4l5i4i2l3v;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE longlists;
-- bwc_tag:end_query

