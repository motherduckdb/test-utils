-- bwc_tag:nb_steps=17
SET default_null_order='nulls_first';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA verify_parallelism
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table students (
	course VARCHAR,
	type VARCHAR,
	value BIGINT
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into students
		(course, type, value)
	values
		('CS', 'Bachelor', 34),
		('CS', 'Bachelor', 34),
		('CS', 'PhD', 12),
		('Math', 'Masters', 12),
		('CS', NULL, 10),
		('CS', NULL, 12),
		('Math', NULL, 12),
		('Math', NULL, NULL);
-- bwc_tag:end_query

SELECT GROUPING(course), course, sum(distinct value), COUNT(*) FROM students GROUP BY course ORDER BY all;
-- bwc_tag:end_query

SELECT sum(distinct value), GROUPING_ID(course), course, COUNT(*) FROM students GROUP BY course ORDER BY all;
-- bwc_tag:end_query

SELECT GROUPING(course), GROUPING(type), course, type, sum(distinct value), COUNT(*), sum(distinct value), FROM students GROUP BY course, type ORDER BY all;
-- bwc_tag:end_query

SELECT GROUPING(course), GROUPING(type), avg(distinct value), course, type, COUNT(*), sum(distinct value), FROM students GROUP BY CUBE(course, type) ORDER BY all;
-- bwc_tag:end_query

SELECT sum(distinct value), GROUPING(course, type), course, type, COUNT(*), sum(distinct value), FROM students GROUP BY CUBE(course, type) ORDER BY all;
-- bwc_tag:end_query

SELECT GROUPING(course), GROUPING(type), sum(distinct value), GROUPING(course)+GROUPING(type), course, type, count(distinct value), COUNT(*) FROM students GROUP BY CUBE(course, type) ORDER BY all;
-- bwc_tag:end_query

SELECT GROUPING(course, type, course, course, type, value, type, course), avg(distinct value), avg(value), avg(distinct value), course, type, COUNT(*) FROM students GROUP BY CUBE(course, type, value) ORDER BY all;
-- bwc_tag:end_query

SELECT GROUPING(students.course), GROUPING(students.type), sum(distinct value), GROUPING(course)+GROUPING(type), course, avg(distinct value), type, COUNT(*) FROM students GROUP BY CUBE(course, type, value) ORDER BY all;
-- bwc_tag:end_query

SELECT GROUPING(course), GROUPING(type), avg(value), GROUPING(course)+GROUPING(type), avg(distinct value), course, type, COUNT(*) FROM students GROUP BY CUBE(students.course, students.type) ORDER BY all;
-- bwc_tag:end_query

SELECT GROUPING(course), GROUPING(value), course, sum(distinct value), COUNT(*) FROM students GROUP BY CUBE(course, value) HAVING GROUPING(course)=0 ORDER BY all;
-- bwc_tag:end_query

SELECT GROUPING(course), GROUPING(type), sum(distinct value), course, type, sum(distinct value), avg(distinct value), COUNT(*) FROM students GROUP BY CUBE(course, value, type, value) HAVING GROUPING(students.course)=0 ORDER BY all;
-- bwc_tag:end_query

SELECT type, COUNT(*), avg(value), sum(distinct value), avg(distinct value), FROM students GROUP BY CUBE(value, type) ORDER BY GROUPING(value), GROUPING(type), 1, 2, 3, 4, 5;
-- bwc_tag:end_query

