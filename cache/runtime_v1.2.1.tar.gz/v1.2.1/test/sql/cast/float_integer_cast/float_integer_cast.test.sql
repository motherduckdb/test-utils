-- bwc_tag:nb_steps=61
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

select cast(0.5::FLOAT as TINYINT) as x;
-- bwc_tag:end_query

select cast(0.55::FLOAT as TINYINT) as x;
-- bwc_tag:end_query

select cast(1.5::FLOAT as TINYINT) as x;
-- bwc_tag:end_query

select cast(-0.5::FLOAT as TINYINT) as x;
-- bwc_tag:end_query

select cast(-0.55::FLOAT as TINYINT) as x;
-- bwc_tag:end_query

select cast(-1.5::FLOAT as TINYINT) as x;
-- bwc_tag:end_query

select cast(0.5::FLOAT as SMALLINT) as x;
-- bwc_tag:end_query

select cast(0.55::FLOAT as SMALLINT) as x;
-- bwc_tag:end_query

select cast(1.5::FLOAT as SMALLINT) as x;
-- bwc_tag:end_query

select cast(-0.5::FLOAT as SMALLINT) as x;
-- bwc_tag:end_query

select cast(-0.55::FLOAT as SMALLINT) as x;
-- bwc_tag:end_query

select cast(-1.5::FLOAT as SMALLINT) as x;
-- bwc_tag:end_query

select cast(0.5::FLOAT as INTEGER) as x;
-- bwc_tag:end_query

select cast(0.55::FLOAT as INTEGER) as x;
-- bwc_tag:end_query

select cast(1.5::FLOAT as INTEGER) as x;
-- bwc_tag:end_query

select cast(-0.5::FLOAT as INTEGER) as x;
-- bwc_tag:end_query

select cast(-0.55::FLOAT as INTEGER) as x;
-- bwc_tag:end_query

select cast(-1.5::FLOAT as INTEGER) as x;
-- bwc_tag:end_query

select cast(0.5::FLOAT as BIGINT) as x;
-- bwc_tag:end_query

select cast(0.55::FLOAT as BIGINT) as x;
-- bwc_tag:end_query

select cast(1.5::FLOAT as BIGINT) as x;
-- bwc_tag:end_query

select cast(-0.5::FLOAT as BIGINT) as x;
-- bwc_tag:end_query

select cast(-0.55::FLOAT as BIGINT) as x;
-- bwc_tag:end_query

select cast(-1.5::FLOAT as BIGINT) as x;
-- bwc_tag:end_query

select cast(0.5::FLOAT as HUGEINT) as x;
-- bwc_tag:end_query

select cast(0.55::FLOAT as HUGEINT) as x;
-- bwc_tag:end_query

select cast(1.5::FLOAT as HUGEINT) as x;
-- bwc_tag:end_query

select cast(-0.5::FLOAT as HUGEINT) as x;
-- bwc_tag:end_query

select cast(-0.55::FLOAT as HUGEINT) as x;
-- bwc_tag:end_query

select cast(-1.5::FLOAT as HUGEINT) as x;
-- bwc_tag:end_query

select cast(0.5::DOUBLE as TINYINT) as x;
-- bwc_tag:end_query

select cast(0.55::DOUBLE as TINYINT) as x;
-- bwc_tag:end_query

select cast(1.5::DOUBLE as TINYINT) as x;
-- bwc_tag:end_query

select cast(-0.5::DOUBLE as TINYINT) as x;
-- bwc_tag:end_query

select cast(-0.55::DOUBLE as TINYINT) as x;
-- bwc_tag:end_query

select cast(-1.5::DOUBLE as TINYINT) as x;
-- bwc_tag:end_query

select cast(0.5::DOUBLE as SMALLINT) as x;
-- bwc_tag:end_query

select cast(0.55::DOUBLE as SMALLINT) as x;
-- bwc_tag:end_query

select cast(1.5::DOUBLE as SMALLINT) as x;
-- bwc_tag:end_query

select cast(-0.5::DOUBLE as SMALLINT) as x;
-- bwc_tag:end_query

select cast(-0.55::DOUBLE as SMALLINT) as x;
-- bwc_tag:end_query

select cast(-1.5::DOUBLE as SMALLINT) as x;
-- bwc_tag:end_query

select cast(0.5::DOUBLE as INTEGER) as x;
-- bwc_tag:end_query

select cast(0.55::DOUBLE as INTEGER) as x;
-- bwc_tag:end_query

select cast(1.5::DOUBLE as INTEGER) as x;
-- bwc_tag:end_query

select cast(-0.5::DOUBLE as INTEGER) as x;
-- bwc_tag:end_query

select cast(-0.55::DOUBLE as INTEGER) as x;
-- bwc_tag:end_query

select cast(-1.5::DOUBLE as INTEGER) as x;
-- bwc_tag:end_query

select cast(0.5::DOUBLE as BIGINT) as x;
-- bwc_tag:end_query

select cast(0.55::DOUBLE as BIGINT) as x;
-- bwc_tag:end_query

select cast(1.5::DOUBLE as BIGINT) as x;
-- bwc_tag:end_query

select cast(-0.5::DOUBLE as BIGINT) as x;
-- bwc_tag:end_query

select cast(-0.55::DOUBLE as BIGINT) as x;
-- bwc_tag:end_query

select cast(-1.5::DOUBLE as BIGINT) as x;
-- bwc_tag:end_query

select cast(0.5::DOUBLE as HUGEINT) as x;
-- bwc_tag:end_query

select cast(0.55::DOUBLE as HUGEINT) as x;
-- bwc_tag:end_query

select cast(1.5::DOUBLE as HUGEINT) as x;
-- bwc_tag:end_query

select cast(-0.5::DOUBLE as HUGEINT) as x;
-- bwc_tag:end_query

select cast(-0.55::DOUBLE as HUGEINT) as x;
-- bwc_tag:end_query

select cast(-1.5::DOUBLE as HUGEINT) as x;
-- bwc_tag:end_query

