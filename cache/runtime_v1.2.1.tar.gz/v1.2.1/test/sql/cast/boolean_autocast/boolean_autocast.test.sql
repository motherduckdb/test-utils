-- bwc_tag:nb_steps=28
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

SELECT true=1;
-- bwc_tag:end_query

SELECT true=0;
-- bwc_tag:end_query

SELECT false=0;
-- bwc_tag:end_query

SELECT false=1;
-- bwc_tag:end_query

SELECT 1=true;
-- bwc_tag:end_query

SELECT 0=true;
-- bwc_tag:end_query

SELECT 0=false;
-- bwc_tag:end_query

SELECT 1=false;
-- bwc_tag:end_query

SELECT true='1';
-- bwc_tag:end_query

SELECT true='1'::VARCHAR;
-- bwc_tag:end_query

SELECT true='0';
-- bwc_tag:end_query

SELECT false='0';
-- bwc_tag:end_query

SELECT false='1';
-- bwc_tag:end_query

SELECT true='true';
-- bwc_tag:end_query

SELECT true='false';
-- bwc_tag:end_query

SELECT false='false';
-- bwc_tag:end_query

SELECT false='true';
-- bwc_tag:end_query

SELECT '1'=true;
-- bwc_tag:end_query

SELECT '0'=true;
-- bwc_tag:end_query

SELECT '0'=false;
-- bwc_tag:end_query

SELECT '1'=false;
-- bwc_tag:end_query

SELECT true='true';
-- bwc_tag:end_query

SELECT true='false';
-- bwc_tag:end_query

SELECT false='false';
-- bwc_tag:end_query

SELECT false='true';
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT false='unknownbool';
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT 'unknownbool'=false;
-- bwc_tag:end_query

