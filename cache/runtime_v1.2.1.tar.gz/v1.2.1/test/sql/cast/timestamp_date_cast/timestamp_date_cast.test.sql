-- bwc_tag:nb_steps=8
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table test as
select '2021-02-04 19:30:00'::timestamp t;
-- bwc_tag:end_query

select *
from test
where (t::date) = '2021-02-04'::date;
-- bwc_tag:end_query

select *
from test
where (t::date) = '2021-02-04';
-- bwc_tag:end_query

WITH t AS (
    SELECT
        '2020-09-13 00:30:00'::TIMESTAMP AS a,
)
SELECT
    a::DATE = '2020-09-13'::DATE,
FROM t;
-- bwc_tag:end_query

WITH t AS (
    SELECT
        '2020-09-13 00:30:00'::TIMESTAMP_S AS a,
)
SELECT
    a::DATE = '2020-09-13'::DATE,
FROM t;
-- bwc_tag:end_query

WITH t AS (
    SELECT
        '2020-09-13 00:30:00'::TIMESTAMP_MS AS a,
)
SELECT
    a::DATE = '2020-09-13'::DATE,
FROM t;
-- bwc_tag:end_query

WITH t AS (
    SELECT
        '2020-09-13 00:30:00'::TIMESTAMP_NS AS a,
)
SELECT
    a::DATE = '2020-09-13'::DATE,
FROM t;
-- bwc_tag:end_query

