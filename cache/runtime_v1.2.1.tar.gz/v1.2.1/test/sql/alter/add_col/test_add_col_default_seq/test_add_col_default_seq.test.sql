-- bwc_tag:nb_steps=7
-- bwc_tag:execute_from_sql
CREATE TABLE test(i INTEGER, j INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (1, 1), (2, 2)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE seq
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test ADD COLUMN m INTEGER DEFAULT nextval('seq')
-- bwc_tag:end_query

SELECT * FROM test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test ADD COLUMN n INTEGER DEFAULT currval('seq')
-- bwc_tag:end_query

SELECT * FROM test
-- bwc_tag:end_query

