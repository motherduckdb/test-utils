-- bwc_tag:nb_steps=14
-- bwc_tag:skip_query
PRAGMA enable_verification;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test (i INTEGER, j INTEGER);
-- bwc_tag:end_query

-- bwc_tag:skip_query
BEGIN TRANSACTION
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (1, 1);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test ADD PRIMARY KEY (j);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (2, 1);
-- bwc_tag:end_query

-- bwc_tag:skip_query
-- bwc_tag:expected_result=error

COMMIT
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (1, 1), (2, 1), (2, NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE other (i INTEGER, j INTEGER);
-- bwc_tag:end_query

-- bwc_tag:skip_query
BEGIN TRANSACTION
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO other VALUES (1, 1), (2, 1);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE other ADD PRIMARY KEY (j);
-- bwc_tag:end_query

-- bwc_tag:skip_query
-- bwc_tag:expected_result=error

COMMIT
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (1, 1), (2, 1), (2, NULL);
-- bwc_tag:end_query

