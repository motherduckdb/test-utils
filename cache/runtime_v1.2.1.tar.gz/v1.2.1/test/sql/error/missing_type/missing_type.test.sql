-- bwc_tag:nb_steps=1
-- bwc_tag:expected_result=error

SELECT ''::blobb
-- bwc_tag:end_query

