-- bwc_tag:nb_steps=12
SET autoload_known_extensions=false;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT dbgen();
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT DBGEN();
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM dbgen();
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CALL dbgen(sf=0.1);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM dbgen
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SET TimeZone='UTC'
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM TimeZone
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT dbgen()
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

CALL dbge()
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SET TimeZon='UTC'
-- bwc_tag:end_query

SET TimeZone='UTC'
-- bwc_tag:end_query

