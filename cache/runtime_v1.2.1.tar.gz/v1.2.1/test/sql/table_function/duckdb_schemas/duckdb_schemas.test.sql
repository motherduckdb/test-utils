-- bwc_tag:nb_steps=4
SELECT COUNT(*) FROM duckdb_schemas;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA scheme;
-- bwc_tag:end_query

SELECT COUNT(*) FROM duckdb_schemas() WHERE schema_name='scheme';
-- bwc_tag:end_query

SELECT COUNT(*) FROM duckdb_schemas WHERE schema_name='scheme';
-- bwc_tag:end_query

