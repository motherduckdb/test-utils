-- bwc_tag:nb_steps=8
select * from range(4,15,6);
-- bwc_tag:end_query

select * from range(-4,-15,-6);
-- bwc_tag:end_query

select * from range(4,15);
-- bwc_tag:end_query

select * from range(4,15,3)a;
-- bwc_tag:end_query

select * from range(-4,-15,-3)a;
-- bwc_tag:end_query

select * from range(4,15,5)a;
-- bwc_tag:end_query

select * from range(4,19,5)a;
-- bwc_tag:end_query

select * from generate_series(4,19,5)a;
-- bwc_tag:end_query

