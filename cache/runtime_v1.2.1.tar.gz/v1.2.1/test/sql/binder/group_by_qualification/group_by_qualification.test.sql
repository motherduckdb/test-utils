-- bwc_tag:nb_steps=6
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA IF NOT EXISTS prd;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE prd.ad_stats_v(event_date DATE, app VARCHAR, country VARCHAR, platform VARCHAR);
-- bwc_tag:end_query

select event_date, country
FROM prd.ad_stats_v
GROUP by event_date, prd.ad_stats_v.country
order by country
-- bwc_tag:end_query

select event_date, ad_stats_v.country
FROM prd.ad_stats_v
GROUP by event_date, prd.ad_stats_v.country
order by ad_stats_v.country
-- bwc_tag:end_query

select event_date, prd.ad_stats_v.country
FROM prd.ad_stats_v
GROUP by event_date, prd.ad_stats_v.country;
-- bwc_tag:end_query

