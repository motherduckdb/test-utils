-- bwc_tag:nb_steps=6
SET default_null_order='nulls_first';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (1), (2), (3), (NULL)
-- bwc_tag:end_query

SELECT t.k FROM integers AS 't'('k') ORDER BY ALL
-- bwc_tag:end_query

SELECT t.k FROM integers t('k') ORDER BY ALL
-- bwc_tag:end_query

