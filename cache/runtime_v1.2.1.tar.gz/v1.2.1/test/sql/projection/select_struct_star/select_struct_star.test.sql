-- bwc_tag:nb_steps=10
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test(a STRUCT(i INT, j INT));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES ({i: 1, j: 2});
-- bwc_tag:end_query

SELECT a.* FROM test;
-- bwc_tag:end_query

SELECT a.* EXCLUDE(j) FROM test;
-- bwc_tag:end_query

SELECT a.* EXCLUDE(i) FROM test;
-- bwc_tag:end_query

SELECT a.* REPLACE(a.i + 3 AS i) FROM test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE a(i row(t int));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE b(i row(t int));
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT i.* FROM a, b;
-- bwc_tag:end_query

