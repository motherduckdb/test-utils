-- bwc_tag:nb_steps=5
-- bwc_tag:execute_from_sql
CREATE TABLE collate_test(s VARCHAR COLLATE NOACCENT.NOCASE)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO collate_test VALUES ('Mühleisen'), ('Hëllö')
-- bwc_tag:end_query

SELECT * FROM collate_test WHERE s='Muhleisen'
-- bwc_tag:end_query

SELECT * FROM collate_test WHERE s='muhleisen'
-- bwc_tag:end_query

SELECT * FROM collate_test WHERE s='hEllô'
-- bwc_tag:end_query

