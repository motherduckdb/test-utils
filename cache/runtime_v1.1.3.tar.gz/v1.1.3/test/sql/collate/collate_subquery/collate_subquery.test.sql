-- bwc_tag:nb_steps=5
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table t0(c1 varchar);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into t0 values ('XXX');
-- bwc_tag:end_query

select (select c1 from t0) collate nocase;
-- bwc_tag:end_query

select (select c1 from t0) collate nocase='xxx';
-- bwc_tag:end_query

