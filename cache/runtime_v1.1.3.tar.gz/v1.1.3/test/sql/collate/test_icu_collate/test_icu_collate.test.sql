-- bwc_tag:needed_extensions=icu
-- bwc_tag:nb_steps=29
LOAD 'icu';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE strings(s VARCHAR);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO strings VALUES ('Gabel'), ('Göbel'), ('Goethe'), ('Goldmann'), ('Göthe'), ('Götz');
-- bwc_tag:end_query

SELECT * FROM strings ORDER BY s COLLATE de;
-- bwc_tag:end_query

SELECT * FROM strings WHERE 'Goethe' > s COLLATE de ORDER BY 1
-- bwc_tag:end_query

SELECT * FROM strings WHERE 'Goethe' > s ORDER BY 1
-- bwc_tag:end_query

SELECT * FROM strings WHERE 'goethe' > s COLLATE de.NOCASE ORDER BY 1
-- bwc_tag:end_query

SELECT * FROM strings WHERE 'goethe' > s COLLATE NOCASE.de ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM strings WHERE 'goethe' > s COLLATE NOACCENT.de ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DELETE FROM strings
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO strings VALUES ('賃貸人側連絡先 (Lessor side contact)'), ('賃借人側連絡先 (Lessee side contact)'), ('解約連絡先 (Termination contacts)'), ('更新連絡先 (Update contact)')
-- bwc_tag:end_query

SELECT * FROM strings ORDER BY s
-- bwc_tag:end_query

SELECT * FROM strings ORDER BY s COLLATE ja.NOCASE
-- bwc_tag:end_query

select icu_sort_key('Ş', 'ro');
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT icu_sort_key('goose', 'DUCK_DUCK_ENUM');
-- bwc_tag:end_query

select icu_sort_key('æ', 'icu_noaccent');
-- bwc_tag:end_query

select icu_sort_key('Æ', 'icu_noaccent');
-- bwc_tag:end_query

select chr(2*16*256+1*256+2*16+11) collate da  =chr(12*16+5) collate da;
-- bwc_tag:end_query

select icu_sort_key(chr(2*16*256+1*256+2*16+11),'da')=icu_sort_key(chr(12*16+5),'da');
-- bwc_tag:end_query

select chr(2*16*256+1*256+2*16+11) collate da > chr(12*16+5) collate da;
-- bwc_tag:end_query

select chr(2*16*256+1*256+2*16+11) collate da > chr(12*16+5) collate da;
-- bwc_tag:end_query

select count(*) from (select chr(2*16*256+1*256+2*16+11) union select chr(12*16+5)) as t(s) group by s collate da;
-- bwc_tag:end_query

select nfc_normalize(chr(2*16*256+1*256+2*16+11))=nfc_normalize(chr(12*16+5));
-- bwc_tag:end_query

select count(*) from (select chr(2*16*256+1*256+2*16+11) union select chr(12*16+5)) as t(s) group by s collate nfc;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t1 (c1 CHAR(10))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES('z'),('Z'),('a'),('A'),('æ'),('Æ'),('à'),('À'),('á'),('Á'),('â'),('Â'),
('ã'),('Ã'),('ä'),('Ä'),('å'),('Å'),('b'),('B')
-- bwc_tag:end_query

SELECT GROUP_CONCAT(c1, '') as group_c1 FROM t1 GROUP BY c1  COLLATE "NOCASE.ICU_NOACCENT" ORDER BY group_c1 COLLATE "NOCASE.ICU_NOACCENT"
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT 'Á' COLLATE "ICU_NOACCENT.NOACCENT"
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT 'Á' COLLATE "NOACCENT.ICU_NOACCENT"
-- bwc_tag:end_query

