-- bwc_tag:fixtures=german_collation.db
-- bwc_tag:nb_steps=5
SET autoload_known_extensions=false;
-- bwc_tag:end_query

ATTACH 'output/german_collation.db' AS db
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
SELECT * FROM db.strings
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM db.strings ORDER BY 1
-- bwc_tag:end_query

SELECT * FROM db.strings ORDER BY 1
-- bwc_tag:end_query

