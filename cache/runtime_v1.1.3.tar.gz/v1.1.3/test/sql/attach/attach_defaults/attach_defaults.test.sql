-- bwc_tag:nb_steps=4
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

ATTACH DATABASE ':memory:' AS new_database;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

ATTACH ':memory:' AS new_database;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

ATTACH ':memory:'
-- bwc_tag:end_query

