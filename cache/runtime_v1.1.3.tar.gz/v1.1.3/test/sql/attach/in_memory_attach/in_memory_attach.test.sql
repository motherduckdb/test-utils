-- bwc_tag:nb_steps=11
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

ATTACH DATABASE ':memory:' AS new_database;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE new_database.integers(i INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO new_database.integers VALUES (42);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO new_database.main.integers VALUES (84);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM integers
-- bwc_tag:end_query

SELECT * FROM new_database.integers ORDER BY i
-- bwc_tag:end_query

SELECT * FROM new_database.main.integers ORDER BY i
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM new_database.integers ORDER BY new_database.i
-- bwc_tag:end_query

SELECT * FROM new_database.integers ORDER BY new_database.integers.i
-- bwc_tag:end_query

SELECT * FROM new_database.main.integers ORDER BY new_database.main.integers.i
-- bwc_tag:end_query

