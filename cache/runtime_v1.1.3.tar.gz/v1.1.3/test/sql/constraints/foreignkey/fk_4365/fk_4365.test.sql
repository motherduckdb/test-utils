-- bwc_tag:nb_steps=3
-- bwc_tag:execute_from_sql
create table x (c1 integer, primary key (c1));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table y (c1 integer, foreign key (c1) references x (c1));
-- bwc_tag:end_query

select count(*) from duckdb_constraints() where constraint_type = 'NOT NULL';
-- bwc_tag:end_query

