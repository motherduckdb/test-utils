-- bwc_tag:nb_steps=12
-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER NOT NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (3)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO integers VALUES (NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
UPDATE integers SET i=4
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

UPDATE integers SET i=NULL
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers_with_null(i INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers_with_null VALUES (3), (4), (5), (NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO integers (i) SELECT * FROM integers_with_null
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers (i) SELECT * FROM integers_with_null WHERE i IS NOT NULL
-- bwc_tag:end_query

SELECT * FROM integers ORDER BY i
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
UPDATE integers SET i=4 WHERE i>4
-- bwc_tag:end_query

SELECT * FROM integers ORDER BY i
-- bwc_tag:end_query

