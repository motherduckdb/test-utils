-- bwc_tag:nb_steps=16
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER, grp INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (1, NULL), (2, 3), (3, 2), (NULL, 1);
-- bwc_tag:end_query

SELECT FIRST(i ORDER BY grp NULLS LAST) FROM integers
-- bwc_tag:end_query

SELECT FIRST(i ORDER BY grp NULLS FIRST) FROM integers
-- bwc_tag:end_query

SELECT ANY_VALUE(i ORDER BY grp NULLS FIRST) FROM integers
-- bwc_tag:end_query

SELECT ANY_VALUE(i ORDER BY grp NULLS LAST) FROM integers
-- bwc_tag:end_query

SELECT ARG_MIN(i, grp) FROM integers
-- bwc_tag:end_query

SELECT FIRST(i ORDER BY grp DESC NULLS LAST) FROM integers
-- bwc_tag:end_query

SELECT ANY_VALUE(i ORDER BY grp DESC NULLS FIRST) FROM integers
-- bwc_tag:end_query

SELECT ANY_VALUE(i ORDER BY grp DESC NULLS LAST) FROM integers
-- bwc_tag:end_query

SELECT ARG_MAX(i, grp) FROM integers
-- bwc_tag:end_query

SELECT LAST(i ORDER BY grp NULLS FIRST) FROM integers
-- bwc_tag:end_query

SELECT ARG_MAX(i, grp) FROM integers
-- bwc_tag:end_query

SELECT LAST(i ORDER BY grp DESC NULLS FIRST) FROM integers
-- bwc_tag:end_query

SELECT ARG_MIN(i, grp) FROM integers
-- bwc_tag:end_query

