-- bwc_tag:nb_steps=26
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA verify_external
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tbl(
	"DATE" DATE,
	"TIMESTAMP" TIMESTAMP,
	"INTEGER" INTEGER,
	"BIGINT" BIGINT,
	"DOUBLE" DOUBLE,
	"VARCHAR" VARCHAR);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO tbl
	SELECT
		DATE '1992-01-02' + INTERVAL ((RANDOM() * 300)::INT) DAYS d,
		TIMESTAMP '1992-01-02 23:20:11' + INTERVAL ((RANDOM() * 300)::INT) DAYS + INTERVAL ((RANDOM() * 60 * 60)::INT) SECONDS ts,
		50 + (RANDOM() * 6000)::INT i,
		10 + (RANDOM() * 899999999)::BIGINT bi,
		1 + RANDOM() * 99 dbl,
		concat(chr(98 + (RANDOM() * 24)::INT), chr(98 + (RANDOM() * 24)::INT), chr(98 + (RANDOM() * 24)::INT), chr(98 + (RANDOM() * 24)::INT), repeat(chr(98 + (RANDOM() * 24)::INT), 29)) str
	FROM
		range(10000);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO tbl VALUES (
	DATE '1992-01-01',
	TIMESTAMP '1992-01-01 23:20:11',
	42,
	0,
	0.5,
	'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'
)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO tbl VALUES (
	DATE '1993-01-01',
	TIMESTAMP '1993-01-01 23:20:11',
	8400,
	999999999,
	100.5,
	'zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz'
)
-- bwc_tag:end_query

SELECT arg_min("VARCHAR", "DATE") FROM tbl
-- bwc_tag:end_query

SELECT arg_min("DATE", "VARCHAR") FROM tbl EXCEPT SELECT MIN("DATE") FROM tbl
-- bwc_tag:end_query

SELECT arg_max("VARCHAR", "DATE") FROM tbl
-- bwc_tag:end_query

SELECT arg_max("DATE", "VARCHAR") FROM tbl EXCEPT SELECT MAX("DATE") FROM tbl
-- bwc_tag:end_query

SELECT arg_min("VARCHAR", "TIMESTAMP") FROM tbl
-- bwc_tag:end_query

SELECT arg_min("TIMESTAMP", "VARCHAR") FROM tbl EXCEPT SELECT MIN("TIMESTAMP") FROM tbl
-- bwc_tag:end_query

SELECT arg_max("VARCHAR", "TIMESTAMP") FROM tbl
-- bwc_tag:end_query

SELECT arg_max("TIMESTAMP", "VARCHAR") FROM tbl EXCEPT SELECT MAX("TIMESTAMP") FROM tbl
-- bwc_tag:end_query

SELECT arg_min("VARCHAR", "INTEGER") FROM tbl
-- bwc_tag:end_query

SELECT arg_min("INTEGER", "VARCHAR") FROM tbl EXCEPT SELECT MIN("INTEGER") FROM tbl
-- bwc_tag:end_query

SELECT arg_max("VARCHAR", "INTEGER") FROM tbl
-- bwc_tag:end_query

SELECT arg_max("INTEGER", "VARCHAR") FROM tbl EXCEPT SELECT MAX("INTEGER") FROM tbl
-- bwc_tag:end_query

SELECT arg_min("VARCHAR", "BIGINT") FROM tbl
-- bwc_tag:end_query

SELECT arg_min("BIGINT", "VARCHAR") FROM tbl EXCEPT SELECT MIN("BIGINT") FROM tbl
-- bwc_tag:end_query

SELECT arg_max("VARCHAR", "BIGINT") FROM tbl
-- bwc_tag:end_query

SELECT arg_max("BIGINT", "VARCHAR") FROM tbl EXCEPT SELECT MAX("BIGINT") FROM tbl
-- bwc_tag:end_query

SELECT arg_min("VARCHAR", "VARCHAR") FROM tbl
-- bwc_tag:end_query

SELECT arg_min("VARCHAR", "VARCHAR") FROM tbl EXCEPT SELECT MIN("VARCHAR") FROM tbl
-- bwc_tag:end_query

SELECT arg_max("VARCHAR", "VARCHAR") FROM tbl
-- bwc_tag:end_query

SELECT arg_max("VARCHAR", "VARCHAR") FROM tbl EXCEPT SELECT MAX("VARCHAR") FROM tbl
-- bwc_tag:end_query

