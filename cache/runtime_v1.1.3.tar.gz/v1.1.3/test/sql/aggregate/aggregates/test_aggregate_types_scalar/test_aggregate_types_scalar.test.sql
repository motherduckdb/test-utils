-- bwc_tag:nb_steps=34
SELECT COUNT(), COUNT(1), COUNT(*), COUNT(NULL), COUNT('hello'), COUNT(DATE '1992-02-02')
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT COUNT(1, 2)
-- bwc_tag:end_query

SELECT SUM(1), SUM(NULL), SUM(33.3)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT SUM(True)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT SUM('hello')
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT SUM(DATE '1992-02-02')
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT SUM()
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT SUM(1, 2)
-- bwc_tag:end_query

SELECT MIN(1), MIN(NULL), MIN(33.3), MIN('hello'), MIN(True), MIN(DATE '1992-02-02'), MIN(TIMESTAMP '2008-01-01 00:00:01')
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT MIN()
-- bwc_tag:end_query

SELECT MIN(1, 2)
-- bwc_tag:end_query

SELECT MAX(1), MAX(NULL), MAX(33.3), MAX('hello'), MAX(True), MAX(DATE '1992-02-02'), MAX(TIMESTAMP '2008-01-01 00:00:01')
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT MAX()
-- bwc_tag:end_query

SELECT MAX(1, 2)
-- bwc_tag:end_query

SELECT FIRST(1), FIRST(NULL), FIRST(33.3), FIRST('hello'), FIRST(True), FIRST(DATE '1992-02-02'), FIRST(TIMESTAMP '2008-01-01 00:00:01')
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT FIRST()
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT FIRST(1, 2)
-- bwc_tag:end_query

SELECT LAST(1), LAST(NULL), LAST(33.3), LAST('hello'), LAST(True), LAST(DATE '1992-02-02'), LAST(TIMESTAMP '2008-01-01 00:00:01')
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT LAST()
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT LAST(1, 2)
-- bwc_tag:end_query

SELECT AVG(1), AVG(NULL), AVG(33.3)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT AVG(True)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT AVG('hello')
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT AVG(DATE '1992-02-02')
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT AVG()
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT AVG(1, 2)
-- bwc_tag:end_query

SELECT STRING_AGG('hello')
-- bwc_tag:end_query

SELECT STRING_AGG('hello', ' '), STRING_AGG('hello', NULL), STRING_AGG(NULL, ' '), STRING_AGG(NULL, NULL), STRING_AGG('', '')
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT STRING_AGG()
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT STRING_AGG(1, 2, 3)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test_val(val INT)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test_val VALUES(1), (2), (3), (3), (2)
-- bwc_tag:end_query

SELECT STRING_AGG(DISTINCT val::VARCHAR ORDER BY val::VARCHAR DESC) from test_val;
-- bwc_tag:end_query

SELECT COUNT(NULL), STRING_AGG(DISTINCT val::VARCHAR ORDER BY val::VARCHAR ASC) from test_val;
-- bwc_tag:end_query

