-- bwc_tag:nb_steps=11
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers AS SELECT i%5 as even_groups, log(1 + i*i)::int as skewed_groups  FROM range(10000) t(i);
-- bwc_tag:end_query

SELECT list_sort(approx_top_k(even_groups, 10)) FROM integers
-- bwc_tag:end_query

SELECT approx_top_k(skewed_groups, 5) FROM integers
-- bwc_tag:end_query

SELECT approx_top_k(concat('this is a long prefix', skewed_groups::VARCHAR), 5) FROM integers
-- bwc_tag:end_query

SELECT approx_top_k([skewed_groups], 5) FROM integers
-- bwc_tag:end_query

SELECT approx_top_k({'i': skewed_groups}, 5) FROM integers
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select approx_top_k(i, 0) from range(5) t(i)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select approx_top_k(i, -1) from range(5) t(i)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select approx_top_k(i, 999999999999999) from range(5) t(i)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select approx_top_k(i, NULL) from range(5) t(i)
-- bwc_tag:end_query

