-- bwc_tag:nb_steps=17
-- bwc_tag:expected_result=error

SELECT COUNT(1, 2, 3)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT COUNT(COUNT(1))
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT STDDEV_SAMP()
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT STDDEV_SAMP(1, 2, 3)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT STDDEV_SAMP(STDDEV_SAMP(1))
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT SUM()
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT SUM(1, 2, 3)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT SUM(SUM(1))
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT FIRST()
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT FIRST(1, 2, 3)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT FIRST(FIRST(1))
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT MAX()
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT MAX(1, 2, 3)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT MAX(MAX(1))
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT MIN()
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT MIN(1, 2, 3)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT MIN(MIN(1))
-- bwc_tag:end_query

