-- bwc_tag:nb_steps=32
SET default_null_order='nulls_first';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA verify_external
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table quantiles as select range r, random() FROM range(0,1000000,100) union all values (NULL, 0.25), (NULL, 0.5), (NULL, 0.75) order by 2;
-- bwc_tag:end_query

SELECT quantile_cont('2021-01-01'::TIMESTAMP + interval (r/100) hour, [0.25, 0.5, 0.75]) FROM quantiles
-- bwc_tag:end_query

SELECT quantile_cont('1990-01-01'::DATE + interval (r/100) day, [0.25, 0.5, 0.75]) FROM quantiles
-- bwc_tag:end_query

SELECT quantile_cont('00:00:00'::TIME + interval (r/100) second, [0.25, 0.5, 0.75]) FROM quantiles
-- bwc_tag:end_query

SELECT quantile_cont(('2021-01-01'::TIMESTAMP + interval (r/100) hour)::TIMESTAMPTZ, [0.25, 0.5, 0.75])
FROM quantiles
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT quantile_cont(interval (r/100) second, [0.25, 0.5, 0.75]) FROM quantiles
-- bwc_tag:end_query

SELECT quantile_cont(r, [0.25, 0.5, 0.75]) FROM quantiles
-- bwc_tag:end_query

SELECT quantile_cont(d::decimal(4,1), [0.25, 0.5, 0.75])
FROM range(0,100) tbl(d)
-- bwc_tag:end_query

SELECT quantile_cont(d::decimal(8,1), [0.25, 0.5, 0.75])
FROM range(0,100) tbl(d)
-- bwc_tag:end_query

SELECT quantile_cont(d::decimal(12,1), [0.25, 0.5, 0.75])
FROM range(0,100) tbl(d)
-- bwc_tag:end_query

SELECT quantile_cont(d::decimal(18,1), [0.25, 0.5, 0.75])
FROM range(0,100) tbl(d)
-- bwc_tag:end_query

SELECT quantile_cont(d::decimal(24,1), [0.25, 0.5, 0.75])
FROM range(0,100) tbl(d)
-- bwc_tag:end_query

SELECT mod(r,1000) as g, quantile_cont(r, [0.25, 0.5, 0.75]) FROM quantiles GROUP BY 1 ORDER BY 1
-- bwc_tag:end_query

SELECT quantile_cont(1, [0.25, 0.5, 0.75]) FROM quantiles
-- bwc_tag:end_query

SELECT quantile_cont(r, [0.25, 0.5, 0.75]) FROM quantiles WHERE 1=0
-- bwc_tag:end_query

SELECT quantile_cont(r, []) FROM quantiles
-- bwc_tag:end_query

-- bwc_tag:skip_query
pragma threads=4
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA verify_parallelism
-- bwc_tag:end_query

SELECT quantile_cont(r, [0.25, 0.5, 0.75]) FROM quantiles
-- bwc_tag:end_query

SELECT mod(r,1000) as g, quantile_cont(r, [0.25, 0.5, 0.75]) FROM quantiles GROUP BY 1 ORDER BY 1
-- bwc_tag:end_query

SELECT quantile_cont(1, [0.25, 0.5, 0.75]) FROM quantiles
-- bwc_tag:end_query

SELECT quantile_cont(r, [0.25, 0.5, 0.75]) FROM quantiles WHERE 1=0
-- bwc_tag:end_query

SELECT quantile_cont(r, []) FROM quantiles
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT quantile_cont(r, [-0.25, 0.5, 0.75]) FROM quantiles
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT quantile_cont(r, (0.25, 0.5, 1.1)) FROM quantiles
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT quantile_cont(r, [0.25, 0.5, NULL]) FROM quantiles
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT quantile_cont(r, ["0.25", "0.5", "0.75"]) FROM quantiles
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT quantile_cont(r::string, [0.25, 0.5, 0.75]) FROM quantiles
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT quantile_cont(r, [0.25, 0.5, 0.75], 50) FROM quantiles
-- bwc_tag:end_query

