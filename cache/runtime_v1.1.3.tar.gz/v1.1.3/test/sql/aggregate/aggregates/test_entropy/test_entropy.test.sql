-- bwc_tag:nb_steps=16
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA verify_external
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select entropy()
-- bwc_tag:end_query

select entropy(NULL)
-- bwc_tag:end_query

select entropy(1)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select entropy(*)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table aggr(k int);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into aggr values (0),(1),(1),(1),(4),(0),(3),(3),(2),(2),(4),(4),(2),(4),(0),(0),(0),(1),(2),(3),(4),(2),(3),(3),(1);
-- bwc_tag:end_query

select entropy(k) from aggr ;
-- bwc_tag:end_query

SELECT entropy(2) FROM range(100);
-- bwc_tag:end_query

select entropy(k) from aggr group by k%2 order by all
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table names (name string)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into names values ('pedro'), ('pedro'), ('pedro'),('hannes'),('hannes'),('mark'),(null);
-- bwc_tag:end_query

select entropy(name) from names;
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
select entropy(k) over (partition by k%2)
    from aggr;
-- bwc_tag:end_query

SELECT entropy(i) FROM range(100) tbl(i) WHERE 1=0;
-- bwc_tag:end_query

