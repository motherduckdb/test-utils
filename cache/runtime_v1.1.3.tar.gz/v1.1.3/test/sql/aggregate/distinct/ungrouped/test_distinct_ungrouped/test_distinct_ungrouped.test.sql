-- bwc_tag:nb_steps=19
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA verify_external
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table tbl as
	(select i%50 as i, i%100 as j from range(50000) tbl(i))
;
-- bwc_tag:end_query

select
	count(distinct i)
from tbl;
-- bwc_tag:end_query

select
	sum(distinct i),
	sum(i),
	sum(j)
from tbl;
-- bwc_tag:end_query

select
	sum(i),
	sum(j),
	sum(distinct i)
from tbl;
-- bwc_tag:end_query

select
	sum(i),
	sum(distinct i),
	sum(j)
from tbl;
-- bwc_tag:end_query

select
	sum(distinct i),
	count(j),
	sum(distinct j)
from tbl;
-- bwc_tag:end_query

select
	sum(j),
	sum(distinct i),
	count(j),
	sum(distinct j)
from tbl;
-- bwc_tag:end_query

select
	sum(j),
	sum(distinct i),
	count(j),
	sum(distinct j)
from tbl;
-- bwc_tag:end_query

select
	sum(distinct i),
	count(j),
	sum(distinct j),
	sum(j)
from tbl;
-- bwc_tag:end_query

select
	count(distinct i) FILTER (WHERE i >= 20)
from tbl;
-- bwc_tag:end_query

select
	sum(distinct i),
	sum(i) FILTER (WHERE j < 20),
	sum(j) FILTER (WHERE i >= 20)
from tbl;
-- bwc_tag:end_query

select
	sum(i),
	sum(j) FILTER (WHERE j == 0),
	sum(distinct i) FILTER (WHERE i == 0)
from tbl;
-- bwc_tag:end_query

select
	sum(i) FILTER (WHERE j == 5),
	sum(distinct i),
	sum(j) FILTER (WHERE i == 5)
from tbl;
-- bwc_tag:end_query

select
	sum(distinct i) FILTER (WHERE i == 5),
	count(j),
	sum(distinct j) FILTER (WHERE i == 5)
from tbl;
-- bwc_tag:end_query

select
	sum(j) FILTER (WHERE j == 5),
	sum(distinct i) FILTER (WHERE j == 5),
	count(j),
	sum(distinct j)
from tbl;
-- bwc_tag:end_query

select
	sum(j) FILTER (WHERE i == 5),
	sum(distinct i),
	count(j),
	sum(distinct j) FILTER (WHERE j == 5)
from tbl;
-- bwc_tag:end_query

select
	sum(distinct i),
	count(j),
	sum(distinct j) FILTER (WHERE j == 5),
	sum(j) FILTER (WHERE j == 5)
from tbl;
-- bwc_tag:end_query

