-- bwc_tag:nb_steps=3
-- bwc_tag:execute_from_sql
create table test (id int, provider int, record_key int, record_rank int, record_date int)
-- bwc_tag:end_query

explain select record_key from (
    select distinct on (id, provider) id, provider, record_key from test order by id, provider, record_rank desc, record_date
)
-- bwc_tag:end_query

explain select distinct on (id, provider) record_key from test order by id, provider, record_rank desc, record_date
-- bwc_tag:end_query

