-- bwc_tag:needed_extensions=httpfs;parquet
-- bwc_tag:nb_steps=3
LOAD 'httpfs';
-- bwc_tag:end_query

LOAD 'parquet';
-- bwc_tag:end_query

FROM 'https://github.com/cwida/duckdb-data/releases/download/v1.0/us+er+da+ta.parquet' LIMIT 1;
-- bwc_tag:end_query

