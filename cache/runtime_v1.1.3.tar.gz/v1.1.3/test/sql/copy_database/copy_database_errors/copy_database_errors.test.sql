-- bwc_tag:nb_steps=13
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

ATTACH DATABASE ':memory:' AS db1;
-- bwc_tag:end_query

ATTACH DATABASE ':memory:' AS db2;
-- bwc_tag:end_query

COPY FROM DATABASE db1 TO db2
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE db1.test(a INTEGER, b INTEGER, c VARCHAR);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO db1.test VALUES (42, 84, 'hello')
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

COPY FROM DATABASE db1 TO db1
-- bwc_tag:end_query

ATTACH DATABASE 'output/read_only.db' AS read_only
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE read_only.t(i INT);
-- bwc_tag:end_query

DETACH read_only
-- bwc_tag:end_query

ATTACH DATABASE 'output/read_only.db' AS read_only (READ_ONLY)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

COPY FROM DATABASE db1 TO read_only
-- bwc_tag:end_query

COPY FROM DATABASE read_only TO db1
-- bwc_tag:end_query

