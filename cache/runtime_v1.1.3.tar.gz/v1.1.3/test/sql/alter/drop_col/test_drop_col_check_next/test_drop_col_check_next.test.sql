-- bwc_tag:nb_steps=7
-- bwc_tag:execute_from_sql
CREATE TABLE test(i INTEGER, j INTEGER CHECK(j < 10))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (1, 1), (2, 2)
-- bwc_tag:end_query

SELECT * FROM test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test DROP COLUMN i
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO test VALUES (20)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (3)
-- bwc_tag:end_query

SELECT * FROM test
-- bwc_tag:end_query

