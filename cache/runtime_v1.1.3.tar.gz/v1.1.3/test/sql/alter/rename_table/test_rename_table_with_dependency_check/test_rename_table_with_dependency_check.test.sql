-- bwc_tag:nb_steps=7
-- bwc_tag:execute_from_sql
CREATE TABLE t0 (c0 INT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE UNIQUE INDEX i1 ON t0 (c0);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE t0 RENAME TO t3;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t3 (c0 INT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE t0 RENAME TO t4;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE t0;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

ANALYZE t4;
-- bwc_tag:end_query

