-- bwc_tag:nb_steps=6
-- bwc_tag:execute_from_sql
CREATE TABLE test(i INTEGER, j INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (1, 1), (2, 2)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE test ADD COLUMN i INTEGER
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW x(x) AS (SELECT 1)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER VIEW x ADD COLUMN i INTEGER
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE i ADD COLUMN j INT, ADD COLUMN k INT
-- bwc_tag:end_query

