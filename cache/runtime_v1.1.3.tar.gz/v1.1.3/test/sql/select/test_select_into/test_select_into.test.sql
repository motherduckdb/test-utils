-- bwc_tag:nb_steps=3
-- bwc_tag:execute_from_sql
CREATE TABLE t (t TEXT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t VALUES ('foo'), ('bar'), ('baz');
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * INTO t2 FROM t WHERE t LIKE 'b%';
-- bwc_tag:end_query

