-- bwc_tag:nb_steps=6
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA s1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE s1.tbl(i INTEGER)
-- bwc_tag:end_query

SELECT s1.tbl.i FROM s1.tbl;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT s2.tbl.i FROM s1.tbl;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT a.tbl.i FROM range(10) tbl(i)
-- bwc_tag:end_query

