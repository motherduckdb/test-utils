-- bwc_tag:nb_steps=42
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test (a INTEGER, b INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test (b) VALUES (3);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (DEFAULT, DEFAULT);
-- bwc_tag:end_query

SELECT * FROM test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test (a INTEGER NOT NULL, b INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO test (b) VALUES (3);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test (a INTEGER DEFAULT 1, b INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test (b) VALUES (3);
-- bwc_tag:end_query

SELECT * FROM test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test (a INTEGER DEFAULT 1+1, b INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test (b) VALUES (3);
-- bwc_tag:end_query

SELECT * FROM test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test (a INTEGER DEFAULT 1+1, b INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test (b) SELECT 3
-- bwc_tag:end_query

SELECT * FROM test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE seq;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test (a INTEGER DEFAULT nextval('seq'), b INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test (b) VALUES (2), (4), (6), (2), (4);
-- bwc_tag:end_query

SELECT * FROM test ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DROP SEQUENCE seq
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP SEQUENCE seq
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE seq;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test (a INTEGER DEFAULT nextval('seq'), b INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test (b) VALUES (1);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
UPDATE test SET a=DEFAULT
-- bwc_tag:end_query

SELECT * FROM test ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE TABLE test (a INTEGER DEFAULT (SELECT 42), b INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE TABLE test (a INTEGER DEFAULT SUM(42), b INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE TABLE test (a INTEGER DEFAULT row_number() OVER (), b INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE TABLE test (a INTEGER DEFAULT b+1, b INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test (a DOUBLE DEFAULT random(), b INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test (b) VALUES (1);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test (b) VALUES (2);
-- bwc_tag:end_query

SELECT COUNT(DISTINCT a) FROM test;
-- bwc_tag:end_query

