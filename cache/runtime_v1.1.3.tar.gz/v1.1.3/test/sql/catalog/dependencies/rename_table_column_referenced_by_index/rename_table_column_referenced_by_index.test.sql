-- bwc_tag:nb_steps=4
-- bwc_tag:skip_query
pragma enable_verification;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table tbl(a varchar);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create index idx on tbl(a);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

alter table tbl rename a to b;
-- bwc_tag:end_query

