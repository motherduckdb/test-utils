-- bwc_tag:nb_steps=6
-- bwc_tag:skip_query
pragma enable_verification;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table tbl (a varchar);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create view vw as select * from tbl;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create macro static_table() as table select * from vw;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
alter view vw rename to vw2;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select * from static_table();
-- bwc_tag:end_query

