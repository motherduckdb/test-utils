-- bwc_tag:nb_steps=3
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create schema """cursed_schema";
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop schema """cursed_schema";
-- bwc_tag:end_query

