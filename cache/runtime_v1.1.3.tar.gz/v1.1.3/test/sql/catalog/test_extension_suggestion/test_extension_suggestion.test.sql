-- bwc_tag:nb_steps=2
SET autoload_known_extensions=false;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT get_substrait("select 1");
-- bwc_tag:end_query

