-- bwc_tag:nb_steps=6
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:skip_query
BEGIN TRANSACTION
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tbl(
    d DATE DEFAULT CURRENT_DATE,
    t TIME DEFAULT CURRENT_TIME,
    ts TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    cur_user VARCHAR DEFAULT CURRENT_USER,
    "user" VARCHAR DEFAULT USER,
    sess_user VARCHAR DEFAULT SESSION_USER,
    cur_catalog VARCHAR DEFAULT CURRENT_CATALOG,
    cur_schema VARCHAR DEFAULT CURRENT_SCHEMA
);
-- bwc_tag:end_query

EXPORT DATABASE 'output/export_special_functions' (FORMAT CSV)
-- bwc_tag:end_query

-- bwc_tag:skip_query
ROLLBACK
-- bwc_tag:end_query

IMPORT DATABASE 'output/export_special_functions'
-- bwc_tag:end_query

