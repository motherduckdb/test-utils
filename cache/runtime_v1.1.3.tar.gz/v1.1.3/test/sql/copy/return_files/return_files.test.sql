-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=11
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers AS SELECT range i FROM range(200000);
-- bwc_tag:end_query

SET preserve_insertion_order=false;
-- bwc_tag:end_query

COPY integers TO 'output/test_copy_to_file.parquet' (RETURN_FILES);
-- bwc_tag:end_query

SET preserve_insertion_order=true;
-- bwc_tag:end_query

COPY integers TO 'output/test_batch_copy_to_file.parquet' (RETURN_FILES TRUE);
-- bwc_tag:end_query

-- bwc_tag:skip_query
SET threads=2;
-- bwc_tag:end_query

COPY integers TO 'output/test_per_thread_output' (RETURN_FILES, PER_THREAD_OUTPUT);
-- bwc_tag:end_query

-- bwc_tag:skip_query
SET threads=1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers2 AS SELECT range i, range % 4 j FROM range(200000);
-- bwc_tag:end_query

COPY integers2 TO 'output/test_partition_by' (RETURN_FILES TRUE, PARTITION_BY j);
-- bwc_tag:end_query

