-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=15
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA verify_parallelism;
-- bwc_tag:end_query

-- bwc_tag:skip_query
pragma threads=4;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE bigdata AS SELECT i AS col_a, i AS col_b FROM range(0,10000) tbl(i);
-- bwc_tag:end_query

COPY (FROM bigdata UNION ALL FROM bigdata) TO 'output/per_thread_output' (FORMAT PARQUET, PER_THREAD_OUTPUT TRUE);
-- bwc_tag:end_query

SELECT COUNT(*) FROM PARQUET_SCAN('output/per_thread_output/*.parquet')
-- bwc_tag:end_query

SELECT COUNT(*) > 1 f FROM GLOB('output/per_thread_output/data_*.parquet') ORDER BY f
-- bwc_tag:end_query

COPY (FROM bigdata UNION ALL FROM bigdata) TO 'output/per_thread_output_csv' (FORMAT CSV,  PER_THREAD_OUTPUT TRUE);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT COUNT(*) FROM read_csv('output/per_thread_output_csv/*.csv', columns={'col_a': 'INT', 'col_b' : 'INT'});
-- bwc_tag:end_query

SELECT COUNT(*) > 2 f FROM GLOB('output/per_thread_output_csv/data_*.csv') ORDER BY f
-- bwc_tag:end_query

COPY (FROM bigdata) TO 'output/per_thread_output2/' (FORMAT PARQUET, PER_THREAD_OUTPUT TRUE);
-- bwc_tag:end_query

SELECT COUNT(*) FROM PARQUET_SCAN('output/per_thread_output2/*.parquet')
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

COPY (FROM bigdata) TO 'output/per_thread_output2/' (FORMAT PARQUET, PER_THREAD_OUTPUT TRUE);
-- bwc_tag:end_query

SELECT COUNT(*) FROM PARQUET_SCAN('output/per_thread_output2/*.parquet')
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

COPY (FROM bigdata) TO 'output/per_thread_output3' (FORMAT PARQUET, PER_THREAD_OUTPUT TRUE, USE_TMP_FILE TRUE);
-- bwc_tag:end_query

