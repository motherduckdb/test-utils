-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=42
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test as SELECT i%2 as part_col, (i+1)%5 as value_col, i as value2_col from range(0,10) tbl(i);
-- bwc_tag:end_query

COPY test TO 'output/no-part-cols' (FORMAT PARQUET, PARTITION_BY (part_col));
-- bwc_tag:end_query

SELECT part_col, value_col, value2_col FROM 'output/no-part-cols/part_col=0/*.parquet' ORDER BY value2_col;
-- bwc_tag:end_query

COPY test TO 'output/no-part-cols2' (FORMAT PARQUET, PARTITION_BY (part_col, value_col));
-- bwc_tag:end_query

SELECT part_col, value_col, value2_col FROM 'output/no-part-cols2/part_col=0/value_col=*/*.parquet' ORDER BY value2_col;
-- bwc_tag:end_query

COPY (SELECT * EXCLUDE (part_col), 'prefix-'::VARCHAR || part_col::VARCHAR as part_col FROM test) TO 'output/no-part-cols3' (FORMAT PARQUET, PARTITION_BY (part_col));
-- bwc_tag:end_query

SELECT part_col, value_col, value2_col FROM 'output/no-part-cols3/part_col=prefix-0/*.parquet' ORDER BY value2_col;
-- bwc_tag:end_query

COPY (SELECT 1 AS part_col, 2 AS value_col, 3 AS value2_col, 4 AS value3_col, 5 AS value4_col, 6 AS value5_col, 7 AS value6_col, 8 AS value7_col, 9 AS value8_col, 10 AS value9_col) TO 'output/no-part-cols4' (FORMAT PARQUET, PARTITION_BY (part_col));
-- bwc_tag:end_query

SELECT part_col, value_col, value2_col, value3_col, value4_col, value5_col, value6_col, value7_col, value8_col, value9_col FROM 'output/no-part-cols4/part_col=1/*.parquet' ORDER BY 1;
-- bwc_tag:end_query

COPY (SELECT 1 AS part_col, 2 AS value_col, 3 AS value2_col, 4 AS value3_col, 5 AS value4_col, 6 AS value5_col, 7 AS value6_col, 8 AS value7_col, 9 AS value8_col, 10 AS value9_col) TO 'output/no-part-cols5' (FORMAT PARQUET, PARTITION_BY (value9_col));
-- bwc_tag:end_query

SELECT part_col, value_col, value2_col, value3_col, value4_col, value5_col, value6_col, value7_col, value8_col, value9_col FROM 'output/no-part-cols5/value9_col=*/*.parquet' ORDER BY 1;
-- bwc_tag:end_query

COPY (SELECT 1 AS part_col, 2 AS value_col, 3 AS value2_col, 4 AS value3_col, 5 AS value4_col, 6 AS value5_col, 7 AS value6_col, 8 AS value7_col, 9 AS value8_col, 10 AS value9_col) TO 'output/no-part-cols6' (FORMAT PARQUET, PARTITION_BY (value8_col, value9_col));
-- bwc_tag:end_query

SELECT part_col, value_col, value2_col, value3_col, value4_col, value5_col, value6_col, value7_col, value8_col, value9_col FROM 'output/no-part-cols6/value8_col=*/value9_col=*/*.parquet' ORDER BY 1;
-- bwc_tag:end_query

COPY (SELECT 1 AS part_col, 2 AS value_col, 3 AS value2_col, 4 AS value3_col, 5 AS value4_col, 6 AS value5_col, 7 AS value6_col, 8 AS value7_col, 9 AS value8_col, 10 AS value9_col) TO 'output/no-part-cols7' (FORMAT PARQUET, PARTITION_BY (value9_col, value8_col, value7_col));
-- bwc_tag:end_query

SELECT part_col, value_col, value2_col, value3_col, value4_col, value5_col, value6_col, value7_col, value8_col, value9_col FROM 'output/no-part-cols7/value9_col=*/value8_col=*/value7_col=*/*.parquet' ORDER BY 1;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

COPY test TO 'output/no-part-cols8' (FORMAT PARQUET, PARTITION_BY (part_col, value_col, value2_col));
-- bwc_tag:end_query

COPY test TO 'output/no-part-cols8' (FORMAT PARQUET, OVERWRITE, PARTITION_BY (part_col, value_col, value2_col), WRITE_PARTITION_COLUMNS);
-- bwc_tag:end_query

SELECT part_col, value_col, value2_col FROM 'output/no-part-cols8/part_col=0/value_col=*/value2_col=*/*.parquet' ORDER BY value2_col;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

COPY test TO 'output/no-part-cols9' (FORMAT PARQUET, PARTITION_BY '*');
-- bwc_tag:end_query

COPY test TO 'output/no-part-cols9' (FORMAT PARQUET, PARTITION_BY '*', OVERWRITE, WRITE_PARTITION_COLUMNS);
-- bwc_tag:end_query

SELECT part_col, value_col, value2_col FROM 'output/no-part-cols9/part_col=0/value_col=*/value2_col=*/*.parquet' ORDER BY value2_col;
-- bwc_tag:end_query

COPY test TO 'output/csv-no-part-cols' (FORMAT CSV, PARTITION_BY (part_col));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT part_col, value_col, value2_col FROM 'output/csv-no-part-cols/part_col=0/*.csv' ORDER BY value2_col;
-- bwc_tag:end_query

COPY test TO 'output/csv-no-part-cols2' (FORMAT CSV, PARTITION_BY (part_col, value_col));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT part_col, value_col, value2_col FROM 'output/csv-no-part-cols2/part_col=0/value_col=*/*.csv' ORDER BY value2_col;
-- bwc_tag:end_query

COPY (SELECT * EXCLUDE (part_col), 'prefix-'::VARCHAR || part_col::VARCHAR as part_col FROM test) TO 'output/csv-no-part-cols3' (FORMAT CSV, PARTITION_BY (part_col));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT part_col, value_col, value2_col FROM 'output/csv-no-part-cols3/part_col=prefix-0/*.csv' ORDER BY value2_col;
-- bwc_tag:end_query

COPY (SELECT 1 AS part_col, 2 AS value_col, 3 AS value2_col, 4 AS value3_col, 5 AS value4_col, 6 AS value5_col, 7 AS value6_col, 8 AS value7_col, 9 AS value8_col, 10 AS value9_col) TO 'output/csv-no-part-cols4' (FORMAT CSV, PARTITION_BY (part_col));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT part_col, value_col, value2_col, value3_col, value4_col, value5_col, value6_col, value7_col, value8_col, value9_col FROM 'output/csv-no-part-cols4/part_col=1/*.csv' ORDER BY 1;
-- bwc_tag:end_query

COPY (SELECT 1 AS part_col, 2 AS value_col, 3 AS value2_col, 4 AS value3_col, 5 AS value4_col, 6 AS value5_col, 7 AS value6_col, 8 AS value7_col, 9 AS value8_col, 10 AS value9_col) TO 'output/csv-no-part-cols5' (FORMAT CSV, PARTITION_BY (value9_col));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT part_col, value_col, value2_col, value3_col, value4_col, value5_col, value6_col, value7_col, value8_col, value9_col FROM 'output/csv-no-part-cols5/value9_col=*/*.csv' ORDER BY 1;
-- bwc_tag:end_query

COPY (SELECT 1 AS part_col, 2 AS value_col, 3 AS value2_col, 4 AS value3_col, 5 AS value4_col, 6 AS value5_col, 7 AS value6_col, 8 AS value7_col, 9 AS value8_col, 10 AS value9_col) TO 'output/csv-no-part-cols6' (FORMAT CSV, PARTITION_BY (value8_col, value9_col));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT part_col, value_col, value2_col, value3_col, value4_col, value5_col, value6_col, value7_col, value8_col, value9_col FROM 'output/csv-no-part-cols6/value8_col=*/value9_col=*/*.csv' ORDER BY 1;
-- bwc_tag:end_query

COPY (SELECT 1 AS part_col, 2 AS value_col, 3 AS value2_col, 4 AS value3_col, 5 AS value4_col, 6 AS value5_col, 7 AS value6_col, 8 AS value7_col, 9 AS value8_col, 10 AS value9_col) TO 'output/csv-no-part-cols7' (FORMAT CSV, PARTITION_BY (value9_col, value8_col, value7_col));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT part_col, value_col, value2_col, value3_col, value4_col, value5_col, value6_col, value7_col, value8_col, value9_col FROM 'output/csv-no-part-cols7/value9_col=*/value8_col=*/value7_col=*/*.csv' ORDER BY 1;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

COPY test TO 'output/csv-no-part-cols8' (FORMAT CSV, PARTITION_BY (part_col, value_col, value2_col));
-- bwc_tag:end_query

COPY test TO 'output/csv-no-part-cols8' (FORMAT CSV, PARTITION_BY (part_col, value_col, value2_col), OVERWRITE, WRITE_PARTITION_COLUMNS);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT part_col, value_col, value2_col FROM 'output/csv-no-part-cols8/part_col=0/value_col=*/value2_col=*/*.csv' ORDER BY value2_col;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

COPY test TO 'output/csv-no-part-cols9' (FORMAT CSV, PARTITION_BY '*');
-- bwc_tag:end_query

COPY test TO 'output/csv-no-part-cols9' (FORMAT CSV, PARTITION_BY '*', OVERWRITE, WRITE_PARTITION_COLUMNS);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT part_col, value_col, value2_col FROM 'output/csv-no-part-cols9/part_col=0/value_col=*/value2_col=*/*.csv' ORDER BY value2_col;
-- bwc_tag:end_query

