-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=5
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:skip_query
SET threads=1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test_5209 AS FROM range(10000);
-- bwc_tag:end_query

COPY test_5209 TO 'output/test_5209.parquet' (ROW_GROUP_SIZE 1000);
-- bwc_tag:end_query

SELECT SUM(total_compressed_size) > 10000, SUM(total_uncompressed_size) > 10000, SUM(total_uncompressed_size) > SUM(total_compressed_size)
FROM parquet_metadata('output/test_5209.parquet');
-- bwc_tag:end_query

