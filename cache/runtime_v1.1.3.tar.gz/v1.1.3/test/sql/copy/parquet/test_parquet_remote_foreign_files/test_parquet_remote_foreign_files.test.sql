-- bwc_tag:needed_extensions=httpfs;parquet
-- bwc_tag:nb_steps=15
LOAD 'parquet';
-- bwc_tag:end_query

LOAD 'httpfs';
-- bwc_tag:end_query

SELECT COUNT(backlink_count) FROM parquet_scan('https://raw.githubusercontent.com/duckdb/duckdb/main/data/parquet-testing/bug1554.parquet') WHERE http_status_code=200
-- bwc_tag:end_query

SELECT http_status_code, COUNT(backlink_count) FROM parquet_scan('https://raw.githubusercontent.com/duckdb/duckdb/main/data/parquet-testing/bug1554.parquet') GROUP BY http_status_code ORDER BY http_status_code
-- bwc_tag:end_query

SELECT has_image_link FROM parquet_scan('https://raw.githubusercontent.com/duckdb/duckdb/main/data/parquet-testing/bug1588.parquet') where has_image_link = 1
-- bwc_tag:end_query

SELECT backlink_count FROM parquet_scan('https://raw.githubusercontent.com/duckdb/duckdb/main/data/parquet-testing/bug1589.parquet') LIMIT 1
-- bwc_tag:end_query

SELECT * FROM parquet_scan('https://raw.githubusercontent.com/duckdb/duckdb/main/data/parquet-testing/bug1589.parquet')
-- bwc_tag:end_query

SELECT "inner"['str_field'] FROM parquet_scan('https://raw.githubusercontent.com/duckdb/duckdb/main/data/parquet-testing/bug1618_struct_strings.parquet')
-- bwc_tag:end_query

SELECT "inner"['f64_field'] FROM parquet_scan('https://raw.githubusercontent.com/duckdb/duckdb/main/data/parquet-testing/bug1618_struct_strings.parquet')
-- bwc_tag:end_query

SELECT "inner" FROM parquet_scan('https://raw.githubusercontent.com/duckdb/duckdb/main/data/parquet-testing/bug1618_struct_strings.parquet')
-- bwc_tag:end_query

select "inner"['f64_field'] from parquet_scan('https://raw.githubusercontent.com/duckdb/duckdb/main/data/parquet-testing/struct.parquet');
-- bwc_tag:end_query

SELECT * FROM parquet_scan('https://raw.githubusercontent.com/duckdb/duckdb/main/data/parquet-testing/bug2267.parquet')
-- bwc_tag:end_query

SELECT assignedLicenses[1] FROM parquet_scan('https://raw.githubusercontent.com/duckdb/duckdb/main/data/parquet-testing/bug2267.parquet')
-- bwc_tag:end_query

select * from parquet_scan(['https://raw.githubusercontent.com/duckdb/duckdb/main/data/parquet-testing/glob/t1.parquet', 'https://raw.githubusercontent.com/duckdb/duckdb/main/data/parquet-testing/glob/t2.parquet'])
-- bwc_tag:end_query

select * from parquet_scan('https://raw.githubusercontent.com/duckdb/duckdb/main/data/parquet-testing/arrow/nation.dict-malformed.parquet') limit 2;
-- bwc_tag:end_query

