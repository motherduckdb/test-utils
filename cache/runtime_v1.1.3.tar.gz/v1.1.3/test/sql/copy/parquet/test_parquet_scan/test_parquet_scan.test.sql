-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=41
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM parquet_scan('does_not_exist')
-- bwc_tag:end_query

SELECT * FROM parquet_scan('data/parquet-testing/arrow/alltypes_plain.parquet')
-- bwc_tag:end_query

SELECT * FROM "data/parquet-testing/arrow/alltypes_plain.parquet"
-- bwc_tag:end_query

SELECT tbl.* FROM "data/parquet-testing/arrow/alltypes_plain.parquet" tbl
-- bwc_tag:end_query

SELECT tbl.a FROM "data/parquet-testing/arrow/alltypes_plain.parquet" tbl(a)
-- bwc_tag:end_query

SELECT * FROM parquet_scan('data/parquet-testing/unsigned.parquet')
-- bwc_tag:end_query

SELECT * FROM parquet_scan('data/parquet-testing/arrow/alltypes_plain.snappy.parquet')
-- bwc_tag:end_query

SELECT * FROM parquet_scan('data/parquet-testing/arrow/alltypes_dictionary.parquet')
-- bwc_tag:end_query

SELECT * FROM parquet_scan('data/parquet-testing/data-types.parquet')
-- bwc_tag:end_query

SELECT COUNT(*) FROM  parquet_scan('data/parquet-testing/userdata1.parquet')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW userdata1 AS SELECT * FROM parquet_scan('data/parquet-testing/userdata1.parquet')
-- bwc_tag:end_query

SELECT COUNT(*) FROM userdata1
-- bwc_tag:end_query

SELECT COUNT(registration_dttm), COUNT(id), COUNT(first_name), COUNT(last_name), COUNT(email), COUNT(gender), COUNT(ip_address), COUNT(cc), COUNT(country), COUNT(birthdate), COUNT(salary), COUNT(title), COUNT(comments) FROM userdata1
-- bwc_tag:end_query

SELECT MIN(registration_dttm), MAX(registration_dttm) FROM userdata1
-- bwc_tag:end_query

SELECT MIN(id), MAX(id) FROM userdata1
-- bwc_tag:end_query

SELECT FIRST(id) OVER w, LAST(id) OVER w FROM userdata1 WINDOW w AS (ORDER BY id RANGE BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) LIMIT 1
-- bwc_tag:end_query

SELECT MIN(first_name), MAX(first_name) FROM userdata1
-- bwc_tag:end_query

SELECT FIRST(first_name) OVER w, LAST(first_name) OVER w FROM userdata1 WINDOW w AS (ORDER BY id RANGE BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) LIMIT 1
-- bwc_tag:end_query

SELECT MIN(last_name), MAX(last_name) FROM userdata1
-- bwc_tag:end_query

SELECT FIRST(last_name) OVER w, LAST(last_name) OVER w FROM userdata1 WINDOW w AS (ORDER BY id RANGE BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) LIMIT 1
-- bwc_tag:end_query

SELECT MIN(email), MAX(email) FROM userdata1
-- bwc_tag:end_query

SELECT FIRST(email) OVER w, LAST(email) OVER w FROM userdata1 WINDOW w AS (ORDER BY id RANGE BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) LIMIT 1
-- bwc_tag:end_query

SELECT MIN(gender), MAX(gender) FROM userdata1
-- bwc_tag:end_query

SELECT FIRST(gender) OVER w, LAST(gender) OVER w FROM userdata1 WINDOW w AS (ORDER BY id RANGE BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) LIMIT 1
-- bwc_tag:end_query

SELECT MIN(ip_address), MAX(ip_address) FROM userdata1
-- bwc_tag:end_query

SELECT FIRST(ip_address) OVER w, LAST(ip_address) OVER w FROM userdata1 WINDOW w AS (ORDER BY id RANGE BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) LIMIT 1
-- bwc_tag:end_query

SELECT MIN(cc), MAX(cc) FROM userdata1
-- bwc_tag:end_query

SELECT FIRST(cc) OVER w, LAST(cc) OVER w FROM userdata1 WINDOW w AS (ORDER BY id RANGE BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) LIMIT 1
-- bwc_tag:end_query

SELECT MIN(country), MAX(country) FROM userdata1
-- bwc_tag:end_query

SELECT FIRST(country) OVER w, LAST(country) OVER w FROM userdata1 WINDOW w AS (ORDER BY id RANGE BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) LIMIT 1
-- bwc_tag:end_query

SELECT MIN(birthdate), MAX(birthdate) FROM userdata1
-- bwc_tag:end_query

SELECT FIRST(birthdate) OVER w, LAST(birthdate) OVER w FROM userdata1 WINDOW w AS (ORDER BY id RANGE BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) LIMIT 1
-- bwc_tag:end_query

SELECT MIN(salary), MAX(salary) FROM userdata1
-- bwc_tag:end_query

SELECT FIRST(salary) OVER w, LAST(salary) OVER w FROM userdata1 WINDOW w AS (ORDER BY id RANGE BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) LIMIT 1
-- bwc_tag:end_query

SELECT MIN(title), MAX(title) FROM userdata1
-- bwc_tag:end_query

SELECT FIRST(title) OVER w, LAST(title) OVER w FROM userdata1 WINDOW w AS (ORDER BY id RANGE BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) LIMIT 1
-- bwc_tag:end_query

SELECT MIN(comments), MAX(comments) FROM userdata1
-- bwc_tag:end_query

SELECT FIRST(comments) OVER w, LAST(comments) OVER w FROM userdata1 WINDOW w AS (ORDER BY id RANGE BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) LIMIT 1
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM parquet_scan('data/parquet-testing/broken-arrow.parquet')
-- bwc_tag:end_query

