-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=43
LOAD 'parquet';
-- bwc_tag:end_query

select id, value, part, date from parquet_scan('data/parquet-testing/hive-partitioning/simple/*/*/test.parquet', HIVE_PARTITIONING=1) order by id
-- bwc_tag:end_query

select id, value, part, date from parquet_scan('data/parquet-testing/hive-partitioning/different_order/*/*/test.parquet', HIVE_PARTITIONING=1) order by id
-- bwc_tag:end_query

select id, date from parquet_scan('data/parquet-testing/hive-partitioning/different_order/*/*/test.parquet', HIVE_PARTITIONING=1) where date = '2013-01-01';
-- bwc_tag:end_query

select id, date from parquet_scan('data/parquet-testing/hive-partitioning/different_order/*/*/test.parquet', HIVE_PARTITIONING=1) where date = '2012-01-01';
-- bwc_tag:end_query

select id, date from parquet_scan('data/parquet-testing/hive-partitioning/different_order/*/*/test.parquet', HIVE_PARTITIONING=1) where date = '2018-01-01';
-- bwc_tag:end_query

select id, value, part, date from parquet_scan('data/parquet-testing/hive-partitioning/different_order/*/*/test.parquet', HIVE_PARTITIONING=1) where part='a' OR part='b' order by id;
-- bwc_tag:end_query

select id, date from parquet_scan('data/parquet-testing/hive-partitioning/different_order/*/*/test.parquet', HIVE_PARTITIONING=1) where date = '2013-01-01' and id = 2;
-- bwc_tag:end_query

select id, date from parquet_scan('data/parquet-testing/hive-partitioning/different_order/*/*/test.parquet', HIVE_PARTITIONING=1) where date = '2013-01-01' and id = 1;
-- bwc_tag:end_query

select id, value, date from parquet_scan('data/parquet-testing/hive-partitioning/different_order/*/*/test.parquet', HIVE_PARTITIONING=1) where date = '2012-01-01' and id = 1;
-- bwc_tag:end_query

select id, value, date from parquet_scan('data/parquet-testing/hive-partitioning/different_order/*/*/test.parquet', HIVE_PARTITIONING=1) where date = '2012-01-01' or id <= 2 order by id;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select * from parquet_scan('data/parquet-testing/hive-partitioning/mismatching_names/*/*/test.parquet', HIVE_PARTITIONING=1)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select * from parquet_scan('data/parquet-testing/hive-partitioning/mismatching_count/*/*/test.parquet', HIVE_PARTITIONING=1) WHERE part=b
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select * from parquet_scan('data/parquet-testing/hive-partitioning/mismatching_names/*/*/test.parquet', HIVE_PARTITIONING=1, UNION_BY_NAME=1)
-- bwc_tag:end_query

EXPLAIN select id, date from parquet_scan('data/parquet-testing/hive-partitioning/different_order/*/*/test.parquet', HIVE_PARTITIONING=1, HIVE_TYPES_AUTOCAST=0) where date = '2013-01-01';
-- bwc_tag:end_query

EXPLAIN select id, date from parquet_scan('data/parquet-testing/hive-partitioning/different_order/*/*/test.parquet', HIVE_PARTITIONING=1, HIVE_TYPES_AUTOCAST=0) where date = '2018-01-01';
-- bwc_tag:end_query

EXPLAIN select id, value, part, date from parquet_scan('data/parquet-testing/hive-partitioning/different_order/*/*/test.parquet', HIVE_PARTITIONING=1) where part='a' OR part='b' order by id;
-- bwc_tag:end_query

EXPLAIN select id, date from parquet_scan('data/parquet-testing/hive-partitioning/simple/*/*/test.parquet', HIVE_PARTITIONING=1, HIVE_TYPES_AUTOCAST=0) where date = '2012-01-01' and id < 10;
-- bwc_tag:end_query

EXPLAIN select id, date from parquet_scan('data/parquet-testing/hive-partitioning/simple/*/*/test.parquet', HIVE_PARTITIONING=1, HIVE_TYPES_AUTOCAST=0) where date = '2013-01-01' and id < 10;
-- bwc_tag:end_query

select id, value, part, CAST(date AS DATE) as date_cast from parquet_scan('data/parquet-testing/hive-partitioning/different_order/*/*/test.parquet', HIVE_PARTITIONING=1) where concat(date_cast::VARCHAR, part) == '2013-01-01b';
-- bwc_tag:end_query

explain select id, value, part, CAST(date AS DATE) as date_cast from parquet_scan('data/parquet-testing/hive-partitioning/different_order/*/*/test.parquet', HIVE_PARTITIONING=1, HIVE_TYPES_AUTOCAST=0) where concat(date_cast::VARCHAR, part) == '2013-01-01b';
-- bwc_tag:end_query

select id, value, part, CAST(date AS DATE) as date_cast from parquet_scan('data/parquet-testing/hive-partitioning/different_order/*/*/test.parquet', HIVE_PARTITIONING=1) where concat(date_cast::VARCHAR, part) == '2012-01-01a';
-- bwc_tag:end_query

explain select id, value, part, CAST(date AS DATE) as date_cast from parquet_scan('data/parquet-testing/hive-partitioning/different_order/*/*/test.parquet', HIVE_PARTITIONING=1, HIVE_TYPES_AUTOCAST=0) where concat(date_cast::VARCHAR, part) == '2012-01-01a';
-- bwc_tag:end_query

explain select id, value, part, CAST(date AS DATE) as date_cast from parquet_scan('data/parquet-testing/hive-partitioning/different_order/*/*/test.parquet', HIVE_PARTITIONING=1, HIVE_TYPES_AUTOCAST=0) where (date_cast=CAST('2013-01-01' as DATE) AND (value='value1' OR concat(date_cast::VARCHAR, part) == '2013-01-01b'));
-- bwc_tag:end_query

explain select id, value, part, CAST(date AS DATE) as date_cast from parquet_scan('data/parquet-testing/hive-partitioning/different_order/*/*/test.parquet', HIVE_PARTITIONING=1, HIVE_TYPES_AUTOCAST=0) where (date_cast=CAST('2012-01-01' as DATE) AND (value='value2' OR concat(date_cast::VARCHAR, part) == '2012-01-01a'));
-- bwc_tag:end_query

SELECT a, b, replace(filename, '\', '/') filename FROM parquet_scan('data/parquet-testing/hive-partitioning/hive_col_also_in_file/*/test.parquet', HIVE_PARTITIONING=0, FILENAME=1) order by filename;
-- bwc_tag:end_query

SELECT a, b, replace(filename, '\', '/') filename FROM parquet_scan('data/parquet-testing/hive-partitioning/hive_col_also_in_file/*/test.parquet', HIVE_PARTITIONING=1, FILENAME=1) order by filename;
-- bwc_tag:end_query

select id, value, part, date 
from parquet_scan('data/parquet-testing/hive-partitioning/missing/*/*/test.parquet', HIVE_PARTITIONING=1) 
order by id
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
Create table t1 (a int, b int, c int);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into t1 (select range, 0*10, 0*100 from range(0,10));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into t1 (select range, 1*10, 1*100 from range(0,10));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into t1 (select range, 2*10, 2*100 from range(0,10));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into t1 (select range, 3*10, 3*100 from range(0,10));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into t1 (select range, 4*10, 4*100 from range(0,10));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into t1 (select range, 5*10, 5*100 from range(0,10));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into t1 (select range, 6*10, 6*100 from range(0,10));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into t1 (select range, 7*10, 7*100 from range(0,10));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into t1 (select range, 8*10, 8*100 from range(0,10));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into t1 (select range, 9*10, 9*100 from range(0,10));
-- bwc_tag:end_query

COPY (SELECT * FROM t1) TO 'output/hive_filters' (FORMAT PARQUET, PARTITION_BY c);
-- bwc_tag:end_query

COPY (SELECT * FROM t1) TO 'output/hive_filters_2' (FORMAT PARQUET, PARTITION_BY (c, b));
-- bwc_tag:end_query

EXPLAIN select a from parquet_scan('output/hive_filters/*/*.parquet', HIVE_PARTITIONING=1, HIVE_TYPES_AUTOCAST=0) where c::INT=500 and a::INT < 4;
-- bwc_tag:end_query

EXPLAIN select a from parquet_scan('output/hive_filters_2/*/*/*.parquet', HIVE_PARTITIONING=1, HIVE_TYPES_AUTOCAST=0) where c::INT > 500 and c::INT < 500;
-- bwc_tag:end_query

