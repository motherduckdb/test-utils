-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=4
LOAD 'parquet';
-- bwc_tag:end_query

copy (select 42 as a) to 'output/conversion_error1.parquet';
-- bwc_tag:end_query

copy (select blob 'hello world' as a) to 'output/conversion_error2.parquet';
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM read_parquet(['output/conversion_error1.parquet', 'output/conversion_error2.parquet'])
-- bwc_tag:end_query

