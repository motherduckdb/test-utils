-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=11
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
pragma enable_object_cache
-- bwc_tag:end_query

select * from parquet_scan('data/parquet-testing/cache/cache1.parquet')
-- bwc_tag:end_query

select * from parquet_scan('data/parquet-testing/cache/cache1.parquet')
-- bwc_tag:end_query

COPY (
	SELECT * FROM parquet_scan('data/parquet-testing/cache/cache1.parquet')
	)
TO 'output/cached.parquet' (FORMAT 'parquet')
-- bwc_tag:end_query

select * from parquet_scan('output/cached.parquet')
-- bwc_tag:end_query

COPY (
	SELECT * FROM parquet_scan('data/parquet-testing/cache/cache2.parquet')
	)
TO 'output/cached.parquet' (FORMAT 'parquet')
-- bwc_tag:end_query

select * from parquet_scan('output/cached.parquet')
-- bwc_tag:end_query

select * from parquet_scan('data/parquet-testing/glob/t1.parquet')
-- bwc_tag:end_query

select * from parquet_scan('data/parquet-testing/glob2/t1.parquet')
-- bwc_tag:end_query

select count(*) from parquet_scan('data/parquet-testing/glob/*.parquet')
-- bwc_tag:end_query

