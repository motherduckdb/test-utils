-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=8
LOAD 'parquet';
-- bwc_tag:end_query

SELECT id FROM 'data/parquet-testing/p2.parquet' offset 4968;
-- bwc_tag:end_query

SELECT id FROM 'data/parquet-testing/p2.parquet' limit 10;
-- bwc_tag:end_query

SELECT id FROM 'data/parquet-testing/p2.parquet' limit 100;
-- bwc_tag:end_query

SELECT id_with_null FROM 'data/parquet-testing/p2.parquet' limit 100;
-- bwc_tag:end_query

select min(id), max(id), sum(id), count(id), min(id_with_null), max(id_with_null), sum(id_with_null), count(id_with_null) from 'data/parquet-testing/p2.parquet'
-- bwc_tag:end_query

select min(id_int), max(id_int), sum(id_int), count(id_int) from 'data/parquet-testing/p2.parquet'
-- bwc_tag:end_query

select * from 'data/parquet-testing/7-set.snappy.arrow2.parquet';
-- bwc_tag:end_query

