-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=4
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT a FROM 'data/parquet-testing/corrupt_stats.parquet' GROUP BY a;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA disable_optimizer
-- bwc_tag:end_query

SELECT a FROM 'data/parquet-testing/corrupt_stats.parquet' GROUP BY a;
-- bwc_tag:end_query

