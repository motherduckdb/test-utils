-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=4
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

select * from parquet_scan('data/parquet-testing/nullbyte.parquet')
-- bwc_tag:end_query

select * from parquet_scan('data/parquet-testing/nullbyte_multiple.parquet')
-- bwc_tag:end_query

