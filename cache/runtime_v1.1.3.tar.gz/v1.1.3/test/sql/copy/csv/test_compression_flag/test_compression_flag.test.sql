-- bwc_tag:nb_steps=20
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE lineitem(a INT NOT NULL,
                      b INT NOT NULL,
                      c INT NOT NULL);
-- bwc_tag:end_query

COPY lineitem FROM 'data/csv/test/test_comp.csv.gzz' (COMPRESSION 'gzip', AUTO_DETECT 1);
-- bwc_tag:end_query

SELECT COUNT(*) FROM lineitem
-- bwc_tag:end_query

SELECT a, b, c FROM lineitem ORDER BY a
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE lineitem
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE lineitem(a INT NOT NULL,
                      b INT NOT NULL,
                      c INT NOT NULL);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY lineitem FROM 'data/csv/test/test_comp.csv.gz' (COMPRESSION 'infer', AUTO_DETECT 1);
-- bwc_tag:end_query

SELECT COUNT(*) FROM lineitem
-- bwc_tag:end_query

SELECT a, b, c FROM lineitem ORDER BY a
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE lineitem
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY lineitem FROM 'data/csv/test/test_comp.csv.gz' COMPRESSION 'none';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE lineitem AS SELECT * FROM read_csv_auto('data/csv/test/test_comp.csv.gzz', compression='gzip');
-- bwc_tag:end_query

SELECT COUNT(*) FROM lineitem
-- bwc_tag:end_query

SELECT a, b, c FROM lineitem ORDER BY a
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE lineitem
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE lineitem AS SELECT * FROM read_csv('data/csv/test/test_comp.csv.gzz', compression='gzip', AUTO_DETECT=TRUE);
-- bwc_tag:end_query

SELECT COUNT(*) FROM lineitem
-- bwc_tag:end_query

SELECT a, b, c FROM lineitem ORDER BY a
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE lineitem
-- bwc_tag:end_query

