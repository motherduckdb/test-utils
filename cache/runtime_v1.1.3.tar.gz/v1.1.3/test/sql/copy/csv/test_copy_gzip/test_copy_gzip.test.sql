-- bwc_tag:nb_steps=8
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE lineitem(l_orderkey INT NOT NULL,
                      l_partkey INT NOT NULL,
                      l_suppkey INT NOT NULL,
                      l_linenumber INT NOT NULL,
                      l_quantity INTEGER NOT NULL,
                      l_extendedprice DECIMAL(15, 2) NOT NULL,
                      l_discount DECIMAL(15, 2) NOT NULL,
                      l_tax DECIMAL(15, 2) NOT NULL,
                      l_returnflag VARCHAR(1) NOT NULL,
                      l_linestatus VARCHAR(1) NOT NULL,
                      l_shipdate DATE NOT NULL,
                      l_commitdate DATE NOT NULL,
                      l_receiptdate DATE NOT NULL,
                      l_shipinstruct VARCHAR(25) NOT NULL,
                      l_shipmode VARCHAR(10) NOT NULL,
                      l_comment VARCHAR(44) NOT NULL);
-- bwc_tag:end_query

COPY lineitem FROM 'data/csv/lineitem1k.tbl.gz' DELIMITER '|';
-- bwc_tag:end_query

SELECT COUNT(*) FROM lineitem
-- bwc_tag:end_query

SELECT l_partkey FROM lineitem WHERE l_orderkey=1 ORDER BY l_linenumber
-- bwc_tag:end_query

COPY lineitem TO 'output/lineitem1k.csv.gz' (DELIMITER '|', HEADER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE lineitem_rt AS FROM 'output/lineitem1k.csv.gz';
-- bwc_tag:end_query

SELECT COUNT(*) FROM (FROM lineitem EXCEPT FROM lineitem_rt)
-- bwc_tag:end_query

