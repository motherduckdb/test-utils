-- bwc_tag:nb_steps=11
-- bwc_tag:execute_from_sql
SELECT typeof(first(column0)), typeof(first(column1)), COUNT(*), SUM(column0), MAX(len(column1)) FROM read_csv_auto(
    'data/csv/error/mismatch/big_bad*.csv',
    sample_size=1,
    store_rejects=true);
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
SELECT * EXCLUDE (scan_id) FROM reject_errors order by all;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT SUM(num) FROM read_csv_auto(
	'data/csv/error/mismatch/half1.csv',
	header=true,
	sample_size=1,
	store_rejects=true)
-- bwc_tag:end_query

SELECT COUNT(*) FROM reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_errors;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE reject_scans;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT SUM(num) FROM read_csv_auto(
	'data/csv/error/mismatch/half2.csv',
	header=true,
	ignore_errors=true,
	sample_size=1,
	rejects_table='csv_rejects_table');
-- bwc_tag:end_query

SELECT COUNT(*) FROM csv_rejects_table;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE csv_rejects_table;
-- bwc_tag:end_query

