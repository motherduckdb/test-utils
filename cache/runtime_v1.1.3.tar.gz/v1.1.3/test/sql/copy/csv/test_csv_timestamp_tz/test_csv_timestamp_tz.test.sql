-- bwc_tag:nb_steps=2
-- bwc_tag:skip_query
pragma enable_verification
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

copy (
select '2021-05-25 04:55:03.382494 UTC'::timestamp as ts, '2021-05-25 04:55:03.382494 UTC'::timestamptz as tstz
) to 'output/timestamps.csv' ( timestampformat '%A');
-- bwc_tag:end_query

