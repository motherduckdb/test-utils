-- bwc_tag:nb_steps=31
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

FROM sniff_csv('data/csv/real/lineitem_sample.csv', delim = ',');
-- bwc_tag:end_query

FROM sniff_csv('data/csv/real/lineitem_sample.csv', delim='|');
-- bwc_tag:end_query

FROM sniff_csv('data/csv/real/lineitem_sample.csv', quote='"');
-- bwc_tag:end_query

FROM sniff_csv('data/csv/real/lineitem_sample.csv', escape='"');
-- bwc_tag:end_query

FROM sniff_csv('data/csv/real/lineitem_sample.csv', escape='"');
-- bwc_tag:end_query

FROM sniff_csv('data/csv/real/lineitem_sample.csv', names=['c1', 'c2', 'c3', 'c4', 'c5', 'c6', 'c7', 'c8', 'c9', 'c10', 'c11', 'c12', 'c13', 'c14', 'c15', 'c16']);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/real/lineitem_sample.csv', auto_detect=false, delim='|', quote='"', escape='"', new_line='\n', skip=0, header=false, columns={'c1': 'BIGINT', 'c2': 'BIGINT', 'c3': 'BIGINT', 'c4': 'BIGINT', 'c5': 'BIGINT', 'c6': 'DOUBLE', 'c7': 'DOUBLE', 'c8': 'DOUBLE', 'c9': 'VARCHAR', 'c10': 'VARCHAR', 'c11': 'DATE', 'c12': 'DATE', 'c13': 'DATE', 'c14': 'VARCHAR', 'c15': 'VARCHAR', 'c16': 'VARCHAR'}, dateformat='%Y-%m-%d') limit 1;
-- bwc_tag:end_query

FROM sniff_csv('data/csv/real/lineitem_sample.csv', columns={'c1': 'BIGINT', 'c2': 'BIGINT', 'c3': 'BIGINT', 'c4': 'BIGINT', 'c5': 'BIGINT', 'c6': 'DOUBLE', 'c7': 'DOUBLE', 'c8': 'DOUBLE', 'c9': 'VARCHAR', 'c10': 'VARCHAR', 'c11': 'DATE', 'c12': 'DATE', 'c13': 'DATE', 'c14': 'VARCHAR', 'c15': 'VARCHAR', 'c16': 'VARCHAR'});
-- bwc_tag:end_query

FROM sniff_csv('data/csv/real/lineitem_sample.csv', skip=1);
-- bwc_tag:end_query

FROM sniff_csv('data/csv/real/lineitem_sample.csv', header=true);
-- bwc_tag:end_query

FROM sniff_csv('data/csv/auto/time_date_timestamp_yyyy.mm.dd.csv', dateformat='%Y.%m.%d')
-- bwc_tag:end_query

FROM sniff_csv('data/csv/auto/time_date_timestamp_yyyy.mm.dd.csv', timestampformat='%Y.%m.%d %H:%M:%S')
-- bwc_tag:end_query

FROM sniff_csv('data/csv/auto/time_date_timestamp_yyyy.mm.dd.csv', dateformat='%Y.%m.%d', timestampformat='%Y.%m.%d %H:%M:%S')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/auto/time_date_timestamp_yyyy.mm.dd.csv', auto_detect=false, delim=',', quote='"', escape='"', new_line='\n', skip=0, header=true, columns={'a': 'BIGINT', 'b': 'VARCHAR', 't': 'TIME', 'd': 'DATE', 'ts': 'TIMESTAMP'}, timestampformat='%Y.%m.%d %H:%M:%S', dateformat='%Y.%m.%d') order by all limit 1;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

FROM sniff_csv('data/csv/real/lineitem_sample.csv', columns={'c1': 'BIGINT', 'c2': 'BIGINT', 'c3': 'BIGINT', 'c4': 'BIGINT', 'c5': 'BIGINT', 'c6': 'DOUBLE', 'c7': 'DOUBLE', 'c8': 'DOUBLE', 'c9': 'VARCHAR', 'c10': 'VARCHAR', 'c11': 'DATE', 'c12': 'DATE', 'c13': 'DATE', 'c14': 'VARCHAR', 'c15': 'VARCHAR', 'c16': 'VARCHAR'}, auto_detect = false);
-- bwc_tag:end_query

FROM sniff_csv('data/csv/real/lineitem_sample.csv', columns={'c1': 'BIGINT', 'c2': 'BIGINT', 'c3': 'BIGINT', 'c4': 'BIGINT', 'c5': 'BIGINT', 'c6': 'DOUBLE', 'c7': 'DOUBLE', 'c8': 'DOUBLE', 'c9': 'VARCHAR', 'c10': 'VARCHAR', 'c11': 'DATE', 'c12': 'DATE', 'c13': 'DATE', 'c14': 'VARCHAR', 'c15': 'VARCHAR', 'c16': 'VARCHAR'}, auto_detect = true);
-- bwc_tag:end_query

FROM sniff_csv('data/csv/autotypecandidates.csv', auto_type_candidates=['SMALLINT','BIGINT', 'DOUBLE', 'FLOAT','VARCHAR']);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/autotypecandidates.csv', auto_detect=false, delim='|', quote='"', escape='"', new_line='\n', skip=0, header=false, columns={'column0': 'SMALLINT', 'column1': 'FLOAT', 'column2': 'VARCHAR'});
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

FROM sniff_csv('data/csv/hive-partitioning/simple/*/*/test.csv');
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

FROM sniff_csv('data/csv/autotypecandidates.csv', oop = True);
-- bwc_tag:end_query

FROM sniff_csv('data/csv/autotypecandidates.csv', HIVE_PARTITIONING=1);
-- bwc_tag:end_query

FROM sniff_csv('data/csv/real/lineitem_sample.csv', types=['INTEGER','BIGINT','BIGINT','BIGINT','BIGINT', 'DOUBLE','DOUBLE','DOUBLE','VARCHAR', 'VARCHAR','DATE', 'DATE',  'DATE', 'VARCHAR',  'VARCHAR', 'VARCHAR']);
-- bwc_tag:end_query

FROM sniff_csv('data/csv/real/lineitem_sample.csv', dtypes=['INTEGER','BIGINT','BIGINT','BIGINT','BIGINT', 'DOUBLE','DOUBLE','DOUBLE','VARCHAR', 'VARCHAR','DATE', 'DATE',  'DATE', 'VARCHAR',  'VARCHAR', 'VARCHAR']);
-- bwc_tag:end_query

FROM sniff_csv('data/csv/real/lineitem_sample.csv', column_types=['INTEGER','BIGINT','BIGINT','BIGINT','BIGINT', 'DOUBLE','DOUBLE','DOUBLE','VARCHAR', 'VARCHAR','DATE', 'DATE',  'DATE', 'VARCHAR',  'VARCHAR', 'VARCHAR']);
-- bwc_tag:end_query

FROM sniff_csv('data/csv/real/lineitem_sample.csv', names=['c01','c02','c03','c04','c5', 'c06','c07','c08','c09', 'c10','c11', 'c12',  'c13', 'c14',  'c15', 'c16']);
-- bwc_tag:end_query

SELECT delimiter FROM sniff_csv('data/csv/ignore_errors.csv');
-- bwc_tag:end_query

SELECT delimiter FROM sniff_csv('data/csv/ignore_errors.csv', ignore_errors=true);
-- bwc_tag:end_query

SELECT delimiter FROM sniff_csv('data/csv/ignore_errors.csv', store_rejects=true);
-- bwc_tag:end_query

SELECT delimiter FROM sniff_csv('data/csv/ignore_errors.csv', rejects_scan='a_1');
-- bwc_tag:end_query

SELECT delimiter FROM sniff_csv('data/csv/ignore_errors.csv', rejects_table='a_2');
-- bwc_tag:end_query

