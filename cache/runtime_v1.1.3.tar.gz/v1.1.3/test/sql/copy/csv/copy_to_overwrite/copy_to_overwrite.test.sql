-- bwc_tag:nb_steps=20
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:skip_query
SET threads=1;
-- bwc_tag:end_query

COPY (SELECT * FROM range(5) t(i)) TO 'output/copy_to_overwrite.csv' (HEADER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM 'output/copy_to_overwrite.csv'
-- bwc_tag:end_query

COPY (SELECT * FROM range(5, 10) t(i)) TO 'output/copy_to_overwrite.csv' (HEADER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM 'output/copy_to_overwrite.csv'
-- bwc_tag:end_query

COPY (SELECT * FROM range(5) t(i)) TO 'output/copy_to_overwrite.csv.gz' (HEADER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM 'output/copy_to_overwrite.csv.gz'
-- bwc_tag:end_query

COPY (SELECT * FROM range(5, 10) t(i)) TO 'output/copy_to_overwrite.csv.gz' (HEADER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM 'output/copy_to_overwrite.csv.gz'
-- bwc_tag:end_query

SET preserve_insertion_order=false
-- bwc_tag:end_query

COPY (SELECT * FROM range(5) t(i)) TO 'output/copy_to_overwrite.csv' (HEADER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM 'output/copy_to_overwrite.csv'
-- bwc_tag:end_query

COPY (SELECT * FROM range(5, 10) t(i)) TO 'output/copy_to_overwrite.csv' (HEADER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM 'output/copy_to_overwrite.csv'
-- bwc_tag:end_query

COPY (SELECT * FROM range(5) t(i)) TO 'output/copy_to_overwrite.csv.gz' (HEADER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM 'output/copy_to_overwrite.csv.gz'
-- bwc_tag:end_query

COPY (SELECT * FROM range(5, 10) t(i)) TO 'output/copy_to_overwrite.csv.gz' (HEADER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM 'output/copy_to_overwrite.csv.gz'
-- bwc_tag:end_query

SET preserve_insertion_order=false
-- bwc_tag:end_query

