-- bwc_tag:needed_extensions=httpfs
-- bwc_tag:nb_steps=8
LOAD 'httpfs';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv_auto('data/csv/real/web_page.csv') ORDER BY 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv_auto('data/csv/lineitem1k.tbl.gz') ORDER BY ALL;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv_auto('https://raw.githubusercontent.com/duckdb/duckdb/main/data/csv/real/web_page.csv') ORDER BY 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select * from read_csv_auto('https://raw.githubusercontent.com/duckdb/duckdb/main/data/csv/lineitem1k.tbl.gz') ORDER BY ALL;
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

FROM sniff_csv('https://github.com/duckdb/duckdb/raw/main/data/csv/customer.csv?v=1')
-- bwc_tag:end_query

