-- bwc_tag:nb_steps=7
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select count(*) from read_csv('data/csv/evil_nullpadding.csv', delim = ';', quote = '"', null_padding = True, header = 0)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select count(*) from read_csv('data/csv/evil_nullpadding_2.csv', delim = ';', quote = '"', null_padding = True, header = 0)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

select * from read_csv('data/csv/evil_nullpadding.csv', delim = ';', quote = '"', null_padding = True, header = 0, buffer_size = 30)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

select count(*) from read_csv('data/csv/evil_nullpadding.csv', delim = ';', quote = '"', null_padding = True, header = 0, buffer_size = 27)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

select count(*) from read_csv('data/csv/evil_nullpadding.csv', delim = ';', quote = '"', null_padding = True, header = 0, buffer_size = 30)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

select * from read_csv('data/csv/evil_nullpadding_2.csv', delim = ';', quote = '"', null_padding = True, header = 0, buffer_size = 26)
-- bwc_tag:end_query

