-- bwc_tag:nb_steps=5
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test (a INTEGER, b VARCHAR DEFAULT('hello'), c INTEGER DEFAULT(3+4));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY test (a) FROM 'data/csv/test/test_default.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY test (c) FROM 'data/csv/test/test_default.csv';
-- bwc_tag:end_query

SELECT COUNT(a), COUNT(b), COUNT(c), MIN(LENGTH(b)), MAX(LENGTH(b)), SUM(a), SUM(c) FROM test;
-- bwc_tag:end_query

