-- bwc_tag:nb_steps=42
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
from read_csv('data/csv/segfault.csv',
   header=false,
   quote='"',
   escape = '"',
   sep=',',
   ignore_errors=true);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
from read_csv('data/csv/venue_pipe.csv',
   header=false,
   quote='"',
   escape = '"',
   sep='|',
   ignore_errors=true, columns = {'a':'varchar'});
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

from 'data/csv/fuzzing/0.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
from 'data/csv/fuzzing/1.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

from 'data/csv/fuzzing/2.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
from 'data/csv/fuzzing/3.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
from 'data/csv/fuzzing/4.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

from 'data/csv/fuzzing/5.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

from 'data/csv/fuzzing/6.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

from 'data/csv/fuzzing/7.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

from 'data/csv/fuzzing/8.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

from 'data/csv/fuzzing/9.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

from 'data/csv/fuzzing/10.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

from 'data/csv/fuzzing/11.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

from 'data/csv/fuzzing/12.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
from 'data/csv/fuzzing/13.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

from 'data/csv/fuzzing/14.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

from 'data/csv/fuzzing/15.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

from 'data/csv/fuzzing/16.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
from 'data/csv/fuzzing/17.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

from 'data/csv/fuzzing/18.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
from 'data/csv/fuzzing/19.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

from 'data/csv/fuzzing/20.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
from 'data/csv/fuzzing/21.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

from 'data/csv/fuzzing/22.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

from 'data/csv/fuzzing/23.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

from 'data/csv/fuzzing/24.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

from 'data/csv/fuzzing/25.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

from 'data/csv/fuzzing/26.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

from 'data/csv/fuzzing/27.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

from 'data/csv/fuzzing/28.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

from 'data/csv/fuzzing/29.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

from 'data/csv/fuzzing/30.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
from 'data/csv/fuzzing/31.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

from 'data/csv/fuzzing/32.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

from 'data/csv/fuzzing/33.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

from 'data/csv/fuzzing/34.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
from 'data/csv/fuzzing/35.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

from 'data/csv/fuzzing/36.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
from 'data/csv/fuzzing/37.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
from 'data/csv/fuzzing/38.csv'
-- bwc_tag:end_query

