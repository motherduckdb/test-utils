-- bwc_tag:nb_steps=9
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

SET default_null_order='nulls_first';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA verify_parallelism
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT id, value, a, part
FROM read_csv_auto('data/csv/union-by-name/part=[ab]/*',HIVE_PARTITIONING=TRUE ,UNION_BY_NAME=TRUE)
ORDER BY id
-- bwc_tag:end_query

SELECT k, c, ts, replace(filename, '\', '/')
FROM read_csv_auto('data/csv/union-by-name/ubn[!1-2].csv',FILENAME=TRUE ,UNION_BY_NAME=TRUE)
ORDER BY c
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT  a, b, c, ts, k
FROM read_csv_auto('data/csv/union-by-name/ubn*.csv',UNION_BY_NAME=TRUE)
ORDER BY a, c, ts
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT  typeof(a), typeof(b), typeof(c), typeof(ts), typeof(k)
FROM read_csv_auto('data/csv/union-by-name/ubn*.csv',UNION_BY_NAME=TRUE)
LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT  c, k
FROM read_csv_auto('data/csv/union-by-name/ubn*.csv',UNION_BY_NAME=TRUE)
ORDER BY c NULLS LAST, k NULLS LAST
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT  ts
FROM read_csv_auto('data/csv/union-by-name/ubn*.csv',UNION_BY_NAME=TRUE)
ORDER BY ts NULLS LAST
-- bwc_tag:end_query

