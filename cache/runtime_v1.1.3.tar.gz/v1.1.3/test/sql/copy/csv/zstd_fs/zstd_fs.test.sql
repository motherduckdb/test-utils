-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=11
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

LOAD 'parquet';
-- bwc_tag:end_query

SET autoload_known_extensions=false;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE lineitem(l_orderkey INT NOT NULL,
                      l_partkey INT NOT NULL,
                      l_suppkey INT NOT NULL,
                      l_linenumber INT NOT NULL,
                      l_quantity INTEGER NOT NULL,
                      l_extendedprice DECIMAL(15, 2) NOT NULL,
                      l_discount DECIMAL(15, 2) NOT NULL,
                      l_tax DECIMAL(15, 2) NOT NULL,
                      l_returnflag VARCHAR(1) NOT NULL,
                      l_linestatus VARCHAR(1) NOT NULL,
                      l_shipdate DATE NOT NULL,
                      l_commitdate DATE NOT NULL,
                      l_receiptdate DATE NOT NULL,
                      l_shipinstruct VARCHAR(25) NOT NULL,
                      l_shipmode VARCHAR(10) NOT NULL,
                      l_comment VARCHAR(44) NOT NULL);
-- bwc_tag:end_query

COPY lineitem FROM 'data/csv/zstd/lineitem1k.tbl.zst' DELIMITER '|';
-- bwc_tag:end_query

SELECT COUNT(*) FROM lineitem
-- bwc_tag:end_query

SELECT l_partkey FROM lineitem WHERE l_orderkey=1 ORDER BY l_linenumber
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE IF NOT EXISTS ncvoters(county_id INTEGER, county_desc STRING, voter_reg_num STRING,status_cd STRING, voter_status_desc STRING, reason_cd STRING, voter_status_reason_desc STRING, absent_ind STRING, name_prefx_cd STRING,last_name STRING, first_name STRING, midl_name STRING, name_sufx_cd STRING, full_name_rep STRING,full_name_mail STRING, house_num STRING, half_code STRING, street_dir STRING, street_name STRING, street_type_cd STRING, street_sufx_cd STRING, unit_designator STRING, unit_num STRING, res_city_desc STRING,state_cd STRING, zip_code STRING, res_street_address STRING, res_city_state_zip STRING, mail_addr1 STRING, mail_addr2 STRING, mail_addr3 STRING, mail_addr4 STRING, mail_city STRING, mail_state STRING, mail_zipcode STRING, mail_city_state_zip STRING, area_cd STRING, phone_num STRING, full_phone_number STRING, drivers_lic STRING, race_code STRING, race_desc STRING, ethnic_code STRING, ethnic_desc STRING, party_cd STRING, party_desc STRING, sex_code STRING, sex STRING, birth_age STRING, birth_place STRING, registr_dt STRING, precinct_abbrv STRING, precinct_desc STRING,municipality_abbrv STRING, municipality_desc STRING, ward_abbrv STRING, ward_desc STRING, cong_dist_abbrv STRING, cong_dist_desc STRING, super_court_abbrv STRING, super_court_desc STRING, judic_dist_abbrv STRING, judic_dist_desc STRING, nc_senate_abbrv STRING, nc_senate_desc STRING, nc_house_abbrv STRING, nc_house_desc STRING,county_commiss_abbrv STRING, county_commiss_desc STRING, township_abbrv STRING, township_desc STRING,school_dist_abbrv STRING, school_dist_desc STRING, fire_dist_abbrv STRING, fire_dist_desc STRING, water_dist_abbrv STRING, water_dist_desc STRING, sewer_dist_abbrv STRING, sewer_dist_desc STRING, sanit_dist_abbrv STRING, sanit_dist_desc STRING, rescue_dist_abbrv STRING, rescue_dist_desc STRING, munic_dist_abbrv STRING, munic_dist_desc STRING, dist_1_abbrv STRING, dist_1_desc STRING, dist_2_abbrv STRING, dist_2_desc STRING, confidential_ind STRING, age STRING, ncid STRING, vtd_abbrv STRING, vtd_desc STRING);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY ncvoters FROM 'data/csv/zstd/ncvoter.csv.zst' DELIMITER '	';
-- bwc_tag:end_query

SELECT county_id, county_desc, vtd_desc, name_prefx_cd FROM ncvoters;
-- bwc_tag:end_query

SELECT * FROM ncvoters
-- bwc_tag:end_query

