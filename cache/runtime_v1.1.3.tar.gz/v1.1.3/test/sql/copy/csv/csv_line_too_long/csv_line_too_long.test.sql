-- bwc_tag:nb_steps=8
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE T1 (name VARCHAR);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY T1(name) from 'data/csv/line_too_long.csv.gz' (DELIMITER ',', HEADER true , COMPRESSION gzip, ALLOW_QUOTED_NULLS false);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY T1(name) from 'data/csv/line_too_long.csv.gz' (DELIMITER ',', HEADER false , COMPRESSION gzip, ALLOW_QUOTED_NULLS false);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY T1(name) from 'data/csv/line_too_long_with_newline.csv.gz' (DELIMITER ',', HEADER true , COMPRESSION gzip, ALLOW_QUOTED_NULLS false);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY T1(name) from 'data/csv/line_too_long_with_newline.csv.gz' (DELIMITER ',', HEADER false , COMPRESSION gzip, ALLOW_QUOTED_NULLS false);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY T1(name) from 'data/csv/multiple_line_too_long.csv.gz' (DELIMITER ',', HEADER true , COMPRESSION gzip, ALLOW_QUOTED_NULLS false);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY T1(name) from 'data/csv/multiple_line_too_long.csv.gz' (DELIMITER ',', HEADER false , COMPRESSION gzip, ALLOW_QUOTED_NULLS false);
-- bwc_tag:end_query

