-- bwc_tag:nb_steps=11
-- bwc_tag:skip_query
pragma enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table t (i int primary key);
-- bwc_tag:end_query

select constraint_text from duckdb_constraints() where constraint_type = 'PRIMARY KEY';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table u (i int references t);
-- bwc_tag:end_query

select constraint_text from duckdb_constraints() where constraint_type = 'PRIMARY KEY';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table v (i int references t);
-- bwc_tag:end_query

select constraint_text from duckdb_constraints() where constraint_type = 'PRIMARY KEY';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop table v;
-- bwc_tag:end_query

select constraint_text from duckdb_constraints() where constraint_type = 'PRIMARY KEY';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop table u;
-- bwc_tag:end_query

select constraint_text from duckdb_constraints() where constraint_type = 'PRIMARY KEY';
-- bwc_tag:end_query

