-- bwc_tag:nb_steps=11
-- bwc_tag:execute_from_sql
CREATE TABLE "a b c"("d e" INTEGER, f INTEGER);
-- bwc_tag:end_query

SELECT * FROM sqlite_master;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE "a b c";
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE "inte""gers"(i INTEGER);
-- bwc_tag:end_query

SELECT * FROM sqlite_master;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE "inte""gers"
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers("a b" INTEGER, "c d" INTEGER, PRIMARY KEY("a b", "c d"))
-- bwc_tag:end_query

SELECT * FROM sqlite_master;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE "1a"(a1 INTEGER, a2 INTEGER);
-- bwc_tag:end_query

SELECT * FROM sqlite_master;
-- bwc_tag:end_query

