-- bwc_tag:nb_steps=14
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers AS SELECT * FROM range(5) tbl(i);
-- bwc_tag:end_query

SELECT i, COUNT(*) AS k FROM integers GROUP BY i HAVING k=1 ORDER BY i;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT i, COUNT(*) AS k FROM integers GROUP BY i HAVING integers.k=1 ORDER BY i;
-- bwc_tag:end_query

SELECT 1 AS i, COUNT(*) FROM integers GROUP BY i HAVING i=2;
-- bwc_tag:end_query

SELECT i AS j, COUNT(*) AS i FROM integers GROUP BY j HAVING integers.i=1 ORDER BY i;
-- bwc_tag:end_query

SELECT i AS j, COUNT(*) AS i FROM integers GROUP BY j HAVING j=1 ORDER BY i;
-- bwc_tag:end_query

SELECT COUNT(i) AS j FROM integers HAVING j=5;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT COUNT(i) AS i FROM integers HAVING i=5;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT COUNT(i) AS i FROM integers HAVING i=5 ORDER BY i;
-- bwc_tag:end_query

SELECT COUNT(i) AS j FROM integers HAVING j=j;
-- bwc_tag:end_query

SELECT COUNT(*) FROM (SELECT i, SUM(RANDOM()) AS k FROM integers GROUP BY i HAVING k=k) tbl(i, k);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT COUNT(i) AS i FROM integers HAVING integers.i=5 ORDER BY i;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT i + i AS i FROM integers HAVING i=5 ORDER BY i;
-- bwc_tag:end_query

