-- bwc_tag:nb_steps=3
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table my_functions as select 'my_name' as function_name;
-- bwc_tag:end_query

select
    function_name as raw,
    replace(raw, '_', ' ') as prettier
from my_functions
group by all;
-- bwc_tag:end_query

