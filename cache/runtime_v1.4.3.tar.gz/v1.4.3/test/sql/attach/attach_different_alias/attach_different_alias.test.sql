-- bwc_tag:nb_steps=6
ATTACH 'output/attach_alias.db' AS alias1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table alias1.tbl1 as select 1 as a;
-- bwc_tag:end_query

FROM alias1.tbl1
-- bwc_tag:end_query

DETACH alias1
-- bwc_tag:end_query

ATTACH 'output/attach_alias.db' AS alias2
-- bwc_tag:end_query

FROM alias2.tbl1
-- bwc_tag:end_query

