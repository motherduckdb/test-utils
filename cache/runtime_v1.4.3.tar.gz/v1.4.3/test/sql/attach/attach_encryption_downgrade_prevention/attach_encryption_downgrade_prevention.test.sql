-- bwc_tag:needed_extensions=httpfs
-- bwc_tag:nb_steps=5
-- bwc_tag:load_db=tmp

ATTACH 'output/tmp.db' AS tmp;
-- bwc_tag:end_query

LOAD 'httpfs';
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

ATTACH 'data/attach_test/encrypted_ctr_key=abcde.db' as enc (ENCRYPTION_KEY 'abcde');
-- bwc_tag:end_query

ATTACH 'data/attach_test/encrypted_ctr_key=abcde.db' as enc1 (ENCRYPTION_KEY 'abcde', ENCRYPTION_CIPHER 'CTR');
-- bwc_tag:end_query

ATTACH 'data/attach_test/encrypted_gcm_key=abcde.db' as enc2 (ENCRYPTION_KEY 'abcde');
-- bwc_tag:end_query

