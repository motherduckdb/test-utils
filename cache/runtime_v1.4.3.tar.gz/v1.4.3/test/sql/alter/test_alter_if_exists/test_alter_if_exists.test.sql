-- bwc_tag:nb_steps=36
-- bwc_tag:execute_from_sql
ALTER SEQUENCE IF EXISTS seq OWNED BY x;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE IF EXISTS t0 ADD COLUMN c0 INT;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO t0 VALUES (42);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE IF EXISTS t0 ADD COLUMN IF NOT EXISTS c0 int;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO t0 VALUES (42);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t0 (c0 INT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE t0 ADD COLUMN IF NOT EXISTS c0 int;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t0 VALUES (42);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE t0 ADD COLUMN c0 int;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE t0 ADD COLUMN c1 int;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t0 VALUES (42, 43);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE t0 ADD COLUMN IF NOT EXISTS c2 int;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t0 VALUES (42, 43, 44);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE IF EXISTS t1 DROP COLUMN IF EXISTS c3;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE IF EXISTS t0 DROP COLUMN if EXISTS c3;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE t1 DROP COLUMN IF EXISTS c3;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE t1 DROP COLUMN c3;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE t0 DROP COLUMN c3;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE t0 DROP COLUMN IF EXISTS c3
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE IF EXISTS t0 DROP COLUMN c3
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE IF EXISTS t1 ALTER COLUMN c0 TYPE varchar;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE IF EXISTS t1 ALTER COLUMN IF EXISTS c0 TYPE varchar;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE unit (price INTEGER, amount_sold INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE unit DROP COLUMN IF EXISTS rowid;
-- bwc_tag:end_query

SELECT rowid FROM unit;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO unit VALUES (10, 5);
-- bwc_tag:end_query

SELECT rowid FROM unit;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE unit ADD COLUMN rowid INTEGER;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO unit VALUES (20, 10, 1337);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE unit DROP COLUMN IF EXISTS rowid;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO unit VALUES (30, 20);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE unit ADD COLUMN IF NOT EXISTS rowid INTEGER;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO unit VALUES (40, 30, 1337);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE unit ADD COLUMN IF NOT EXISTS rowid INTEGER;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE unit DROP COLUMN rowid;
-- bwc_tag:end_query

SELECT rowid FROM unit;
-- bwc_tag:end_query

