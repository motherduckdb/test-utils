-- bwc_tag:nb_steps=9
-- bwc_tag:execute_from_sql
CREATE TABLE test(s STRUCT(s2 STRUCT(v1 INT, v2 INT)))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (ROW(ROW(1, 1))), (ROW(ROW(2, 2)))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test ADD COLUMN s.s2.k INTEGER
-- bwc_tag:end_query

SELECT * FROM test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE test ADD COLUMN s.s2.v1 VARCHAR
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test ADD COLUMN IF NOT EXISTS s.s2.v1 VARCHAR
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test ADD COLUMN s.i INTEGER DEFAULT 100
-- bwc_tag:end_query

SELECT * FROM test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE test ADD COLUMN s.s2.v1.x INTEGER
-- bwc_tag:end_query

