-- bwc_tag:nb_steps=7
-- bwc_tag:execute_from_sql
CREATE TABLE test(s STRUCT(s2 STRUCT(v1 INT, v2 INT)))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (ROW(ROW(1, 1))), (ROW(ROW(2, 2)))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test RENAME s.s2.v1 TO i
-- bwc_tag:end_query

SELECT * FROM test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE test RENAME COLUMN s.s2.v2 TO i
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test RENAME COLUMN s.s2 TO x
-- bwc_tag:end_query

SELECT * FROM test
-- bwc_tag:end_query

