-- bwc_tag:nb_steps=32
CALL enable_logging('QueryLog', storage_config={'buffer_size': 10, 'only_flush_on_full_buffer': true});
-- bwc_tag:end_query

SELECT 1 as a;
-- bwc_tag:end_query

SELECT count(*) FROM duckdb_logs
-- bwc_tag:end_query

SELECT 1 as a;
-- bwc_tag:end_query

SELECT 1 as a;
-- bwc_tag:end_query

SELECT 1 as a;
-- bwc_tag:end_query

SELECT 1 as a;
-- bwc_tag:end_query

SELECT 1 as a;
-- bwc_tag:end_query

SELECT 1 as a;
-- bwc_tag:end_query

SELECT 1 as a;
-- bwc_tag:end_query

SELECT 1 as a;
-- bwc_tag:end_query

SELECT 1 as a;
-- bwc_tag:end_query

SELECT 1 as a;
-- bwc_tag:end_query

SELECT count(*) FROM duckdb_logs
-- bwc_tag:end_query

CALL disable_logging()
-- bwc_tag:end_query

CALL truncate_duckdb_logs()
-- bwc_tag:end_query

CALL enable_logging('', level='trace', storage='memory', storage_config={'buffer_size': 3000, 'only_flush_on_full_buffer': true});
-- bwc_tag:end_query

SELECT write_log('hello from the connection log scope', level := 'error', scope := 'connection') from range(0,2999);
-- bwc_tag:end_query

SELECT count(*) FROM duckdb_logs()
-- bwc_tag:end_query

SELECT write_log('hello from the connection log scope', level := 'error', scope := 'connection');
-- bwc_tag:end_query

SELECT count(*) FROM duckdb_logs() where type=''
-- bwc_tag:end_query

SELECT count(*) FROM duckdb_log_contexts()
-- bwc_tag:end_query

CALL disable_logging()
-- bwc_tag:end_query

CALL truncate_duckdb_logs()
-- bwc_tag:end_query

CALL enable_logging(level='trace', storage='memory', storage_config={'buffer_size': 20*2048});
-- bwc_tag:end_query

SELECT write_log('hello from the connection log scope', level := 'error', scope := 'connection') from range(0,40*2048);
-- bwc_tag:end_query

FROM duckdb_logs()
-- bwc_tag:end_query

CALL enable_logging(level='trace', storage='file', storage_config={'buffer_size': 20*2048, 'path': 'output/logging_buffer_size'});
-- bwc_tag:end_query

SELECT write_log('hello from the connection log scope', level := 'error', scope := 'connection') from range(0,40*2048);
-- bwc_tag:end_query

CALL enable_logging(level='trace', storage='file', storage_config={'buffer_size': 0, 'path': 'output/logging_buffer_size'});
-- bwc_tag:end_query

SELECT write_log('hello from the connection log scope', level := 'error', scope := 'connection') from range(0, 2048);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

CALL enable_logging(level='trace', storage='file', storage_config={'buffer_size': -1, 'path': 'output/logging_buffer_size'});
-- bwc_tag:end_query

