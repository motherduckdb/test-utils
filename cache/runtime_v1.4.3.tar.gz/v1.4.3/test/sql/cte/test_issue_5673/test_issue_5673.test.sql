-- bwc_tag:nb_steps=6
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create or replace table orders(ordered_at int);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create or replace table stg_orders(ordered_at int);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into orders values (1);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into stg_orders values (1);
-- bwc_tag:end_query

with
orders as (
    select * from main.stg_orders
    where ordered_at >= (select max(ordered_at) from main.orders)
),
some_more_logic as (
    select *
    from orders
)
select * from some_more_logic;
-- bwc_tag:end_query

