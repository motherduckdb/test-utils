-- bwc_tag:nb_steps=12
-- bwc_tag:execute_from_sql
CREATE TABLE t1(i INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES (41), (42), (43)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE VIEW v1 (j, "j2") AS SELECT * FROM t1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW v1 (j, "j2") AS SELECT i,i+1 FROM t1
-- bwc_tag:end_query

SELECT j, j2 FROM v1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP VIEW v1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW v1 (j, "j2") AS SELECT i,i+1, i+2 FROM t1
-- bwc_tag:end_query

SELECT j, j2 FROM v1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP VIEW v1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW v1 (j, "j2") AS SELECT i,i+1, i+2 as x FROM t1
-- bwc_tag:end_query

SELECT j, j2, x FROM v1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP VIEW v1
-- bwc_tag:end_query

