-- bwc_tag:nb_steps=12
-- bwc_tag:execute_from_sql
CREATE TABLE hello(i INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test.bye(i INTEGER);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM helloo;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM bye;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA a;
CREATE TABLE a.foo(name text);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM foo;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA b;
CREATE TABLE b.foo(name text);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM foo;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA c;
CREATE TABLE c.foo(name text);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM foo;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM a.fooo;
-- bwc_tag:end_query

