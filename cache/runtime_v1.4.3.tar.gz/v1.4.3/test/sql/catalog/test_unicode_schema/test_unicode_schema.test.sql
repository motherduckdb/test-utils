-- bwc_tag:nb_steps=11
-- bwc_tag:execute_from_sql
CREATE TABLE 👤(🔑 INTEGER PRIMARY KEY, 🗣 varchar(64), 🗓 DATE);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE ✍(🔑 INTEGER PRIMARY KEY, 🗣 varchar(64));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE 📕(🔑 INTEGER PRIMARY KEY, 💬 varchar(64), 🔖 varchar(64), ✍ INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE 👤🏠📕(👤 INTEGER, 📕 INTEGER, ⭐ TEXT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO 👤 VALUES (1, 'Jeff', '2019-01-01'), (2, 'Annie', '2019-01-01');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO ✍ VALUES (1, 'Herman Melville'), (2, 'Lewis Carroll');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO 📕 VALUES (1, 'Alice in Wonderland', '🔮', 2), (2, 'Moby Dick', '📖', 1), (3, 'Through the Looking-Glass', '🔮', 2);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO 👤🏠📕 VALUES (1, 1, '😍'), (1, 2, '🤢'), (2, 2, '🙂');
-- bwc_tag:end_query

SELECT 👤.🗣 AS 👤, 📕.💬 AS 📕 FROM 👤 JOIN 👤🏠📕 ON 👤.🔑 = 👤🏠📕.👤 JOIN 📕 ON 📕.🔑 = 👤🏠📕.📕 ORDER BY 👤, 📕;
-- bwc_tag:end_query

SELECT 👤.🗣, 👤🏠📕.⭐ FROM 👤🏠📕 JOIN 📕 ON 👤🏠📕.📕 = 📕.🔑 JOIN 👤 ON 👤🏠📕.👤=👤.🔑 WHERE 📕.💬 = 'Moby Dick' ORDER BY 👤.🗣;
-- bwc_tag:end_query

SELECT type, name FROM sqlite_master WHERE name='👤' ORDER BY name;
-- bwc_tag:end_query

