-- bwc_tag:nb_steps=44
-- bwc_tag:execute_from_sql
create table A as select 1 as "X", 2 as "Y";
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table B as select 1 as "X", 3 as "Z";
-- bwc_tag:end_query

select * from A join B using(X);
-- bwc_tag:end_query

select * from A join B using("X");
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE "A"
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE "B"
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table A as select 1 as "X", 2 as "Y";
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table B as select 1 as X, 3 as "Z";
-- bwc_tag:end_query

select * from A join B using(X);
-- bwc_tag:end_query

select * from A join B using(X);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE "A"
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE "B"
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table A as select 1 as "hello", 2 as x;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table B as select 1 as "HELLO", 3 as x2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table C as select 1 as "hEllO", 4 as x3;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table D as select 1 as "HElLo", 5 as x4;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table E as select 1 as "heLLo", 6 as x5;
-- bwc_tag:end_query

SELECT * FROM a JOIN b USING (hello)
-- bwc_tag:end_query

SELECT * FROM a JOIN b USING (hello, "HELLO");
-- bwc_tag:end_query

SELECT * FROM a JOIN b USING (hello) JOIN c USING (hello)
-- bwc_tag:end_query

SELECT * FROM a JOIN b USING (hello) JOIN c USING ("HELLO")
-- bwc_tag:end_query

SELECT * FROM a JOIN b USING (hello) JOIN c USING (hello) JOIN d USING (hello)
-- bwc_tag:end_query

SELECT * FROM a JOIN b USING ("HELLO") JOIN c USING ("HeLLo") JOIN d USING (hello)
-- bwc_tag:end_query

SELECT * FROM a JOIN b USING (hello) JOIN c USING (hello) JOIN d USING (hello) JOIN e USING (hello)
-- bwc_tag:end_query

SELECT * FROM a FULL OUTER JOIN b USING (hello)
-- bwc_tag:end_query

SELECT * FROM a FULL OUTER JOIN b USING (hello) FULL OUTER JOIN c USING (hello)
-- bwc_tag:end_query

SELECT * FROM a FULL OUTER JOIN b USING (hello) FULL OUTER JOIN c USING (hello) FULL OUTER JOIN d USING (hello)
-- bwc_tag:end_query

SELECT * FROM a FULL OUTER JOIN b USING (hello) FULL OUTER JOIN c USING (hello) FULL OUTER JOIN d USING (hello) FULL OUTER JOIN e USING (hello)
-- bwc_tag:end_query

SELECT * FROM a NATURAL JOIN b
-- bwc_tag:end_query

SELECT * FROM a NATURAL JOIN b NATURAL JOIN c
-- bwc_tag:end_query

SELECT * FROM a NATURAL JOIN b NATURAL JOIN c NATURAL JOIN d
-- bwc_tag:end_query

SELECT * FROM a NATURAL JOIN b NATURAL JOIN c NATURAL JOIN d NATURAL JOIN e
-- bwc_tag:end_query

SELECT * FROM (a NATURAL JOIN b NATURAL JOIN c) NATURAL JOIN (d NATURAL JOIN e)
-- bwc_tag:end_query

SELECT * FROM a NATURAL FULL OUTER JOIN b
-- bwc_tag:end_query

SELECT * FROM a NATURAL FULL OUTER JOIN b NATURAL FULL OUTER JOIN c
-- bwc_tag:end_query

SELECT * FROM a NATURAL FULL OUTER JOIN b NATURAL FULL OUTER JOIN c NATURAL FULL OUTER JOIN d
-- bwc_tag:end_query

SELECT * FROM a NATURAL FULL OUTER JOIN b NATURAL FULL OUTER JOIN c NATURAL FULL OUTER JOIN d NATURAL FULL OUTER JOIN e
-- bwc_tag:end_query

SELECT * FROM (a NATURAL FULL OUTER JOIN b NATURAL FULL OUTER JOIN c) NATURAL FULL OUTER JOIN (d NATURAL FULL OUTER JOIN e)
-- bwc_tag:end_query

SELECT * FROM (SELECT 1 "hello", 2 "hello") NATURAL JOIN (SELECT 1 "hello", 2 "hello")
-- bwc_tag:end_query

SELECT * FROM (SELECT 1 "hello", 2 "HeLlO") NATURAL JOIN (SELECT 1 "hello", 2 "HeLlO")
-- bwc_tag:end_query

SELECT * FROM (SELECT 1 "hello", 2 "hello") t1, (SELECT 1 "hello", 2 "hello") t2
-- bwc_tag:end_query

SELECT * FROM (SELECT 1 "hello", 2 "hello") t1 JOIN (SELECT 1 "hello", 2 "hello") t2 USING (hello);
-- bwc_tag:end_query

SELECT * FROM (SELECT 1 "hello", 2 "HeLlO") t1 JOIN (SELECT 1 "hello", 2 "HeLlO") t2 USING (hello);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT hello FROM (a JOIN b USING (hello)), (d JOIN e USING (hello))
-- bwc_tag:end_query

