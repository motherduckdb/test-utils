-- bwc_tag:nb_steps=26
-- bwc_tag:execute_from_sql
CREATE TABLE cards_tbl  (val int, name string, suit string);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO cards_tbl values (1, 'ace', 'clubs'),    (11,'jack', 'clubs' ),
(12, 'queen', 'clubs' ),     (13, 'king', 'clubs');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO cards_tbl values (1, 'ace', 'diamonds'), (11,'jack', 'diamonds' ),
(12, 'queen', 'diamonds' ),  (13, 'king', 'diamonds');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO cards_tbl values (1, 'ace', 'hearts'),   (11,'jack', 'hearts' ),
(12, 'queen', 'hearts' ),    (13, 'king', 'hearts');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO cards_tbl values (1, 'ace', 'spades'),   (11,'jack', 'spades' ),
(12, 'queen', 'spades' ),    (13, 'king', 'spades');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO card_select(_val_min:=1, _val_max:=1,  _name:='%', _suit:='%')
as TABLE SELECT * FROM  cards_tbl WHERE val>=_val_min AND val<=_val_max AND name like  _name AND suit like _suit;
-- bwc_tag:end_query

SELECT DISTINCT val from card_select();
-- bwc_tag:end_query

SELECT  * FROM  card_select(_suit:='clubs');
-- bwc_tag:end_query

SELECT * FROM  card_select(_name:='king', _val_max:=13) ORDER BY suit;
-- bwc_tag:end_query

SELECT count(suit) FROM  card_select() GROUP BY ALL;
-- bwc_tag:end_query

SELECT * FROM card_select(_name:='king', _val_max:=13, _suit:='hearts', _val_min:=10);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO card_select_args(_val_min, _val_max,  _name:='%', _suit:='%')
as TABLE SELECT * FROM  cards_tbl WHERE val>=_val_min AND val<=_val_max AND name like  _name AND suit like _suit;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM  card_select_args(_name:='king',1, 13);
-- bwc_tag:end_query

SELECT suit FROM card_select_args(1, 13, _name:='king' ) ORDER BY suit;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO card_dfl() as TABLE SELECT DISTINCT suit FROM cards_tbl where suit='hearts';
-- bwc_tag:end_query

SELECT * FROM card_dfl();
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO  sc(aorder, border, nlimit) AS TABLE SELECT * FROM cards_tbl ORDER BY aorder,border LIMIT nlimit;
-- bwc_tag:end_query

SELECT * FROM sc(name, suit, 4);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO sc2(dlimit, noffset) AS TABLE SELECT DISTINCT  suit from cards_tbl order by all limit dlimit% offset noffset;
-- bwc_tag:end_query

SELECT * FROM sc2(50.0, 2);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO sc3(col) AS TABLE SELECT DISTINCT ON (col) col FROM cards_tbl ORDER BY col;
-- bwc_tag:end_query

SELECT * FROM sc3(name);
-- bwc_tag:end_query

SELECT * FROM sc3(suit);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE MACRO card_no_tbl() as TABLE SELECT * FROM suit_tbl;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE MACRO card_select_args(_val_min, _name:='%', _suit:='%', _val_max)
as TABLE SELECT * FROM  cards_tbl WHERE val>=_val_min AND val<=_val_max AND name like  _name AND suit like _suit;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE MACRO card_select_val(_val_min, _val_min) as TABLE SELECT * FROM cards_tbl WHERE val>=_val_min AND val<=_val_max;
-- bwc_tag:end_query

