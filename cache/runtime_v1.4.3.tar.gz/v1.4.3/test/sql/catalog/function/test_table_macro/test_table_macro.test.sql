-- bwc_tag:nb_steps=29
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test_tbl (id INT, name string);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test2_tbl (id INT, name string);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE greek_tbl (id INT, name string);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test_tbl VALUES (1,'tom'), (2,'dick'),(3,'harry'), (4,'mary'), (5,'mungo'), (6,'midge');  
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test_tbl VALUES (20,'andrew'), (21,'boris'),(22,'Caleb'), (23,'david'), (24,'evan');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO  greek_tbl VALUES (1, 'alpha'), (2, 'beta'), (3, 'gamma'), (4, 'delta'), (5, 'epsilon'),(6, 'zeta'), (7, 'eta') , (8, 'theta'), (9, 'iota') , (10, 'kappa'); 
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE  MACRO xt(a,_name) as TABLE SELECT * FROM test_tbl WHERE(id>=a or name=_name);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE  MACRO xt2(a,_name) as TABLE SELECT * FROM test_tbl WHERE(id>=a or name like _name);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE  MACRO sgreek(a,b,c) as TABLE SELECT a,b FROM greek_tbl WHERE(id >= c);
-- bwc_tag:end_query

( SELECT* FROM xt(1, 'tom') UNION SELECT* FROM  xt2(1, '%%%') ) INTERSECT SELECT* FROM xt(100,'midge');
-- bwc_tag:end_query

(SELECT* FROM xt(1, 'tom') EXCEPT SELECT* FROM xt(20,'tom' )) INTERSECT SELECT* FROM xt(100,'harry');
-- bwc_tag:end_query

SELECT	* FROM  xt(200,'andrew');
-- bwc_tag:end_query

SELECT * FROM xt2(100,'m%');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE  MACRO xtm(cmp_str) as TABLE SELECT id, name FROM test_tbl  WHERE( name similar to cmp_str);
-- bwc_tag:end_query

SELECT * FROM xtm('m.*');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE  MACRO  xt_reg(cmp) as TABLE SELECT * FROM test_tbl WHERE regexp_matches(name ,cmp );
-- bwc_tag:end_query

SELECT * FROM xt_reg('^m');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO   cmp(a,m) as regexp_matches(a,m) or a similar to m;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE  MACRO gm(m) as TABLE SELECT * FROM  greek_tbl WHERE cmp(name,m);
-- bwc_tag:end_query

SELECT * FROM  gm('^m');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO xt(a,b) as a+b;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP MACRO TABLE xt;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO xt(id, imax) as TABLE SELECT id,name FROM test_tbl WHERE id<=imax;
-- bwc_tag:end_query

SELECT * FROM xt(id,1);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE  MACRO range(a,b) as TABLE select a,b from test_tbl;
-- bwc_tag:end_query

SELECT * FROM test_tbl where id>=(SELECT max(id) FROM xt(id,30));
-- bwc_tag:end_query

SELECT * FROM greek_tbl where id<=(SELECT min(id) FROM xt(id,30));
-- bwc_tag:end_query

SELECT schema_name, function_name, function_type, description, return_type, parameters, parameter_types, varargs, macro_definition FROM duckdb_functions() WHERE function_type = 'table_macro' AND
 ( function_name = 'sgreek' or  function_name = 'xt') order by function_name;
-- bwc_tag:end_query

