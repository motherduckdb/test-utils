-- bwc_tag:nb_steps=8
-- bwc_tag:execute_from_sql
create or replace macro my_macro(a:=true) as a;
-- bwc_tag:end_query

select my_macro()
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create or replace macro my_macro(a:=false) as a;
-- bwc_tag:end_query

select my_macro()
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create or replace macro my_macro(a:={duck:42}) as a;
-- bwc_tag:end_query

select my_macro()
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create or replace macro my_macro(a:=[42]) as a;
-- bwc_tag:end_query

select my_macro()
-- bwc_tag:end_query

