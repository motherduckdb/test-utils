-- bwc_tag:nb_steps=13
SET storage_compatibility_version = 'v0.10.3';
-- bwc_tag:end_query

ATTACH 'output/test_fk_eager.db' AS fk_db;
-- bwc_tag:end_query

USE fk_db;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tbl_pk (i INT PRIMARY KEY, payload STRUCT(v VARCHAR, i INTEGER[]));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO tbl_pk VALUES (1, {'v': 'hello', 'i': [42]}), (2, {'v': 'world', 'i': [43]});
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tbl_fk (i INT REFERENCES tbl_pk(i));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO tbl_fk VALUES (1), (1), (1);
-- bwc_tag:end_query

ATTACH 'output/test_other_fk_eager.db' AS other_fk_db;
-- bwc_tag:end_query

USE other_fk_db;
-- bwc_tag:end_query

CHECKPOINT fk_db;
-- bwc_tag:end_query

DETACH fk_db;
-- bwc_tag:end_query

ATTACH 'output/test_fk_eager.db' AS fk_db;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

UPDATE fk_db.tbl_pk SET payload = {'v': 'new hello', 'i': [7]} WHERE i = 1;
-- bwc_tag:end_query

