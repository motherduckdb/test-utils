-- bwc_tag:nb_steps=10
SET default_null_order='nulls_first';
-- bwc_tag:end_query

SELECT COUNT(1), MIN(1), FIRST(1), LAST(1),MAX(1), SUM(1), STRING_AGG('hello', ',')
-- bwc_tag:end_query

SELECT COUNT(NULL), MIN(NULL), FIRST(NULL), LAST(NULL), MAX(NULL), SUM(NULL), STRING_AGG(NULL, NULL)
-- bwc_tag:end_query

SELECT FIRST(NULL)
-- bwc_tag:end_query

SELECT LAST(NULL)
-- bwc_tag:end_query

SELECT NULL as a, NULL as b, 1 as id UNION SELECT CAST('00:00:00' AS TIME) as a, CAST('12:34:56' AS TIME) as b, 2 as id ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (1), (2), (NULL)
-- bwc_tag:end_query

SELECT COUNT(1), MIN(1), FIRST(1), LAST(1), MAX(1), SUM(1), STRING_AGG('hello', ',') FROM integers
-- bwc_tag:end_query

SELECT COUNT(NULL), MIN(NULL), FIRST(NULL), LAST(NULL), MAX(NULL), SUM(NULL), STRING_AGG(NULL, NULL) FROM integers
-- bwc_tag:end_query

