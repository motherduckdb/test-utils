-- bwc_tag:nb_steps=22
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE obs(n BIGINT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO obs VALUES (0), (5), (7), (12), (20), (23), (24), (25), (26), (28), (31), (34), (36), (41), (47)
-- bwc_tag:end_query

SELECT histogram(n, [10, 20, 30, 40, 50]) FROM obs
-- bwc_tag:end_query

SELECT histogram(n, [10, 20, 30, 40]) FROM obs
-- bwc_tag:end_query

SELECT histogram(n::double, [10, 20, 30, 40]) FROM obs
-- bwc_tag:end_query

SELECT histogram(n, []) FROM obs
-- bwc_tag:end_query

SELECT histogram(n, [10, 40, 50, 30, 20]) FROM obs
-- bwc_tag:end_query

SELECT n%2=0 is_even, histogram(n, [10, 20, 30, 40, 50]) FROM obs GROUP BY is_even ORDER BY is_even
-- bwc_tag:end_query

SELECT n%2=0 is_even, histogram(n, case when n%2=0 then [10, 20, 30, 40, 50] else [11, 21, 31, 41, 51] end) FROM obs GROUP BY is_even ORDER BY is_even
-- bwc_tag:end_query

SELECT histogram(n, [10, 20, 30, 40, 50]) FROM obs
-- bwc_tag:end_query

SELECT histogram(i, range(999, 10000, 1000)) FROM range(10000) t(i)
-- bwc_tag:end_query

SELECT histogram(v, [-9223372036854775808, -9223372036854775807, 9223372036854775807]) FROM
(VALUES (-9223372036854775808), (-9223372036854775807), (0), (9223372036854775807)) t(v)
-- bwc_tag:end_query

SELECT histogram(v, ['-infinity'::double, -10, 0, 10, 'infinity']) FROM
(VALUES (-1e308), (-0.5), (0), ('inf'), ('-inf'), (0.5)) t(v)
-- bwc_tag:end_query

SELECT histogram(v, range(timestamp '2000-01-01', timestamp '2005-01-01', interval '1 year')) FROM
(VALUES (timestamp '2000-01-01'), (timestamp '2003-01-01')) t(v)
-- bwc_tag:end_query

SELECT histogram(v, ['a', 'b', 'c', 'z']) FROM
(VALUES ('a'), ('aaaa'), ('b'), ('c'), ('d')) t(v)
-- bwc_tag:end_query

SELECT histogram(concat('thisisalongprefix_', v), ['thisisalongprefix_'||x for x in ['a', 'b', 'c', 'z']]) FROM
(VALUES ('a'), ('aaaa'), ('b'), ('c'), ('d')) t(v)
-- bwc_tag:end_query

SELECT histogram({'i': n}, [{'i': x} for x in [10, 20, 30, 40, 50]]) FROM obs
-- bwc_tag:end_query

SELECT histogram([n], [[x] for x in [10, 20, 30, 40, 50]]) FROM obs
-- bwc_tag:end_query

SELECT histogram(n, [10, 10, 10, 10]) FROM obs
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT histogram(n, [10, 20, NULL]) FROM obs
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT histogram(n, NULL::BIGINT[]) FROM obs
-- bwc_tag:end_query

