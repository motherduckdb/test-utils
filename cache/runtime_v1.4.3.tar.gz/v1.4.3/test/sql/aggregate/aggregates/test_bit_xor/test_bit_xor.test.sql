-- bwc_tag:nb_steps=17
SELECT BIT_XOR(3), BIT_XOR(NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE seq;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT BIT_XOR(nextval('seq'))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT BIT_XOR(nextval('seq'))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (3), (7), (15), (31), (3), (15)
-- bwc_tag:end_query

SELECT BIT_XOR(i), BIT_XOR(1), BIT_XOR(DISTINCT i), BIT_XOR(NULL) FROM integers
-- bwc_tag:end_query

SELECT BIT_XOR(i) FROM integers WHERE i > 100
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT BIT_XOR()
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT BIT_XOR(1, 2, 3)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT BIT_XOR(BIT_XOR(1))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE bits(b BIT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO bits VALUES ('1010101001'), ('0011010101'), ('0001011101'), ('1011111101'), ('0000010001'), ('1000110001')
-- bwc_tag:end_query

SELECT BIT_XOR(b) FROM bits
-- bwc_tag:end_query

SELECT BIT_XOR(b) FROM bits WHERE get_bit(b, 3) = 1;
-- bwc_tag:end_query

SELECT BIT_XOR('101011'::BIT)
-- bwc_tag:end_query

SELECT BIT_XOR('0010101010101010101101011'::BIT) from bits
-- bwc_tag:end_query

