-- bwc_tag:nb_steps=4
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tbl(i INT)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM tbl GROUP BY DEFAULT
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM tbl GROUP BY SUM(41)
-- bwc_tag:end_query

