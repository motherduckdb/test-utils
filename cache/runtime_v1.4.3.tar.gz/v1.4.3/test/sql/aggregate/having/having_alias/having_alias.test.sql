-- bwc_tag:nb_steps=8
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

SELECT b, sum(a) AS a
FROM (VALUES (1, 0), (1, 1)) t(a, b)
GROUP BY b
HAVING a > 0
ORDER BY ALL
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table t1(a int);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into t1 values (42), (84);
-- bwc_tag:end_query

select a+1 as a from t1 group by a having a=42;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table t2(a int);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into t2 values (42), (84), (42);
-- bwc_tag:end_query

select a as b, sum(a) as a from t2 group by b having a=42;
-- bwc_tag:end_query

