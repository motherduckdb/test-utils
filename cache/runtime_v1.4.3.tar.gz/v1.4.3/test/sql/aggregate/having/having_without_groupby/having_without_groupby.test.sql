-- bwc_tag:nb_steps=4
SELECT 1 AS one FROM (
	values
	(1,2),
	(3,2)
) t(a, b)
HAVING 1 < 2;
-- bwc_tag:end_query

SELECT 1 AS one FROM (
	values
	(1,2),
	(3,2)
) t(a, b)
HAVING false;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select a FROM (
	values
	(1,2),
	(3,2)
) t(a, b)
HAVING true
-- bwc_tag:end_query

select sum(a) FROM (
	values
	(1,2),
	(3,2)
) t(a, b)
HAVING true
-- bwc_tag:end_query

