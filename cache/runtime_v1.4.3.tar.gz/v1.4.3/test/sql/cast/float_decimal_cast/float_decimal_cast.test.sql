-- bwc_tag:nb_steps=3
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

select 1.35::FLOAT::decimal(3, 1), 1.45::FLOAT::decimal(3, 1)
-- bwc_tag:end_query

select 1.35::DOUBLE::decimal(3, 1), 1.45::DOUBLE::decimal(3, 1)
-- bwc_tag:end_query

