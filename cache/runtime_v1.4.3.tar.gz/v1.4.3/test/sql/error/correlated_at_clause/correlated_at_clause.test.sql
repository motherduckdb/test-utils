-- bwc_tag:nb_steps=2
-- bwc_tag:execute_from_sql
CREATE TABLE t (i VARCHAR)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

FROM t, t AT (VERSION => i)
-- bwc_tag:end_query

