-- bwc_tag:nb_steps=18
-- bwc_tag:execute_from_sql
create table tbl (a varchar, b varchar);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into tbl values ('ö', '>>>>>ö<<<<<'), ('o', '>>>>>o<<<<<'), ('p', '>>>>>p<<<<<');
-- bwc_tag:end_query

select a from tbl where contains(b collate nocase, 'O') order by all
-- bwc_tag:end_query

select concat(a collate noaccent, a) from tbl order by all;
-- bwc_tag:end_query

select lower(a collate noaccent) from tbl order by all;
-- bwc_tag:end_query

select upper(a collate noaccent) from tbl order by all;
-- bwc_tag:end_query

select trim(b collate noaccent, '<>') from tbl order by all
-- bwc_tag:end_query

select ltrim(b collate noaccent, '<>') from tbl order by all
-- bwc_tag:end_query

select rtrim(b collate noaccent, '<>') from tbl order by all
-- bwc_tag:end_query

select repeat(a collate noaccent, 10) from tbl order by all;
-- bwc_tag:end_query

select left(b collate noaccent, 6) from tbl order by all;
-- bwc_tag:end_query

select right(b collate noaccent, 6) from tbl order by all;
-- bwc_tag:end_query

select right(left(b collate noaccent, 6), 1) from tbl order by all;
-- bwc_tag:end_query

select reverse(a collate noaccent) from tbl order by all;
-- bwc_tag:end_query

select a from tbl where contains(b collate noaccent, 'o') order by all
-- bwc_tag:end_query

select a from tbl where contains(b, 'ö' collate noaccent) order by all
-- bwc_tag:end_query

select a from tbl where contains(b collate nocase, 'O') order by all
-- bwc_tag:end_query

select a from tbl where starts_with(b collate noaccent, '>>>>>o') order by all
-- bwc_tag:end_query

