-- bwc_tag:nb_steps=19
SELECT 'a' AS c1 ORDER BY 1 COLLATE NOCASE;
-- bwc_tag:end_query

SELECT 'a' ORDER BY 1 COLLATE NOCASE;
-- bwc_tag:end_query

SELECT 'A', 'B' ORDER BY 2 COLLATE NOCASE;
-- bwc_tag:end_query

SELECT 999::VARCHAR ORDER BY 1 COLLATE NOCASE;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT 999 FROM ORDER BY 1 COLLATE NOCASE;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT 'a' FROM ORDER BY -1 COLLATE NOCASE;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT 'a' FROM ORDER BY 0 COLLATE NOCASE;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT 'a' FROM ORDER BY -0 COLLATE NOCASE;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE collate_test(s VARCHAR);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO collate_test VALUES ('ã'),('B'),('a'),('A');
-- bwc_tag:end_query

SELECT s FROM collate_test ORDER BY 1 COLLATE NOCASE;
-- bwc_tag:end_query

SELECT s FROM collate_test ORDER BY s COLLATE NOCASE;
-- bwc_tag:end_query

SELECT CONCAT(s, s) FROM collate_test ORDER BY 1 COLLATE NOCASE;
-- bwc_tag:end_query

SELECT CONCAT(s, s) AS concat, concat FROM collate_test ORDER BY 2 COLLATE NOCASE;
-- bwc_tag:end_query

SELECT collate_test.s FROM collate_test ORDER BY 1 COLLATE NOCASE;
-- bwc_tag:end_query

SELECT CASE WHEN s[1]='a' THEN s ELSE NULL END FROM collate_test ORDER BY 1 COLLATE NOCASE;
-- bwc_tag:end_query

SELECT (SELECT s) FROM collate_test ORDER BY 1 COLLATE NOCASE;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT (SELECT s) AS c1 FROM collate_test ORDER BY c11 COLLATE NOCASE;
-- bwc_tag:end_query

SELECT concat('a', (SELECT s)) FROM collate_test ORDER BY 1 COLLATE NOCASE;
-- bwc_tag:end_query

