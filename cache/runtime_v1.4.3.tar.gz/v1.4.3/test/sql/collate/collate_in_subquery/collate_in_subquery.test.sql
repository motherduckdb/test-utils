-- bwc_tag:nb_steps=6
select 'ABC' collate nocase in (select 'aBc');
-- bwc_tag:end_query

select upper in (select lower) from (values ('ABC' COLLATE nocase, 'aBc' COLLATE nocase)) t(upper, lower);
-- bwc_tag:end_query

select 'ABC' collate nocase in (select s) from (values ('aBc')) t(s);
-- bwc_tag:end_query

select 'ABC' in (select s collate nocase) from (values ('aBc')) t(s);
-- bwc_tag:end_query

select 'AB' collate nocase in (select 'AB');
-- bwc_tag:end_query

select 'Ab' collate nocase in (select 'Ab');
-- bwc_tag:end_query

