-- bwc_tag:nb_steps=17
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER, j INTEGER, k INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (1, 2, 3);
-- bwc_tag:end_query

SELECT renamed_col FROM (SELECT * RENAME i AS renamed_col FROM integers)
-- bwc_tag:end_query

SELECT renamed_col FROM (SELECT COLUMNS(* RENAME i AS renamed_col) FROM integers)
-- bwc_tag:end_query

SELECT renamed_col FROM (SELECT * RENAME integers.i AS renamed_col FROM integers)
-- bwc_tag:end_query

SELECT renamed_col FROM (SELECT integers.* RENAME integers.i AS renamed_col FROM integers)
-- bwc_tag:end_query

SELECT r1, r2 FROM (SELECT * RENAME (integers.i AS r1, j AS r2) FROM integers)
-- bwc_tag:end_query

SELECT r1, r2 FROM (SELECT * RENAME (integers.i AS r1, j AS r2,) FROM integers)
-- bwc_tag:end_query

SELECT i FROM (SELECT * EXCLUDE (i) RENAME (j AS i) FROM integers)
-- bwc_tag:end_query

SELECT r FROM (SELECT struct.* RENAME (i AS r) FROM (SELECT {'i': 42} AS struct))
-- bwc_tag:end_query

SELECT new_col FROM (SELECT * RENAME (i AS new_col) FROM integers i1 JOIN integers i2 USING (i))
-- bwc_tag:end_query

SELECT new_col, new_col2 FROM (SELECT * RENAME (i1.i AS new_col, i1.j AS new_col2) FROM integers i1 JOIN integers i2 USING (i))
-- bwc_tag:end_query

SELECT new_col FROM (SELECT * RENAME (i AS new_col) FROM integers i1 LEFT JOIN integers i2 USING (i))
-- bwc_tag:end_query

SELECT new_col FROM (SELECT * RENAME (i1.i AS new_col) FROM integers i1 FULL OUTER JOIN integers i2 USING (i))
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * EXCLUDE (i) RENAME (i AS renamed_col) FROM integers
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * REPLACE (i + 1 AS i) RENAME (i AS renamed_col) FROM integers
-- bwc_tag:end_query

