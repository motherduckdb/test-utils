-- bwc_tag:nb_steps=4
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table tbl as select case when i%2=0 then null else i end as i from range(10) tbl(i);
-- bwc_tag:end_query

select i, coalesce(rowid+i, rowid) from tbl ORDER BY rowid;
-- bwc_tag:end_query

select i, rowid, rowid+i, COALESCE(rowid+i, NULL) IS NULL OR rowid+3=6 from tbl ORDER BY rowid;
-- bwc_tag:end_query

