-- bwc_tag:nb_steps=14
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE a (i integer, j integer);
-- bwc_tag:end_query

SELECT i, j FROM a;
-- bwc_tag:end_query

SELECT * FROM a;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO a VALUES (42, 84);
-- bwc_tag:end_query

SELECT * FROM a;
-- bwc_tag:end_query

SELECT x, y FROM a i1(x, y);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test (a INTEGER, b INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (11, 22), (12, 21), (13, 22)
-- bwc_tag:end_query

SELECT a, b FROM test;
-- bwc_tag:end_query

SELECT a + 2, b FROM test WHERE a = 11;
-- bwc_tag:end_query

SELECT a + 2, b FROM test WHERE a = 12;
-- bwc_tag:end_query

SELECT cast(a AS VARCHAR) FROM test;
-- bwc_tag:end_query

SELECT cast(cast(a AS VARCHAR) as INTEGER) FROM test;
-- bwc_tag:end_query

