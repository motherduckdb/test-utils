-- bwc_tag:nb_steps=6
-- bwc_tag:execute_from_sql
prepare p1 as select 42;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table tbl(a varchar);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
prepare p2 as insert into tbl values ('test');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
prepare p3 as select 21, $1, $2
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
prepare p4 as select $name, $other_name
-- bwc_tag:end_query

select * from duckdb_prepared_statements() order by name;
-- bwc_tag:end_query

