-- bwc_tag:nb_steps=11
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test (a VARCHAR, b INTEGER, c INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test SELECT * FROM read_csv_auto('data/csv/nullpadding_big_mixed.csv', null_padding=True)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT COUNT(*) FROM read_csv_auto('data/csv/nullpadding_big_mixed.csv', null_padding=True)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT COUNT(*) FROM read_csv_auto('data/csv/nullpadding_big_mixed.csv', null_padding=False, ignore_errors=True)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT COUNT(*) FROM read_csv_auto('data/csv/nullpadding_big_mixed.csv')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test2 (a VARCHAR, b INTEGER, c INTEGER, d INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT COUNT(*) FROM read_csv_auto('data/csv/nullpadding_commas.csv', null_padding=True)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT COUNT(*) FROM read_csv('data/csv/nullpadding_commas.csv', sep=',',  columns={'a': INT, 'b': INT, 'c': INT, 'd': INT}, ignore_errors=True, null_padding=False)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT COUNT(*) FROM read_csv_auto('data/csv/nullpadding_big_mixed.csv', buffer_size=55)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT COUNT(*) FROM read_csv_auto('data/csv/nullpadding_big_mixed.csv', buffer_size=55, null_padding=False)
-- bwc_tag:end_query

