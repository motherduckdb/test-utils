-- bwc_tag:nb_steps=14
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

COPY (SELECT DATE '1992-01-01' d, 42 i, 'hello' s) TO 'output/projection_pushdown_f1.csv' (HEADER, DELIMITER '|')
-- bwc_tag:end_query

COPY (SELECT DATE '1993-01-01' d, 84 i, 'world' s) TO 'output/projection_pushdown_f2.csv' (HEADER, DELIMITER '|')
-- bwc_tag:end_query

COPY (SELECT DATE '1994-01-01' d, 100 i, 'this is a long string' s) TO 'output/projection_pushdown_f3.csv' (HEADER, DELIMITER '|')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW glob_view AS SELECT * FROM read_csv_auto('output/projection_pushdown_f*.csv')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW list_view AS SELECT * FROM read_csv_auto(['output/projection_pushdown_f1.csv', 'output/projection_pushdown_f2.csv', 'output/projection_pushdown_f3.csv'])
-- bwc_tag:end_query

SELECT i FROM glob_view ORDER BY i
-- bwc_tag:end_query

SELECT d FROM glob_view ORDER BY d
-- bwc_tag:end_query

SELECT s FROM glob_view ORDER BY s
-- bwc_tag:end_query

SELECT COUNT(*) FROM glob_view
-- bwc_tag:end_query

SELECT i FROM list_view ORDER BY i
-- bwc_tag:end_query

SELECT d FROM list_view ORDER BY d
-- bwc_tag:end_query

SELECT s FROM list_view ORDER BY s
-- bwc_tag:end_query

SELECT COUNT(*) FROM list_view
-- bwc_tag:end_query

