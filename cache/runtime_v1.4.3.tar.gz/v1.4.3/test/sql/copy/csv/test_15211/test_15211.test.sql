-- bwc_tag:nb_steps=3
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:skip_query
set threads=1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select count(*) FROM read_csv(['data/csv/drug_exposure.csv', 'data/csv/drug_exposure.csv','data/csv/drug_exposure.csv', 'data/csv/drug_exposure.csv','data/csv/drug_exposure.csv', 'data/csv/drug_exposure.csv','data/csv/drug_exposure.csv', 'data/csv/drug_exposure.csv','data/csv/drug_exposure.csv'], buffer_size = 500)
-- bwc_tag:end_query

