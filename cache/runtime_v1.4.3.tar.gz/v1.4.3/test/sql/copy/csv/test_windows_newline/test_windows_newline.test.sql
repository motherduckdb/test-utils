-- bwc_tag:nb_steps=10
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test (a INTEGER, b VARCHAR, c INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY test FROM 'data/csv/test/windows_newline.csv';
-- bwc_tag:end_query

SELECT SUM(a), MIN(LENGTH(b)), MAX(LENGTH(b)), SUM(LENGTH(b)), SUM(c) FROM test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DELETE FROM test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY test FROM 'data/csv/test/windows_newline.csv' (QUOTE 'BLABLABLA', AUTO_DETECT FALSE);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test (a INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY test FROM 'data/csv/test/windows_newline_empty.csv' (HEADER 0);
-- bwc_tag:end_query

SELECT SUM(a) FROM test;
-- bwc_tag:end_query

