-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=3
LOAD 'parquet';
-- bwc_tag:end_query

COPY (SELECT i%2 AS grp, i FROM range(1000) t(i)) TO 'output/partitioned_glob.parquet' (PARTITION_BY (grp));
-- bwc_tag:end_query

SELECT grp, COUNT(*) FROM 'output/partitioned_glob.parquet' GROUP BY ALL ORDER BY ALL
-- bwc_tag:end_query

