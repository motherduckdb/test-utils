-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=11
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

SET storage_compatibility_version='v1.1.0'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER);
-- bwc_tag:end_query

COPY (SELECT DATE '1992-01-01' d) TO 'output/single_date.parquet' (FORMAT parquet);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

COPY integers FROM 'output/single_date.parquet'
-- bwc_tag:end_query

COPY (SELECT DATE '1992-01-01' d, 42 k) TO 'output/too_many_columns.parquet' (FORMAT parquet);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

COPY integers FROM 'output/too_many_columns.parquet'
-- bwc_tag:end_query

COPY (SELECT 42 i) TO 'output/f2.parquet' (FORMAT parquet);
-- bwc_tag:end_query

COPY (SELECT date '1992-01-01' d, 84 i) TO 'output/f1.parquet' (FORMAT parquet);
-- bwc_tag:end_query

-- bwc_tag:expected_result=unknown

COPY integers FROM 'output/f*.parquet' (FORMAT parquet);
-- bwc_tag:end_query

