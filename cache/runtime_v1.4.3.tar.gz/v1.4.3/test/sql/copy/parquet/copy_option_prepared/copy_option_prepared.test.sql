-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=4
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PREPARE statement as COPY (
	SELECT
		42 AS number,
		true AS is_even
) TO 'output/prepared_parquet_copy.parquet' (
	FORMAT parquet,
	KV_METADATA {
		number: $1,
	}
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
execute statement(42)
-- bwc_tag:end_query

select * from 'output/prepared_parquet_copy.parquet';
-- bwc_tag:end_query

