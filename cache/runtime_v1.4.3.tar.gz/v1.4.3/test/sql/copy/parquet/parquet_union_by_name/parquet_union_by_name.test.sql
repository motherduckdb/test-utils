-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=45
SET default_null_order='nulls_first';
-- bwc_tag:end_query

LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE ubn1(a BIGINT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE ubn2(a INTEGER, b INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE ubn3(a INTEGER, c INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO ubn1 VALUES (1), (2), (9223372036854775807);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO ubn2 VALUES (3,4), (5, 6);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO ubn3 VALUES (100,101), (102, 103);
-- bwc_tag:end_query

COPY ubn1 TO 'output/ubn1.parquet' WITH (FORMAT PARQUET);
-- bwc_tag:end_query

COPY ubn2 TO 'output/ubn2.parquet' WITH (FORMAT PARQUET);
-- bwc_tag:end_query

COPY ubn3 TO 'output/ubn3.parquet' WITH (FORMAT PARQUET);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT a,b,c FROM parquet_scan('output/ubn*.parquet')
-- bwc_tag:end_query

SELECT a,b,c 
FROM parquet_scan('output/ubn*.parquet', UNION_BY_NAME=TRUE) 
ORDER BY a;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT a 
FROM parquet_scan(['output/ubn2.parquet', 'output/ubn1.parquet', 'output/ubn3.parquet']) 
ORDER BY a;
-- bwc_tag:end_query

SELECT a 
FROM parquet_scan('output/ubn*.parquet', UNION_BY_NAME=TRUE) 
ORDER BY a;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT b
FROM parquet_scan('output/ubn*.parquet') 
ORDER BY b;
-- bwc_tag:end_query

SELECT b
FROM parquet_scan('output/ubn*.parquet', UNION_BY_NAME=TRUE) 
ORDER BY b;
-- bwc_tag:end_query

SELECT typeof(a), typeof(b), typeof(c)
FROM parquet_scan('output/ubn*.parquet', UNION_BY_NAME=TRUE)
LIMIT 1;
-- bwc_tag:end_query

COPY (SELECT [42::INT] a, [43::INT] b) TO 'output/listubn1.parquet' (FORMAT PARQUET)
-- bwc_tag:end_query

COPY (SELECT [44::BIGINT] b, [45::INT] c) TO 'output/listubn2.parquet' (FORMAT PARQUET)
-- bwc_tag:end_query

SELECT a,b,c 
FROM parquet_scan('output/listubn[12].parquet', union_by_name=true)
ORDER BY a;
-- bwc_tag:end_query

SELECT typeof(a),typeof(b),typeof(c)
FROM parquet_scan('output/listubn[12].parquet', union_by_name=true)
LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA threads=1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE ubn1(a BIGINT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE ubn2(a INTEGER, b INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE ubn3(a INTEGER, c INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO ubn1 VALUES (1), (2), (9223372036854775807);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO ubn2 VALUES (3,4), (5, 6);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO ubn3 VALUES (100,101), (102, 103);
-- bwc_tag:end_query

COPY ubn1 TO 'output/ubn1.parquet' WITH (FORMAT PARQUET);
-- bwc_tag:end_query

COPY ubn2 TO 'output/ubn2.parquet' WITH (FORMAT PARQUET);
-- bwc_tag:end_query

COPY ubn3 TO 'output/ubn3.parquet' WITH (FORMAT PARQUET);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT a,b,c FROM parquet_scan('output/ubn*.parquet')
-- bwc_tag:end_query

SELECT a,b,c 
FROM parquet_scan('output/ubn*.parquet', UNION_BY_NAME=TRUE) 
ORDER BY a;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT a 
FROM parquet_scan(['output/ubn2.parquet', 'output/ubn1.parquet', 'output/ubn3.parquet']) 
ORDER BY a;
-- bwc_tag:end_query

SELECT a 
FROM parquet_scan('output/ubn*.parquet', UNION_BY_NAME=TRUE) 
ORDER BY a;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT b
FROM parquet_scan('output/ubn*.parquet') 
ORDER BY b;
-- bwc_tag:end_query

SELECT b
FROM parquet_scan('output/ubn*.parquet', UNION_BY_NAME=TRUE) 
ORDER BY b;
-- bwc_tag:end_query

SELECT typeof(a), typeof(b), typeof(c)
FROM parquet_scan('output/ubn*.parquet', UNION_BY_NAME=TRUE)
LIMIT 1;
-- bwc_tag:end_query

COPY (SELECT [42::INT] a, [43::INT] b) TO 'output/listubn1.parquet' (FORMAT PARQUET)
-- bwc_tag:end_query

COPY (SELECT [44::BIGINT] b, [45::INT] c) TO 'output/listubn2.parquet' (FORMAT PARQUET)
-- bwc_tag:end_query

SELECT a,b,c 
FROM parquet_scan('output/listubn[12].parquet', union_by_name=true)
ORDER BY a;
-- bwc_tag:end_query

SELECT typeof(a),typeof(b),typeof(c)
FROM parquet_scan('output/listubn[12].parquet', union_by_name=true)
LIMIT 1;
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA threads=1
-- bwc_tag:end_query

