-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=16
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test AS SELECT 'thisisaverylongstringbutitrepeatsmanytimessoitshighlycompressible' || (range % 10) i FROM range(100000)
-- bwc_tag:end_query

COPY test TO 'output/dictionary_compression_ratio_threshold.parquet' (dictionary_compression_ratio_threshold -2)
-- bwc_tag:end_query

COPY test TO 'output/dictionary_compression_ratio_threshold.parquet'
-- bwc_tag:end_query

SELECT dictionary_page_offset IS NULL FROM parquet_metadata('output/dictionary_compression_ratio_threshold.parquet')
-- bwc_tag:end_query

COPY test TO 'output/dictionary_compression_ratio_threshold.parquet' (dictionary_compression_ratio_threshold -1)
-- bwc_tag:end_query

SELECT dictionary_page_offset IS NULL FROM parquet_metadata('output/dictionary_compression_ratio_threshold.parquet')
-- bwc_tag:end_query

COPY test TO 'output/dictionary_compression_ratio_threshold.parquet' (dictionary_compression_ratio_threshold 10)
-- bwc_tag:end_query

SELECT dictionary_page_offset IS NULL FROM parquet_metadata('output/dictionary_compression_ratio_threshold.parquet')
-- bwc_tag:end_query

COPY test TO 'output/dictionary_compression_ratio_threshold.parquet' (dictionary_compression_ratio_threshold 20)
-- bwc_tag:end_query

SELECT dictionary_page_offset IS NULL FROM parquet_metadata('output/dictionary_compression_ratio_threshold.parquet')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE test AS SELECT 'coolstring' || range i FROM range(100000)
-- bwc_tag:end_query

COPY test TO 'output/dictionary_compression_ratio_threshold.parquet'
-- bwc_tag:end_query

SELECT dictionary_page_offset IS NULL FROM parquet_metadata('output/dictionary_compression_ratio_threshold.parquet')
-- bwc_tag:end_query

COPY test TO 'output/dictionary_compression_ratio_threshold.parquet' (dictionary_compression_ratio_threshold 0)
-- bwc_tag:end_query

SELECT dictionary_page_offset IS NULL FROM parquet_metadata('output/dictionary_compression_ratio_threshold.parquet')
-- bwc_tag:end_query

