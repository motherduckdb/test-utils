-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=11
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA threads=4
-- bwc_tag:end_query

select count(*) from parquet_scan('data/parquet-testing/glob/t?.parquet')
-- bwc_tag:end_query

select count(*) from parquet_scan('data/parquet-testing/glob/*')
-- bwc_tag:end_query

select count(*) from parquet_scan('data/parquet-testing/glob/*.parquet')
-- bwc_tag:end_query

select count(*) from parquet_scan('data/parquet-testing/g*/*.parquet')
-- bwc_tag:end_query

select count(*) from parquet_scan('data/parquet-testing/g*/t1.parquet')
-- bwc_tag:end_query

SET parquet_metadata_cache=true
-- bwc_tag:end_query

select count(*) from parquet_scan('data/parquet-testing/g*/t1.parquet')
-- bwc_tag:end_query

select count(*) from parquet_scan('data/parquet-testing/g*/t1.parquet')
-- bwc_tag:end_query

