-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=11
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE list AS SELECT * FROM (VALUES
	([1, 2, 3]),
	([4, 5]),
	([6, 7]),
    ([8, 9, 10, 11])
) tbl(i);
-- bwc_tag:end_query

COPY list TO 'output/test_list.parquet' (FORMAT 'parquet');
-- bwc_tag:end_query

SELECT i FROM parquet_scan('output/test_list.parquet');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE null_empty_list AS SELECT * FROM (VALUES
	([1, 2, 3]),
	([4, 5]),
	([6, 7]),
	([NULL]),
	([]),
	([]),
	([]),
	([]),
    ([8, NULL, 10, 11]),
    (NULL)
) tbl(i);
-- bwc_tag:end_query

COPY null_empty_list TO 'output/test_list.parquet' (FORMAT 'parquet');
-- bwc_tag:end_query

SELECT * FROM parquet_scan('output/test_list.parquet');
-- bwc_tag:end_query

COPY (SELECT []::INT[]) TO 'output/test_empty_list.parquet' (FORMAT 'parquet');
-- bwc_tag:end_query

SELECT * FROM 'output/test_empty_list.parquet'
-- bwc_tag:end_query

COPY (SELECT NULL::INT[]) TO 'output/test_null_list.parquet' (FORMAT 'parquet');
-- bwc_tag:end_query

SELECT * FROM 'output/test_null_list.parquet'
-- bwc_tag:end_query

