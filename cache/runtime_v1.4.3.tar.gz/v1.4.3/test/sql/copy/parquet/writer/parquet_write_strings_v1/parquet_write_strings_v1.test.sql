-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=27
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE strings(s VARCHAR);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO strings VALUES
	('happy'), ('happy'), ('joy'), ('joy'),
	('happy'), ('happy'), ('joy'), ('joy'),
    ('happy'), ('happy'), ('joy'), ('joy'),
    ('happy'), ('happy'), ('joy'), ('joy'),
    ('happy'), ('happy'), ('joy'), ('joy'),
    ('happy'), ('happy'), ('joy'), ('joy'),
    ('happy'), ('happy'), ('joy'), ('joy'), ('surprise');
-- bwc_tag:end_query

COPY strings TO 'output/strings.parquet' (FORMAT PARQUET, PARQUET_VERSION v1);
-- bwc_tag:end_query

SELECT encodings FROM parquet_metadata('output/strings.parquet')
-- bwc_tag:end_query

SELECT * FROM 'output/strings.parquet'
-- bwc_tag:end_query

SELECT stats_distinct_count FROM parquet_metadata('output/strings.parquet')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
UPDATE strings SET s=NULL WHERE s='joy'
-- bwc_tag:end_query

COPY strings TO 'output/strings.parquet' (FORMAT PARQUET);
-- bwc_tag:end_query

SELECT * FROM 'output/strings.parquet'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
UPDATE strings SET s=NULL
-- bwc_tag:end_query

COPY strings TO 'output/strings.parquet' (FORMAT PARQUET);
-- bwc_tag:end_query

SELECT * FROM 'output/strings.parquet'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DELETE FROM strings
-- bwc_tag:end_query

COPY strings TO 'output/strings.parquet' (FORMAT PARQUET);
-- bwc_tag:end_query

SELECT * FROM 'output/strings.parquet'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DELETE FROM strings
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO strings VALUES
	('0'), ('1'), ('2'), ('3'), ('4'), ('5'), ('6'), ('7'), ('8'), ('9'),
	('10'), ('11'), ('12'), ('13'), ('14'), ('15'), ('16'), ('17'), ('18'), ('19'),
	('20'), ('21'), ('22'), ('23'), ('24'), ('25'), ('26'), ('27'), ('28'), ('29')
-- bwc_tag:end_query

COPY strings TO 'output/strings.parquet' (FORMAT PARQUET);
-- bwc_tag:end_query

SELECT encodings FROM parquet_metadata('output/strings.parquet')
-- bwc_tag:end_query

SELECT * FROM 'output/strings.parquet'
-- bwc_tag:end_query

SELECT stats_distinct_count FROM parquet_metadata('output/strings.parquet')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DELETE FROM strings
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO strings VALUES
	('0'), ('1'), ('2'), (NULL), ('4'), ('5'), ('6'), (NULL), ('8'), ('9'),
	('10'), ('11'), ('12'), ('13'), ('14'), ('15'), ('16'), ('17'), ('18'), ('19'),
	('20'), (NULL), ('22'), ('23'), ('24'), ('25'), (NULL), ('27'), ('28'), ('29')
-- bwc_tag:end_query

COPY strings TO 'output/strings.parquet' (FORMAT PARQUET);
-- bwc_tag:end_query

SELECT * FROM 'output/strings.parquet'
-- bwc_tag:end_query

