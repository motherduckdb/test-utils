-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=11
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:load_db=parquet_write_memory_usage

ATTACH 'output/parquet_write_memory_usage.db' AS parquet_write_memory_usage;
-- bwc_tag:end_query

-- bwc_tag:skip_query
set threads=1
-- bwc_tag:end_query

set memory_limit='0.8mb'
-- bwc_tag:end_query

copy (select * from range(163840)) to 'output/parquet_write_memory_usage.parquet' (row_group_size 20480)
-- bwc_tag:end_query

set memory_limit='4gb'
-- bwc_tag:end_query

select sum(range) = (count(*) * (count(*) - 1)) // 2 from 'output/parquet_write_memory_usage.parquet'
-- bwc_tag:end_query

set memory_limit='1.6mb'
-- bwc_tag:end_query

copy (select * from range(163840)) to 'output/parquet_write_memory_usage.parquet' (row_group_size 40960)
-- bwc_tag:end_query

set memory_limit='4gb'
-- bwc_tag:end_query

select sum(range) = (count(*) * (count(*) - 1)) // 2 from 'output/parquet_write_memory_usage.parquet'
-- bwc_tag:end_query

