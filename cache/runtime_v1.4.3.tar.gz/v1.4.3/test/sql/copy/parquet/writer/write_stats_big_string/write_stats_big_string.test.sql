-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=9
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE varchar(v VARCHAR);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO varchar VALUES (NULL), ('hello'), (NULL), ('world'), (NULL)
-- bwc_tag:end_query

COPY varchar TO 'output/bigvarchar.parquet'
-- bwc_tag:end_query

SELECT stats_min_value, stats_max_value, stats_min, stats_max, min_is_exact, max_is_exact FROM parquet_metadata('output/bigvarchar.parquet')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO varchar SELECT repeat('A', 100000) v
-- bwc_tag:end_query

COPY varchar TO 'output/bigvarchar.parquet'
-- bwc_tag:end_query

SELECT stats_min_value, stats_max_value, stats_min, stats_max, min_is_exact, max_is_exact FROM parquet_metadata('output/bigvarchar.parquet')
-- bwc_tag:end_query

