-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=9
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE dates(d DATE)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO dates VALUES (DATE '1992-01-01'), (DATE '1900-01-01'), (NULL), (DATE '2020-09-27')
-- bwc_tag:end_query

SELECT * FROM dates
-- bwc_tag:end_query

COPY dates TO 'output/dates.parquet' (FORMAT 'parquet');
-- bwc_tag:end_query

SELECT * FROM 'output/dates.parquet'
-- bwc_tag:end_query

SELECT typeof(d) FROM 'output/dates.parquet' LIMIT 1
-- bwc_tag:end_query

SELECT * FROM 'output/dates.parquet' WHERE d='1992-01-01'
-- bwc_tag:end_query

