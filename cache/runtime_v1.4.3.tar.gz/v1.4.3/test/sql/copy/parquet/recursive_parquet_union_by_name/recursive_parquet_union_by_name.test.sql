-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=4
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create view r AS from read_parquet('data/parquet-testing/hive-partitioning/union_by_name/*/*.parquet', hive_partitioning=1, union_by_name=1)
-- bwc_tag:end_query

WITH RECURSIVE t(it, accum) AS
(
	SELECT 1, 0
	UNION ALL
	(
		SELECT it + 1, accum + j
		FROM t, r
		WHERE it <= x
	)
)
SELECT * FROM t ORDER BY it, accum;
-- bwc_tag:end_query

