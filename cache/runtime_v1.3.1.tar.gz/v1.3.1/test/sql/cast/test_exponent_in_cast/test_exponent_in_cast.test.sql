-- bwc_tag:nb_steps=11
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT CAST('e1' AS INTEGER);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT CAST('  e1' AS INTEGER);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT CAST('  E1' AS INTEGER);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT CAST('e1' AS DOUBLE);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT CAST('  e1' AS DOUBLE);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT CAST('  E1' AS DOUBLE);
-- bwc_tag:end_query

SELECT CAST('1e1' AS INTEGER);
-- bwc_tag:end_query

SELECT CAST('  1e1' AS INTEGER);
-- bwc_tag:end_query

SELECT CAST('1e1' AS DOUBLE);
-- bwc_tag:end_query

SELECT CAST('   1e1' AS DOUBLE);
-- bwc_tag:end_query

