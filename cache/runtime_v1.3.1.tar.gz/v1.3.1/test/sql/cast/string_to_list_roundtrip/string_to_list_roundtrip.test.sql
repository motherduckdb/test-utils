-- bwc_tag:nb_steps=7
select $$[\"abc\", def, ghi]$$::VARCHAR[] a, a::VARCHAR::VARCHAR[] b, a == b
-- bwc_tag:end_query

COPY (select $$[\"abc\", def, ghi]$$::VARCHAR[] a) TO 'output/copy_test.csv' (FORMAT CSV);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select a, a::VARCHAR[] from read_csv('output/copy_test.csv') t(a);
-- bwc_tag:end_query

select $$["  \"abc\"  ", def, ghi]$$::VARCHAR[] a, a::VARCHAR::VARCHAR[] b, a == b
-- bwc_tag:end_query

select $$[\  \\abc\\ \ , def, ghi]$$::VARCHAR[] a, a::VARCHAR::VARCHAR[] b, a == b
-- bwc_tag:end_query

select $$["\  \\abc\\ \ ", def, ghi]$$::VARCHAR[] a, a::VARCHAR::VARCHAR[] b, a == b
-- bwc_tag:end_query

select $$[{}]$$::VARCHAR[] a, a::VARCHAR::VARCHAR[] b, a == b
-- bwc_tag:end_query

