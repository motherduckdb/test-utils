-- bwc_tag:nb_steps=7
-- bwc_tag:execute_from_sql
create sequence seq;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table integers(i integer default nextval('seq'));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

drop sequence seq;
-- bwc_tag:end_query

-- bwc_tag:skip_query
begin transaction;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop table integers;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop sequence seq;
-- bwc_tag:end_query

-- bwc_tag:skip_query
commit
-- bwc_tag:end_query

