-- bwc_tag:nb_steps=116
-- bwc_tag:execute_from_sql
CREATE SEQUENCE seq;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE SEQUENCE seq;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE IF NOT EXISTS seq;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('seq')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE SEQUENCE seq
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('seq')
-- bwc_tag:end_query

SELECT currval('seq')
-- bwc_tag:end_query

SELECT currval('seq')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('seq')
-- bwc_tag:end_query

SELECT currval('seq')
-- bwc_tag:end_query

SELECT currval('seq')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('seq'), nextval('seq');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval(NULL)
-- bwc_tag:end_query

SELECT currval(NULL)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT nextval(a) FROM (VALUES ('seq'), (NULL), ('seq')) tbl1(a)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT currval(a) FROM (VALUES ('seq'), (NULL), ('seq')) tbl1(a)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE SEQUENCE seq;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP SEQUENCE seq;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DROP SEQUENCE seq;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP SEQUENCE IF EXISTS seq;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE seq INCREMENT BY 2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('seq')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('"seq"')
-- bwc_tag:end_query

SELECT currval('"seq"')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP SEQUENCE seq;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE seq MINVALUE 3;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('seq')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('seq')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP SEQUENCE seq;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE seq MAXVALUE 2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('seq')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('seq')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT nextval('seq')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP SEQUENCE seq;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE seq MAXVALUE 2 CYCLE;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('seq')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('seq')
-- bwc_tag:end_query

SELECT currval('seq')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('seq')
-- bwc_tag:end_query

SELECT currval('seq')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP SEQUENCE seq;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE seq MINVALUE 3 MAXVALUE 5 START WITH 4 CYCLE;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('seq')
-- bwc_tag:end_query

SELECT currval('seq')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('seq')
-- bwc_tag:end_query

SELECT currval('seq')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('seq')
-- bwc_tag:end_query

SELECT currval('seq')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP SEQUENCE seq;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE seq INCREMENT BY -1 MINVALUE 0 MAXVALUE 2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('seq')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('seq')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('seq')
-- bwc_tag:end_query

SELECT currval('seq')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT nextval('seq')
-- bwc_tag:end_query

SELECT currval('seq')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP SEQUENCE seq;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE seq INCREMENT BY 1 MINVALUE 0 MAXVALUE 2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('seq')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('seq')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('seq')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT nextval('seq')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP SEQUENCE seq;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE seq INCREMENT 1 MAXVALUE 3 START 2 CYCLE;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('seq')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('seq')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('seq')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP SEQUENCE seq;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE seq INCREMENT -1 CYCLE;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('seq')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('seq')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('seq')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP SEQUENCE seq;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE seq INCREMENT -1 MINVALUE -2 CYCLE;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('seq')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('seq')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('seq')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP SEQUENCE seq;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE SEQUENCE seq INCREMENT 1 START -1 CYCLE;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE SEQUENCE seq INCREMENT -1 START 1 CYCLE;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA a;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA b;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE a.seq;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE b.seq;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('a.seq'), nextval('b.seq');
-- bwc_tag:end_query

SELECT currval('a.seq'), currval('b.seq');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('"a"."seq"'), nextval('"b".seq');
-- bwc_tag:end_query

SELECT currval('"a"."seq"'), currval('"b".seq');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT nextval('"a"."seq');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT nextval('a.b.c.d');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE SEQUENCE seq MAXVALUE 5 START WITH 6;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE SEQUENCE seq MINVALUE 5 START WITH 4;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE SEQUENCE seq MINVALUE 7 MAXVALUE 5;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE SEQUENCE seq INCREMENT 0;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE seq;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE seq2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT nextval('s'||'e'||'q')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP SEQUENCE seq;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE seq;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE strings(s VARCHAR);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO strings VALUES ('seq'), ('seq2')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT s, nextval('seq') FROM strings
-- bwc_tag:end_query

SELECT s, currval('seq') FROM strings
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT s, nextval(s) FROM strings
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT s, currval(s) FROM strings
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO strings VALUES ('nonexistant_seq')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT s, nextval(s) FROM strings
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE fresh;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select currval('fresh');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

select nextval(1 + 1);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select currval(true);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE SEQUENCE wrongseq NO MAXVALUE MAXVALUE 2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE SEQUENCE wrongseq MINVALUE 10 MINVALUE 2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE SEQUENCE wrongseq START 13 START WITH 3;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE SEQUENCE wrongseq CYCLE MAXVALUE 2 MINVALUE 1 NO CYCLE;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE SEQUENCE wrongseq INCREMENT 2 INCREMENT BY -1;
-- bwc_tag:end_query

