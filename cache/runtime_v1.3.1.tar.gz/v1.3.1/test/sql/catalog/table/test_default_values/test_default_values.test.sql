-- bwc_tag:nb_steps=12
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table x (i int default 1, j int default 2)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into x default values;
-- bwc_tag:end_query

SELECT * FROM x
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into x default values returning (i);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into x default values returning (j);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

insert into x(i) default values;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop table x;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table x (i int primary key default 1, j int default 2)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into x default values;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

insert into x default values;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into x default values on conflict do nothing;
-- bwc_tag:end_query

