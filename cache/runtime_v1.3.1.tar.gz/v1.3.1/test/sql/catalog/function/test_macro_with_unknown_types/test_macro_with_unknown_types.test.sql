-- bwc_tag:nb_steps=3
-- bwc_tag:skip_query
PRAGMA enable_verification;
-- bwc_tag:end_query

CREATE TEMP MACRO m1(x, y) AS (
    SELECT list_has_all(x, y) AND list_has_all(y, x)
);
-- bwc_tag:end_query

SELECT m1([1, 2], [1, 2]);
-- bwc_tag:end_query

