-- bwc_tag:nb_steps=5
SET autoload_known_extensions=false;
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

SELECT COUNT(*)
FROM range(
  current_date,
  current_date + interval '7' days,
  interval '1 day'
)
-- bwc_tag:end_query

SELECT to_timestamp(range) as entry
    FROM range(
      epoch(date_trunc('month', current_date))::BIGINT,
      epoch(date_trunc('month', current_date) + interval '1 month' - interval '1 day')::BIGINT,
      epoch(interval '1 day')::BIGINT
    )
-- bwc_tag:end_query

SELECT to_timestamp(range) as entry
FROM range(
  epoch(date_trunc('month', current_date))::BIGINT,
  epoch(date_trunc('month', current_date) + interval '1 month' - interval '1 day')::BIGINT,
  epoch(interval '1 day')::BIGINT
)
-- bwc_tag:end_query

