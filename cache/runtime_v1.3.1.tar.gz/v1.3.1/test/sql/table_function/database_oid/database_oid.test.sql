-- bwc_tag:nb_steps=3
CREATE TEMP TABLE x (x INT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE x (x INT);
-- bwc_tag:end_query

SELECT COUNT(DISTINCT database_oid) FROM duckdb_tables();
-- bwc_tag:end_query

