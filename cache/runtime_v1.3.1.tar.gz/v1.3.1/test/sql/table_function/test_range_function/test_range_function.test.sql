-- bwc_tag:nb_steps=29
SELECT * FROM range(0, 10, 1)
-- bwc_tag:end_query

CALL range(10)
-- bwc_tag:end_query

SELECT * FROM generate_series(0, 10, 1)
-- bwc_tag:end_query

SELECT * FROM range(10, 0, -1) ORDER BY 1 ASC
-- bwc_tag:end_query

SELECT * FROM generate_series(10, 0, -1) ORDER BY 1 ASC
-- bwc_tag:end_query

SELECT * FROM range(0, -5, -1)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM range(0, 10, 0)
-- bwc_tag:end_query

SELECT * FROM range(0, 10, -1)
-- bwc_tag:end_query

SELECT * FROM range(10, 0, 1)
-- bwc_tag:end_query

SELECT * FROM range(10)
-- bwc_tag:end_query

SELECT * FROM range(0, 10)
-- bwc_tag:end_query

SELECT EXISTS(SELECT * FROM range(10))
-- bwc_tag:end_query

SELECT EXISTS(SELECT * FROM range(0))
-- bwc_tag:end_query

SELECT * FROM range(10) t1(j) WHERE j=3
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM range('hello')
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM range(10, 'hello')
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM range(10, 10, 'hello')
-- bwc_tag:end_query

select * from generate_series(-2305843009213693951, 2305843009213693951, 2305843009213693951)
-- bwc_tag:end_query

select * from generate_series(2305843009213693951, -2305843009213693951, -2305843009213693951)
-- bwc_tag:end_query

select * from generate_series(0, 10, 9223372036854775807);
-- bwc_tag:end_query

select * from generate_series(0, 9223372036854775807, 9223372036854775807);
-- bwc_tag:end_query

select * from generate_series(0, -9223372036854775807, -9223372036854775807);
-- bwc_tag:end_query

select * from generate_series(-9223372036854775808, 9223372036854775807, 9223372036854775807);
-- bwc_tag:end_query

select * from generate_series(-9223372036854775807, -9223372036854775808, -1);
-- bwc_tag:end_query

select * from generate_series(-9223372036854775808, 9223372036854775807, 9223372036854775807);
-- bwc_tag:end_query

select * from generate_series(0, -9223372036854775808, -9223372036854775808);
-- bwc_tag:end_query

select * from generate_series(0, 9223372036854775807, 9223372036854775807);
-- bwc_tag:end_query

select * from generate_series(0, 10, 9223372036854775807);
-- bwc_tag:end_query

select * FROM generate_series(1, 3, 1) AS _(x), generate_series(x, 2, 1) AS __(y);
-- bwc_tag:end_query

