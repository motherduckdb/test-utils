-- bwc_tag:nb_steps=4
SELECT * FROM duckdb_dependencies();
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE INDEX i_index ON integers(i)
-- bwc_tag:end_query

SELECT * FROM duckdb_dependencies();
-- bwc_tag:end_query

