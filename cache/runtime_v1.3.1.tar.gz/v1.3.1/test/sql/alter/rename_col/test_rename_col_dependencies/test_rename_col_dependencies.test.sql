-- bwc_tag:nb_steps=6
-- bwc_tag:execute_from_sql
CREATE TABLE test(i INTEGER, j INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PREPARE v1 AS SELECT i, j FROM test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PREPARE v2 AS SELECT * FROM test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test RENAME COLUMN i TO k
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

EXECUTE v1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
EXECUTE v2
-- bwc_tag:end_query

