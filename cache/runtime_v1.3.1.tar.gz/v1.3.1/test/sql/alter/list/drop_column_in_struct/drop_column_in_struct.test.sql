-- bwc_tag:nb_steps=10
-- bwc_tag:execute_from_sql
CREATE TABLE test(
	s STRUCT(
		i INTEGER,
		j INTEGER
	)[]
)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES
	([ROW(1, 1)]),
	([ROW(2, 2)])
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE test DROP COLUMN s.element
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test DROP COLUMN s.element.j
-- bwc_tag:end_query

select * from test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop table test;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test(
	s STRUCT(
		a STRUCT(
			i INTEGER,
			j INTEGER
		)[]
	)
)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES
	(ROW([ROW(1, 1)])),
	(ROW([ROW(2, 2)]))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test DROP COLUMN s.a.element.i
-- bwc_tag:end_query

select * from test
-- bwc_tag:end_query

