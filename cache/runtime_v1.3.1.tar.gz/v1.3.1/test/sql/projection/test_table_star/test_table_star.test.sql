-- bwc_tag:nb_steps=15
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test (a INTEGER, b INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (11, 22), (12, 21), (13, 22)
-- bwc_tag:end_query

SELECT * FROM test
-- bwc_tag:end_query

SELECT test.* FROM test
-- bwc_tag:end_query

SELECT t.* FROM test t
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT test.* FROM test t
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT xyz.* FROM test
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT xyz.*
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table r4 (i int, j int)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into r4 (i, j) values (1,1), (1,2), (1,3), (1,4), (1,5)
-- bwc_tag:end_query

select t1.i, t1.j as a, t2.j as b from r4 t1 inner join r4 t2 using(i,j) ORDER BY a
-- bwc_tag:end_query

select t1.i, t1.j as a, t2.j as b from r4 t1 inner join r4 t2 on t1.i=t2.i and t1.j=t2.j ORDER BY a
-- bwc_tag:end_query

select t1.*, t2.j b from r4 t1 inner join r4 t2 using(i,j) ORDER BY t1.j
-- bwc_tag:end_query

select t1.*, t2.j b from r4 t1 inner join r4 t2 on t1.i=t2.i and t1.j=t2.j ORDER BY t1.j
-- bwc_tag:end_query

