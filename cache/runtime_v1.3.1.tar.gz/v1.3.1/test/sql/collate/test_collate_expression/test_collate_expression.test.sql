-- bwc_tag:nb_steps=11
-- bwc_tag:execute_from_sql
CREATE TABLE collate_test(s VARCHAR)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO collate_test VALUES ('hEllO'), ('WöRlD'), ('wozld')
-- bwc_tag:end_query

SELECT 'hëllo' COLLATE NOACCENT='hello'
-- bwc_tag:end_query

SELECT 'hëllo' COLLATE POSIX='hello'
-- bwc_tag:end_query

SELECT 'hëllo' COLLATE C='hello'
-- bwc_tag:end_query

SELECT * FROM collate_test WHERE s='hello'
-- bwc_tag:end_query

SELECT * FROM collate_test WHERE s='hello' COLLATE NOCASE
-- bwc_tag:end_query

SELECT * FROM collate_test WHERE s COLLATE NOCASE='hello'
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT * FROM collate_test WHERE s COLLATE NOCASE='hello' COLLATE NOACCENT
-- bwc_tag:end_query

SELECT * FROM collate_test ORDER BY s COLLATE NOCASE
-- bwc_tag:end_query

SELECT * FROM collate_test ORDER BY s COLLATE NOCASE.NOACCENT
-- bwc_tag:end_query

