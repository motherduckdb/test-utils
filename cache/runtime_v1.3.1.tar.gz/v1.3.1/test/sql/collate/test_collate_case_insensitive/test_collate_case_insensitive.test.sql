-- bwc_tag:nb_steps=16
-- bwc_tag:execute_from_sql
CREATE TABLE collate_test(s VARCHAR COLLATE NOCASE)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO collate_test VALUES ('hello'), ('WoRlD'), ('world'), ('Mühleisen')
-- bwc_tag:end_query

SELECT * FROM collate_test WHERE s='HeLlo'
-- bwc_tag:end_query

SELECT * FROM collate_test WHERE s='MÜhleisen'
-- bwc_tag:end_query

SELECT * FROM collate_test WHERE s='world'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE collate_join_table(s VARCHAR, i INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO collate_join_table VALUES ('HeLlO', 1), ('mÜHLEISEN', 3)
-- bwc_tag:end_query

SELECT collate_test.s, collate_join_table.s, i FROM collate_test JOIN collate_join_table ON (collate_test.s=collate_join_table.s) ORDER BY i
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE collate_test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE collate_test(s VARCHAR COLLATE NOCASE)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO collate_test VALUES ('Hallo'), ('ham'), ('HELLO'), ('hElp')
-- bwc_tag:end_query

SELECT * FROM collate_test ORDER BY s
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE collate_test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE collate_test(s VARCHAR COLLATE NOCASE)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO collate_test VALUES ('Hallo'), ('hallo')
-- bwc_tag:end_query

SELECT DISTINCT s FROM collate_test
-- bwc_tag:end_query

