-- bwc_tag:nb_steps=9
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (1), (2), (3), (NULL)
-- bwc_tag:end_query

SELECT i % 2 AS k FROM integers WHERE k<>0;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT i % 2 AS k FROM integers WHERE integers.k<>0;
-- bwc_tag:end_query

SELECT i % 2 AS i FROM integers WHERE i<>0;
-- bwc_tag:end_query

SELECT i % 2 AS k FROM integers WHERE integers.i<>0;
-- bwc_tag:end_query

SELECT i % 2 AS k FROM integers WHERE k=k;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT i % 2 AS o, COUNT(i) AS c FROM integers WHERE c = 0 GROUP BY o;
-- bwc_tag:end_query

