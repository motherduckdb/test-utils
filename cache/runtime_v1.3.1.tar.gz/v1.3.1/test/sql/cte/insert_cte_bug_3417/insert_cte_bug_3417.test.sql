-- bwc_tag:nb_steps=4
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE table1 (id INTEGER, a INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE table2 (table1_id INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO table2 WITH cte AS (INSERT INTO table1 SELECT 1, 2 RETURNING id) SELECT id FROM cte;
-- bwc_tag:end_query

