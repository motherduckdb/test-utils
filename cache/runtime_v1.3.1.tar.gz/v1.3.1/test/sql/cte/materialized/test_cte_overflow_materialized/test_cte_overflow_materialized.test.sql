-- bwc_tag:nb_steps=4
-- bwc_tag:execute_from_sql
create table a (id integer)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into a values (1729)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create view va as (with v as MATERIALIZED (select * from a) select * from v)
-- bwc_tag:end_query

with a as MATERIALIZED (select * from va) select * from a
-- bwc_tag:end_query

