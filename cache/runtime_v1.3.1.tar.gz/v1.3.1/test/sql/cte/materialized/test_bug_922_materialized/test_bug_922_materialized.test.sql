-- bwc_tag:nb_steps=2
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

WITH my_list(value) AS MATERIALIZED (VALUES (1), (2), (3))
    SELECT * FROM my_list LIMIT 0 OFFSET 1
-- bwc_tag:end_query

