-- bwc_tag:nb_steps=18
-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER CHECK(i < 5))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (3)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO integers VALUES (7)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (NULL)
-- bwc_tag:end_query

SELECT * FROM integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE integers;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER CHECK(i + j < 10), j INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (3, 3)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO integers VALUES (5, 5)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO integers VALUES (3, 3), (5, 5)
-- bwc_tag:end_query

SELECT * FROM integers
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE TABLE indirect_subq(
	i INTEGER,
	CHECK (i > (2 * (SELECT(1))))
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE TABLE integers2(i INTEGER CHECK(i > (SELECT 42)), j INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE TABLE integers2(i INTEGER CHECK(i > SUM(j)), j INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE TABLE integers3(i INTEGER CHECK(k < 10), j INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE TABLE integers3(i INTEGER CHECK(integers3.k < 10), j INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE TABLE integers3(i INTEGER CHECK(integers2.i < 10), j INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers4(i INTEGER CHECK(integers4.i < 10), j INTEGER)
-- bwc_tag:end_query

