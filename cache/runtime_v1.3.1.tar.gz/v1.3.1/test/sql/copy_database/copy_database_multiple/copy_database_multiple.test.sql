-- bwc_tag:nb_steps=7
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

ATTACH ':memory:' AS db1;
-- bwc_tag:end_query

ATTACH ':memory:' AS db2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE db1.tbl1 AS FROM range(3) r(i);
-- bwc_tag:end_query

COPY FROM DATABASE db1 TO db2;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

COPY FROM DATABASE db1 TO db2;
-- bwc_tag:end_query

FROM db2.tbl1
-- bwc_tag:end_query

