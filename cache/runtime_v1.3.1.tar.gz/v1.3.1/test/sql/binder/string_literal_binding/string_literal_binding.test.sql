-- bwc_tag:nb_steps=19
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

select '01'=1;
-- bwc_tag:end_query

SELECT cos('0')
-- bwc_tag:end_query

select date '1992-01-01'>'1991-01-01';
-- bwc_tag:end_query

select date '2023-12-11' < '2023-12-11 15:54:45.119';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test (
    "date" DATE,
    value VARCHAR
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES ('2023-08-01', 1), ('2023-08-02', 2), ('2023-08-03', 3), ('2023-08-04', 4), ('2023-08-05', 5), ('2023-08-06', 6), ('2023-08-07', 7);
-- bwc_tag:end_query

SELECT * FROM test WHERE date >= '2023-08-05 00:00:00' AND date < '2023-08-06 00:00:00';
-- bwc_tag:end_query

SELECT '[hello]'[1];
-- bwc_tag:end_query

SELECT list('hello world')
-- bwc_tag:end_query

select 1 IN ('1', '2');
-- bwc_tag:end_query

SELECT COALESCE(1, '1');
-- bwc_tag:end_query

select i=1 from (values ('01')) t(i);
-- bwc_tag:end_query

select i IN (1) from (values ('01')) t(i);
-- bwc_tag:end_query

WITH cte AS (SELECT '01' AS s)
SELECT 1=s AS in_res FROM cte;
-- bwc_tag:end_query

WITH cte AS (SELECT '01' AS s)
SELECT 1 IN (s) AS in_res FROM cte;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select i>1 from (values ('01')) t(i);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select date '1992-01-01'>i from (values ('1991-01-01')) t(i);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select d[1] from (values (date '1992-01-01')) t(d);
-- bwc_tag:end_query

