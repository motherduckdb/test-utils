-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=11
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE seq
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE weird_tbl(id INT DEFAULT nextval('seq'), key VARCHAR)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO weird_tbl (key) VALUES
	('/'),
	('\/\/'),
	('==='),
	('value with strings'),
	('?:&'),
	('🦆'),
	('==='),
	('===');
-- bwc_tag:end_query

COPY weird_tbl TO 'output/escaped_partitions' (FORMAT PARQUET, PARTITION_BY(key))
-- bwc_tag:end_query

select key, COUNT(*)
from parquet_scan('output/escaped_partitions/**/*.parquet')
GROUP BY ALL
ORDER BY ALL
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE weird_tbl RENAME COLUMN key TO "=/ \\/"
-- bwc_tag:end_query

COPY weird_tbl TO 'output/escaped_partitions_names' (FORMAT PARQUET, PARTITION_BY("=/ \\/"))
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select "=/ \\/", COUNT(*)
from parquet_scan('output/escaped_partitions_names/**/*.parquet')
GROUP BY ALL
ORDER BY ALL
-- bwc_tag:end_query

COPY weird_tbl TO 'output/escaped_partitions_names' (FORMAT PARQUET, PARTITION_BY("=/ \\/"), OVERWRITE, WRITE_PARTITION_COLUMNS)
-- bwc_tag:end_query

select "=/ \\/", COUNT(*)
from parquet_scan('output/escaped_partitions_names/**/*.parquet')
GROUP BY ALL
ORDER BY ALL
-- bwc_tag:end_query

