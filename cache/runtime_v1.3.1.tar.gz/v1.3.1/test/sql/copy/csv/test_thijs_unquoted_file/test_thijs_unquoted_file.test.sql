-- bwc_tag:nb_steps=7
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

from read_csv('data/csv/thijs_unquoted.csv', quote='"', sep='|', escape='"', columns={'a':'varchar', 'b': 'varchar', 'c': 'integer'}, auto_detect=false);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
from read_csv('data/csv/thijs_unquoted.csv', quote='"', sep='|', escape='"', columns={'a':'varchar', 'b': 'varchar', 'c': 'integer'}, auto_detect=false, strict_mode = False);
-- bwc_tag:end_query

SELECT DELIMITER, QUOTE FROM sniff_csv('data/csv/rabo-anon.csv.gz', strict_mode=FALSE)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE T AS FROM read_csv('data/csv/rabo-anon.csv.gz', strict_mode=FALSE);
-- bwc_tag:end_query

select count(*) from T
-- bwc_tag:end_query

select * from T limit 1
-- bwc_tag:end_query

