-- bwc_tag:nb_steps=3
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA verify_parallelism
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT count(*) FROM read_csv_auto ('data/csv/auto/titlebasicsdebug.tsv', nullstr='\N', sample_size = -1);
-- bwc_tag:end_query

