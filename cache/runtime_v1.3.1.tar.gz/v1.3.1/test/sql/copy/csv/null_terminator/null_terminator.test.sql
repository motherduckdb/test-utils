-- bwc_tag:nb_steps=8
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM 'data/csv/null_terminator.csv'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/null_terminator.csv', header = 0)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/null_terminator.csv', header = 0, escape = '')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/null_terminator.csv', header = 0, delim = '\t', quote = '', escape = '')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create or replace table t as (from values ('a' || chr(0) || 'b') t(i));
-- bwc_tag:end_query

copy t to 'output/csv2tsv.tsv' (header false, delimiter '\t', escape '', quote '');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('output/csv2tsv.tsv', header = 0)
-- bwc_tag:end_query

