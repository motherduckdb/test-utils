-- bwc_tag:nb_steps=13
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE date_tests (a DATE)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
copy date_tests from 'data/csv/auto_date/date_example_1.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
copy date_tests from 'data/csv/auto_date/date_example_2.csv';
-- bwc_tag:end_query

FROM date_tests
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE date_tests
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE date_tests (a DATE)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
copy date_tests from 'data/csv/auto_date/date_example_1.csv' WITH (dateformat 'AUTO');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
copy date_tests from 'data/csv/auto_date/date_example_2.csv' WITH (dateformat 'AUTO');
-- bwc_tag:end_query

FROM date_tests
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE stg_device_metadata_with_dates (
    device_id VARCHAR,
    device_name VARCHAR,
    device_type VARCHAR,
    manufacturer VARCHAR,
    model_number VARCHAR,
    firmware_version VARCHAR,
    installation_date DATE,
    location_id VARCHAR,
    location_name VARCHAR,
    facility_zone VARCHAR,
    is_active BOOLEAN,
    expected_lifetime_months INT,
    maintenance_interval_days INT,
    last_maintenance_date DATE
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY stg_device_metadata_with_dates
 FROM 'data/csv/auto_date/device_metadata_1.csv' WITH (
 delimiter ',',
 skip '1',
 header 'false'
)
-- bwc_tag:end_query

FROM stg_device_metadata_with_dates
-- bwc_tag:end_query

