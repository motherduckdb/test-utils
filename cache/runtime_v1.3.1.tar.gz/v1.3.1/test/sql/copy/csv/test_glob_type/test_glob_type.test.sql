-- bwc_tag:nb_steps=9
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT typeof(bar) FROM 'data/csv/17451/*.csv' limit 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE T AS SELECT 'bar,baz', UNION ALL SELECT ',baz' from range (0,100000)
-- bwc_tag:end_query

COPY T TO 'output/t.csv' (QUOTE '', HEADER 0)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT typeof(bar) FROM read_csv(['data/csv/17451/1.csv', 'output/t.csv']) limit 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT typeof(bar) FROM read_csv(['data/csv/17451/1.csv','data/csv/17451/1.csv','data/csv/17451/1.csv','data/csv/17451/1.csv','data/csv/17451/1.csv','data/csv/17451/1.csv','data/csv/17451/1.csv','data/csv/17451/1.csv','data/csv/17451/1.csv','data/csv/17451/1.csv','data/csv/17451/1.csv','data/csv/17451/2.csv','data/csv/17451/extra/3.csv'], files_to_sniff = 0) limit 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT typeof(bar) FROM read_csv(['data/csv/17451/1.csv','data/csv/17451/1.csv','data/csv/17451/1.csv','data/csv/17451/1.csv','data/csv/17451/1.csv','data/csv/17451/1.csv','data/csv/17451/1.csv','data/csv/17451/1.csv','data/csv/17451/1.csv','data/csv/17451/1.csv','data/csv/17451/1.csv','data/csv/17451/2.csv','data/csv/17451/extra/3.csv'], files_to_sniff = 5) limit 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

FROM read_csv(['data/csv/17451/1.csv','data/csv/17451/1.csv','data/csv/17451/1.csv','data/csv/17451/1.csv','data/csv/17451/1.csv','data/csv/17451/1.csv','data/csv/17451/1.csv','data/csv/17451/1.csv','data/csv/17451/1.csv','data/csv/17451/1.csv','data/csv/17451/1.csv','data/csv/17451/2.csv','data/csv/17451/extra/3.csv'], files_to_sniff = 5)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT typeof(bar) FROM read_csv(['data/csv/17451/1.csv','data/csv/17451/1.csv','data/csv/17451/1.csv','data/csv/17451/1.csv','data/csv/17451/1.csv','data/csv/17451/1.csv','data/csv/17451/1.csv','data/csv/17451/1.csv','data/csv/17451/1.csv','data/csv/17451/1.csv','data/csv/17451/1.csv','data/csv/17451/2.csv','data/csv/17451/extra/3.csv'], files_to_sniff = -1) limit 1
-- bwc_tag:end_query

