-- bwc_tag:nb_steps=23
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
from read_csv('data/csv/unescaped_quotes/stops.csv');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
from read_csv('data/csv/unescaped_quotes/stops.csv', strict_mode=false);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
from read_csv('data/csv/unescaped_quotes/unescaped_quote.csv', escape = '"', strict_mode=false);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
from read_csv('data/csv/unescaped_quotes/unescaped_quote.csv', strict_mode=false, escape = '', quote = '"', delim = ';');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
from read_csv('data/csv/unescaped_quotes/unescaped_quote.csv', strict_mode=false, escape = '', buffer_size = 30, header = 0)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
from read_csv('data/csv/unescaped_quotes/unescaped_quote.csv', strict_mode=false, escape = '', buffer_size = 31, header = 0)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
from read_csv('data/csv/unescaped_quotes/unescaped_quote.csv', strict_mode=false, escape = '', buffer_size = 32, header = 0)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
from read_csv('data/csv/unescaped_quotes/unescaped_quote.csv', strict_mode=false, escape = '', buffer_size = 33, header = 0)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
from read_csv('data/csv/unescaped_quotes/unescaped_quote.csv', strict_mode=false, escape = '', buffer_size = 34, header = 0)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table t as from read_csv('data/csv/unescaped_quotes/unescaped_quote_new_line.csv', strict_mode=false, header = 0)
-- bwc_tag:end_query

select count(*) from t;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop table t;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

create table t as from read_csv('data/csv/unescaped_quotes/unescaped_quote_new_line_rn.csv', strict_mode=false, buffer_size = 20, header = 0, delim = ';')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table t as from read_csv('data/csv/unescaped_quotes/unescaped_quote_new_line.csv', strict_mode=false, buffer_size = 30, header = 0, parallel = false)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop table t
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table t as from read_csv('data/csv/unescaped_quotes/unescaped_quote_new_line_rn.csv', strict_mode=false, buffer_size = 30, header = 0, parallel = false)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/unescaped_quotes/end_quote.csv', columns = {'a':'varchar'}, header = false, quote = '"', strict_mode = false)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/unescaped_quotes/end_quote.csv', columns = {'a':'varchar'}, header = false, quote = '"', strict_mode = false)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/unescaped_quotes/end_quote_2.csv', columns = {'a':'varchar'}, header = false, quote = '"', strict_mode = false)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/unescaped_quotes/end_quote_3.csv', columns = {'a':'varchar'}, header = false, quote = '"', strict_mode = false)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/unescaped_quotes/some_escaped_some_not.csv', columns = {'a':'varchar'}, header = false, quote = '"', escape = '"', strict_mode = false)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/unescaped_quotes/end_quote_mixed.csv', columns = {'a':'varchar'}, header = false, quote = '"', escape = '', strict_mode = false)
-- bwc_tag:end_query

