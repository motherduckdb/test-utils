-- bwc_tag:nb_steps=10
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

select columns from sniff_csv('data/csv/15473.csv');
-- bwc_tag:end_query

select columns from sniff_csv('data/csv/15473_time.csv');
-- bwc_tag:end_query

select columns from sniff_csv('data/csv/15473_timestamp.csv');
-- bwc_tag:end_query

select columns from sniff_csv('data/csv/15473_date_timestamp.csv');
-- bwc_tag:end_query

select columns from sniff_csv('data/csv/15473_time_timestamp.csv');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t1 AS select '2024/12/12' as a, '01:02:03' as b, '2020/01/01 01:02:03' as c from range(0,10000) ;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into t1  values ('1','1','1');
-- bwc_tag:end_query

COPY t1 TO 'output/date_int.csv' (FORMAT CSV);
-- bwc_tag:end_query

select columns from sniff_csv('output/date_int.csv');
-- bwc_tag:end_query

