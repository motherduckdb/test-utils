-- bwc_tag:nb_steps=46
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/null_padding/1.csv', null_padding=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/null_padding/2.csv', null_padding=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/null_padding/3.csv', null_padding=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/null_padding/4.csv', null_padding=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/null_padding/5.csv', null_padding=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/null_padding/6.csv', null_padding=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/null_padding/7.csv', null_padding=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/null_padding/8.csv', null_padding=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/null_padding/9.csv', null_padding=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/null_padding/10.csv', null_padding=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/null_padding/11.csv', null_padding=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/null_padding/12.csv', null_padding=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/null_padding/13.csv', null_padding=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/null_padding/14.csv', null_padding=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/null_padding/15.csv', null_padding=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/null_padding/16.csv', null_padding=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/null_padding/17.csv', null_padding=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/null_padding/18.csv', null_padding=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/null_padding/19.csv', null_padding=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/null_padding/20.csv', null_padding=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/null_padding/21.csv', null_padding=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/null_padding/22.csv', null_padding=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/null_padding/23.csv', null_padding=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/null_padding/24.csv', null_padding=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/null_padding/25.csv', null_padding=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/null_padding/26.csv', null_padding=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/null_padding/27.csv', null_padding=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/null_padding/28.csv', null_padding=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/null_padding/29.csv', null_padding=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/null_padding/30.csv', null_padding=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/null_padding/31.csv', null_padding=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/null_padding/32.csv', null_padding=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/null_padding/33.csv', null_padding=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/null_padding/34.csv', null_padding=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/null_padding/35.csv', null_padding=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/null_padding/36.csv', null_padding=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/null_padding/37.csv', null_padding=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/null_padding/38.csv', null_padding=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/null_padding/39.csv', null_padding=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/null_padding/40.csv', null_padding=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/null_padding/41.csv', null_padding=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/null_padding/42.csv', null_padding=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/null_padding/43.csv', null_padding=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/null_padding/44.csv', null_padding=true)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=unknown

FROM read_csv('data/csv/afl/null_padding/45.csv', null_padding=true)
-- bwc_tag:end_query

