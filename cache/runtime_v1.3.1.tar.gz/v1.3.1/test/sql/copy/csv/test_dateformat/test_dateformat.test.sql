-- bwc_tag:nb_steps=26
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE dates (d DATE);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY dates FROM 'data/csv/test/dateformat.csv' (AUTO_DETECT 0, HEADER 0)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY dates FROM 'data/csv/test/dateformat.csv' (HEADER 0, DATEFORMAT '%d/%m/%Y')
-- bwc_tag:end_query

SELECT * FROM dates
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY dates FROM 'data/csv/test/dateformat.csv' (HEADER 0, DATEFORMAT '%m/%d/%Y')
-- bwc_tag:end_query

SELECT * FROM dates ORDER BY d
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE new_dates (d DATE);
-- bwc_tag:end_query

COPY dates TO 'output/dateformat.csv' (HEADER 0, DATEFORMAT '%d/%m/%Y')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY new_dates FROM 'output/dateformat.csv' (HEADER 0, DATEFORMAT '%d/%m/%Y')
-- bwc_tag:end_query

SELECT * FROM new_dates ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE timestamps(t TIMESTAMP);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY timestamps FROM 'data/csv/test/timestampformat.csv' (HEADER 0, DELIMITER '|', TIMESTAMPFORMAT '%a %d, %B %Y, %I:%M:%S %p')
-- bwc_tag:end_query

SELECT * FROM timestamps
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE new_timestamps (t TIMESTAMP);
-- bwc_tag:end_query

COPY timestamps TO 'output/timestampformat.csv' (HEADER 0, TIMESTAMPFORMAT '%a %d, %B %Y, %I:%M:%S %p')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY new_timestamps FROM 'output/timestampformat.csv' (HEADER 0, TIMESTAMPFORMAT '%a %d, %B %Y, %I:%M:%S %p')
-- bwc_tag:end_query

SELECT * FROM new_timestamps ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DELETE FROM new_timestamps
-- bwc_tag:end_query

COPY timestamps TO 'output/timestampformat.csv' (HEADER 0, TIMESTAMPFORMAT ISO)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY new_timestamps FROM 'output/timestampformat.csv' (HEADER 0)
-- bwc_tag:end_query

SELECT * FROM new_timestamps ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY dates FROM 'data/csv/test/dateformat.csv' (HEADER 0, DATEFORMAT '%')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

COPY timestamps FROM 'data/csv/test/timestampformat.csv' (HEADER 0, DELIMITER '|', TIMESTAMPFORMAT '%')
-- bwc_tag:end_query

select columns FROM sniff_csv('data/csv/dateformat/working.csv',  header=true,dateformat='%d-%b-%Y');
-- bwc_tag:end_query

select columns FROM sniff_csv('data/csv/dateformat/not_working.csv',  header=true,dateformat='%d-%b-%Y');
-- bwc_tag:end_query

