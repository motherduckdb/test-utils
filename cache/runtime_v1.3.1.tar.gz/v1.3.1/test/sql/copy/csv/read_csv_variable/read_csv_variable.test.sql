-- bwc_tag:nb_steps=5
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE globbed_files AS FROM glob('data/csv/glob/a?/*.csv');
-- bwc_tag:end_query

SET VARIABLE csv_files=(SELECT LIST(file ORDER BY file) FROM globbed_files)
-- bwc_tag:end_query

SELECT [x.replace('\', '/') for x in getvariable('csv_files')]
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv(getvariable('csv_files')) ORDER BY 1
-- bwc_tag:end_query

