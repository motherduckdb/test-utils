-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=25
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

COPY (SELECT i, i + 1 AS j, i + 2 AS k, -i AS l FROM range(10) t(i)) TO 'output/late_materialization.parquet';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW test AS FROM 'output/late_materialization.parquet';
-- bwc_tag:end_query

SET explain_output='optimized_only'
-- bwc_tag:end_query

explain SELECT * FROM test ORDER BY j DESC LIMIT 2;
-- bwc_tag:end_query

SELECT * FROM test ORDER BY j DESC LIMIT 2;
-- bwc_tag:end_query

explain SELECT * FROM test ORDER BY j, i LIMIT 2;
-- bwc_tag:end_query

SELECT * FROM test ORDER BY j, i LIMIT 2;
-- bwc_tag:end_query

explain SELECT i FROM test ORDER BY i LIMIT 2;
-- bwc_tag:end_query

explain SELECT * FROM (SELECT i + random() AS i, j, k, l FROM test) ORDER BY i LIMIT 2;
-- bwc_tag:end_query

SELECT * FROM (SELECT -i i, -j j, -k k, -l l FROM test) ORDER BY -j DESC LIMIT 2
-- bwc_tag:end_query

SELECT * FROM (SELECT 100 + i i, 1000 + j j, 10000 + k k, 100000 + l l FROM (SELECT -i i, -j j, -k k, -l l FROM test)) ORDER BY j DESC LIMIT 2
-- bwc_tag:end_query

explain SELECT * FROM test LIMIT 2 OFFSET 2;
-- bwc_tag:end_query

SELECT * FROM test LIMIT 2 OFFSET 2;
-- bwc_tag:end_query

explain SELECT * FROM test USING SAMPLE 2 ROWS
-- bwc_tag:end_query

explain SELECT * FROM test USING SAMPLE 10%
-- bwc_tag:end_query

SELECT * FROM test ORDER BY -j DESC LIMIT 2
-- bwc_tag:end_query

SELECT * FROM (SELECT -i i, -j j, -k k, -l l FROM test) ORDER BY -j DESC LIMIT 2
-- bwc_tag:end_query

SELECT * FROM (
	SELECT * FROM test ORDER BY j DESC LIMIT 2
) WHERE i=8
-- bwc_tag:end_query

SELECT l FROM (
	SELECT * FROM test ORDER BY j DESC LIMIT 2
) WHERE k=10
-- bwc_tag:end_query

COPY (SELECT i, printf('%02d', i + 1) AS j, printf('%02d', i + 2) AS k, -i AS l FROM range(10) t(i)) TO 'output/late_materialization_varchar.parquet';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE VIEW test AS FROM 'output/late_materialization_varchar.parquet';
-- bwc_tag:end_query

SELECT * FROM test ORDER BY j DESC LIMIT 2;
-- bwc_tag:end_query

SELECT j, k, l, i FROM test WHERE i > 5 ORDER BY j DESC LIMIT 2;
-- bwc_tag:end_query

