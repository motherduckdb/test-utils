-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=3
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

select count(col1) from parquet_scan('data/parquet-testing/bug687_nulls.parquet')
-- bwc_tag:end_query

