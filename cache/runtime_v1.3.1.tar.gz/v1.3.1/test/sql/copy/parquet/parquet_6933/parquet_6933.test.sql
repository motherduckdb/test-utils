-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=12
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE table1 (
    name VARCHAR,
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO table1 VALUES ('Test value 1!');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO table1 VALUES ('Test value 2!');
-- bwc_tag:end_query

COPY table1 TO 'output/output1.parquet' (FORMAT PARQUET);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE table2 (
    name VARCHAR,
    number INTEGER,
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO table2 VALUES ('Other test value', 1);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO table2 VALUES ('Other test value', 2);
-- bwc_tag:end_query

COPY table2 TO 'output/output2.parquet' (FORMAT PARQUET);
-- bwc_tag:end_query

set parquet_metadata_cache=true;
-- bwc_tag:end_query

SELECT name, number FROM read_parquet(['output/output*.parquet'], union_by_name=True) ORDER BY name, number
-- bwc_tag:end_query

