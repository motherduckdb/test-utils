-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=10
LOAD 'parquet';
-- bwc_tag:end_query

SELECT * FROM parquet_metadata('data/parquet-testing/lineitem-top10000.gzip.parquet');
-- bwc_tag:end_query

SELECT * FROM parquet_schema('data/parquet-testing/lineitem-top10000.gzip.parquet');
-- bwc_tag:end_query

SELECT COUNT(*) > 0 FROM parquet_metadata('data/parquet-testing/lineitem-top10000.gzip.parquet');
-- bwc_tag:end_query

SELECT COUNT(*) > 0 FROM parquet_schema('data/parquet-testing/lineitem-top10000.gzip.parquet');
-- bwc_tag:end_query

select * from parquet_schema('data/parquet-testing/decimal/decimal_dc.parquet');
-- bwc_tag:end_query

select * from parquet_schema('data/parquet-testing/decimal/int64_decimal.parquet');
-- bwc_tag:end_query

select * from parquet_metadata('data/parquet-testing/glob/*.parquet');
-- bwc_tag:end_query

select * from parquet_schema('data/parquet-testing/glob/*.parquet');
-- bwc_tag:end_query

select * from parquet_schema(['data/parquet-testing/decimal/int64_decimal.parquet', 'data/parquet-testing/decimal/int64_decimal.parquet']);
-- bwc_tag:end_query

