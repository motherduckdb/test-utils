-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=18
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

select * from parquet_scan('data/parquet-testing/glob*/t?.parquet') order by i
-- bwc_tag:end_query

select * from parquet_scan('data/parquet-testing/glob/t[0-9].parquet') order by i
-- bwc_tag:end_query

select * from parquet_scan('data/parquet-testing/glob/*') order by i
-- bwc_tag:end_query

select * from parquet_scan('data/parquet-testing/glob/*.parquet') order by i
-- bwc_tag:end_query

select * from parquet_scan('data/parquet-testing/g*/*.parquet') order by i
-- bwc_tag:end_query

select * from parquet_scan('data/parquet-testing/g*/t1.parquet') order by i
-- bwc_tag:end_query

select * from parquet_scan('./data/parquet-testing/g*/t1.parquet') order by i
-- bwc_tag:end_query

select * from parquet_scan('data\parquet-testing\g*\t1.parquet') order by i
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
FROM parquet_scan('data/parquet-testing/glob3/*/dir/*.parquet');
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select count(*) from parquet_scan('')
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select * from parquet_scan('data/parquet-testing/*.parquet')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE vals (i INTEGER, j BLOB)
-- bwc_tag:end_query

COPY vals FROM 'data/parquet-testing/glob/t?.parquet' (FORMAT PARQUET);
-- bwc_tag:end_query

SELECT * FROM vals ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE vals2 (i INTEGER, j INTEGER)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

COPY vals2 FROM '*/sql/*/parquet/*/glob/t?.parquet' (FORMAT PARQUET);
-- bwc_tag:end_query

