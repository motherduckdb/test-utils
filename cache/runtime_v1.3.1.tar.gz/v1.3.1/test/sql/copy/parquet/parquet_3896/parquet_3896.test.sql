-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=18
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW v1 AS
SELECT map([2], [{'key1': map([3,4],[1,2]), 'key2':2}]) AS x
-- bwc_tag:end_query

SELECT * FROM v1;
-- bwc_tag:end_query

COPY v1
TO 'output/map.parquet' (FORMAT 'parquet');
-- bwc_tag:end_query

SELECT * FROM 'output/map.parquet';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW v2 AS
SELECT map([2], [{'key1': map([3,4],[1,2]), 'key2':2}]) AS x
UNION ALL
SELECT map([2], [{'key1': map([3,4],[1,2]), 'key2':2}])
-- bwc_tag:end_query

SELECT * FROM v2;
-- bwc_tag:end_query

COPY v2
TO 'output/map.parquet' (FORMAT 'parquet');
-- bwc_tag:end_query

SELECT * FROM 'output/map.parquet';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW v3 AS
SELECT {'key': [2], 'val': [{'key1': {'key': [3,4], 'val': [1,2]}, 'key2':2}]} AS x
-- bwc_tag:end_query

SELECT * FROM v3;
-- bwc_tag:end_query

COPY v3
TO 'output/map.parquet' (FORMAT 'parquet');
-- bwc_tag:end_query

SELECT * FROM 'output/map.parquet';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW v4 AS
SELECT {'key': [2], 'val': [{'key1': {'key': [3,4], 'val': [1,2]}, 'key2':[2]}]} AS x
-- bwc_tag:end_query

SELECT * FROM v4;
-- bwc_tag:end_query

COPY v4
TO 'output/map.parquet' (FORMAT 'parquet');
-- bwc_tag:end_query

SELECT * FROM 'output/map.parquet';
-- bwc_tag:end_query

