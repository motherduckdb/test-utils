-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=7
LOAD 'parquet';
-- bwc_tag:end_query

COPY (SELECT 42 val) TO 'output/file.parquet';
-- bwc_tag:end_query

ATTACH 'output/file.parquet' AS attached_parquet
-- bwc_tag:end_query

USE attached_parquet
-- bwc_tag:end_query

SELECT * FROM file
-- bwc_tag:end_query

SELECT * FROM attached_parquet
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

ATTACH 'duckdb:output/file.parquet' AS duck_attach
-- bwc_tag:end_query

