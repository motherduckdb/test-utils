-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=10
LOAD 'parquet';
-- bwc_tag:end_query

copy (select * from values ('\x0An\xC3\xB5'::blob), ('\xFFXl\x9D'::blob) tbl(b)) to 'output/blobs.parquet'
-- bwc_tag:end_query

select stats_min_value from parquet_metadata('output/blobs.parquet')
-- bwc_tag:end_query

select min(b) from 'output/blobs.parquet'
-- bwc_tag:end_query

select stats_max_value from parquet_metadata('output/blobs.parquet')
-- bwc_tag:end_query

select max(b) from 'output/blobs.parquet'
-- bwc_tag:end_query

select hex(stats_min_value::BLOB) from parquet_metadata('output/blobs.parquet')
-- bwc_tag:end_query

select hex(min(b)) from 'output/blobs.parquet'
-- bwc_tag:end_query

select hex(stats_max_value::BLOB) from parquet_metadata('output/blobs.parquet')
-- bwc_tag:end_query

select hex(max(b)) from 'output/blobs.parquet'
-- bwc_tag:end_query

