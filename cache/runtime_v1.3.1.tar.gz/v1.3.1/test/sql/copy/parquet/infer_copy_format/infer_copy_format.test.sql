-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=6
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers AS SELECT * FROM range(6) tbl(i);
-- bwc_tag:end_query

COPY integers TO 'output/integers.parquet';
-- bwc_tag:end_query

SELECT SUM(i) FROM 'output/integers.parquet';
-- bwc_tag:end_query

COPY integers TO 'output/integers.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT SUM(i) FROM 'output/integers.csv' tbl(i);
-- bwc_tag:end_query

