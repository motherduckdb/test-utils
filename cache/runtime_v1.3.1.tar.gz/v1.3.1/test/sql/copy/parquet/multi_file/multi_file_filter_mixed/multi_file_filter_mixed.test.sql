-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=11
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

COPY (FROM (VALUES ('f1', 42), ('f1', 8), ('f1', NULL)) t(f, i)) TO 'output/multi_file_filter_f1.parquet'
-- bwc_tag:end_query

COPY (FROM (VALUES ('042', 'f2'), ('124', 'f2'), (NULL, 'f2')) t(i, f)) TO 'output/multi_file_filter_f2.parquet'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW integer_file_first AS FROM read_parquet(['output/multi_file_filter_f1.parquet', 'output/multi_file_filter_f2.parquet'])
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW string_file_first AS FROM read_parquet(['output/multi_file_filter_f2.parquet', 'output/multi_file_filter_f1.parquet'])
-- bwc_tag:end_query

SELECT f, i
FROM integer_file_first
WHERE i='042'
-- bwc_tag:end_query

SELECT f, i
FROM string_file_first
WHERE i='042'
-- bwc_tag:end_query

SELECT f, i
FROM integer_file_first
WHERE i>10
ORDER BY ALL
-- bwc_tag:end_query

SELECT f, i
FROM string_file_first
WHERE i>'10'
ORDER BY ALL
-- bwc_tag:end_query

SELECT f, i
FROM integer_file_first
WHERE i IS NULL
-- bwc_tag:end_query

