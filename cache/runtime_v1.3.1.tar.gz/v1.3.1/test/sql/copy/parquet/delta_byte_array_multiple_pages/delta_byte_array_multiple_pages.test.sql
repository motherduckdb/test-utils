-- bwc_tag:needed_extensions=httpfs;parquet
-- bwc_tag:nb_steps=5
LOAD 'parquet';
-- bwc_tag:end_query

LOAD 'httpfs';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE delta_byte_array AS SELECT * FROM parquet_scan('https://github.com/duckdb/duckdb-data/releases/download/v1.0/delta_byte_array_multiple_pages.parquet')
-- bwc_tag:end_query

SELECT COUNT(*) FROM delta_byte_array
-- bwc_tag:end_query

SELECT min(strlen(json_column)), max(strlen(json_column)) FROM delta_byte_array
-- bwc_tag:end_query

