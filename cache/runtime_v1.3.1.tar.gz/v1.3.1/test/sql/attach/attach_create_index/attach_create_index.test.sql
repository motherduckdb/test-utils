-- bwc_tag:nb_steps=3
ATTACH '' AS tmp;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tmp.t1(id int);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE INDEX idx ON tmp.t1(id);
-- bwc_tag:end_query

