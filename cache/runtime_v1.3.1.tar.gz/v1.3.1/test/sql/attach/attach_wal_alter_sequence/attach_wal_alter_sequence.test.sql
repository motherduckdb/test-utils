-- bwc_tag:nb_steps=13
-- bwc_tag:execute_from_sql
PRAGMA disable_checkpoint_on_shutdown
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA wal_autocheckpoint='1TB';
-- bwc_tag:end_query

attach 'output/attach_wal_with_sequence.db' as db1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE db1.seq;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE db1.test (a INTEGER DEFAULT nextval('seq'), b INTEGER, c INTEGER DEFAULT currval('seq'));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO db1.test (b) VALUES (1);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
alter table db1.test RENAME TO blubb;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO db1.blubb (b) VALUES (10);
-- bwc_tag:end_query

SELECT * FROM db1.blubb
-- bwc_tag:end_query

DETACH db1
-- bwc_tag:end_query

attach 'output/attach_wal_with_sequence.db' as db2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO db2.blubb (b) VALUES (100);
-- bwc_tag:end_query

SELECT * FROM db2.blubb
-- bwc_tag:end_query

