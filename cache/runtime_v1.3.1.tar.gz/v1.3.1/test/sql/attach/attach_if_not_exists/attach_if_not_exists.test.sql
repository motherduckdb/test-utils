-- bwc_tag:nb_steps=15
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

ATTACH 'output/attach_if_not_exists.db' AS db1
-- bwc_tag:end_query

ATTACH IF NOT EXISTS 'output/attach_if_not_exists.db' AS db1
-- bwc_tag:end_query

ATTACH IF NOT EXISTS ':memory:' AS db1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE db1.integers(i INTEGER);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

ATTACH IF NOT EXISTS 'output/attach_if_not_exists.db' AS db2
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

ATTACH ':memory:' AS db1
-- bwc_tag:end_query

DETACH db1
-- bwc_tag:end_query

ATTACH 'output/attach_if_not_exists.db' AS db1 (READ_WRITE);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

ATTACH IF NOT EXISTS 'output/attach_if_not_exists.db' AS db1 (READ_ONLY);
-- bwc_tag:end_query

ATTACH IF NOT EXISTS 'output/attach_if_not_exists.db' AS db1
-- bwc_tag:end_query

DETACH db1
-- bwc_tag:end_query

ATTACH 'output/attach_if_not_exists.db' AS db1 (READ_ONLY)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

ATTACH IF NOT EXISTS 'output/attach_if_not_exists.db' AS db1 (READ_WRITE);
-- bwc_tag:end_query

ATTACH IF NOT EXISTS 'output/attach_if_not_exists.db' AS db1
-- bwc_tag:end_query

