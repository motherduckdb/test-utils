-- bwc_tag:nb_steps=25
-- bwc_tag:execute_from_sql
CREATE TABLE strings(s STRING, g INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO strings VALUES ('hello', 0), ('world', 1), (NULL, 0), ('r', 1)
-- bwc_tag:end_query

SELECT COUNT(*), COUNT(s), MIN(s), MAX(s) FROM strings
-- bwc_tag:end_query

SELECT COUNT(*), COUNT(s), MIN(s), MAX(s) FROM strings WHERE s IS NULL
-- bwc_tag:end_query

SELECT STRING_AGG(s, ' '), STRING_AGG(s, ''), STRING_AGG('', ''), STRING_AGG('hello', ' ') FROM strings
-- bwc_tag:end_query

SELECT g, COUNT(*), COUNT(s), MIN(s), MAX(s), STRING_AGG(s, ' ') FROM strings GROUP BY g ORDER BY g
-- bwc_tag:end_query

SELECT g, COUNT(*), COUNT(s), MIN(s), MAX(s), STRING_AGG(DISTINCT g::VARCHAR ORDER BY g::VARCHAR DESC) FROM strings GROUP BY g ORDER BY g;
-- bwc_tag:end_query

SELECT g, COUNT(*), COUNT(s), MIN(s), MAX(s), STRING_AGG(DISTINCT s ORDER BY s ASC) FROM strings GROUP BY g ORDER BY g;
-- bwc_tag:end_query

SELECT g, COUNT(*), COUNT(s), MIN(s), MAX(s), STRING_AGG(s, ' ') FROM strings WHERE s IS NULL OR s <> 'hello' GROUP BY g ORDER BY g
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT SUM(s) FROM strings GROUP BY g ORDER BY g
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT AVG(s) FROM strings GROUP BY g ORDER BY g
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE booleans(b BOOLEAN, g INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO booleans VALUES (false, 0), (true, 1), (NULL, 0), (false, 1)
-- bwc_tag:end_query

SELECT COUNT(*), COUNT(b), MIN(b), MAX(b) FROM booleans
-- bwc_tag:end_query

SELECT COUNT(*), COUNT(b), MIN(b), MAX(b) FROM booleans WHERE b IS NULL
-- bwc_tag:end_query

SELECT g, COUNT(*), COUNT(b), MIN(b), MAX(b) FROM booleans GROUP BY g ORDER BY g
-- bwc_tag:end_query

SELECT g, COUNT(*), COUNT(b), MIN(b), MAX(b) FROM booleans WHERE b IS NULL OR b=true GROUP BY g ORDER BY g
-- bwc_tag:end_query

SELECT SUM(b) FROM booleans GROUP BY g ORDER BY g
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT AVG(b) FROM booleans GROUP BY g ORDER BY g
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER, g INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (12, 0), (22, 1), (NULL, 0), (14, 1)
-- bwc_tag:end_query

SELECT COUNT(*), COUNT(i), MIN(i), MAX(i), SUM(i) FROM integers
-- bwc_tag:end_query

SELECT COUNT(*), COUNT(i), MIN(i), MAX(i), SUM(i) FROM INTEGERS WHERE i IS NULL
-- bwc_tag:end_query

SELECT g, COUNT(*), COUNT(i), MIN(i), MAX(i), SUM(i) FROM integers GROUP BY g ORDER BY g
-- bwc_tag:end_query

SELECT g, COUNT(*), COUNT(i), MIN(i), MAX(i), SUM(i) FROM integers WHERE i IS NULL OR i > 15 GROUP BY g ORDER BY g
-- bwc_tag:end_query

