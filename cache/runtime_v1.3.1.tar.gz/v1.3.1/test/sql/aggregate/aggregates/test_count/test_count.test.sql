-- bwc_tag:nb_steps=7
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

SELECT COUNT(*), COUNT(1), COUNT(100), COUNT(NULL), COUNT(DISTINCT 1)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (1), (2), (NULL)
-- bwc_tag:end_query

SELECT COUNT(*), COUNT(1), COUNT(i), COUNT(COALESCE(i, 1)), COUNT(DISTINCT i), COUNT(DISTINCT 1) FROM integers
-- bwc_tag:end_query

SELECT COUNT(1 ORDER BY 1)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT COUNT(DISTINCT *) FROM integers
-- bwc_tag:end_query

