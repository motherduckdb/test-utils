-- bwc_tag:nb_steps=5
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA verify_external
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table lists as select array[i] l from generate_series(0,5,1) tbl(i);
-- bwc_tag:end_query

select min(l) from lists where l[1]>2;
-- bwc_tag:end_query

select min(l) from lists where l[0]>2;
-- bwc_tag:end_query

