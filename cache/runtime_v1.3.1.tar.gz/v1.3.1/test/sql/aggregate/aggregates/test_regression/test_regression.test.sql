-- bwc_tag:nb_steps=71
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

select regr_avgx(NULL,NULL)
-- bwc_tag:end_query

select regr_avgx(1,1)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select regr_avgx()
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select regr_avgx(*)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select regr_avgy()
-- bwc_tag:end_query

select regr_avgy(NULL,NULL)
-- bwc_tag:end_query

select regr_avgy(1,1)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select regr_avgy(*)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select regr_count()
-- bwc_tag:end_query

select regr_count(NULL,NULL)
-- bwc_tag:end_query

select regr_count(1,1)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select regr_count(*)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select regr_slope()
-- bwc_tag:end_query

select regr_slope(NULL,NULL)
-- bwc_tag:end_query

select regr_slope(1,1)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select regr_slope(*)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select regr_r2()
-- bwc_tag:end_query

select regr_r2(NULL,NULL)
-- bwc_tag:end_query

select regr_r2(1,1)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select regr_r2(0, 1e230*i) from range(5) tbl(i);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select regr_r2(1e230*i, i) from range(5) tbl(i);
-- bwc_tag:end_query

select regr_r2(1e230*i, 0) from range(5) tbl(i);
-- bwc_tag:end_query

select regr_r2(0, i) from range(5) tbl(i);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select regr_r2(*)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select regr_sxx()
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select regr_sxx(0, 2e230*i) from range(5) tbl(i)
-- bwc_tag:end_query

select regr_sxx(2e230*i, 0) from range(5) tbl(i)
-- bwc_tag:end_query

select regr_sxx(NULL,NULL)
-- bwc_tag:end_query

select regr_sxx(1,1)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select regr_syy()
-- bwc_tag:end_query

select regr_syy(NULL,NULL)
-- bwc_tag:end_query

select regr_syy(1,1)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select regr_sxy(*)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select regr_sxy()
-- bwc_tag:end_query

select regr_sxy(NULL,NULL)
-- bwc_tag:end_query

select regr_sxy(1,1)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select regr_syy(*)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select regr_intercept()
-- bwc_tag:end_query

select regr_intercept(NULL,NULL)
-- bwc_tag:end_query

select regr_intercept(1,1)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select regr_intercept(*)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create  table aggr(k int, v decimal(10,2), v2 decimal(10, 2));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into aggr values(1, 10, null), (2, 10, 11), (2, 20, 22), (2, 25, null), (2, 30, 35);
-- bwc_tag:end_query

select k, regr_avgx(v, v2) from aggr group by k ORDER BY ALL;
-- bwc_tag:end_query

select k, regr_avgy(v, v2) from aggr group by k ORDER BY ALL;
-- bwc_tag:end_query

select k, count(*), regr_count(v, v2) from aggr group by k ORDER BY ALL;
-- bwc_tag:end_query

select k, regr_slope(v, v2) from aggr group by k ORDER BY ALL;
-- bwc_tag:end_query

select k, regr_r2(v, v2) from aggr group by k ORDER BY ALL;
-- bwc_tag:end_query

select k, regr_sxx(v, v2) from aggr group by k ORDER BY ALL;
-- bwc_tag:end_query

select k, regr_syy(v, v2) from aggr group by k ORDER BY ALL;
-- bwc_tag:end_query

select k, regr_sxy(v, v2) from aggr group by k ORDER BY ALL;
-- bwc_tag:end_query

select k, regr_intercept(v, v2) from aggr group by k ORDER BY ALL;
-- bwc_tag:end_query

select regr_avgx(v, v2) from aggr ;
-- bwc_tag:end_query

select  regr_avgy(v, v2) from aggr ;
-- bwc_tag:end_query

select  regr_count(v, v2) from aggr ;
-- bwc_tag:end_query

select regr_slope(v, v2) from aggr ;
-- bwc_tag:end_query

select regr_r2(v, v2) from aggr ;
-- bwc_tag:end_query

select  regr_sxx(v, v2) from aggr ;
-- bwc_tag:end_query

select regr_syy(v, v2) from aggr ;
-- bwc_tag:end_query

select regr_sxy(v, v2) from aggr;
-- bwc_tag:end_query

select regr_intercept(v, v2) from aggr;
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
select  regr_avgx(v, v2) over (partition by k)
    from aggr;
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
select  regr_avgy(v, v2) over (partition by k)
    from aggr;
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
select  regr_count(v, v2) over (partition by k)
    from aggr;
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
select  regr_slope(v, v2) over (partition by k)
    from aggr;
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
select  regr_r2(v, v2) over (partition by k)
    from aggr;
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
select  regr_sxx(v, v2) over (partition by k)
    from aggr;
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
select  regr_syy(v, v2) over (partition by k)
    from aggr;
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
select  regr_sxy(v, v2) over (partition by k)
    from aggr;
-- bwc_tag:end_query

-- bwc_tag:sort=row_sort
select  regr_intercept(v, v2) over (partition by k)
    from aggr;
-- bwc_tag:end_query

