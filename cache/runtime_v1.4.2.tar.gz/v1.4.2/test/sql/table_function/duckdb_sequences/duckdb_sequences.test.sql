-- bwc_tag:nb_steps=5
SELECT COUNT(*) FROM duckdb_sequences();
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SEQUENCE seq
-- bwc_tag:end_query

CREATE TEMPORARY SEQUENCE seq2 MINVALUE 3 MAXVALUE 5 START WITH 4 CYCLE;
-- bwc_tag:end_query

SELECT schema_name, sequence_name, temporary, start_value, min_value, max_value, increment_by, cycle
FROM duckdb_sequences() ORDER BY sequence_name;
-- bwc_tag:end_query

SELECT database_name = current_database() OR database_name = 'temp'
FROM duckdb_sequences();
-- bwc_tag:end_query

