-- bwc_tag:nb_steps=14
-- bwc_tag:execute_from_sql
CREATE TABLE integers(i INTEGER);
-- bwc_tag:end_query

SELECT * FROM sqlite_master;
-- bwc_tag:end_query

SELECT EXISTS(SELECT * FROM sqlite_master)
-- bwc_tag:end_query

SELECT EXISTS(SELECT * FROM sqlite_master OFFSET 1)
-- bwc_tag:end_query

SELECT COUNT(*) FROM sqlite_master WHERE name='test'
-- bwc_tag:end_query

SELECT COUNT(*) FROM sqlite_master WHERE name='integers'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table tconstraint1(i integer primary key default(3), j blob not null);
-- bwc_tag:end_query

SELECT * FROM sqlite_master WHERE name='tconstraint1';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table tconstraint2(i integer, j integer, k integer, l integer unique, primary key(i, j, k));
-- bwc_tag:end_query

SELECT * FROM sqlite_master WHERE name='tconstraint2';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE INDEX i_index ON integers(i);
-- bwc_tag:end_query

SELECT * REPLACE (trim(sql, chr(10)) as sql) FROM sqlite_master WHERE name='i_index';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW v1 AS SELECT 42
-- bwc_tag:end_query

SELECT "type", "name", "tbl_name", rootpage FROM sqlite_master WHERE name='v1';
-- bwc_tag:end_query

