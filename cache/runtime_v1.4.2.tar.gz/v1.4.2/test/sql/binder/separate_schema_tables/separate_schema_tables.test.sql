-- bwc_tag:nb_steps=36
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA IF NOT EXISTS s1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA IF NOT EXISTS s2;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA IF NOT EXISTS s3;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE s1.tbl(i INT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE s2.tbl(i INT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE s3.tbl(i INT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tbl(i INT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO s1.tbl VALUES (10);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO s2.tbl VALUES (100);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO s3.tbl VALUES (1000);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO tbl VALUES (1);
-- bwc_tag:end_query

SELECT * FROM tbl, s1.tbl, s2.tbl
-- bwc_tag:end_query

SELECT * FROM tbl, s1.tbl, s2.tbl, s3.tbl
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT tbl.i FROM s1.tbl, s2.tbl
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT tbl.i FROM s1.tbl, s2.tbl, s3.tbl
-- bwc_tag:end_query

SELECT s1.tbl, s2.tbl, s3.tbl FROM s1.tbl, s2.tbl, s3.tbl
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE s1.t AS SELECT 1 id, 's1.t' payload UNION ALL SELECT 10 id, 'AAA' payload
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE s2.t AS SELECT 1 id, 's2.t' payload2 UNION ALL SELECT 100 id, 'BBB' payload2
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE s3.t AS SELECT 1 id, 's3.t' payload3 UNION ALL SELECT 1000 id, 'CCC' payload3
-- bwc_tag:end_query

SELECT * FROM s1.t JOIN s2.t USING (id) JOIN s3.t USING (id)
-- bwc_tag:end_query

SELECT id FROM s1.t JOIN s2.t USING (id) JOIN s3.t USING (id)
-- bwc_tag:end_query

SELECT * FROM s1.t NATURAL JOIN s2.t NATURAL JOIN s3.t
-- bwc_tag:end_query

SELECT id, s1.t.id, s2.t.id, s3.t.id, s1.t.payload, s2.t.payload2, s3.t.payload3
FROM s1.t LEFT JOIN s2.t USING (id) LEFT JOIN s3.t USING (id)
ORDER BY ALL
-- bwc_tag:end_query

SELECT id, s1.t.id, s2.t.id, s3.t.id, s1.t.payload, s2.t.payload2, s3.t.payload3
FROM s1.t RIGHT JOIN s2.t USING (id) RIGHT JOIN s3.t USING (id)
ORDER BY ALL
-- bwc_tag:end_query

SELECT id, s1.t.id, s2.t.id, s3.t.id, s1.t.payload, s2.t.payload2, s3.t.payload3
FROM s1.t FULL OUTER JOIN s2.t USING (id) FULL OUTER JOIN s3.t USING (id)
ORDER BY ALL
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE s1.tbl(col INT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE s2.TBL(COL INT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE s3.Tbl(Col INT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO s1.tbl VALUES (10);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO s2.tbl VALUES (100);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO s3.tbl VALUES (1000);
-- bwc_tag:end_query

SELECT * FROM tbl, s1.tbl, s2.tbl, s3.tbl
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT tbl.col FROM s1.tbl, s2.tbl
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT tbl.col FROM s1.tbl, s2.tbl, s3.tbl
-- bwc_tag:end_query

SELECT s1.tbl, s2.tbl, s3.tbl FROM s1.tbl, s2.tbl, s3.tbl
-- bwc_tag:end_query

