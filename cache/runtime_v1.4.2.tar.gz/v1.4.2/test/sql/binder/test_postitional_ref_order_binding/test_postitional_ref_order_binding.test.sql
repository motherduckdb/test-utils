-- bwc_tag:needed_extensions=tpch
-- bwc_tag:nb_steps=4
LOAD 'tpch';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table test as select * from (values (42, 43), (44, 45)) v(i, j);
-- bwc_tag:end_query

select i, sum(j) as s from test group by i order by #1;
-- bwc_tag:end_query

