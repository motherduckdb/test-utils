-- bwc_tag:needed_extensions=json
-- bwc_tag:nb_steps=13
-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE tbl (example VARCHAR);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO tbl VALUES ('hello');
-- bwc_tag:end_query

SELECT (WITH keys AS (
    		SELECT example AS k
    	), nonNull AS (
    		SELECT keys.k, example AS v
    		FROM keys
    		WHERE v IS NOT NULL
    	)
    	SELECT nonNull.v
    	FROM nonNull
)
FROM tbl;
-- bwc_tag:end_query

LOAD 'json';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE testjson (example JSON);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO testjson VALUES ('{ "location" : { "address" : "123 Main St" }, "sampleField" : null, "anotherField" : 123, "yetAnotherField" : "abc" }');
-- bwc_tag:end_query

SELECT (WITH keys AS (SELECT unnest(json_keys(example)) AS k), nonNull AS (
    		SELECT keys.k, example->keys.k AS v
    		FROM keys WHERE nullif(v, 'null') IS NOT NULL
    	)
    	SELECT json_group_object(nonNull.k, nonNull.v)
    	FROM nonNull
)
FROM testjson;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE MACRO strip_null_value(jsonValue) AS (
	WITH keys AS (SELECT UNNEST(json_keys(jsonValue)) AS k),
		nonNull AS (
		SELECT keys.k, jsonValue->keys.k AS v
		FROM keys WHERE nullif(v, 'null') IS NOT NULL
	)
	SELECT json_group_object(nonNull.k, nonNull.v)
	FROM nonNull
);
-- bwc_tag:end_query

SELECT strip_null_value('{ "location" : { "address" : "123 Main St" }, "sampleField" : null, "anotherField" : 123, "yetAnotherField" : "abc" }')
AS example;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE testjson (example JSON);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO testjson
VALUES ('{ "location" : { "address" : "123 Main St" }, "sampleField" : null, "anotherField" : 123, "yetAnotherField" : "abc" }');
-- bwc_tag:end_query

SELECT strip_null_value(example) FROM testjson;
-- bwc_tag:end_query

WITH x AS (
	SELECT '{ "location" : { "address" : "123 Main St" }, "sampleField" : null, "anotherField" : 123, "yetAnotherField" : "abc" }'
	AS example)
SELECT strip_null_value(x.example) AS test
FROM x;
-- bwc_tag:end_query

