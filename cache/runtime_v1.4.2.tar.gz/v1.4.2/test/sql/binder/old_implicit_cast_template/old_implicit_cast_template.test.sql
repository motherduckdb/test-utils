-- bwc_tag:nb_steps=4
-- bwc_tag:execute_from_sql
create table t1 as select * from values ('1-2', '3-4', 'a-z', NULL) as r(v);
-- bwc_tag:end_query

SELECT list_extract(string_split(v, '-'), 1) FROM t1;
-- bwc_tag:end_query

SET old_implicit_casting = true;
-- bwc_tag:end_query

SELECT list_extract(string_split(v, '-'), 1) FROM t1;
-- bwc_tag:end_query

