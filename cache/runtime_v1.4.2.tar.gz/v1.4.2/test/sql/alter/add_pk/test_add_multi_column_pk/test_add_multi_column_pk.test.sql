-- bwc_tag:nb_steps=7
-- bwc_tag:skip_query
PRAGMA enable_verification;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test (i INTEGER, j INTEGER, d TEXT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (3, 4, 'hello'), (44, 45, '56');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test ADD PRIMARY KEY (i, j);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (1, 1, 'foo'), (1, 2, 'bar');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO test VALUES (1, 2, 'oops');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO test VALUES (NULL, 2, 'nada');
-- bwc_tag:end_query

