-- bwc_tag:nb_steps=12
-- bwc_tag:load_db=test_add_pk_attach

ATTACH 'output/test_add_pk_attach.db' AS test_add_pk_attach;
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE test (i INTEGER, j INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test ADD PRIMARY KEY (j)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (1, 1)
-- bwc_tag:end_query

ATTACH ':memory:' as memory
-- bwc_tag:end_query

USE memory
-- bwc_tag:end_query

DETACH test_add_pk_attach
-- bwc_tag:end_query

ATTACH 'output/test_add_pk_attach.db' as test_add_pk_attach
-- bwc_tag:end_query

USE test_add_pk_attach
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE test ADD PRIMARY KEY (i)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO test VALUES (2, 1)
-- bwc_tag:end_query

