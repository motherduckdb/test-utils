-- bwc_tag:nb_steps=10
-- bwc_tag:execute_from_sql
CREATE TABLE test(s STRUCT(i INTEGER, j INTEGER))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test VALUES (ROW(1, 1)), (ROW(2, 2))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test DROP COLUMN s.i
-- bwc_tag:end_query

SELECT * FROM test
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE test DROP COLUMN s.j
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE test DROP COLUMN s.v
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test DROP COLUMN IF EXISTS s.v
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE test DROP COLUMN s.j.a
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE test DROP COLUMN z.j
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

ALTER TABLE test DROP COLUMN s.v1.a
-- bwc_tag:end_query

