-- bwc_tag:nb_steps=6
-- bwc_tag:execute_from_sql
CREATE TABLE test(i INTEGER CHECK(i < 10), j INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test (i, j) VALUES (1, 2), (2, 3)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO test (i, j) VALUES (100, 2)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE test RENAME COLUMN i TO k
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO test (k, j) VALUES (1, 2), (2, 3)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO test (k, j) VALUES (100, 2)
-- bwc_tag:end_query

