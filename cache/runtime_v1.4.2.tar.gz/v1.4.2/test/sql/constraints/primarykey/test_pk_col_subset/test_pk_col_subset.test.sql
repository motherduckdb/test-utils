-- bwc_tag:nb_steps=8
-- bwc_tag:execute_from_sql
CREATE TABLE numbers(a integer, b integer, c integer, d integer, e integer, PRIMARY KEY(a,b))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO numbers VALUES (1,1,1,1,1), (1,1,1,1,1)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO numbers VALUES (1,1,1,1,1),(1,2,1,1,1),(2,1,2,1,1),(2,2,2,2,2)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO numbers VALUES (1,1,1,1,1),(1,5,1,1,4);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO numbers VALUES (1,5,1,1,4);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
UPDATE numbers SET c=1 WHERE c=2
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

UPDATE numbers SET b=1 WHERE b=2
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
UPDATE numbers SET b=3 WHERE b=2
-- bwc_tag:end_query

