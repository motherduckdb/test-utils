-- bwc_tag:nb_steps=3
-- bwc_tag:execute_from_sql
CREATE TABLE vdata AS SELECT * FROM (VALUES ('v2',)) v(id);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW v AS SELECT * FROM vdata;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE TABLE t(v_id TEXT, FOREIGN KEY (v_id) REFERENCES v(id));
-- bwc_tag:end_query

