-- bwc_tag:nb_steps=5
-- bwc_tag:execute_from_sql
CREATE SCHEMA s1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE SCHEMA s2
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE s1.pk_integers(i INTEGER PRIMARY KEY)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO s1.pk_integers VALUES (1), (2), (3)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE TABLE s2.fk_integers(j INTEGER, FOREIGN KEY (j) REFERENCES s1.pk_intexgers(i))
-- bwc_tag:end_query

