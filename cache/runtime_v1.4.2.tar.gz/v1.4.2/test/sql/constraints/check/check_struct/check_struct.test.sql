-- bwc_tag:nb_steps=7
-- bwc_tag:execute_from_sql
CREATE TABLE tbl(t ROW(t INTEGER) CHECK(t.t=42));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO tbl VALUES ({'t': 43})
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO tbl VALUES ({'t': 42})
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE tbl;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tbl(t ROW(t INTEGER) CHECK(tbl.t.t=42));
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO tbl VALUES ({'t': 43})
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO tbl VALUES ({'t': 42})
-- bwc_tag:end_query

