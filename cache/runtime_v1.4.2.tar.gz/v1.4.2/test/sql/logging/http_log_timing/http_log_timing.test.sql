-- bwc_tag:needed_extensions=httpfs
-- bwc_tag:nb_steps=4
LOAD 'httpfs';
-- bwc_tag:end_query

CALL enable_logging('HTTP')
-- bwc_tag:end_query

FROM 'https://github.com/duckdb/duckdb-data/releases/download/v1.0/title.principals.tsv'
-- bwc_tag:end_query

SELECT 
	request.type, 
	request.duration_ms >= 0,
	request.duration_ms <= 1000 * 1000
FROM 
	duckdb_logs_parsed('HTTP')
WHERE 
	request.type='HEAD'
-- bwc_tag:end_query

