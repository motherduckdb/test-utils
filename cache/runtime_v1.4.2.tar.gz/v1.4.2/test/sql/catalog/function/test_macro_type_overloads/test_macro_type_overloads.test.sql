-- bwc_tag:nb_steps=62
attach ':memory:' AS inmemorydb
-- bwc_tag:end_query

use inmemorydb
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create or replace macro m(s varchar) as s || 'c'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop macro m;
-- bwc_tag:end_query

attach 'output/test_macro_type_overloads_olderdb.db' AS olderdb (storage_version 'v1.3.0')
-- bwc_tag:end_query

use olderdb
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

create or replace macro m(s varchar) as s || 'c'
-- bwc_tag:end_query

create or replace temporary macro m(s varchar) as s || 'c'
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop macro m;
-- bwc_tag:end_query

attach 'output/test_macro_type_overloads_newerdb.db' AS newerdb (storage_version 'v1.4.0')
-- bwc_tag:end_query

use newerdb
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create view v as select 42
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create or replace macro m(s varchar) as s || 'c'
-- bwc_tag:end_query

select m('ab')
-- bwc_tag:end_query

select m(s := 'ab')
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select m([42])
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select m(s := [42])
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create or replace macro m(s varchar := 'cc') as s || 'c'
-- bwc_tag:end_query

select m('ab')
-- bwc_tag:end_query

select m(s := 'ab')
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select m([42])
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select m(s := [42])
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create or replace macro m
    (a tinyint) as a + 1,
    (a smallint) as a + 2,
    (a integer) as a + 3,
    (a bigint) as a + 4,
    (a hugeint) as a + 5,
    (a) as a + 10
-- bwc_tag:end_query

select parameter_types[1]
from duckdb_functions()
where function_name = 'm'
and function_type = 'macro'
order by all
-- bwc_tag:end_query

select
    m(0::tinyint),
    m(0::smallint),
    m(0::integer),
    m(0::bigint),
    m(0::hugeint),
    m(0::double)
-- bwc_tag:end_query

select
    m(0::utinyint),
    m(0::usmallint),
    m(0::uinteger),
    m(0::ubigint),
    m(0::uhugeint),
    m(0::float)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create or replace macro m
    (i int, j) as i + j,
    (i, j int) as i - j;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select m(0, 42)
-- bwc_tag:end_query

select m(0, 42::float)
-- bwc_tag:end_query

select m(0::float, 42)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create or replace type cool_string as varchar;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create or replace macro m(s cool_string) as s;
-- bwc_tag:end_query

select m('duck')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

create or replace macro m(s varchar := 42) as s
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create or replace macro m(s varchar := 42::varchar) as s
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create or replace macro m(i bigint := 42::integer) as i
-- bwc_tag:end_query

select typeof(m(42::integer))
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create or replace macro m(s varchar) as table (select s || 'c')
-- bwc_tag:end_query

from m('ab')
-- bwc_tag:end_query

from m(s := 'ab')
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

from m([42])
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

from m(s := [42])
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create or replace macro m(s varchar := 'cc') as table (select s || 'c')
-- bwc_tag:end_query

from m('ab')
-- bwc_tag:end_query

from m(s := 'ab')
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

from m([42])
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

from m(s := [42])
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create or replace macro m
    (a tinyint) as table (select a + 1),
    (a smallint) as table (select a + 2),
    (a integer) as table (select a + 3),
    (a bigint) as table (select a + 4),
    (a hugeint) as table (select a + 5),
    (a) as table (select a + 10)
-- bwc_tag:end_query

select parameter_types[1]
from duckdb_functions()
where function_name = 'm'
and function_type = 'table_macro'
order by all
-- bwc_tag:end_query

from m(0::tinyint)
union all
from m(0::smallint)
union all
from m(0::integer)
union all
from m(0::bigint)
union all
from m(0::hugeint)
union all
from m(0::double)
-- bwc_tag:end_query

from m(0::utinyint)
union all
from m(0::usmallint)
union all
from m(0::uinteger)
union all
from m(0::ubigint)
union all
from m(0::uhugeint)
union all
from m(0::float)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create or replace macro m
    (i int, j) as table (select i + j),
    (i, j int) as table (select i - j);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

from m(0, 42)
-- bwc_tag:end_query

from m(0, 42::float)
-- bwc_tag:end_query

from m(0::float, 42)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create or replace type cool_string as varchar;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create or replace macro m(s cool_string) as table (select s);
-- bwc_tag:end_query

from m('duck')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

create or replace macro m(s varchar := 42) as table (select s)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create or replace macro m(s varchar := 42::varchar) as table (select s)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create or replace macro m(i bigint := 42::integer) as table (select i as i)
-- bwc_tag:end_query

select typeof(i) from m(42::integer)
-- bwc_tag:end_query

