-- bwc_tag:nb_steps=7
-- bwc_tag:execute_from_sql
create macro m() as 42;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create macro m() as table (select 42 i);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop macro m;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select m();
-- bwc_tag:end_query

from m();
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
drop macro m;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

from m();
-- bwc_tag:end_query

