-- bwc_tag:nb_steps=18
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE integers (a INT)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO integers VALUES (1)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO parameterized_cte(a) AS (WITH cte AS (SELECT a AS answer) SELECT answer FROM cte)
-- bwc_tag:end_query

SELECT parameterized_cte(42)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO in_with_cte(i) AS i IN (WITH cte AS (SELECT a AS answer FROM integers) SELECT answer FROM cte)
-- bwc_tag:end_query

SELECT in_with_cte(1)
-- bwc_tag:end_query

SELECT in_with_cte(2)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO plus42(a) AS (WITH cte AS (SELECT 42 AS answer) SELECT answer + a FROM cte)
-- bwc_tag:end_query

SELECT plus42(42)
-- bwc_tag:end_query

SELECT plus42(a) FROM integers
-- bwc_tag:end_query

SELECT plus42(3) + a FROM integers
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT plus42(42) + answer FROM cte;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO plus1(a) AS (WITH tbl AS (SELECT 1 AS one) SELECT one + a FROM tbl)
-- bwc_tag:end_query

SELECT plus1(3)
-- bwc_tag:end_query

SELECT plus42(a) + plus1(a) FROM integers;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE MACRO deep_cte(param) AS (
    WITH cte1 AS (
        WITH cte2 AS (
            WITH cte3 AS (
                WITH cte4 AS (
                    SELECT param AS d
                )
                SELECT d AS c FROM cte4
            )
            SELECT c AS b FROM cte3
        )
        SELECT b AS a FROM cte2
    )
    SELECT a FROM cte1
)
-- bwc_tag:end_query

SELECT deep_cte(42)
-- bwc_tag:end_query

