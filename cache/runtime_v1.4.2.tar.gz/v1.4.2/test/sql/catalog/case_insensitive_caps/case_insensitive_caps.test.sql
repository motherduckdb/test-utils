-- bwc_tag:nb_steps=6
-- bwc_tag:execute_from_sql
CREATE TABLE mytable(mycolumn INTEGER, myothercolumn INTEGER);
-- bwc_tag:end_query

SELECT "MYCOLUMN" FROM "MYTABLE";
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE "MYTABLE" DROP COLUMN "MYCOLUMN";
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE "MYTABLE" ADD COLUMN mycolumn INTEGER;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
ALTER TABLE "MYTABLE" ALTER COLUMN "MYCOLUMN" SET DEFAULT 3
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE "MYTABLE"
-- bwc_tag:end_query

