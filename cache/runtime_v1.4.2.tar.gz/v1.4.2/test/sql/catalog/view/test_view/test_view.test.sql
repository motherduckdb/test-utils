-- bwc_tag:nb_steps=17
-- bwc_tag:execute_from_sql
CREATE TABLE t1(i INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO t1 VALUES (41), (42), (43)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW v1 AS SELECT
	i AS j
FROM t1 WHERE i < 43
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE VIEW v1 AS SELECT 'whatever'
-- bwc_tag:end_query

SELECT j FROM v1 WHERE j > 41
-- bwc_tag:end_query

SELECT x FROM v1 t1(x) WHERE x > 41
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP VIEW v1
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT j FROM v1 WHERE j > 41
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW v1 AS SELECT 'whatever'
-- bwc_tag:end_query

SELECT * FROM v1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE VIEW v1 AS SELECT 42
-- bwc_tag:end_query

SELECT * FROM v1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

INSERT INTO v1 VALUES (1)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP VIEW v1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

DROP VIEW v1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP VIEW IF EXISTS v1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

CREATE VIEW v1 AS SELECT * FROM dontexist
-- bwc_tag:end_query

