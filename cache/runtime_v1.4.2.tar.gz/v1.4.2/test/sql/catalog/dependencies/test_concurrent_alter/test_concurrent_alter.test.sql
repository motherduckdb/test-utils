-- bwc_tag:nb_steps=3
-- bwc_tag:execute_from_sql
CREATE TABLE t2 AS (SELECT 42);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create sequence seq;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
alter sequence seq owned by t2;
-- bwc_tag:end_query

