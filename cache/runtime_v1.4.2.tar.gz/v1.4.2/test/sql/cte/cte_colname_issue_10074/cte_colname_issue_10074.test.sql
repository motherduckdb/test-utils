-- bwc_tag:nb_steps=3
-- bwc_tag:skip_query
pragma enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table t as with q(id,s) as (values(1,42)),
a(s)as materialized(select 42)
select id from q join a on q.s=a.s
-- bwc_tag:end_query

select id from t
-- bwc_tag:end_query

