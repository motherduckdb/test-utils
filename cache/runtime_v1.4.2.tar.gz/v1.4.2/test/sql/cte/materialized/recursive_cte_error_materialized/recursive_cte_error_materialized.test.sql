-- bwc_tag:nb_steps=4
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tag(id int, name string, subclassof int);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO tag VALUES
  (7, 'Music',  9),
  (8, 'Movies', 9),
  (9, 'Art',    NULL)
;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

WITH RECURSIVE tag_hierarchy(id, source, path, target) AS materialized (
  SELECT id, name, name AS path, NULL AS target -- this should be '' for correct behaviour
  FROM tag
  WHERE subclassof IS NULL
  UNION ALL
  SELECT tag.id, tag.name, tag_hierarchy.path || ' <- ' || tag.name, tag.name AS target
  FROM tag, tag_hierarchy
  WHERE tag.subclassof = tag_hierarchy.id
)
SELECT source, path, target
FROM tag_hierarchy
;
-- bwc_tag:end_query

