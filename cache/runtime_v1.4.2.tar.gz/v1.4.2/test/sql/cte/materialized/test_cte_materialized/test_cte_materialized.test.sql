-- bwc_tag:nb_steps=24
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table a(i integer);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into a values (42);
-- bwc_tag:end_query

with cte1 as MATERIALIZED (Select i as j from a) select * from cte1;
-- bwc_tag:end_query

with cte1 as MATERIALIZED (Select i as j from a) select x from cte1 t1(x);
-- bwc_tag:end_query

with cte1(xxx) as MATERIALIZED (Select i as j from a) select xxx from cte1;
-- bwc_tag:end_query

with cte1(xxx) as MATERIALIZED (Select i as j from a) select x from cte1 t1(x);
-- bwc_tag:end_query

with cte1 as MATERIALIZED (Select i as j from a), cte2 as MATERIALIZED (select ref.j as k from cte1 as ref), cte3 as MATERIALIZED (select ref2.j+1 as i from cte1 as ref2) select * from cte2 , cte3;
-- bwc_tag:end_query

with cte1 as MATERIALIZED (select i as j from a), cte2 as MATERIALIZED (select ref.j as k from cte1 as ref), cte3 as MATERIALIZED (select ref2.j+1 as i from cte1 as ref2) select * from cte2 union all select * FROM cte3;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

with cte1 as MATERIALIZED (select 42), cte1 as MATERIALIZED (select 42) select * FROM cte1;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

with cte3 as MATERIALIZED (select ref2.j as i from cte1 as ref2), cte1 as MATERIALIZED (Select i as j from a), cte2 as MATERIALIZED (select ref.j+1 as k from cte1 as ref) select * from cte2 union all select * FROM cte3;
-- bwc_tag:end_query

with cte1 as MATERIALIZED (Select i as j from a) select * from cte1 cte11, cte1 cte12;
-- bwc_tag:end_query

with cte1 as MATERIALIZED (Select i as j from a) select * from cte1 where j = (select max(j) from cte1 as cte2);
-- bwc_tag:end_query

with cte1(x, y) as MATERIALIZED (select 42 a, 84 b) select zzz, y from cte1 t1(zzz);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create view va AS (with cte as MATERIALIZED (Select i as j from a) select * from cte);
-- bwc_tag:end_query

select * from va
-- bwc_tag:end_query

with cte AS MATERIALIZED (SELECT * FROM va) SELECT * FROM cte;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create view vb AS (with cte1 as MATERIALIZED (Select i as j from a), cte2 as MATERIALIZED (select ref.j+1 as k from cte1 as ref) select * from cte2);
-- bwc_tag:end_query

select * from vb
-- bwc_tag:end_query

SELECT 1 UNION ALL (WITH cte AS MATERIALIZED (SELECT 42) SELECT * FROM cte);
-- bwc_tag:end_query

WITH RECURSIVE cte(d) AS MATERIALIZED (
		SELECT 1
	UNION ALL
		(WITH c(d) AS (SELECT * FROM cte)
			SELECT d + 1
			FROM c
			WHERE FALSE
		)
)
SELECT max(d) FROM cte;
-- bwc_tag:end_query

with cte (a) as MATERIALIZED (
    select 1
)
select
    a as alias1,
    alias1 as alias2
from cte
where alias2 > 0;
-- bwc_tag:end_query

WITH RECURSIVE t(x,v) AS (
  SELECT 1, ARRAY[] :: int[]
    UNION ALL
  (WITH u(x) AS MATERIALIZED (SELECT 1)
    SELECT f.x, (SELECT array_agg(x) FROM u)
    FROM   t, LATERAL (SELECT t.x + 1) AS f(x)
    WHERE  t.x < 5
  )
) SELECT * FROM t ORDER BY x;
-- bwc_tag:end_query

SELECT * FROM (WITH t(x) AS MATERIALIZED (SELECT * FROM generate_series(1,10) LIMIT 75%) SELECT * FROM t LIMIT 80%) AS _(x) ORDER BY x LIMIT 50%;
-- bwc_tag:end_query

