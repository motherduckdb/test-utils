-- bwc_tag:nb_steps=23
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

SELECT j : 42;
-- bwc_tag:end_query

select column_name from (describe SELECT j : 42)
-- bwc_tag:end_query

SELECT "j" : 42;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT 'j': 42
-- bwc_tag:end_query

SELECT "hel lo" : 42;
-- bwc_tag:end_query

select column_name from (describe SELECT "hel lo" : 42)
-- bwc_tag:end_query

SELECT j1 : 42, 42 AS j2, 42 j3;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE a (i INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO a VALUES (42);
-- bwc_tag:end_query

SELECT j : i FROM a
-- bwc_tag:end_query

SELECT "j" : "i" FROM a
-- bwc_tag:end_query

SELECT * FROM b : a
-- bwc_tag:end_query

SELECT * FROM "b" : a
-- bwc_tag:end_query

SELECT i FROM b : a
-- bwc_tag:end_query

SELECT b.i FROM b : a
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT a.i FROM b : a
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT a : 42 AS b
-- bwc_tag:end_query

from my_wonderful_values : (values(42))
-- bwc_tag:end_query

from 'my_wonderful_values' : (values(42))
-- bwc_tag:end_query

from "my_wonderful_values" : (values(42))
-- bwc_tag:end_query

from r : range(1)
-- bwc_tag:end_query

from "r" : range(1)
-- bwc_tag:end_query

