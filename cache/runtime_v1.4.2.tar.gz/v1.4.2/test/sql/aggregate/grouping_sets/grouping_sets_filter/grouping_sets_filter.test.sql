-- bwc_tag:nb_steps=8
SET default_null_order='nulls_first';
-- bwc_tag:end_query

-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table students (course VARCHAR, type VARCHAR);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into students
		(course, type)
	values
		('CS', 'Bachelor'),
		('CS', 'Bachelor'),
		('CS', 'PhD'),
		('Math', 'Masters'),
		('CS', NULL),
		('CS', NULL),
		('Math', NULL);
-- bwc_tag:end_query

SELECT course, COUNT(*) FROM students GROUP BY GROUPING SETS ((), (course))  HAVING course LIKE 'C%' ORDER BY 1, 2;
-- bwc_tag:end_query

SELECT course, COUNT(*) FROM students GROUP BY GROUPING SETS ((), (course)) HAVING course LIKE 'C%' OR course NOT LIKE 'C%' OR course IS NULL ORDER BY 1, 2;
-- bwc_tag:end_query

SELECT course, COUNT(*) FROM students GROUP BY GROUPING SETS ((), (course)) HAVING random()<1000 ORDER BY ALL;
-- bwc_tag:end_query

SELECT course, COUNT(*) FROM students GROUP BY GROUPING SETS ((), (course)) HAVING random()>1000;
-- bwc_tag:end_query

