-- bwc_tag:nb_steps=10
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tbl(a INTEGER, b VARCHAR)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO tbl VALUES (1, NULL), (2, 'thisisalongstring'), (3, 'thisisalsoalongstring')
-- bwc_tag:end_query

SELECT LAST(b) FROM tbl WHERE a=2
-- bwc_tag:end_query

SELECT LAST(b) FROM tbl WHERE a=1
-- bwc_tag:end_query

SELECT LAST(b) FROM tbl WHERE a=1 GROUP BY a
-- bwc_tag:end_query

SELECT LAST(b) FROM tbl WHERE a=0
-- bwc_tag:end_query

SELECT LAST(b) FROM tbl WHERE a=0 GROUP BY b
-- bwc_tag:end_query

SELECT a, LAST(b) FROM tbl GROUP BY a ORDER BY a
-- bwc_tag:end_query

SELECT LAST(i) FROM (VALUES (NULL::INT32)) tbl(i)
-- bwc_tag:end_query

