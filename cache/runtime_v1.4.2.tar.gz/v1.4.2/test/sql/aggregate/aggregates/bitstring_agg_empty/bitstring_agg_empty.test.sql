-- bwc_tag:nb_steps=6
-- bwc_tag:skip_query
PRAGMA verify_external
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE t1 (k VARCHAR, el VARCHAR);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE VIEW t1_v AS (SELECT * FROM t1 LIMIT 0);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE el_ids (el VARCHAR, idx INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO el_ids VALUES ('el', 10);
-- bwc_tag:end_query

SELECT    k, bitstring_agg(idx)
FROM      t1_v
JOIN      el_ids USING (el)
GROUP BY  k;
-- bwc_tag:end_query

