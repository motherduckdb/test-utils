-- bwc_tag:nb_steps=3
-- bwc_tag:execute_from_sql
CREATE TABLE doubles(n DOUBLE);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO doubles (n) VALUES ('9007199254740992'::DOUBLE), (1::DOUBLE), (1::DOUBLE), (0::DOUBLE);
-- bwc_tag:end_query

SELECT FAVG(n) - '2251799813685248.5'::DOUBLE FROM doubles;
-- bwc_tag:end_query

