-- bwc_tag:nb_steps=28
-- bwc_tag:execute_from_sql
create table stddev_test(val integer, grp integer)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into stddev_test values (42, 1), (43, 1), (42, 2), (1000, 2), (NULL, 1), (NULL, 3)
-- bwc_tag:end_query

SELECT stddev_samp(1)
-- bwc_tag:end_query

SELECT var_samp(1)
-- bwc_tag:end_query

select round(stddev_samp(val), 1) from stddev_test
-- bwc_tag:end_query

select round(stddev_samp(val), 1) from stddev_test  where val is not null
-- bwc_tag:end_query

select grp, sum(val), round(stddev_samp(val), 1), min(val) from stddev_test group by grp order by grp
-- bwc_tag:end_query

select grp, sum(val), round(stddev_samp(val), 1), min(val) from stddev_test where val is not null group by grp order by grp
-- bwc_tag:end_query

select round(stddev_pop(val), 1) from stddev_test
-- bwc_tag:end_query

select round(stddev_pop(val), 1) from stddev_test  where val is not null
-- bwc_tag:end_query

select grp, sum(val), round(stddev_pop(val), 1), min(val) from stddev_test group by grp order by grp
-- bwc_tag:end_query

select grp, sum(val), round(stddev_pop(val), 1), min(val) from stddev_test where val is not null group by grp order by grp
-- bwc_tag:end_query

select round(var_samp(val), 1) from stddev_test
-- bwc_tag:end_query

select round(variance(val), 1) from stddev_test
-- bwc_tag:end_query

select round(var_samp(val), 1) from stddev_test  where val is not null
-- bwc_tag:end_query

select grp, sum(val), round(var_samp(val), 1), min(val) from stddev_test group by grp order by grp
-- bwc_tag:end_query

select grp, sum(val), round(var_samp(val), 1), min(val) from stddev_test where val is not null group by grp order by grp
-- bwc_tag:end_query

select round(var_pop(val), 1) from stddev_test
-- bwc_tag:end_query

select round(var_pop(val), 1) from stddev_test  where val is not null
-- bwc_tag:end_query

select grp, sum(val), round(var_pop(val), 2), min(val) from stddev_test group by grp order by grp
-- bwc_tag:end_query

select grp, sum(val), round(var_pop(val), 2), min(val) from stddev_test where val is not null group by grp order by grp
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
create table stddev_test_alias(val integer, grp integer)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into stddev_test_alias values (42, 1), (43, 1), (42, 2), (1000, 2), (NULL, 1), (NULL, 3)
-- bwc_tag:end_query

select round(stddev(val), 1) from stddev_test_alias
-- bwc_tag:end_query

select stddev(0) from range(10)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select stddev(a) from (values (1e301), (-1e301)) tbl(a)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select var_samp(a) from (values (1e301), (-1e301)) tbl(a)
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

select var_pop(a) from (values (1e301), (-1e301)) tbl(a)
-- bwc_tag:end_query

