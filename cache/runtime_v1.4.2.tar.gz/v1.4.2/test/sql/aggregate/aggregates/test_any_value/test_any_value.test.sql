-- bwc_tag:nb_steps=50
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tbl(i INTEGER)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO tbl VALUES (NULL), (2), (3)
-- bwc_tag:end_query

SELECT ANY_VALUE(i) AS a FROM tbl
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE tbl
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE five AS SELECT i::float AS i FROM range(1, 6, 1) t1(i)
-- bwc_tag:end_query

SELECT ANY_VALUE(i) FROM five
-- bwc_tag:end_query

SELECT i % 3 AS g, ANY_VALUE(i) FROM five GROUP BY 1 ORDER BY 1
-- bwc_tag:end_query

SELECT ANY_VALUE(i ORDER BY 5-i) FROM five
-- bwc_tag:end_query

SELECT i % 3 AS g, ANY_VALUE(i ORDER BY 5-i) FROM five GROUP BY 1 ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE five
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE five AS SELECT i::double AS i FROM range(1, 6, 1) t1(i)
-- bwc_tag:end_query

SELECT ANY_VALUE(i) FROM five
-- bwc_tag:end_query

SELECT i % 3 AS g, ANY_VALUE(i) FROM five GROUP BY 1 ORDER BY 1
-- bwc_tag:end_query

SELECT ANY_VALUE(i ORDER BY 5-i) FROM five
-- bwc_tag:end_query

SELECT i % 3 AS g, ANY_VALUE(i ORDER BY 5-i) FROM five GROUP BY 1 ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE five
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE five AS SELECT i::decimal(4,1) AS i FROM range(1, 6, 1) t1(i)
-- bwc_tag:end_query

SELECT ANY_VALUE(i ORDER BY 5-i) FROM five
-- bwc_tag:end_query

SELECT i::INTEGER % 3 AS g, ANY_VALUE(i ORDER BY 5-i) FROM five GROUP BY 1 ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE five
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE five AS SELECT i::decimal(8,1) AS i FROM range(1, 6, 1) t1(i)
-- bwc_tag:end_query

SELECT ANY_VALUE(i ORDER BY 5-i) FROM five
-- bwc_tag:end_query

SELECT i::INTEGER % 3 AS g, ANY_VALUE(i ORDER BY 5-i) FROM five GROUP BY 1 ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE five
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE five AS SELECT i::decimal(12,1) AS i FROM range(1, 6, 1) t1(i)
-- bwc_tag:end_query

SELECT ANY_VALUE(i ORDER BY 5-i) FROM five
-- bwc_tag:end_query

SELECT i::INTEGER % 3 AS g, ANY_VALUE(i ORDER BY 5-i) FROM five GROUP BY 1 ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE five
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE five AS SELECT i::decimal(18,1) AS i FROM range(1, 6, 1) t1(i)
-- bwc_tag:end_query

SELECT ANY_VALUE(i ORDER BY 5-i) FROM five
-- bwc_tag:end_query

SELECT i::INTEGER % 3 AS g, ANY_VALUE(i ORDER BY 5-i) FROM five GROUP BY 1 ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE five
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE five_dates AS
        SELECT 1 AS i,
               NULL::DATE AS d,
               NULL::TIMESTAMP AS dt,
               NULL::TIME AS t,
               NULL::INTERVAL AS s
        UNION ALL
	SELECT
		i::integer AS i,
		'2021-08-20'::DATE + i::INTEGER AS d,
		'2021-08-20'::TIMESTAMP + INTERVAL (i) HOUR AS dt,
		'14:59:37'::TIME + INTERVAL (i) MINUTE AS t,
		INTERVAL (i) SECOND AS s
	FROM range(1, 6, 1) t1(i)
-- bwc_tag:end_query

SELECT ANY_VALUE(d), ANY_VALUE(dt), ANY_VALUE(t), ANY_VALUE(s) FROM five_dates
-- bwc_tag:end_query

SELECT i % 3 AS g, ANY_VALUE(d), ANY_VALUE(dt), ANY_VALUE(t), ANY_VALUE(s)
FROM five_dates
GROUP BY 1
ORDER BY 1
-- bwc_tag:end_query

SELECT ANY_VALUE(d ORDER BY 5-i), ANY_VALUE(dt ORDER BY 5-i), ANY_VALUE(t ORDER BY 5-i), ANY_VALUE(s ORDER BY 5-i) FROM five_dates
-- bwc_tag:end_query

SELECT i % 3 AS g, ANY_VALUE(d ORDER BY 5-i), ANY_VALUE(dt ORDER BY 5-i), ANY_VALUE(t ORDER BY 5-i), ANY_VALUE(s ORDER BY 5-i)
FROM five_dates
GROUP BY 1
ORDER BY 1
-- bwc_tag:end_query

SELECT ANY_VALUE(dt::TIMESTAMPTZ), ANY_VALUE(t::TIMETZ) FROM five_dates
-- bwc_tag:end_query

SELECT i % 3 AS g, ANY_VALUE(dt::TIMESTAMPTZ), ANY_VALUE(t::TIMETZ)
FROM five_dates
GROUP BY 1
ORDER BY 1
-- bwc_tag:end_query

SELECT ANY_VALUE(dt::TIMESTAMPTZ ORDER BY 5-i), ANY_VALUE(t::TIMETZ ORDER BY 5-i) FROM five_dates
-- bwc_tag:end_query

SELECT i % 3 AS g, ANY_VALUE(dt::TIMESTAMPTZ ORDER BY 5-i), ANY_VALUE(t::TIMETZ ORDER BY 5-i)
FROM five_dates
GROUP BY 1
ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE five_dates
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE five_complex AS
	SELECT
		1 AS i,
		NULL::VARCHAR AS s,
		NULL::BIGINT[] AS l,
		NULL AS r
        UNION ALL
	SELECT
		i::integer AS i,
		i::VARCHAR AS s,
		[i] AS l,
		{'a': i} AS r
	FROM range(1, 6, 1) t1(i)
-- bwc_tag:end_query

SELECT ANY_VALUE(s), ANY_VALUE(l), ANY_VALUE(r)
FROM five_complex
-- bwc_tag:end_query

SELECT i % 3 AS g, ANY_VALUE(s), ANY_VALUE(l), ANY_VALUE(r)
FROM five_complex
GROUP BY 1
ORDER BY 1
-- bwc_tag:end_query

SELECT ANY_VALUE(s ORDER BY 5-i), ANY_VALUE(l ORDER BY 5-i), ANY_VALUE(r ORDER BY 5-i)
FROM five_complex
-- bwc_tag:end_query

SELECT i % 3 AS g, ANY_VALUE(s ORDER BY 5-i), ANY_VALUE(l ORDER BY 5-i), ANY_VALUE(r ORDER BY 5-i)
FROM five_complex
GROUP BY 1
ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE five_complex
-- bwc_tag:end_query

SELECT ANY_VALUE(i) OVER (PARTITION BY i) AS a 
FROM generate_series(1, 5) t(i)
ORDER BY ALL
-- bwc_tag:end_query

