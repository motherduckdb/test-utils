-- bwc_tag:nb_steps=55
-- bwc_tag:skip_query
PRAGMA verify_external
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE tinyints(i TINYINT)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO tinyints VALUES(1), (8), (3), (12), (7), (1), (2), (8)
-- bwc_tag:end_query

SELECT BITSTRING_AGG(i) FROM tinyints
-- bwc_tag:end_query

SELECT bit_count(BITSTRING_AGG(i)) FROM tinyints WHERE i <= 7
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE smallints(i SMALLINT)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO smallints VALUES(1), (8), (-3), (12), (7), (1), (-1), (-9), (NULL), (-2), (8)
-- bwc_tag:end_query

SELECT BITSTRING_AGG(i) FROM smallints
-- bwc_tag:end_query

SELECT bit_count(BITSTRING_AGG(i)) FROM smallints WHERE i = 8
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE ints(i INTEGER);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO ints VALUES(10), (-5), (11), (NULL), (30), (11), (23), (17), (27), (15), (5), (14)
-- bwc_tag:end_query

SELECT BITSTRING_AGG(i) FROM ints
-- bwc_tag:end_query

SELECT bit_count(BITSTRING_AGG(i)) FROM ints WHERE i > 20 AND i < 28
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE bigints(i BIGINT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO bigints VALUES(2378097), (2378100), (2378095), (2378104), (NULL), (2378113), (2378100), (2378095), (2378105), (2378097)
-- bwc_tag:end_query

SELECT BITSTRING_AGG(i) FROM bigints
-- bwc_tag:end_query

SELECT bit_count(BITSTRING_AGG(i)) FROM bigints WHERE i = 100
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE hugeints(i HUGEINT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO hugeints VALUES(12243372036854775807), (12243372036854778191), (12243372036854730332), (12243372036854773737), (12243372036854737711), (12243372036854722124), (12243372036854778191)
-- bwc_tag:end_query

SELECT bit_length(BITSTRING_AGG(i)) FROM hugeints
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE uhugeints(i UHUGEINT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO uhugeints VALUES(12243372036854775807), (12243372036854778191), (12243372036854730332), (12243372036854773737), (12243372036854737711), (12243372036854722124), (12243372036854778191)
-- bwc_tag:end_query

SELECT bit_length(BITSTRING_AGG(i)) FROM uhugeints
-- bwc_tag:end_query

SELECT bit_count(BITSTRING_AGG(i)) FROM smallints
-- bwc_tag:end_query

SELECT COUNT(DISTINCT i) FROM smallints
-- bwc_tag:end_query

SELECT bit_count(BITSTRING_AGG(i)) FROM ints
-- bwc_tag:end_query

SELECT COUNT(DISTINCT i) FROM ints
-- bwc_tag:end_query

SELECT bit_count(BITSTRING_AGG(i)) FROM bigints
-- bwc_tag:end_query

SELECT COUNT(DISTINCT i) FROM bigints
-- bwc_tag:end_query

SELECT bit_count(BITSTRING_AGG(i)) FROM hugeints
-- bwc_tag:end_query

SELECT COUNT(DISTINCT i) FROM hugeints
-- bwc_tag:end_query

SELECT BITSTRING_AGG(i, -5, 30) FROM ints
-- bwc_tag:end_query

SELECT BITSTRING_AGG(i, -10, 40) FROM ints
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT BITSTRING_AGG(i, -10, 20) FROM ints
-- bwc_tag:end_query

SELECT BITSTRING_AGG(i, 0, 15) FROM tinyints
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT BITSTRING_AGG(i, 2, 15) FROM tinyints
-- bwc_tag:end_query

SELECT BITSTRING_AGG(i, 2378080, 2378150) FROM bigints
-- bwc_tag:end_query

SELECT BITSTRING_AGG(3)
-- bwc_tag:end_query

SELECT BITSTRING_AGG(2, 0, 5)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE null_table(i INT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO null_table VALUES(NULL)
-- bwc_tag:end_query

SELECT BITSTRING_AGG(i) FROM null_table
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO null_table VALUES(6), (NULL), (NULL), (NULL), (NULL)
-- bwc_tag:end_query

SELECT BITSTRING_AGG(i) FROM null_table
-- bwc_tag:end_query

COPY (SELECT i FROM ints) TO 'output/bitstring_agg.csv' (HEADER 0);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT BITSTRING_AGG(column0) FROM 'output/bitstring_agg.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT BITSTRING_AGG(column0, -10, 40) FROM 'output/bitstring_agg.csv';
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT BITSTRING_AGG()
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT BITSTRING_AGG(1, 3, 4, 8, 0)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE groups(i INT, g VARCHAR);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO groups VALUES(10, 'a'), (13, 'b'), (9, 'a'), (16, 'c'), (NULL, 'd'), (2, 'a'), (6, 'c'), (9, 'b')
-- bwc_tag:end_query

SELECT g, BITSTRING_AGG(i) FROM groups GROUP BY g ORDER BY g
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA disable_optimizer
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT BITSTRING_AGG(i) FROM ints
-- bwc_tag:end_query

SELECT BITSTRING_AGG(i, -5, 32) FROM ints
-- bwc_tag:end_query

