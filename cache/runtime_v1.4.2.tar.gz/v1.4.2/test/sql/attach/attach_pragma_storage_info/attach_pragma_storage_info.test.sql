-- bwc_tag:nb_steps=5
-- bwc_tag:load_db=alter_dependency_conflict

ATTACH 'output/alter_dependency_conflict.db' AS alter_dependency_conflict;
-- bwc_tag:end_query

ATTACH 'output/database.db' as persistent;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE OR REPLACE TABLE persistent.T1 (A0 int);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
insert into persistent.T1 values (5);
-- bwc_tag:end_query

SELECT column_name from pragma_storage_info('persistent.T1');
-- bwc_tag:end_query

