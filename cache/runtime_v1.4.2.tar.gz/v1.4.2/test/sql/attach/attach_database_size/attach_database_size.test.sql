-- bwc_tag:nb_steps=4
ATTACH 'output/attach_database_size.db' AS db1
-- bwc_tag:end_query

SELECT database_name FROM pragma_database_size() WHERE database_name = 'db1';
-- bwc_tag:end_query

ATTACH ':memory:' AS db2
-- bwc_tag:end_query

SELECT database_name FROM pragma_database_size() WHERE database_name = 'db1' OR database_name = 'db2' ORDER BY ALL;
-- bwc_tag:end_query

