-- bwc_tag:nb_steps=3
ATTACH DATABASE ':memory:' AS new_database;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

ATTACH ':memory:' AS new_database;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

ATTACH ':memory:'
-- bwc_tag:end_query

