-- bwc_tag:nb_steps=20
ATTACH 'output/attach_enums.db' AS db1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TYPE db1.mood AS ENUM ('sad', 'ok', 'happy');
-- bwc_tag:end_query

SELECT enum_range(NULL::db1.mood) AS my_enum_range;
-- bwc_tag:end_query

SELECT enum_range(NULL::db1.main.mood) AS my_enum_range;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT enum_range(NULL::xx.db1.main.mood) AS my_enum_range;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TYPE db1.mood
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TYPE IF EXISTS db1.main.mood
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TYPE db1.mood AS ENUM ('sad', 'ok', 'happy');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE db1.person (
    name text,
    current_mood mood
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO db1.person VALUES ('Moe', 'happy');
-- bwc_tag:end_query

select * from db1.person
-- bwc_tag:end_query

DETACH db1
-- bwc_tag:end_query

ATTACH 'output/attach_enums.db' AS db1 (READ_ONLY)
-- bwc_tag:end_query

select * from db1.person
-- bwc_tag:end_query

ATTACH 'output/attach_enums_2.db' AS db2
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TYPE db2.mood AS ENUM ('ble','grr','kkcry');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE db2.person (
    name text,
    current_mood mood
);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO db2.person VALUES ('Moe', 'kkcry');
-- bwc_tag:end_query

select * from db1.person
-- bwc_tag:end_query

select * from db2.person
-- bwc_tag:end_query

