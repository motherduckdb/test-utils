-- bwc_tag:nb_steps=17
-- bwc_tag:expected_result=error

ATTACH 'output/not_pow_of_two.db' (BLOCK_SIZE 123456);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

ATTACH 'output/exceeds_maximum.db' (BLOCK_SIZE 2147483648);
-- bwc_tag:end_query

ATTACH 'output/not_default.db' (BLOCK_SIZE 16384);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

ATTACH 'output/too_small.db' (BLOCK_SIZE 128);
-- bwc_tag:end_query

ATTACH 'output/default_size.db' (BLOCK_SIZE 262144);
-- bwc_tag:end_query

DETACH default_size;
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

ATTACH 'output/default_size.db' (BLOCK_SIZE 16384);
-- bwc_tag:end_query

ATTACH 'output/default_size.db';
-- bwc_tag:end_query

DETACH default_size;
-- bwc_tag:end_query

ATTACH 'output/dbname.db' (BLOCK_SIZE 16384);
-- bwc_tag:end_query

DETACH dbname;
-- bwc_tag:end_query

ATTACH 'output/dbname.db';
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SET default_block_size = '123456';
-- bwc_tag:end_query

SET default_block_size = '16384';
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SET default_block_size = '128';
-- bwc_tag:end_query

SET default_block_size = '262144';
-- bwc_tag:end_query

ATTACH 'output/default_size.db';
-- bwc_tag:end_query

