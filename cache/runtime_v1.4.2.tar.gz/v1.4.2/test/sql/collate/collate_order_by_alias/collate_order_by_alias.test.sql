-- bwc_tag:nb_steps=6
-- bwc_tag:execute_from_sql
CREATE TABLE CreditCardTable(id BIGINT, creditCard_number VARCHAR);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE CustomerTable(id BIGINT, pk BIGINT);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO CreditCardTable VALUES (1, 'A'), (2, 'z');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO CustomerTable VALUES (1, 100), (2, 0);
-- bwc_tag:end_query

select
  creditCard_number as "pk", CustomerTable.pk AS inner_pk
from
  CreditCardTable JOIN CustomerTable USING (id)
order by
  "pk" COLLATE NOCASE;
-- bwc_tag:end_query

select
  creditCard_number as "pk", CustomerTable.pk AS inner_pk
from
  CreditCardTable JOIN CustomerTable USING (id)
order by #1 COLLATE NOCASE;
-- bwc_tag:end_query

