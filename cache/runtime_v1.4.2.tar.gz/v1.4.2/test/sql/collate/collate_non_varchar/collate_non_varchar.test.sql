-- bwc_tag:nb_steps=3
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA default_collation=NOCASE;
-- bwc_tag:end_query

select typeof(x) from (select 1::INT as x group by x);
-- bwc_tag:end_query

