-- bwc_tag:nb_steps=32
SELECT strpos('HELLO' COLLATE NOCASE, 'el')
-- bwc_tag:end_query

SELECT strpos('HELLO' COLLATE NOCASE, 'EL')
-- bwc_tag:end_query

SELECT strpos('hello' COLLATE NOCASE, 'EL')
-- bwc_tag:end_query

SELECT strpos('HeLLo' COLLATE NOCASE, 'el')
-- bwc_tag:end_query

SELECT instr('HELLO' COLLATE NOCASE, 'el')
-- bwc_tag:end_query

SELECT instr('hello' COLLATE NOCASE, 'EL')
-- bwc_tag:end_query

SELECT position('el' IN ('HELLO' COLLATE NOCASE))
-- bwc_tag:end_query

SELECT position('EL' IN ('hello' COLLATE NOCASE))
-- bwc_tag:end_query

SELECT strpos('HELLO' COLLATE NOCASE, '')
-- bwc_tag:end_query

SELECT strpos('HELLO' COLLATE NOCASE, 'xyz')
-- bwc_tag:end_query

SELECT strpos('HELLO' COLLATE NOCASE, 'HELLO')
-- bwc_tag:end_query

SELECT strpos('Hello World' COLLATE NOCASE, 'world')
-- bwc_tag:end_query

SELECT strpos('HELLO WORLD' COLLATE NOCASE, 'o w')
-- bwc_tag:end_query

SELECT contains('HELLO' COLLATE NOCASE, 'hEllO')
-- bwc_tag:end_query

SELECT starts_with('HELLO' COLLATE NOCASE, 'heL')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE collate_test(s VARCHAR COLLATE NOCASE)
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
INSERT INTO collate_test VALUES ('Hello World'), ('HELLO WORLD'), ('hElLo WoRlD')
-- bwc_tag:end_query

SELECT strpos(s COLLATE NOCASE, 'hello') FROM collate_test ORDER BY s
-- bwc_tag:end_query

SELECT strpos(s COLLATE NOCASE, 'world') FROM collate_test ORDER BY s
-- bwc_tag:end_query

SELECT strpos('HELLO' COLLATE NOCASE, 'el' COLLATE NOCASE)
-- bwc_tag:end_query

SELECT strpos('HELLO' COLLATE NOCASE, 'EL')
-- bwc_tag:end_query

SELECT strpos('HELLO', 'el')
-- bwc_tag:end_query

SELECT strpos('HELLO', 'EL')
-- bwc_tag:end_query

SELECT strpos('' COLLATE NOCASE, '')
-- bwc_tag:end_query

SELECT strpos('' COLLATE NOCASE, 'a')
-- bwc_tag:end_query

SELECT strpos('a' COLLATE NOCASE, '')
-- bwc_tag:end_query

SELECT strpos('HéLLO' COLLATE NOCASE, 'éll')
-- bwc_tag:end_query

SELECT strpos('HÉLLO' COLLATE NOCASE, 'éll')
-- bwc_tag:end_query

SELECT strpos('HELLO', 'HELLO')
-- bwc_tag:end_query

SELECT strpos('HELLO', '')
-- bwc_tag:end_query

SELECT strpos('HELLO', 'xyz')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DROP TABLE collate_test
-- bwc_tag:end_query

