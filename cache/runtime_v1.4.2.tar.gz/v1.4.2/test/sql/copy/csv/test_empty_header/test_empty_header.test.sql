-- bwc_tag:nb_steps=5
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

select columns[1].name,columns[2].name,columns[3].name,columns[4].name,columns[5].name
from sniff_csv('data/csv/headers/empty_1.csv')
-- bwc_tag:end_query

select columns[1].name,columns[2].name,columns[3].name,columns[4].name,columns[5].name
from sniff_csv('data/csv/headers/empty_2.csv')
-- bwc_tag:end_query

select columns[1].name,columns[2].name,columns[3].name,columns[4].name,columns[5].name
from sniff_csv('data/csv/headers/empty_3.csv')
-- bwc_tag:end_query

select columns[1].name,columns[2].name,columns[3].name,columns[4].name,columns[5].name
from sniff_csv('data/csv/headers/empty_4.csv')
-- bwc_tag:end_query

