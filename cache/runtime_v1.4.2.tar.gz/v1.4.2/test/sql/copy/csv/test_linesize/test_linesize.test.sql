-- bwc_tag:nb_steps=2
-- bwc_tag:skip_query
pragma enable_verification;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

FROM read_csv('data/csv/15473.csv', max_line_size = 10)
-- bwc_tag:end_query

