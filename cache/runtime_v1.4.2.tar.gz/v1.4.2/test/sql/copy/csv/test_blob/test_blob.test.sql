-- bwc_tag:nb_steps=12
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE blobs (b BYTEA);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY blobs FROM 'data/csv/test/blob.csv' (HEADER 0, AUTO_DETECT 0);
-- bwc_tag:end_query

SELECT b FROM blobs
-- bwc_tag:end_query

COPY blobs TO 'output/blob.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DELETE FROM blobs
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY blobs FROM 'output/blob.csv';
-- bwc_tag:end_query

SELECT b FROM blobs
-- bwc_tag:end_query

COPY blobs TO 'output/blob.csv' DELIMITER 'A' QUOTE 'B' ESCAPE 'C';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
DELETE FROM blobs
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
COPY blobs FROM 'output/blob.csv' (DELIMITER 'A', QUOTE 'B', ESCAPE 'C');
-- bwc_tag:end_query

SELECT b FROM blobs
-- bwc_tag:end_query

