-- bwc_tag:nb_steps=3
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

select columns FROM sniff_csv('data/csv/headers/escaped_quote.csv');
-- bwc_tag:end_query

select columns FROM sniff_csv('data/csv/headers/unescaped_quote.csv');
-- bwc_tag:end_query

