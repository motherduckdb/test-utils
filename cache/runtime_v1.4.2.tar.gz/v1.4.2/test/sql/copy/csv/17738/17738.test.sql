-- bwc_tag:nb_steps=5
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/17738_rn.csv',header=False,skip=3, delim = ';');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/17738.csv',header=False,skip=3);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/17738.csv',header=False,skip=4);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv('data/csv/17738.csv',header=False,skip=7);
-- bwc_tag:end_query

