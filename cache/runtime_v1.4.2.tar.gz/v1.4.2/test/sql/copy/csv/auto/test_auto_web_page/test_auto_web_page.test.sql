-- bwc_tag:nb_steps=6
-- bwc_tag:execute_from_sql
CREATE TABLE web_page AS SELECT * FROM read_csv_auto ('data/csv/real/web_page.csv');
-- bwc_tag:end_query

SELECT COUNT(*) FROM web_page;
-- bwc_tag:end_query

SELECT * FROM web_page ORDER BY column00 LIMIT 3;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
PRAGMA verify_parallelism
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
CREATE TABLE web_page2 AS SELECT * FROM read_csv_auto ('data/csv/real/web_page.csv');
-- bwc_tag:end_query

(SELECT * FROM web_page EXCEPT SELECT * FROM web_page2)
UNION ALL
(SELECT * FROM web_page2 EXCEPT SELECT * FROM web_page)
-- bwc_tag:end_query

