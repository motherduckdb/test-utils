-- bwc_tag:nb_steps=5
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT column1, column2, column3, parse_filename(filename) FROM read_csv('data/csv/filename_filter/*.csv', filename=true);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT column1, column2, column3, parse_filename(filename) FROM read_csv(['data/csv/filename_filter/a.csv','data/csv/filename_filter/b.csv','data/csv/filename_filter/c.csv','data/csv/filename_filter/d.csv'], filename=true) WHERE filename like '%d.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT column1, column2, column3, parse_filename(filename) FROM read_csv(['data/csv/filename_filter/a.csv','data/csv/filename_filter/b.csv','data/csv/filename_filter/c.csv','data/csv/filename_filter/d.csv'], filename=true, union_by_name=true) WHERE filename like '%d.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT column1, column2, column3, parse_filename(filename) FROM read_csv('data/csv/filename_filter/*.csv', filename=true, union_by_name=true) WHERE filename like '%d.csv';
-- bwc_tag:end_query

