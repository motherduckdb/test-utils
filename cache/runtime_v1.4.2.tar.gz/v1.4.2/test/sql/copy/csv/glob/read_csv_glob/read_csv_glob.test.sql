-- bwc_tag:nb_steps=42
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select typeof(#1),typeof(#2),typeof(#3),typeof(#4),typeof(#5) FROM read_csv('data/csv/per_thread/*.csv') limit 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select typeof(#1),typeof(#2),typeof(#3),typeof(#4),typeof(#5) FROM read_csv(['data/csv/per_thread/c1.csv', 'data/csv/per_thread/c2.csv']) limit 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
select typeof(#1),typeof(#2),typeof(#3),typeof(#4),typeof(#5) FROM read_csv(['data/csv/per_thread/c2.csv', 'data/csv/per_thread/c1.csv', 'data/csv/per_thread/c3.csv']) limit 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv('data/csv/glob/a?/*.csv') ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv('data/csv/glob/a?/a*.csv') ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv(['data/csv/glob/a1/a1.csv', 'data/csv/glob/a2/a2.csv']) ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv_auto(['data/csv/glob/a1/a1.csv', 'data/csv/glob/a2/a2.csv']) ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv(['data/csv/glob/a?/a*.csv', 'data/csv/glob/a?/a*.csv']) ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv('data/csv/*/a?/a*.csv') ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT a, b LIKE '%a1.csv%' FROM read_csv('data/csv/*/a?/a*.csv', filename=1) t1(a,b) ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT * FROM read_csv('data/csv/glob/*/*.csv') ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT * FROM read_csv('data/csv/glob/*/*.csv', columns=STRUCT_PACK(d := 'STRING')) ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
SELECT a, b LIKE '%a_.csv' FROM read_csv('data/csv/glob/*/*.csv', columns=STRUCT_PACK(d := 'STRING'), filename=1) t(a,b) ORDER BY 1
-- bwc_tag:end_query

SELECT COUNT(*) FROM glob('data/csv/glob/*/*.csv')
-- bwc_tag:end_query

SELECT COUNT(*) FROM glob(['data/csv/glob/*/*.csv'])
-- bwc_tag:end_query

SELECT COUNT(*) FROM glob(['data/csv/glob/*/*.csv', 'data/csv/glob/*/*.csv'])
-- bwc_tag:end_query

SELECT COUNT(*) FROM glob('data\csv\glob\*\*.csv')
-- bwc_tag:end_query

SELECT COUNT(*) FROM glob('data//csv///glob///*//////*.csv')
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT * FROM read_csv('data/csv/glob/*/a*a.csv') ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT * FROM read_csv(['data/csv/glob/*/a*a.csv']) ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT * FROM read_csv_auto(['data/csv/glob/*/a*a.csv']) ORDER BY 1
-- bwc_tag:end_query

SELECT COUNT(*) FROM glob('data/csv/glob/*/a*a.csv')
-- bwc_tag:end_query

select count(*) from glob('/rewoiarwiouw3rajkawrasdf790273489*.csv') limit 10;
-- bwc_tag:end_query

select count(*) from glob('~/rewoiarwiouw3rajkawrasdf790273489*.py') limit 10;
-- bwc_tag:end_query

set file_search_path='data/csv/glob';
-- bwc_tag:end_query

SELECT COUNT(*) FROM glob('*/*.csv');
-- bwc_tag:end_query

set file_search_path='data/csv/glob/a1,data/csv/glob/a2';
-- bwc_tag:end_query

SELECT COUNT(*) FROM glob('*.csv');
-- bwc_tag:end_query

set file_search_path='data/csv/glob,garbage';
-- bwc_tag:end_query

SELECT COUNT(*) FROM glob('*/*.csv');
-- bwc_tag:end_query

SELECT COUNT(*) FROM glob('csv/glob/*/*.csv');
-- bwc_tag:end_query

set file_search_path='';
-- bwc_tag:end_query

SELECT COUNT(*) FROM glob('data/csv/glob/*/*.csv');
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT * FROM read_csv_auto([]) ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT * FROM read_csv_auto([]::VARCHAR[]) ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT * FROM read_csv_auto(NULL) ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT * FROM read_csv_auto([NULL]) ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT * FROM read_csv_auto(NULL::VARCHAR) ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

SELECT * FROM read_csv_auto(NULL::VARCHAR[]) ORDER BY 1
-- bwc_tag:end_query

-- bwc_tag:skip_query
SET threads=1;
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
-- bwc_tag:expected_result=error

FROM read_csv('data/csv/glob/*/*.csv');
-- bwc_tag:end_query

