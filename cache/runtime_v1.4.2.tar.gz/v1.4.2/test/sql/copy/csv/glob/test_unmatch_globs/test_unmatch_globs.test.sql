-- bwc_tag:nb_steps=5
-- bwc_tag:skip_query
PRAGMA enable_verification
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM 'data/csv/glob_dif_dialect/14166/__200*.csv';
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv(['data/csv/glob_dif_dialect/14166/__2000.csv', 'data/csv/glob_dif_dialect/14166/__2001.csv', 'data/csv/glob_dif_dialect/14166/empty.csv']);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM read_csv(['data/csv/glob_dif_dialect/14166/__2000.csv','data/csv/glob_dif_dialect/14166/matching_types.csv']);
-- bwc_tag:end_query

-- bwc_tag:execute_from_sql
FROM 'data/csv/glob_dif_dialect/f_*.csv' order by all
-- bwc_tag:end_query

