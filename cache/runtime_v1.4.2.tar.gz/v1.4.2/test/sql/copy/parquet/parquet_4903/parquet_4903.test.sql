-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=2
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT type_param_constraints FROM 'data/parquet-testing/bug4903.parquet' limit 10
-- bwc_tag:end_query

