-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=53
LOAD 'parquet';
-- bwc_tag:end_query

copy (select (r1.range * 10)::TINYINT r from range(10) r1, range(1000) r2) to 'output/dict-TINYINT.parquet' (row_group_size 2048);
-- bwc_tag:end_query

select first(encodings) from parquet_metadata('output/dict-TINYINT.parquet') group by encodings;
-- bwc_tag:end_query

SELECT COUNT(*) from 'output/dict-TINYINT.parquet' WHERE r='20'
-- bwc_tag:end_query

select column_id, BOOL_AND(bloom_filter_offset > 4), BOOL_AND(bloom_filter_length > 1)  from parquet_metadata('output/dict-TINYINT.parquet') group by column_id order by column_id;
-- bwc_tag:end_query

copy (select (r1.range * 10)::SMALLINT r from range(10) r1, range(1000) r2) to 'output/dict-SMALLINT.parquet' (row_group_size 2048);
-- bwc_tag:end_query

select first(encodings) from parquet_metadata('output/dict-SMALLINT.parquet') group by encodings;
-- bwc_tag:end_query

SELECT COUNT(*) from 'output/dict-SMALLINT.parquet' WHERE r='20'
-- bwc_tag:end_query

select column_id, BOOL_AND(bloom_filter_offset > 4), BOOL_AND(bloom_filter_length > 1)  from parquet_metadata('output/dict-SMALLINT.parquet') group by column_id order by column_id;
-- bwc_tag:end_query

copy (select (r1.range * 10)::INTEGER r from range(10) r1, range(1000) r2) to 'output/dict-INTEGER.parquet' (row_group_size 2048);
-- bwc_tag:end_query

select first(encodings) from parquet_metadata('output/dict-INTEGER.parquet') group by encodings;
-- bwc_tag:end_query

SELECT COUNT(*) from 'output/dict-INTEGER.parquet' WHERE r='20'
-- bwc_tag:end_query

select column_id, BOOL_AND(bloom_filter_offset > 4), BOOL_AND(bloom_filter_length > 1)  from parquet_metadata('output/dict-INTEGER.parquet') group by column_id order by column_id;
-- bwc_tag:end_query

copy (select (r1.range * 10)::BIGINT r from range(10) r1, range(1000) r2) to 'output/dict-BIGINT.parquet' (row_group_size 2048);
-- bwc_tag:end_query

select first(encodings) from parquet_metadata('output/dict-BIGINT.parquet') group by encodings;
-- bwc_tag:end_query

SELECT COUNT(*) from 'output/dict-BIGINT.parquet' WHERE r='20'
-- bwc_tag:end_query

select column_id, BOOL_AND(bloom_filter_offset > 4), BOOL_AND(bloom_filter_length > 1)  from parquet_metadata('output/dict-BIGINT.parquet') group by column_id order by column_id;
-- bwc_tag:end_query

copy (select (r1.range * 10)::HUGEINT r from range(10) r1, range(1000) r2) to 'output/dict-HUGEINT.parquet' (row_group_size 2048);
-- bwc_tag:end_query

select first(encodings) from parquet_metadata('output/dict-HUGEINT.parquet') group by encodings;
-- bwc_tag:end_query

SELECT COUNT(*) from 'output/dict-HUGEINT.parquet' WHERE r='20'
-- bwc_tag:end_query

select column_id, BOOL_AND(bloom_filter_offset > 4), BOOL_AND(bloom_filter_length > 1)  from parquet_metadata('output/dict-HUGEINT.parquet') group by column_id order by column_id;
-- bwc_tag:end_query

copy (select (r1.range * 10)::UTINYINT r from range(10) r1, range(1000) r2) to 'output/dict-UTINYINT.parquet' (row_group_size 2048);
-- bwc_tag:end_query

select first(encodings) from parquet_metadata('output/dict-UTINYINT.parquet') group by encodings;
-- bwc_tag:end_query

SELECT COUNT(*) from 'output/dict-UTINYINT.parquet' WHERE r='20'
-- bwc_tag:end_query

select column_id, BOOL_AND(bloom_filter_offset > 4), BOOL_AND(bloom_filter_length > 1)  from parquet_metadata('output/dict-UTINYINT.parquet') group by column_id order by column_id;
-- bwc_tag:end_query

copy (select (r1.range * 10)::USMALLINT r from range(10) r1, range(1000) r2) to 'output/dict-USMALLINT.parquet' (row_group_size 2048);
-- bwc_tag:end_query

select first(encodings) from parquet_metadata('output/dict-USMALLINT.parquet') group by encodings;
-- bwc_tag:end_query

SELECT COUNT(*) from 'output/dict-USMALLINT.parquet' WHERE r='20'
-- bwc_tag:end_query

select column_id, BOOL_AND(bloom_filter_offset > 4), BOOL_AND(bloom_filter_length > 1)  from parquet_metadata('output/dict-USMALLINT.parquet') group by column_id order by column_id;
-- bwc_tag:end_query

copy (select (r1.range * 10)::UINTEGER r from range(10) r1, range(1000) r2) to 'output/dict-UINTEGER.parquet' (row_group_size 2048);
-- bwc_tag:end_query

select first(encodings) from parquet_metadata('output/dict-UINTEGER.parquet') group by encodings;
-- bwc_tag:end_query

SELECT COUNT(*) from 'output/dict-UINTEGER.parquet' WHERE r='20'
-- bwc_tag:end_query

select column_id, BOOL_AND(bloom_filter_offset > 4), BOOL_AND(bloom_filter_length > 1)  from parquet_metadata('output/dict-UINTEGER.parquet') group by column_id order by column_id;
-- bwc_tag:end_query

copy (select (r1.range * 10)::UBIGINT r from range(10) r1, range(1000) r2) to 'output/dict-UBIGINT.parquet' (row_group_size 2048);
-- bwc_tag:end_query

select first(encodings) from parquet_metadata('output/dict-UBIGINT.parquet') group by encodings;
-- bwc_tag:end_query

SELECT COUNT(*) from 'output/dict-UBIGINT.parquet' WHERE r='20'
-- bwc_tag:end_query

select column_id, BOOL_AND(bloom_filter_offset > 4), BOOL_AND(bloom_filter_length > 1)  from parquet_metadata('output/dict-UBIGINT.parquet') group by column_id order by column_id;
-- bwc_tag:end_query

copy (select (r1.range * 10)::UHUGEINT r from range(10) r1, range(1000) r2) to 'output/dict-UHUGEINT.parquet' (row_group_size 2048);
-- bwc_tag:end_query

select first(encodings) from parquet_metadata('output/dict-UHUGEINT.parquet') group by encodings;
-- bwc_tag:end_query

SELECT COUNT(*) from 'output/dict-UHUGEINT.parquet' WHERE r='20'
-- bwc_tag:end_query

select column_id, BOOL_AND(bloom_filter_offset > 4), BOOL_AND(bloom_filter_length > 1)  from parquet_metadata('output/dict-UHUGEINT.parquet') group by column_id order by column_id;
-- bwc_tag:end_query

copy (select (r1.range * 10)::FLOAT r from range(10) r1, range(1000) r2) to 'output/dict-FLOAT.parquet' (row_group_size 2048);
-- bwc_tag:end_query

select first(encodings) from parquet_metadata('output/dict-FLOAT.parquet') group by encodings;
-- bwc_tag:end_query

SELECT COUNT(*) from 'output/dict-FLOAT.parquet' WHERE r='20'
-- bwc_tag:end_query

select column_id, BOOL_AND(bloom_filter_offset > 4), BOOL_AND(bloom_filter_length > 1)  from parquet_metadata('output/dict-FLOAT.parquet') group by column_id order by column_id;
-- bwc_tag:end_query

copy (select (r1.range * 10)::DOUBLE r from range(10) r1, range(1000) r2) to 'output/dict-DOUBLE.parquet' (row_group_size 2048);
-- bwc_tag:end_query

select first(encodings) from parquet_metadata('output/dict-DOUBLE.parquet') group by encodings;
-- bwc_tag:end_query

SELECT COUNT(*) from 'output/dict-DOUBLE.parquet' WHERE r='20'
-- bwc_tag:end_query

select column_id, BOOL_AND(bloom_filter_offset > 4), BOOL_AND(bloom_filter_length > 1)  from parquet_metadata('output/dict-DOUBLE.parquet') group by column_id order by column_id;
-- bwc_tag:end_query

copy (select (r1.range * 10)::VARCHAR r from range(10) r1, range(1000) r2) to 'output/dict-VARCHAR.parquet' (row_group_size 2048);
-- bwc_tag:end_query

select first(encodings) from parquet_metadata('output/dict-VARCHAR.parquet') group by encodings;
-- bwc_tag:end_query

SELECT COUNT(*) from 'output/dict-VARCHAR.parquet' WHERE r='20'
-- bwc_tag:end_query

select column_id, BOOL_AND(bloom_filter_offset > 4), BOOL_AND(bloom_filter_length > 1)  from parquet_metadata('output/dict-VARCHAR.parquet') group by column_id order by column_id;
-- bwc_tag:end_query

