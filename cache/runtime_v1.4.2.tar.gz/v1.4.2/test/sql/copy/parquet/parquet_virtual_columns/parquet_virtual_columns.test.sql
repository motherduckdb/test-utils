-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=8
LOAD 'parquet';
-- bwc_tag:end_query

SELECT file_index FROM 'data/parquet-testing/glob/t1.parquet'
-- bwc_tag:end_query

SELECT file_index, i, j FROM read_parquet(['data/parquet-testing/glob/t1.parquet', 'data/parquet-testing/glob/t2.parquet', 'data/parquet-testing/glob2/t1.parquet'])
-- bwc_tag:end_query

SELECT file_index, i, j
FROM read_parquet(['data/parquet-testing/glob/t1.parquet', 'data/parquet-testing/glob/t2.parquet', 'data/parquet-testing/glob2/t1.parquet'])
WHERE file_index=1
-- bwc_tag:end_query

select filename from 'data/parquet-testing/glob/t1.parquet'
-- bwc_tag:end_query

select i, j, parse_path(filename)[-2:] from 'data/parquet-testing/glob*/t?.parquet' order by i;
-- bwc_tag:end_query

select * from 'data/parquet-testing/glob*/t?.parquet' order by i;
-- bwc_tag:end_query

select i, j, parse_path(filename)[-2:] from 'data/parquet-testing/glob*/t?.parquet' where filename='data/parquet-testing/glob/t1.parquet'
-- bwc_tag:end_query

