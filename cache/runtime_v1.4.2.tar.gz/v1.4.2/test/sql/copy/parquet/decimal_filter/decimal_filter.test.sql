-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=11
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:skip_query
pragma enable_verification
-- bwc_tag:end_query

select * from 'data/parquet-testing/decimals.parquet'
-- bwc_tag:end_query

select * from 'data/parquet-testing/decimals.parquet' WHERE l1=0.1
-- bwc_tag:end_query

select * from 'data/parquet-testing/decimals.parquet' WHERE l1=-0.1
-- bwc_tag:end_query

select * from 'data/parquet-testing/decimals.parquet' WHERE l2=0.1
-- bwc_tag:end_query

select * from 'data/parquet-testing/decimals.parquet' WHERE l2=-0.1
-- bwc_tag:end_query

select * from 'data/parquet-testing/decimals.parquet' WHERE l3=0.1
-- bwc_tag:end_query

select * from 'data/parquet-testing/decimals.parquet' WHERE l3=-0.1
-- bwc_tag:end_query

select * from 'data/parquet-testing/decimals.parquet' WHERE l4=0.1
-- bwc_tag:end_query

select * from 'data/parquet-testing/decimals.parquet' WHERE l4=-0.1
-- bwc_tag:end_query

