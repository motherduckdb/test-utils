-- bwc_tag:needed_extensions=parquet
-- bwc_tag:nb_steps=3
LOAD 'parquet';
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

copy (select 42) to 'file.parquet' (partition_b (a));
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

copy (select 42) to 'file.csv' (partition_b (a));
-- bwc_tag:end_query

