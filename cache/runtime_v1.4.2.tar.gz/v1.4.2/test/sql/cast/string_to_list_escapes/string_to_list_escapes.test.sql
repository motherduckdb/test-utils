-- bwc_tag:nb_steps=51
SELECT $$[hello, world]$$::VARCHAR[];
-- bwc_tag:end_query

SELECT $$["hello\ world", world]$$::VARCHAR[];
-- bwc_tag:end_query

SELECT $$[hello\ world, world]$$::VARCHAR[];
-- bwc_tag:end_query

SELECT $$[hello\,world, test]$$::VARCHAR[];
-- bwc_tag:end_query

SELECT $$["hello\,world", test]$$::VARCHAR[];
-- bwc_tag:end_query

SELECT $$["hello\,", test]$$::VARCHAR[];
-- bwc_tag:end_query

SELECT $$[hello\,, test]$$::VARCHAR[];
-- bwc_tag:end_query

SELECT $$['']$$::VARCHAR[] a, a::VARCHAR::VARCHAR[] b, a == b;
-- bwc_tag:end_query

SELECT $$[hello\"quoted\"text, more]$$::VARCHAR[];
-- bwc_tag:end_query

SELECT $$[escaped\\backslash, test]$$::VARCHAR[];
-- bwc_tag:end_query

SELECT $$["escaped\\backslash", test]$$::VARCHAR[];
-- bwc_tag:end_query

SELECT $$[nested[brackets], test]$$::VARCHAR[];
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT $$[nested[bracket, test]$$::VARCHAR[];
-- bwc_tag:end_query

SELECT $$[nested"["bracket, test]$$::VARCHAR[];
-- bwc_tag:end_query

SELECT $$[quote\'in\'string, test]$$::VARCHAR[];
-- bwc_tag:end_query

SELECT $$[mix\ of\ special\,chars]$$::VARCHAR[];
-- bwc_tag:end_query

SELECT $$["mix\ of\ special\,chars"]$$::VARCHAR[];
-- bwc_tag:end_query

SELECT $$["mix\ of\ special\,"chars]$$::VARCHAR[];
-- bwc_tag:end_query

SELECT $$["ends with space ", "trailing space "]$$::VARCHAR[];
-- bwc_tag:end_query

SELECT $$["ends with comma,", "another,"]$$::VARCHAR[];
-- bwc_tag:end_query

SELECT $$["quote at end\"", "\""]$$::VARCHAR[];
-- bwc_tag:end_query

SELECT $$["ends with bracket]", "[bracket"]$$::VARCHAR[];
-- bwc_tag:end_query

SELECT $$["backslash at end\\", "\\"]$$::VARCHAR[];
-- bwc_tag:end_query

SELECT $$[" space at start", " leading space"]$$::VARCHAR[];
-- bwc_tag:end_query

SELECT $$[",comma at start", ",leading comma"]$$::VARCHAR[];
-- bwc_tag:end_query

SELECT $$["\"quote at start", "\"leading quote"]$$::VARCHAR[];
-- bwc_tag:end_query

SELECT $$["[bracket at start", "[leading bracket"]$$::VARCHAR[];
-- bwc_tag:end_query

SELECT $$["\\backslash at start", "\\leading backslash"]$$::VARCHAR[];
-- bwc_tag:end_query

SELECT $$[" space at start and end ", " leading and trailing space "]$$::VARCHAR[];
-- bwc_tag:end_query

SELECT $$[",comma at start and end,", ",leading and trailing comma,"]$$::VARCHAR[];
-- bwc_tag:end_query

SELECT $$["\"quote at start and end\"", "\"leading and trailing quote\""]$$::VARCHAR[];
-- bwc_tag:end_query

SELECT $$["[bracket at start and end]", "[leading and trailing bracket]"]$$::VARCHAR[];
-- bwc_tag:end_query

SELECT $$["\\backslash at start and end\\", "\\leading and trailing backslash\\"]$$::VARCHAR[];
-- bwc_tag:end_query

SELECT $$[" mix, of special\ characters " , "[various] \"combinations\" "]$$::VARCHAR[];
-- bwc_tag:end_query

SELECT $$[", starts and ends with ,", "[brackets] and ,commas,"]$$::VARCHAR[];
-- bwc_tag:end_query

SELECT $$["\"quotes\" and \ spaces ", "\ leading and trailing \ "]$$::VARCHAR[];
-- bwc_tag:end_query

SELECT $$["[complex\ combination, of\" special]", "\\all cases covered\\"]$$::VARCHAR[];
-- bwc_tag:end_query

SELECT $$["hello, world"]$$::VARCHAR[];
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT $$["missing quote]]$$::VARCHAR[]; -- Mismatched quotes
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT $$["backslash at end\"]$$::VARCHAR[]; -- Improper escaping
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT $$[unescaped[bracket]$$::VARCHAR[]; -- Unescaped bracket
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT $$[unterminated string]"]$$::VARCHAR[];
-- bwc_tag:end_query

SELECT $$[]$$::VARCHAR[];  -- Empty list
-- bwc_tag:end_query

SELECT $$[""]$$::VARCHAR[]; -- List with empty string
-- bwc_tag:end_query

SELECT $$[" "]$$::VARCHAR[]; -- List with whitespace string
-- bwc_tag:end_query

SELECT $$["\\"]$$::VARCHAR[]; -- List with only a backslash
-- bwc_tag:end_query

SELECT $$["\""]$$::VARCHAR[]; -- List with only a quote
-- bwc_tag:end_query

SELECT $$[\,]$$::VARCHAR[]; -- List with only a comma (not quoted)
-- bwc_tag:end_query

SELECT $$["\,"]$$::VARCHAR[]; -- List with only a comma
-- bwc_tag:end_query

SELECT $$[","]$$::VARCHAR[]; -- List with only a comma
-- bwc_tag:end_query

select $$[NULL, 'null', 'nUlL', NuLl, "NULLz", "NULL"]$$::VARCHAR[] a, a::VARCHAR::VARCHAR[] b, a == b
-- bwc_tag:end_query

