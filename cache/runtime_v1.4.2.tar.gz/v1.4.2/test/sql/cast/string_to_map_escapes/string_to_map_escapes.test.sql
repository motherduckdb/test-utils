-- bwc_tag:nb_steps=25
SELECT $${"key\ with\ space" = "value\ with\ space"}$$::MAP(VARCHAR, VARCHAR);
-- bwc_tag:end_query

SELECT $${\"key\" = \"value\"}$$::MAP(VARCHAR, VARCHAR);
-- bwc_tag:end_query

SELECT $${"key\ with\ backslash" = "value\ with\ backslash"}$$::MAP(VARCHAR, VARCHAR);
-- bwc_tag:end_query

SELECT $${"key\ with\, comma" = "value\ with\, comma"}$$::MAP(VARCHAR, VARCHAR);
-- bwc_tag:end_query

SELECT $${"key\ with\ colon\:" = "value\ with\ colon\:"}$$::MAP(VARCHAR, VARCHAR);
-- bwc_tag:end_query

SELECT $${key with space = value with space}$$::MAP(VARCHAR, VARCHAR);
-- bwc_tag:end_query

SELECT $${key"with"quote = value}$$::MAP(VARCHAR, VARCHAR);
-- bwc_tag:end_query

SELECT $${key = value"with"quote}$$::MAP(VARCHAR, VARCHAR);
-- bwc_tag:end_query

SELECT $${key,with,comma = value}$$::MAP(VARCHAR, VARCHAR);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT $${key = value,with,comma}$$::MAP(VARCHAR, VARCHAR);
-- bwc_tag:end_query

SELECT $${key{with}bracket = value}$$::MAP(VARCHAR, VARCHAR);
-- bwc_tag:end_query

SELECT $${key = value{with}bracket}$$::MAP(VARCHAR, VARCHAR);
-- bwc_tag:end_query

SELECT $${"key\with\backslash" = value}$$::MAP(VARCHAR, VARCHAR);
-- bwc_tag:end_query

SELECT $${key = "value\with\backslash"}$$::MAP(VARCHAR, VARCHAR);
-- bwc_tag:end_query

SELECT $${key=with=equals = value}$$::MAP(VARCHAR, VARCHAR) a, a['key'];
-- bwc_tag:end_query

SELECT $${"key\=with" = equals = value}$$::MAP(VARCHAR, VARCHAR) a, a['key=with'];
-- bwc_tag:end_query

SELECT $${"key\=with\=equals" = value}$$::MAP(VARCHAR, VARCHAR) a, a['key=with=equals'];
-- bwc_tag:end_query

SELECT $${}$$::MAP(VARCHAR, VARCHAR);
-- bwc_tag:end_query

SELECT $${=}$$::MAP(VARCHAR, VARCHAR);
-- bwc_tag:end_query

-- bwc_tag:expected_result=error

SELECT $${\{escaped\brace\} = \}escaped\brace\\}$$::MAP(VARCHAR, VARCHAR);
-- bwc_tag:end_query

SELECT $${"\{escaped\brace\}" = "\}escaped\brace\\"}$$::MAP(VARCHAR, VARCHAR);
-- bwc_tag:end_query

SELECT $${key=}$$::MAP(VARCHAR, VARCHAR);
-- bwc_tag:end_query

SELECT $${=value}$$::MAP(VARCHAR, VARCHAR);
-- bwc_tag:end_query

select $${'NULL'=true}$$::MAP(VARCHAR, VARCHAR) a, a::VARCHAR::MAP(VARCHAR, VARCHAR) b, a == b
-- bwc_tag:end_query

select $${'a'='NULL'}$$::MAP(VARCHAR, VARCHAR) a, a::VARCHAR::MAP(VARCHAR, VARCHAR) b, a == b
-- bwc_tag:end_query

